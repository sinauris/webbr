$url=$args[0]
$url=$url.Remove(0,6)
$url=$url.TrimEnd("/")
enter-pssession -computername $url