create PACKAGE BODY np_tmp_session_pkg
AS
    FUNCTION get_allow_triggers
    RETURN NUMBER
    IS
    BEGIN
      RETURN allow_triggers;
    END;

    PROCEDURE set_allow_triggers(v IN NUMBER)
    AS
    BEGIN
      allow_triggers:=v;
    END;
END;

/

