create TYPE t_offline_table AS TABLE OF t_offline
/

