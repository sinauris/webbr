create FUNCTION ToStr(v IN number) RETURN VARCHAR2 IS
            BEGIN
                RETURN to_char(v);
            END;
/

