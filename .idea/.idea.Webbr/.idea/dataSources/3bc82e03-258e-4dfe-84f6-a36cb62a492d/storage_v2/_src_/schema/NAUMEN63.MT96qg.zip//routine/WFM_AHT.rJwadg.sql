create function wfm_aht(start_time timestamp, stop_time timestamp) return wfm_aht_tp_tab
pipelined
is 
line wfm_aht_tp := wfm_aht_tp(null, null, null, null);
begin
    for i in 
       (
          with handlings as
            (select *
             from table(wfm_handlings(start_time, stop_time, NUMTODSINTERVAL(3, 'hour')))
            )
          
          , intervals as
            (select
                s as dt_from
              , f as dt_till
             from table(intervalize(start_time, stop_time, 'MI', 15))
            )
          
          , durations as
            (select
                intervals.dt_from as zn_tm
              , handlings.project_uuid
              , handlings.session_id
              , least(intervals.dt_till, handlings.handling_till) 
                - greatest(intervals.dt_from ,handlings.handling_from) as duration
             from intervals
                  inner join handlings 
                           on  (handlings.handling_from < intervals.dt_till
                           and handlings.handling_from >= intervals.dt_from)
            )
          
          , preaggregated as
            (select
                durations.zn_tm
              , durations.project_uuid
              , count(distinct durations.session_id) as value
              , round(avg(intervaltosec(durations.duration))) as aht
            from durations
            group by
               durations.zn_tm
             , durations.project_uuid
            )
          
          select
             preaggregated.zn_tm as zn_tm
          , preaggregated.project_uuid as project_id
          , preaggregated.value as value
          , preaggregated.aht as aht
          from preaggregated
          order by  
             preaggregated.project_uuid
           , preaggregated.zn_tm       
       )
       loop
           line := wfm_aht_tp(i.zn_tm, i.project_id, i.value, i.aht);
           pipe row(line);
       end loop;
    return;
end;
/

