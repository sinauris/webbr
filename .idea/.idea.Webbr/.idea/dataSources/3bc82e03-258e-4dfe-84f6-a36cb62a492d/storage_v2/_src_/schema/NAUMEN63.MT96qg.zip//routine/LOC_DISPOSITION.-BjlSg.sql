create FUNCTION LOC_DISPOSITION(dispositionTitle varchar, reason_treat varchar, final_stage varchar, cpd_result varchar, connected timestamp)
                RETURN VARCHAR2 IS
            BEGIN
                RETURN (CASE
                    WHEN dispositionTitle IS NOT NULL
                      THEN dispositionTitle
                    WHEN reason_treat IS NOT NULL
                      THEN ':adhoc-basereport.report.dialing_results.result_values.' || reason_treat || ':'
                    WHEN final_stage in ('ivr', 'queue')
                      THEN ':adhoc-basereport.report.dialing_results.result_values.gone:'
                    WHEN  connected IS NOT NULL AND (cpd_result IS NULL OR cpd_result = 'Unknown')
                      THEN ':adhoc-basereport.report.dialing_results.result_values.connect:'
                    ELSE ':adhoc-basereport.report.dialing_results.result_values.failure:'
                  END);
            END;
/

