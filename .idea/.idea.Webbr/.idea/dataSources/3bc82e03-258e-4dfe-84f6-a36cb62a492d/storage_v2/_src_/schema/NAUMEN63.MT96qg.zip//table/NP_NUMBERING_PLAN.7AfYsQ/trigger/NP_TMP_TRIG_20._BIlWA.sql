create trigger NP_TMP_TRIG_20
  after insert or update or delete
  on NP_NUMBERING_PLAN
  for each row
  BEGIN
  IF np_tmp_session_pkg.get_allow_triggers = 1 THEN
      IF :o.id IS NOT NULL THEN
         INSERT INTO np_tmp_trigdata VALUES(np_tmp_trigdata_id_gen.nextval, 'np_numbering_plan', :o.id);
      END IF;
      IF :n.id IS NOT NULL AND (:o.id IS NULL OR :n.id <> :o.id) THEN
         INSERT INTO np_tmp_trigdata VALUES(np_tmp_trigdata_id_gen.nextval, 'np_numbering_plan', :n.id);
      END IF;
      DBMS_ALERT.SIGNAL('np_tmp_trigger_alert', '');
  END IF;
END;

/

