create view RECORD_SEANCES as
  SELECT
  rec.session_id,
  cl1.src_abonent as operator_login,
  cl2.dst_id as remote_phone,
  cl1.created as call_time,
  cast('out' as VARCHAR(10)) as direction,
  rec.record_length as record_len,
  rec.filename as file_name
FROM
  records40 rec,
  audio_links al,
  call_legs cl1,
  call_legs cl2
WHERE
  cl1.id = al.src_leg and
  cl2.id = al.dst_leg and
  rec.session_id = cl1.session_id and
  rec.session_id = cl2.session_id and
  al.src_leg < al.dst_leg and
  cl1.incoming = '1' and
  cl1.src_abonent is not null
UNION
SELECT
  rec.session_id,
  cl2.dst_abonent as operator_login,
  cl1.src_id as remote_phone,
  cl1.created as call_time,
  cast('in' as VARCHAR(10)) as direction,
  rec.record_length as record_len,
  rec.filename as file_name
FROM
  records40 rec,
  audio_links al,
  call_legs cl1,
  call_legs cl2
WHERE
  cl1.id = al.src_leg and
  cl2.id = al.dst_leg and
  rec.session_id = cl1.session_id and
  rec.session_id = cl2.session_id and
  al.src_leg < al.dst_leg and
  cl2.incoming = '0' and
  cl2.dst_abonent is not null
/

