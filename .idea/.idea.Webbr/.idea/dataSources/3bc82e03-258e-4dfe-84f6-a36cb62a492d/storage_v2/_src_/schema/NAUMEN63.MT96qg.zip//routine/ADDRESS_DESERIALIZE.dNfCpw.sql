create FUNCTION ADDRESS_DESERIALIZE(str IN varchar2, ordinal IN number, prefix IN number) RETURN VARCHAR IS
                token VARCHAR2(64);
            BEGIN
              token := REGEXP_SUBSTR(str, '^([^;]*;){8}\$');
              IF token is null THEN RETURN null; END IF;
              token := REGEXP_SUBSTR(str, '([^;]*)', 1, ordinal);
              IF token is null THEN RETURN null; END IF;
              RETURN SUBSTR(token, prefix);
            END;
/

