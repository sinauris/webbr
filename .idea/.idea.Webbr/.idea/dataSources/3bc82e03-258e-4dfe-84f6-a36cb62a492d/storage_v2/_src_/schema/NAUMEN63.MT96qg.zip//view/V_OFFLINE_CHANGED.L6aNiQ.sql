create view V_OFFLINE_CHANGED as
  select
  to_date(to_char(ENTERED, 'yyyy-mm-dd'),'yyyy-mm-dd') as CHANGE_DATE,
  ENTERED as CHANGE_TIME,
  LOGIN as LOGIN,
  'in' as DIRECTION
  from V_STATUS_CHANGES
  where STATUS = 'offline' and COALESCE(REASON, CHR(0)) != 'set callplan'
union all
select
  to_date(to_char(cast(ENTERED + DURATION / 86400 as timestamp), 'yyyy-mm-dd'),'yyyy-mm-dd') as CHANGE_DATE,
  cast(ENTERED + DURATION / 86400 as timestamp) as CHANGE_TIME,
  LOGIN as LOGIN,
  'out' as DIRECTION
  from STATUS_CHANGES
  where STATUS = 'offline' and COALESCE(REASON, CHR(0)) != 'set callplan'
/

