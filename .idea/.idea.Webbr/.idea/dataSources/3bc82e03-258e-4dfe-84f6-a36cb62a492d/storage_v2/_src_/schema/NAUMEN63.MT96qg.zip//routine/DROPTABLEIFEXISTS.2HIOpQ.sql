create PROCEDURE dropTableIfExists (table_name IN VARCHAR2) IS
    sql_string VARCHAR2(1024);
BEGIN
    sql_string := 'DROP TABLE ' || table_name; 
    EXECUTE IMMEDIATE sql_string;
EXCEPTION
    WHEN OTHERS THEN
    IF SQLCODE <> -942 THEN
      RAISE;
    END IF;
    dbms_output.put_line('NOTICE:  table ' || table_name || ' does not exist, skipping');
END dropTableIfExists;
/

