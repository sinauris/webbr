create type wfm_states_tp
AS OBJECT 
(
  oper_id varchar2(32),
  time_from timestamp,
  time_to timestamp,
  state varchar2(32)  
);
/

