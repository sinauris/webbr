create view GROUPS as
  SELECT DISTINCT abonents.id, abonents.login, abonents.name 
FROM abonents_hier LEFT OUTER JOIN abonents ON abonents.id = abonents_hier.parent
/

