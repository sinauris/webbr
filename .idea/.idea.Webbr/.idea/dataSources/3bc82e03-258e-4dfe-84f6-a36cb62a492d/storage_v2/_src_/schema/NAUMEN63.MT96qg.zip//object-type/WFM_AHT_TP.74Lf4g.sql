create type wfm_aht_tp
AS OBJECT 
(
    zn_tm timestamp,
    project_uuid varchar2(32),
    value integer,
    aht integer
);
/

