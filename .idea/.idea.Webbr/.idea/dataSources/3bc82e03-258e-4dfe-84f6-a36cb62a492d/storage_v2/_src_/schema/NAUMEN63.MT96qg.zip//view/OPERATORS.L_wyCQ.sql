create view OPERATORS as
  SELECT abonents.id, abonents.login, abonents.name 
FROM abonents LEFT OUTER JOIN abonents_hier ON abonents.id = abonents_hier.parent 
WHERE abonents_hier.parent IS NULL
/

