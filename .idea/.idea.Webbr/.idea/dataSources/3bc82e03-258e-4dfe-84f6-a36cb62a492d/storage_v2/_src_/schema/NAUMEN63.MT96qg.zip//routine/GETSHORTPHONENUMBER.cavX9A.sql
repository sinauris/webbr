create FUNCTION GetShortPhoneNumber(phone IN VARCHAR2, nlen IN NUMBER) RETURN VARCHAR2 AS BEGIN DECLARE   len INTEGER;   BEGIN   len:=length(phone);   IF (len > nlen) THEN RETURN substr(phone, len - nlen + 1, nlen); END IF;     RETURN phone;   END; END;
/

