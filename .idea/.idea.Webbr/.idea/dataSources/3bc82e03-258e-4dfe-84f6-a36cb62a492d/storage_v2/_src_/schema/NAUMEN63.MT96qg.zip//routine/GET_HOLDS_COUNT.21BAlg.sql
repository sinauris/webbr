create Function GET_HOLDS_COUNT ( sess in varchar2, oper in varchar2 ) Return Number is
            CNT NUMBER;
            Begin
               select nvl(count(*),0) into CNT
                from call_status
                where session_id = sess
                and initiator_id = oper;
                Return(CNT);
            END;
/

