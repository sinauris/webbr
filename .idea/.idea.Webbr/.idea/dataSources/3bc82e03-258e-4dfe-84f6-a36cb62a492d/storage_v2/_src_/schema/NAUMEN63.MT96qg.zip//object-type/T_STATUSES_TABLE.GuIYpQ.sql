create type t_statuses_table as table of t_statuses
/

