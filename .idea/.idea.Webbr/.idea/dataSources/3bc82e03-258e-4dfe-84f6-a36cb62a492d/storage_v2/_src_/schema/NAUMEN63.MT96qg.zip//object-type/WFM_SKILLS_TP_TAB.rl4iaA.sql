create TYPE wfm_skills_tp_tab AS TABLE OF wfm_skills_tp;
/

