create TYPE wfm_handlings_tp_tab AS TABLE OF wfm_handlings_tp;
/

