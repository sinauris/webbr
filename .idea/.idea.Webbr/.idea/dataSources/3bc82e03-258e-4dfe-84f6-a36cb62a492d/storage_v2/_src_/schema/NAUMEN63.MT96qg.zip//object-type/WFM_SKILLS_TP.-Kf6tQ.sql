create type wfm_skills_tp
AS OBJECT 
(
  oper_id varchar2(32),
  project_id varchar2(32)  
);
/

