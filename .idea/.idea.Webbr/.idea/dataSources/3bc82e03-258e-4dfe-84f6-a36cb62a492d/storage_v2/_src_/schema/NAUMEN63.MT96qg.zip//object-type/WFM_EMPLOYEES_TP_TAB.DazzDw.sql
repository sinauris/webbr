create TYPE wfm_employees_tp_tab AS TABLE OF wfm_employees_tp;
/

