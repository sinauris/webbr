create type t_queue_len
 as object(
PROJECT_ID VARCHAR2(100),
CHANGED TIMESTAMP,
AMOUNT NUMBER)
/

