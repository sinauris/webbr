create TYPE wfm_aht_tp_tab AS TABLE OF wfm_aht_tp;
/

