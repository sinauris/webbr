create function p_statuses_duration_per_date(START_TIME in DATE, STOP_TIME in DATE, START_WINDOW CHAR default '00:00', STOP_WINDOW CHAR default '23:59')
return t_statuses_table
PIPELINED
is
line t_statuses:=t_statuses(null,null,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
CT DATE:=null;
begin
  CT := START_TIME;
  while CT < STOP_TIME
    loop
      for i in
      (
         select
            LOGIN,
            ACCIDENT,
            AVAILABLE,
            AWAY,
            AWAY_DINNER,
            AWAY_TECHNICALBREAK,
            AWAY_CUSTOM_REASON1,
            AWAY_CUSTOM_REASON2,
            AWAY_CUSTOM_REASON3,
            AWAY_CUSTOM_REASON4,
            AWAY_CUSTOM_REASON5,
            AWAY_CUSTOM_REASON6,
            AWAY_CUSTOM_REASON7,
            AWAY_CUSTOM_REASON8,
            AWAY_CUSTOM_REASON9,
            AWAY_CUSTOM_REASON10,
            CUSTOM1,
            CUSTOM2,
            CUSTOM3,
            DND,
            NORMAL,
            NOTAVAILABLE,
            OFF,
            REDIRECT,
            RINGING,
            SPEAKING,
            STANDOFF,
            WRAPUP
            from table(p_statuses_duration(windowtotimestamp(CT,START_WINDOW),windowtotimestamp(CT,STOP_WINDOW)))
      )
      loop
        line := t_statuses(CT, i.LOGIN, i.ACCIDENT, i.AVAILABLE, i.AWAY, i.AWAY_DINNER, i.AWAY_TECHNICALBREAK, i.AWAY_CUSTOM_REASON1, i.AWAY_CUSTOM_REASON2, i.AWAY_CUSTOM_REASON3, i.AWAY_CUSTOM_REASON4, i.AWAY_CUSTOM_REASON5, i.AWAY_CUSTOM_REASON6, i.AWAY_CUSTOM_REASON7, i.AWAY_CUSTOM_REASON8, i.AWAY_CUSTOM_REASON9, i.AWAY_CUSTOM_REASON10, i.CUSTOM1, i.CUSTOM2, i.CUSTOM3, i.DND, i.NORMAL, i.NOTAVAILABLE, i.OFF, i.REDIRECT, i.RINGING, i.SPEAKING, i.STANDOFF, i.WRAPUP);
        pipe row(line);
      end loop;
      CT := CT + 1;
    end loop;
  return;
end;
/

