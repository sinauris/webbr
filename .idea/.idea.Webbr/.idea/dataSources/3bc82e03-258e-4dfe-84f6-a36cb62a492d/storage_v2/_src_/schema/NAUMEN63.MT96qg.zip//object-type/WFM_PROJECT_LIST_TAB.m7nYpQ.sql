create TYPE wfm_project_list_tab AS TABLE OF wfm_project_list;
/

