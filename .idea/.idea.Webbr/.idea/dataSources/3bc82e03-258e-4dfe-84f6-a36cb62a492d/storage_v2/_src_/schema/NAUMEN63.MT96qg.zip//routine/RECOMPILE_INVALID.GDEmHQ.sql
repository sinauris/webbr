create PROCEDURE recompile_invalid (
    object_owner IN VARCHAR2
) AS
    curr NUMBER := NULL;
    prev NUMBER := NULL;
BEGIN
    LOOP
        curr := 0;
        FOR cur IN (
            SELECT
                OBJECT_NAME, OBJECT_TYPE, OWNER
            FROM
                ALL_OBJECTS
            WHERE
                OWNER = object_owner AND STATUS = 'INVALID'
        ) LOOP
            BEGIN
                curr := curr + 1;
                IF cur.OBJECT_TYPE = 'PACKAGE BODY' THEN
                    EXECUTE IMMEDIATE 'ALTER ' || cur.OBJECT_TYPE || ' ' ||  cur.OWNER || '.' || cur.OBJECT_NAME || ' COMPILE BODY';
                ELSE
                    EXECUTE IMMEDIATE 'ALTER ' || cur.OBJECT_TYPE || ' ' ||  cur.OWNER || '.' || cur.OBJECT_NAME || ' COMPILE';
                END IF;
            EXCEPTION
                WHEN OTHERS THEN NULL;
            END;
        END LOOP;
        EXIT WHEN prev IS NOT NULL AND prev = curr;
        prev := curr;
    END LOOP;
END;
/

