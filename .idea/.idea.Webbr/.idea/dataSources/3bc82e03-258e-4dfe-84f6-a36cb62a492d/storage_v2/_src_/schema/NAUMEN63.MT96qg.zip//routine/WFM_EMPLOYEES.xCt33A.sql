create function wfm_employees return wfm_employees_tp_tab
pipelined
as
line wfm_employees_tp := wfm_employees_tp(null, null, null, null, null, null, null, null); 
begin
    for i in 
        (
          select          
            mv_employee.uuid as oper_id
          , mv_employee.firstname as first_name
          , mv_employee.lastname as  last_name
          , mv_employee.middlename as middle_name
          , ('Внутренний: '
            ||  mv_employee.internalphonenumber
            ||  ', Рабочий: '
            ||  Null
            ||  ', Мобильный: '
            ||  mv_employee.mobilephonenumber
            ||  ', Домашний: '
            ||  mv_employee.homephonenumber) as phone
          , mv_employee.dateofbirth as dateOfBirth
          , mv_employee.removaldate as firingDate
          , mv_employee.creationdate as hiringDate
          from  
             mv_employee
        )
        loop
            line := wfm_employees_tp(i.oper_id, i.first_name, i.last_name, i.middle_name, i.phone, 
                                     i.dateOfBirth, i.firingDate, i.hiringDate);
            pipe row(line);
        end loop;
    return;
end;
/

