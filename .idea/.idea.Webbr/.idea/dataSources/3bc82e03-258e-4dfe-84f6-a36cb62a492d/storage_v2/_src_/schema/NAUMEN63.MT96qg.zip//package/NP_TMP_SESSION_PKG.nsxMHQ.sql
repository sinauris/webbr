create PACKAGE np_tmp_session_pkg
AS
    allow_triggers  NUMBER := 1;

    FUNCTION get_allow_triggers RETURN NUMBER;
    PROCEDURE set_allow_triggers(v IN NUMBER);
END;

/

