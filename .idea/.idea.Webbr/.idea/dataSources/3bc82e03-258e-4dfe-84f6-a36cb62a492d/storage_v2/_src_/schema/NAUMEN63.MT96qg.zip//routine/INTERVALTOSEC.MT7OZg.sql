create FUNCTION intervaltosec( intr INTERVAL DAY TO SECOND ) RETURN NUMBER AS BEGIN return extract( SECOND from intr )+extract( MINUTE from intr )*60+extract( HOUR from intr )*60*60+extract( DAY from intr )*60*60*24;END INTERVALTOSEC;
/

