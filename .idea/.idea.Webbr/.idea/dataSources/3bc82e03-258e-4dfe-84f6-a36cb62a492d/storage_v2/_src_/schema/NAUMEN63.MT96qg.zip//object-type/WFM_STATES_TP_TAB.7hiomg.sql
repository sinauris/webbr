create TYPE wfm_states_tp_tab AS TABLE OF wfm_states_tp;
/

