create PROCEDURE NP_TMP_WAIT_ALERT AS
  v varchar2(128);
  st number;
BEGIN
    DBMS_ALERT.WAITONE('np_tmp_trigger_alert',v ,st);
END;

/

