create type xy_dataset_type as table of xy_record_type
/

