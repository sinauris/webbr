create view V_PROJECT_SESSIONS as
  (
 SELECT "PROJECT_ID","SESSION_ID","SESSIONS_COUNT","EVENT","TIMESTAMP","DURATION","LEAVED" FROM project_sessions
 UNION ALL
 SELECT last_project_sessions."PROJECT_ID",last_project_sessions."SESSION_ID",last_project_sessions."SESSIONS_COUNT",last_project_sessions."EVENT",last_project_sessions."TIMESTAMP",
        intervaltosec(SYSDATE - timestamp) AS duration,
        SYSDATE as leaved
 FROM last_project_sessions)
/

