create type t_queue_len_table as table of t_queue_len
/

