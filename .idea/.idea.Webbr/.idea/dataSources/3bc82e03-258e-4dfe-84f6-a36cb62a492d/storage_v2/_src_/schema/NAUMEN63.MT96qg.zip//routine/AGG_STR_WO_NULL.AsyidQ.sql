create FUNCTION AGG_STR_WO_NULL (p_input VARCHAR2)
            RETURN VARCHAR2
            PARALLEL_ENABLE AGGREGATE USING t_agg_str_wo_null;
/

