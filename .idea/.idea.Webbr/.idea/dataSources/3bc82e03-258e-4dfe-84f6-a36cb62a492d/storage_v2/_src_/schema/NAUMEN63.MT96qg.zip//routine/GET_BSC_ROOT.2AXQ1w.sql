create FUNCTION get_bsc_root(
                  nodeId IN VARCHAR2)
                RETURN VARCHAR2
              IS
                parentId VARCHAR2(32);
              BEGIN
                SELECT parent INTO parentId FROM TBL_BSC_NODE WHERE UUID=nodeId;
                IF parentId IS NULL THEN
                  RETURN nodeId;
                ELSE
                  RETURN get_bsc_root(parentId);
                END IF;
              END;
/

