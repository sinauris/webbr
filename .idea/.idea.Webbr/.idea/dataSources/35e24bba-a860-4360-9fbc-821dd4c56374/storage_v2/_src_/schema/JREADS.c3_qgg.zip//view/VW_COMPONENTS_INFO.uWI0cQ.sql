create view VW_COMPONENTS_INFO as
  SELECT
node_assoc.source_node_id
, comp.CNAME
, COMP.ID
, COUNT(DISTINCT comp.CNAME) OVER(PARTITION BY node_assoc.source_node_id) AS comp_count
FROM "JIRA_AGILE"."NODEASSOCIATION" node_assoc
JOIN "JIRA_AGILE"."COMPONENT" comp
  ON comp.ID = node_assoc.sink_node_id
WHERE association_type = 'IssueComponent'
/

