create trigger TRG_EMPLOYEES_ID
  before insert
  on EMPLOYEES
  for each row
  BEGIN
   if inserting then 
      if :NEW."ID" is null then 
         select SEQ_EMPLOYEES.nextval into :NEW."ID" from dual; 
      end if; 
   end if; 
END;
/

