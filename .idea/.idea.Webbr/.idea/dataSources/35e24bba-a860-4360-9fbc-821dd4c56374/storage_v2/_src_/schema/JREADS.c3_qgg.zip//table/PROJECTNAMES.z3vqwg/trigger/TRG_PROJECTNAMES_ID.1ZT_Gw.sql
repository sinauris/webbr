create trigger TRG_PROJECTNAMES_ID
  before insert
  on PROJECTNAMES
  for each row
  BEGIN
   if inserting then 
      if :NEW."ID" is null then 
         select SEQ_PROJECTNAMES.nextval into :NEW."ID" from dual; 
      end if; 
   end if; 
END;
/

