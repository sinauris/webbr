create trigger TRG_GROUPS
  before insert
  on GROUPS
  for each row
  begin
   if inserting then
      if :NEW."ID" is null then
         select SEQ_GROUPS.nextval into :NEW."ID" from dual;
      end if;
   end if;
end;
/

