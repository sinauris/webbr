create FUNCTION wfm_skills
RETURN wfm_type_skill_table
AS
V_Test wfm_type_skill_table;
BEGIN
SELECT wfm_type_skill
  (
      aa.oper_login, 
        aa.project_id
  )
BULK COLLECT INTO V_Test
FROM
  (
  Select 
                mv_employee.login                       as oper_login, 
                MV_PARTICIPANT_HISTORY.PROJECTUUID      as project_id
    from MV_PARTICIPANT_HISTORY
    join mv_employee 
        on 
            mv_employee.uuid=MV_PARTICIPANT_HISTORY.PERSONUUID
    where   
                mv_employee.REMOVED=0
            and MV_PARTICIPANT_HISTORY.ENDDATE is null
            and mv_participant_history.roletype='participaints'
  ) aa;
RETURN V_Test;
END;
/

