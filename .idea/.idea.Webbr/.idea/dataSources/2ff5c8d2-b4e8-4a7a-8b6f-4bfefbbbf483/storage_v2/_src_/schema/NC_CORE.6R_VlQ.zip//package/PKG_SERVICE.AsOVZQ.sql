create PACKAGE PKG_SERVICE AS
/*
----------------------------------------СЛУЖЕБНЫЕ ФУНКЦИИ И ПРОЦЕДУРЫ----------------------------------------

  SP_UPDATE_CALLS - процедура обновления инфорамции по ЗФ
*/
  --Типы по логинам, работающих на проектах
  TYPE PTR_LOGINS IS RECORD (
                              LOGIN VARCHAR2(50),
                              CC_CAPTION VARCHAR2(150),
                              LOCATION_CAPTION VARCHAR2(150),
                              FID_PLATFORM NUMBER
                            );
  TYPE PT_LOGINS IS TABLE OF PTR_LOGINS;

  --Выборка логинов, работающих на проектах
  FUNCTION FNC_GET_LOGINS(I_DATE_START TIMESTAMP, --Дата начала отбора
                          I_DATE_END TIMESTAMP, --Дата окончания отбора
                          I_PROJECT VARCHAR2 DEFAULT NULL, --Проект/группа проектов
                          I_LOCATION VARCHAR2 DEFAULT NULL, --Call-центр/площадка
                          I_GROUP_LOCATION NUMBER DEFAULT 2, --Группировка по Call-центру/площадке
                          I_PLATFORMS VARCHAR2 DEFAULT NULL, --Платформы
                          I_LOGIN VARCHAR2 DEFAULT NULL, --Логин оператора
                          I_ROLETYPE VARCHAR2 DEFAULT NULL) --Роль сотрудника (оператор, супервайзер, ...)
    RETURN PT_LOGINS PIPELINED;

  --Тип по приоритетам работы оператора на проектах
  TYPE PTR_LOGIN_RATIO IS RECORD
                                (
                                  START_RANGE TIMESTAMP,
                                  STOP_RANGE TIMESTAMP,
                                  LOGIN  VARCHAR2(50),
                                  FID_PROJECT VARCHAR2(150),
                                  FID_PLATFORM NUMBER(2),
                                  PROJECT_RATE NUMBER(6,5)
                                );
  TYPE PT_LOGIN_RATIO IS TABLE OF PTR_LOGIN_RATIO;

  --Получение пропорций работы операторов на проектах
  FUNCTION FNC_GET_LOGIN_RATIO(
                                I_DATE_START TIMESTAMP, --Дата начала отбора
                                I_DATE_END TIMESTAMP, --Дата окончания отбора
                                I_PROJECT VARCHAR2 DEFAULT NULL, --Проект/группа проектов
                                I_GROUP_PROJECTS_LEVEL NUMBER DEFAULT 2, --Уровень группировки проектов
                                I_LOGIN VARCHAR2 DEFAULT NULL, --Логин оператора
                                I_LOCATION VARCHAR2 DEFAULT NULL, --Call-центр/площадка
                                I_PLATFORMS VARCHAR2 DEFAULT NULL, --Платформы
                                I_ROLETYPE VARCHAR2 DEFAULT NULL) --Роль сотрудника (оператор, супервайзер, ...)
    RETURN PT_LOGIN_RATIO PIPELINED;

  --Типы данных статусов операторов
  TYPE PTR_STATUS_CHANGES IS RECORD (
                                      ENTERED TIMESTAMP,
                                      LOGIN VARCHAR2(50),
                                      PROJECT_ID VARCHAR2(150),
                                      FID_STATUS NUMBER,
                                      REASON VARCHAR2(500),
                                      PROJECT_RATE NUMBER(6,5),
                                      DURATION NUMBER(25,5),
                                      FULL_DURATION NUMBER,
                                      FID_PLATFORM NUMBER(2),
                                      CC_CAPTION VARCHAR2(150),
                                      LOCATION_CAPTION VARCHAR2(150)
                                    );
  TYPE PT_STATUS_CHANGES IS TABLE OF PTR_STATUS_CHANGES;

  --Выборка статусов операторов
  FUNCTION FNC_GET_STATUSES(I_DATE_START TIMESTAMP, --Дата начала отбора
                            I_DATE_END TIMESTAMP, --Дата окончания отбора
                            I_PROJECT VARCHAR2 DEFAULT NULL, --Проект/группа проектов
                            I_GROUP_PROJECTS_LEVEL NUMBER DEFAULT 2, --Уровень группировки проектов
                            I_LOGIN VARCHAR2 DEFAULT NULL, --Логин оператора
                            I_LOCATION VARCHAR2 DEFAULT NULL, --Call-центр/площадка
                            I_GROUP_LOCATION NUMBER DEFAULT 2, --Группировка по Call-центру/площадке
                            I_STEP NUMBER DEFAULT 1, --Длина шага разделения по времени
                            I_STEP_TYPE VARCHAR2 DEFAULT 'DD', --Тип шаг разделения по времени
                            I_STATUSES VARCHAR2 DEFAULT NULL, --Статусы
                            I_PLATFORMS VARCHAR2 DEFAULT NULL, --Платформы
                            I_ROLETYPE VARCHAR2 DEFAULT NULL, --Роль сотрудника (оператор, супервайзер, ...)
                            I_COMPRESS CHAR DEFAULT 'Y') --Убирать offline занимающие целый диапазон
    RETURN PT_STATUS_CHANGES PIPELINED;

  --Типы для получение id проектов из группы
  TYPE PTR_PROJECTS_IDS IS RECORD(PROJECT_ID VARCHAR2(200 CHAR),
                                  ID_GROUP NUMBER,
                                  FID_GROUP NUMBER,
                                  FID_PLATFORM NUMBER);
  TYPE PT_PROJECTS_IDS IS TABLE OF PTR_PROJECTS_IDS;

  --Получение id проектов из группы
  FUNCTION FNC_PROJECTS_IDS(I_PROJECTS_GROUP T_LIST_VARCHAR,
                            I_SEARCH_SUBGROUP CHAR DEFAULT 'Y',
                            I_PLATFORMS T_LIST_INTEGER DEFAULT NULL,
                            I_ACTIVE NUMBER DEFAULT NULL)
    RETURN PT_PROJECTS_IDS PIPELINED;
  FUNCTION FNC_PROJECTS_IDS(I_PROJECTS_GROUP VARCHAR2,
                            I_SEARCH_SUBGROUP CHAR DEFAULT 'Y',
                            I_PLATFORMS VARCHAR2 DEFAULT NULL,
                            I_ACTIVE NUMBER DEFAULT NULL)
    RETURN PT_PROJECTS_IDS PIPELINED;

  --Получение списка проектов по выбранному в фильтре параметру
  FUNCTION FNC_FILTERED_PROJECTS_IDS(I_PARAM VARCHAR2)
    RETURN PT_PROJECTS_IDS PIPELINED;

  --Процедура обновления инфорамции по ЗФ
  PROCEDURE SP_UPDATE_CALLS(I_DATE_START TIMESTAMP,
                            I_DATE_END TIMESTAMP,
                            I_FORCE CHAR,
                            I_PLATFORMS T_LIST_INTEGER DEFAULT NULL);

  --Процедура обновления кодов операторов связи
  PROCEDURE SP_UPDATE_PROVIDERS(I_DATE_START TIMESTAMP,
                                I_DATE_END TIMESTAMP,
                                I_FORCE CHAR DEFAULT 'N');

  --Процедура обновления инфорамции по переключениям статусов
  PROCEDURE SP_UPDATE_STATUSES (I_DATE_START TIMESTAMP,
                                I_DATE_END TIMESTAMP,
                                I_FORCE CHAR,
                                I_PLATFORMS T_LIST_INTEGER DEFAULT NULL);

  --Процедура синхронизации групп с PMS
  PROCEDURE SP_SYNCHRONIZATION_GROUPS;

  --Процедура изменения структуры групп
  PROCEDURE SP_CHANGE_GROUPS(
                              IO_ACTION IN OUT VARCHAR2,
                              IO_GROUP_ID IN OUT NUMBER,
                              I_GROUP_NAME IN VARCHAR2,
                              I_PARENT_GROUP_ID NUMBER,
                              I_PROJECT_ID VARCHAR2);

  --Включение и отключение JOBов в схеме
  PROCEDURE SP_CHANGE_JOB_STATE(I_ENABLED CHAR DEFAULT 'Y');

  -- Процедура расчета рабочих интервалов
  PROCEDURE PRC_LOAD_WORK_INTERVALS
            (
              I_DATE_START IN TIMESTAMP DEFAULT NULL,
              I_DATE_END IN TIMESTAMP DEFAULT NULL,
              I_FORCE IN VARCHAR2 DEFAULT 'N'
            );

  -- Процедура расчета коэффициента работы на проектах
  PROCEDURE PRC_LOAD_LOGIN_RATES
            (
              I_DATE_START IN TIMESTAMP DEFAULT NULL,
              I_DATE_END IN TIMESTAMP DEFAULT NULL
            );

  -- Процедура рассчета суммы длительностей статусов
  PROCEDURE PRC_LOAD_STATUSES_SUM
            (
              I_DATE_START IN TIMESTAMP DEFAULT NULL,
              I_DATE_END IN TIMESTAMP DEFAULT NULL
            );

  -- Процедура обновления реестра Россвязи
  PROCEDURE PRC_UPDATE_ROSSVYAZ(I_CHANGE_DATE IN TIMESTAMP DEFAULT SYSTIMESTAMP);

  --Процедура обновления инфорамции по чатам, почте
  PROCEDURE SP_UPDATE_CHATS(I_DATE_START TIMESTAMP,
                            I_DATE_END TIMESTAMP,
                            I_FORCE CHAR DEFAULT 'N',
                            I_PLATFORMS T_LIST_INTEGER DEFAULT NULL);
END PKG_SERVICE;
/

