create view CALLS_CASE_UUID as
Select
    session_id,
    param_value as case_uuid,
    changed
From
    call_params
Where
    param_name = 'case_uuid'
/

