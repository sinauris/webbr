create trigger TRG_D_PROJECT_WORK_TIME_ID
    before insert
    on D_PROJECT_WORK_TIME
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_DPWT" IS NULL THEN
                                 SELECT SEQ_D_PROJECT_WORK_TIME_ID.NEXTVAL INTO :NEW."ID_DPWT" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

