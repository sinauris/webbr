create materialized view MV_USER_PROFILE
    refresh force on demand
as
SELECT LOGIN, PROFILE_NAME, FID_PLATFORM
FROM VW_USER_PROFILE
/

