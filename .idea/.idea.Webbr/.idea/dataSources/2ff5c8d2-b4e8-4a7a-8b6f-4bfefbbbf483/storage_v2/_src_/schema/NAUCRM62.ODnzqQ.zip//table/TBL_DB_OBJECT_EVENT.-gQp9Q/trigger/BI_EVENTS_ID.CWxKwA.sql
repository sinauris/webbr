create trigger BI_EVENTS_ID
    before insert
    on TBL_DB_OBJECT_EVENT
    for each row
BEGIN 
	IF (:NEW.ID IS NULL) THEN
		SELECT TBL_DB_OBJECT_EVENT_ID_GEN.NEXTVAL INTO :NEW.ID FROM DUAL;
	END IF;     
END;
/

