create type           SYS_PLSQL_1808372_1148_1 as table of "NC_CORE"."SYS_PLSQL_1808372_1122_1";
/

