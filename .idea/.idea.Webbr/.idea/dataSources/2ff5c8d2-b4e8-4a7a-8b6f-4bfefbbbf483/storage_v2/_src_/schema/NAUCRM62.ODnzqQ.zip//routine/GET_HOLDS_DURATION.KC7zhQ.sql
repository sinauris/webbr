create Function GET_HOLDS_DURATION ( sess in varchar2, oper in varchar2 ) Return Number is
            CNT NUMBER;
            Begin
               select nvl(sum(INTERVALTOSEC(ended-entered)),0) into CNT
                from call_status
                where session_id = sess
                and initiator_id = oper;
                Return(CNT);
             END;
/

