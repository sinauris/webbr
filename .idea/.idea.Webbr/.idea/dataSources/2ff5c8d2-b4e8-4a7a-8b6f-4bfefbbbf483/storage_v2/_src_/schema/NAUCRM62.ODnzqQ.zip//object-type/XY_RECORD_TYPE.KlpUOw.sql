create type xy_record_type as object (x double precision, y double precision)
/

