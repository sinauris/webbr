create PACKAGE PKG_BILLING AS
/*
----------------------------------------СЛУЖЕБНЫЕ ФУНКЦИИ И ПРОЦЕДУРЫ----------------------------------------

  SP_UPDATE_CALLS - процедура обновления инфорамции по ЗФ
*/
  --Процедура обновления стоимости соединений
  PROCEDURE SP_UPDATE_COSTS(I_DATE_START TIMESTAMP,
                            I_DATE_END TIMESTAMP,
                            I_FORCE CHAR DEFAULT 'N');

END PKG_BILLING;
/

