create trigger TRG_INTERVIEW_VACANCIES_ID
    before insert
    on INTERVIEW_VACANCIES
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_INTERVIEW_VACANCY" IS NULL THEN
                                 SELECT SEQ_INTERVIEW_VACANCIES_ID.NEXTVAL INTO :NEW."ID_INTERVIEW_VACANCY" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

