create Function XML_DETECT(P_SESSION_ID In VarChar2) Return VarChar2 As L_RETURN VARCHAR2(32767);
Begin
With
P1 As (Select P_SESSION_ID SESSION_ID From DUAL),
P2 As (Select Distinct a.SESSION_ID, a.SRC_ID AB From NAUCRM.CALL_LEGS a, P1 b Where a.SESSION_ID = b.SESSION_ID Union Select Distinct a.SESSION_ID, a.DST_ID AB From NAUCRM.CALL_LEGS a, P1 b Where a.SESSION_ID = b.SESSION_ID),
P3_ID As (Select 'project340' ID_PROJ From DUAL Union All Select 'project257' ID_PROJ From DUAL),
P3 As (Select a.AB, d.SESSION_ID From P2 a, NAUCRM.ABONENTS b, NAUCRM.PROJECT_AGENTS c, P1 d, P3_ID e Where a.SESSION_ID = d.SESSION_ID And a.AB = b.LOGIN And b.ID = c.ABONENT_ID And c.PROJECT_ID = e.ID_PROJ),
P4 As (Select a.SESSION_ID, Decode(b.AB, Null, 0, 1) NUMS From P1 a, P3 b Where a.SESSION_ID = b.SESSION_ID (+)),
P5 As (Select Sum(NUMS) NUMS From P4)
Select To_Char(Sign(NUMS)) NUMS Into L_RETURN
From P5;
RETURN L_RETURN;
End XML_DETECT;
/

