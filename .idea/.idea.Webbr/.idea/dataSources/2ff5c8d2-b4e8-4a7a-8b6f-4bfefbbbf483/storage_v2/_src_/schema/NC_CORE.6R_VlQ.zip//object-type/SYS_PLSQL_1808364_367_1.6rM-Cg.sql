create type           SYS_PLSQL_1808364_367_1 as table of "NC_CORE"."SYS_PLSQL_1808364_342_1";
/

