create TYPE t_agg_str_wo_null AS OBJECT
(
  g_string VARCHAR2(4000),

  STATIC FUNCTION ODCIAggregateInitialize(sctx  IN OUT  t_agg_str_wo_null)
    RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateIterate(self   IN OUT  t_agg_str_wo_null,
                                       value  IN      VARCHAR2 )
     RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateTerminate(self         IN   t_agg_str_wo_null,
                                         returnValue  OUT  VARCHAR2,
                                         flags        IN   NUMBER)
    RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateMerge(self  IN OUT  t_agg_str_wo_null,
                                     ctx2  IN      t_agg_str_wo_null)
    RETURN NUMBER
);
/

