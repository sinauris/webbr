create TYPE wfm_type_project FORCE AS OBJECT
    (
    project_id        char(32),
    project_name      varchar(450),
    project_state     number(1),
    project_type      varchar(150)
    );
/

