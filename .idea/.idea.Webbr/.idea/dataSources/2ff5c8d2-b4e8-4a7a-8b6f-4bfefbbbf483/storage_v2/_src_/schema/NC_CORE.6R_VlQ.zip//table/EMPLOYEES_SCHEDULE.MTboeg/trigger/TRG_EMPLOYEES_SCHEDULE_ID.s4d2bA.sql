create trigger TRG_EMPLOYEES_SCHEDULE_ID
    before insert
    on EMPLOYEES_SCHEDULE
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_SCHEDULE" IS NULL THEN
                                 SELECT SEQ_EMPLOYEES_SCHEDULE_ID.NEXTVAL INTO :NEW."ID_SCHEDULE" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

