create trigger TRG_D_GROUPS43_ID
    before insert
    on D_GROUPS
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_GROUP" IS NULL THEN
                                 SELECT SEQ_D_GROUPS43_ID.NEXTVAL INTO :NEW."ID_GROUP" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

