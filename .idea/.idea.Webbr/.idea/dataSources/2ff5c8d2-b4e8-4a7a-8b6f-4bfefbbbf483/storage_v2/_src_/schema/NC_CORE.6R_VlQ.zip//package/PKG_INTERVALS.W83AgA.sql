create PACKAGE PKG_INTERVALS AS
/*
----------------------------------------УТИЛИТЫ ДЛЯ РАБОТЫ С ИНТЕРВАЛАМИ----------------------------------------

  FNC_INTERVALTOSEC - Преобразование интервала в секунды
  FNC_INTERVALTOMIN - Преобразование интервала в минуты с возможностью округления до целых. Возможное округление:
    U-вверх,
    D-вниз,
    M-математически
  FNC_INTERVALTOHOUR - Преобразование интервала в часы с возможностью округления до целых. Возможное округление:
    U-вверх,
    D-вниз,
    M-математически
  FNC_INTERVALTOCHAR - Преобразование интервала в строку с указанием формата преобразования. Структура формата преобразования:
    D - выводит количество дней в интервале;
    DD - выводит количество дней в интервале в 2 цыфры;
    H - выводит количество часов в интервале в 12-часовом формате;
    HH - выводит количество часов в интервале в 2 цифры в 12-часовом формате;
    H24 - выводит количество часов в интервале в 24-часовом формате;
    HH24 - выводит количество часов в интервале в 2 цифры в 24-часовом формате;
    MI - выводит количество минут в интервале в 2 цифры;
    SS - выводит количество секунд в интервале в 2 цифры;
  FNC_INTERVALTORANGES - разбивает интервал на диапазоны с указанием шага и маски текстового представления. Возможные шаги:
    YY - года,
    MM - месяцы,
    DD - дни,
    HH - часы,
    MI - минуты,
    SS - секунды
*/
  SUBTYPE PT_INTERVAL IS INTERVAL DAY(9) TO SECOND(9);

  --Преобразование интервала в секунды
  FUNCTION FNC_INTERVALTOSEC(I_INTERVAL PT_INTERVAL)
    RETURN NUMBER;
  FUNCTION FNC_INTERVALTOSEC(I_START_DATE TIMESTAMP, I_END_DATE TIMESTAMP)
    RETURN NUMBER;
    
  /*Преобразование интервала в минуты
    I_ROUND_UP - округление до целых: U-вверх, D-вниз, M-математически
  */
  FUNCTION FNC_INTERVALTOMIN(I_INTERVAL PT_INTERVAL, I_DECIMALS NUMBER DEFAULT 2, I_ROUND_UP CHAR DEFAULT 'U')
    RETURN NUMBER;
  FUNCTION FNC_INTERVALTOMIN(I_START_DATE TIMESTAMP, I_END_DATE TIMESTAMP, I_DECIMALS NUMBER DEFAULT 2, I_ROUND_UP CHAR DEFAULT 'U')
    RETURN NUMBER;
  
  /*Преобразование интервала в часы
    I_ROUND_UP - округление до целых: U-вверх, D-вниз, M-математически
  */
  FUNCTION FNC_INTERVALTOHOUR(I_INTERVAL PT_INTERVAL, I_DECIMALS NUMBER DEFAULT 2, I_ROUND_UP CHAR DEFAULT 'U')
    RETURN NUMBER;
  FUNCTION FNC_INTERVALTOHOUR(I_START_DATE TIMESTAMP, I_END_DATE TIMESTAMP, I_DECIMALS NUMBER DEFAULT 2, I_ROUND_UP CHAR DEFAULT 'U')
    RETURN NUMBER;

  /*Преобразование интервала в строку
    I_ROUND_UP - округление до целых: U-вверх, D-вниз, M-математически
  */
  FUNCTION FNC_INTERVALTOCHAR(I_INTERVAL PT_INTERVAL, I_MASK VARCHAR2 DEFAULT 'HH24:MI:SS')
    RETURN VARCHAR2;
  FUNCTION FNC_INTERVALTOCHAR(I_START_DATE TIMESTAMP, I_END_DATE TIMESTAMP, I_MASK VARCHAR2 DEFAULT 'HH24:MI:SS')
    RETURN VARCHAR2;
    
  /*Разбиение интервала на диапазоны
    I_STEP - длина шага разбиения;
    I_STEP_TYPE - шаг разбиения;
    I_MASK - маска преобразования даты в строку;
    I_SEPARATOR - разделитель дат в строке
  */
  TYPE TPR_RANGE IS RECORD(START_RANGE TIMESTAMP, STOP_RANGE TIMESTAMP, FULL_RANGE VARCHAR2(200));
  TYPE TP_RANGES IS TABLE OF TPR_RANGE;
  FUNCTION FNC_INTERVALTORANGES(I_START_DATE TIMESTAMP, I_END_DATE TIMESTAMP,
                                I_STEP NUMBER DEFAULT 1, I_STEP_TYPE VARCHAR2 DEFAULT 'DD',
                                I_MASK VARCHAR2 DEFAULT 'DD.MM.YYYY HH24:MI:SS', I_SEPARATOR CHAR DEFAULT '-')
    RETURN TP_RANGES PIPELINED;

END PKG_INTERVALS;
/

