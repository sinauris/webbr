create view VW_PROJECTS as
    SELECT 'project_not_determined' AS PROJECT_ID,
  'Проект не определен'         AS NAME,
  NULL                          AS DIRECTION,
  NULL                          AS BEGIN_TIME,
  NULL                          AS END_TIME,
  0                             AS FID_PLATFORM,
  1                             AS IS_ACTIVE
FROM DUAL

UNION
--основная инсталляция наумен 6
SELECT ICP.UUID AS PROJECT_ID,
  ICP.TITLE AS NAME,
  'IN' AS DIRECTION,
  CASE
    WHEN ICP.REMOVED=1
      OR ICP.STATE='Блокированный' THEN NULL
    ELSE ICP.CREATIONDATE
  END                                                            AS BEGIN_TIME,
  NVL(ICP.REMOVALDATE, TO_TIMESTAMP('01.01.2999', 'dd.mm.yyyy')) AS END_TIME,
  2                                                              AS FID_PLATFORM,
  DECODE(ICP.STATE,'Активный',1,0)                               AS IS_ACTIVE
FROM NAUCRM62.MV_INCOMING_CALL_PROJECT ICP
UNION
SELECT OCP.UUID,
  OCP.TITLE,
  'OUT' AS DIRECTION,
  CASE
    WHEN OCP.REMOVED=1
      OR OCP.STATE='Блокированный' THEN NULL
    ELSE OCP.CREATIONDATE
  END                                                            AS BEGIN_TIME,
  NVL(OCP.REMOVALDATE, TO_TIMESTAMP('01.01.2999', 'dd.mm.yyyy')) AS END_TIME,
  2                                                              AS FID_PLATFORM,
  DECODE(OCP.STATE,'Активный',1,0)                               AS IS_ACTIVE
FROM NAUCRM62.MV_OUTCOMING_CALL_PROJECT OCP
/

comment on table VW_PROJECTS is 'Список проектов с группами по всем платформам'
/

