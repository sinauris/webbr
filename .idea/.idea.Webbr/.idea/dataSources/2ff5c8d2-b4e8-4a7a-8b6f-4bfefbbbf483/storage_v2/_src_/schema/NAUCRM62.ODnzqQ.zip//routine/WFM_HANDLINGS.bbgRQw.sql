create function
wfm_handlings(start_time timestamp, stop_time timestamp, intrvl interval day to second) return wfm_handlings_tp_tab
pipelined
is
line wfm_handlings_tp := wfm_handlings_tp(null, null, null, null, null, null, null, 
                                    null, null, null, null, null, null, null, null, null, null, null, null);
                                       
begin
   for i in 
       (
        with discrete_handlings as
          (select
              mbstat_message_handlings.mb_session_id as  session_id
            , mbstat_message_handlings.project_id as  project_id
            , mbstat_message_handlings.operator as  login
            , mbstat_message_handlings.distributed_time as  ringing_from
            , mbstat_message_handlings.distributed_time as  ringing_till
            , mbstat_message_handlings.distributed_time as  speaking_from
            , mbstat_message_handlings.ended_time as  speaking_till
          from mbstat_message_handlings
          where
             mbstat_message_handlings.unblocked_time is  not null
             and mbstat_message_handlings.distributed_time >= start_time - intrvl
             and mbstat_message_handlings.distributed_time < stop_time
          )
        
        , all_agent_voice_sessions_in as
          (select
              call_legs.created as ringing_from
            , coalesce(call_legs.connected, call_legs.ended) as ringing_till
            , call_legs.connected as speaking_from
            , (case
                 when call_legs.connected is null then null
                 else call_legs.ended
              end) as  speaking_till
            , call_legs.dst_abonent as login
            , call_legs.session_id
            , call_legs.leg_id
          from call_legs
          where
              call_legs.connected >= start_time - intrvl
              and call_legs.connected < stop_time
              and call_legs.dst_abonent_type = 'SP'
        )
        
        , all_agent_voice_sessions_out as
          (select
              call_legs.created as ringing_from
            , coalesce(call_legs.connected, call_legs.ended) as ringing_till
            , call_legs.connected as  speaking_from
            , case
                when call_legs.connected is null then null
                else    call_legs.ended
              end as speaking_till
            , call_legs.src_abonent as login
            , call_legs.session_id
          from call_legs
          where
            call_legs.created >= start_time - intrvl
            and call_legs.created < stop_time
            and call_legs.src_abonent_type = 'SP'
        )
        
        , all_agent_voice_sessions as
          (select
              all_agent_voice_sessions_in.session_id
            , all_agent_voice_sessions_in.login
            , all_agent_voice_sessions_in.ringing_from
            , all_agent_voice_sessions_in.ringing_till
            , all_agent_voice_sessions_in.speaking_from
            , all_agent_voice_sessions_in.speaking_till
          from all_agent_voice_sessions_in
          union all
          select
             all_agent_voice_sessions_out.session_id
           , all_agent_voice_sessions_out.login
           , all_agent_voice_sessions_out.ringing_from
           , all_agent_voice_sessions_out.ringing_till
           , all_agent_voice_sessions_out.speaking_from
           , all_agent_voice_sessions_out.speaking_till
          from all_agent_voice_sessions_out
        )
        
        , q_calls as
          (select
              queued_calls.session_id
            , queued_calls.project_id
            , queued_calls.next_leg_id as nextleg
           from queued_calls
           where
             queued_calls.enqueued_time >= start_time - intrvl
             and queued_calls.enqueued_time < stop_time
             and queued_calls.final_stage = 'operator'
        )
        
        , wrapup_states as
          (select
              status_changes.entered as  dt_from
            , status_changes.leaved as dt_till
            , status_changes.login
            , status_changes.reason as session_id
          from status_changes
          where
            status_changes.entered >= start_time - intrvl
            and status_changes.entered < stop_time
            and status_changes.status = 'wrapup'
        )
        
        , voice_handlings_in as
          (select
              q_calls.session_id
            , q_calls.project_id
            , all_agent_voice_sessions_in.login
            , all_agent_voice_sessions_in.ringing_from
            , all_agent_voice_sessions_in.ringing_till
            , all_agent_voice_sessions_in.speaking_from
            , all_agent_voice_sessions_in.speaking_till
            , wrapup_states.dt_from as wrapup_from
            , wrapup_states.dt_till as wrapup_till
          from q_calls
               left join all_agent_voice_sessions_in
                       on (all_agent_voice_sessions_in.session_id = q_calls.session_id
                           and all_agent_voice_sessions_in.leg_id = q_calls.nextleg)
               left join   wrapup_states
                      on (wrapup_states.session_id = q_calls.session_id
                         and wrapup_states.login = all_agent_voice_sessions_in.login)
        )
        
        , dialer_sessions as
          (select
                                    detail_outbound_sessions.session_id
                                ,   detail_outbound_sessions.project_id
                                ,   detail_outbound_sessions.login
          from detail_outbound_sessions
          where
            detail_outbound_sessions.attempt_start >= start_time - intrvl
            and detail_outbound_sessions.attempt_start < stop_time
        )
        
        , voice_handlings_out as
          (select
              dialer_sessions.session_id
            , dialer_sessions.project_id
            , dialer_sessions.login
            , all_agent_voice_sessions.ringing_from
            , all_agent_voice_sessions.ringing_till
            , all_agent_voice_sessions.speaking_from
            , all_agent_voice_sessions.speaking_till
            , wrapup_states.dt_from as  wrapup_from
            , wrapup_states.dt_till as  wrapup_till
          from dialer_sessions
               inner join all_agent_voice_sessions 
                        on (all_agent_voice_sessions.session_id = dialer_sessions.session_id
                        and all_agent_voice_sessions.login = dialer_sessions.login)
               left join  wrapup_states 
                       on  (wrapup_states.session_id = all_agent_voice_sessions.session_id
                       and wrapup_states.login = all_agent_voice_sessions.login)
                )
        
        , all_handlings as
          (select
              discrete_handlings.session_id
            , discrete_handlings.project_id
            , mv_incoming_call_project.title as project_title
            , discrete_handlings.login
            , discrete_handlings.ringing_from
            , discrete_handlings.ringing_till
            , discrete_handlings.speaking_from
            , discrete_handlings.speaking_till
            , null as  wrapup_from
            , null as  wrapup_till
            , 'text' as project_type
          from discrete_handlings
               left join mv_incoming_call_project 
                       on mv_incoming_call_project.uuid = discrete_handlings.project_id
          union all
          select
             voice_handlings_in.session_id
           , voice_handlings_in.project_id
           , mv_incoming_call_project.title as  project_title
           , voice_handlings_in.login
           , voice_handlings_in.ringing_from
           , voice_handlings_in.ringing_till
           , voice_handlings_in.speaking_from
           , voice_handlings_in.speaking_till
           , voice_handlings_in.wrapup_from
           , voice_handlings_in.wrapup_till
           , 'voice inbound' as project_type
          from voice_handlings_in
               left join mv_incoming_call_project 
                       on mv_incoming_call_project.uuid = voice_handlings_in.project_id
          union all
          select        
             voice_handlings_out.session_id
           , voice_handlings_out.project_id
           , mv_outcoming_call_project.title as  project_title
           , voice_handlings_out.login
           , voice_handlings_out.ringing_from
           , voice_handlings_out.ringing_till
           , voice_handlings_out.speaking_from
           , voice_handlings_out.speaking_till
           , voice_handlings_out.wrapup_from
           , voice_handlings_out.wrapup_till
           , 'voice outbound' as  project_type
          from voice_handlings_out
               left join   mv_outcoming_call_project  on mv_outcoming_call_project.uuid = voice_handlings_out.project_id
          )
        
        , preaggregated as
          (select
              all_handlings.session_id as session_id
            , all_handlings.project_id as  project_uuid
            , all_handlings.project_title as project_title
            , all_handlings.project_type as project_type
            , mv_employee.uuid as employee_uuid
            , mv_employee.title as employee_title
            , all_handlings.login as employee_login
            , all_handlings.ringing_from as handling_from
            , greatest(all_handlings.wrapup_till, all_handlings.speaking_till , all_handlings.ringing_till  ) as  handling_till
            , all_handlings.ringing_from as ringing_from
            , all_handlings.ringing_till as ringing_till
            , (all_handlings.ringing_till-all_handlings.ringing_from) as ringing_duration
            , all_handlings.speaking_from as speaking_from
            , all_handlings.speaking_till as speaking_till
            , coalesce(all_handlings.speaking_till - all_handlings.speaking_from, NUMTODSINTERVAL(0, 'second')) as speaking_duration
            , all_handlings.wrapup_from as wrapup_from
            , all_handlings.wrapup_till as wrapup_till
            , coalesce(all_handlings.wrapup_till - all_handlings.wrapup_from, NUMTODSINTERVAL(0, 'second')) as wrapup_duration
          from  all_handlings
            left join mv_employee on mv_employee.login = all_handlings.login
                )
        
        , aggregated as
          (select
              preaggregated.session_id
            , preaggregated.project_uuid
            , preaggregated.project_title
            , preaggregated.project_type
            , preaggregated.employee_uuid
            , preaggregated.employee_title
            , preaggregated.employee_login
            , preaggregated.handling_from
            , preaggregated.handling_till
            , (preaggregated.handling_till - preaggregated.handling_from) as  handling_duration
            , preaggregated.ringing_from
            , preaggregated.ringing_till
            , preaggregated.ringing_duration
            , preaggregated.speaking_from
            , preaggregated.speaking_till
            , preaggregated.speaking_duration
            , preaggregated.wrapup_from
            , preaggregated.wrapup_till
            , preaggregated.wrapup_duration
          from preaggregated
          where
            preaggregated.employee_login is not null
            )
        select *
        from aggregated
        order by 
           handling_from
           , session_id
           , project_title
       )
       loop
           line := wfm_handlings_tp(i.session_id, i.project_uuid, i.project_title, i.project_type, i.employee_uuid, 
                                 i.employee_title, i.employee_login, i.handling_from, i.handling_till, i.handling_duration,
                                 i.ringing_from, i.ringing_till, i.ringing_duration, i.speaking_from, i.speaking_till,
                                 i.speaking_duration, i.wrapup_from, i.wrapup_till, i.wrapup_duration);
           pipe row(line);
       end loop;
   return;
end;
/

