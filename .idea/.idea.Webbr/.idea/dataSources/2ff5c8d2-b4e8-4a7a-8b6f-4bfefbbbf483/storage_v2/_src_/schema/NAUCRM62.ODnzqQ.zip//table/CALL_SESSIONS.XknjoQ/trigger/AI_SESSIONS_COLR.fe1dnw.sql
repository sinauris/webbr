create trigger AI_SESSIONS_COLR
    after insert
    on CALL_SESSIONS
    for each row
BEGIN
    INSERT INTO sessions_for_update (session_id, created) VALUES (:new.session_id, :new.created);
END;
/

