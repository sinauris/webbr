create PROCEDURE NP_TMP_UPDATE_SEQ(seq_name IN VARCHAR2, table_name IN VARCHAR2) AS
   des_next   NUMBER;
   act_next   NUMBER;
BEGIN
   EXECUTE IMMEDIATE 'SELECT MAX(id) + 1 AS n FROM ' || table_name INTO des_next;
   EXECUTE IMMEDIATE 'SELECT ' || seq_name || '.nextval FROM dual' INTO act_next;
   IF des_next IS NULL OR des_next < 1 THEN
      des_next := 1;
   END IF;
   IF (des_next - act_next - 1) != 0 THEN
      EXECUTE IMMEDIATE 'ALTER SEQUENCE ' || seq_name || ' INCREMENT BY ' || (des_next - act_next - 1) || ' MINVALUE 0';
   END IF;
   EXECUTE IMMEDIATE 'SELECT ' || seq_name || '.nextval FROM dual' INTO act_next;
   EXECUTE IMMEDIATE 'ALTER SEQUENCE ' || seq_name || ' INCREMENT BY 1';
END;

/

