create type           SYS_PLSQL_1808372_582_1 as table of "NC_CORE"."SYS_PLSQL_1808372_539_1";
/

