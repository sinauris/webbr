create trigger TRG_EMPLOYEES_TEACH_DAYS_ID
    before insert
    on EMPLOYEES_TEACH_DAYS
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_DAY" IS NULL THEN
                                 SELECT SEQ_EMPLOYEES_TEACH_DAYS_ID.NEXTVAL INTO :NEW."ID_DAY" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

