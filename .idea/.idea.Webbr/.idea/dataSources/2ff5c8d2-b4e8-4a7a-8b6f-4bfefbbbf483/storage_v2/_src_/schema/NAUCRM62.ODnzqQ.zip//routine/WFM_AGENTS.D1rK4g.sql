create FUNCTION wfm_agents
RETURN wfm_type_agent_table
AS
V_Test wfm_type_agent_table;
BEGIN
SELECT wfm_type_agent
	(
	      aa.oper_id, 
       	aa.first_name, 
       	aa.last_name, 
       	aa.middle_name,
       	aa.phone,
       	aa.dateOfBirth,
        aa.hiringDate, 
       	aa.firingDate
	)
BULK COLLECT INTO V_Test
FROM
	(
	select          
                  mv_employee.uuid                  as  oper_id,
            	   	mv_employee.firstname             as  first_name,
            	   	mv_employee.lastname              as  last_name,
            	   	mv_employee.middlename            as  middle_name,
               		(    'Internal: '
                	||  mv_employee.internalphonenumber
                	||  ', Work: '
                	||  mv_employee.cityphone
                	||  ', Mobile: '
                	||  mv_employee.mobilephonenumber
                	||  ', HomePhone: '
                	||  mv_employee.homephonenumber)  as  phone,
            	   	mv_employee.dateofbirth           as  dateOfBirth,
               		mv_employee.creationdate          as  hiringDate,
                  mv_employee.removaldate           as  firingDate
	from            mv_employee
	) aa;
RETURN V_Test;
END;
/

