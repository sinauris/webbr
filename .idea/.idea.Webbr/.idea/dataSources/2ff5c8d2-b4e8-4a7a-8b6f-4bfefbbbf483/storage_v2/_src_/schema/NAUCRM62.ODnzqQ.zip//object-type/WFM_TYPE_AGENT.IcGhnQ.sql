create TYPE wfm_type_agent FORCE AS OBJECT
       (
              oper_id           char(32), 
              first_name        varchar2(512), 
              last_name         varchar2(512), 
              middle_name       varchar2(512),
              phone             varchar2(512),
              dateOfBirth       date, 
              firingDate        date,
              hiringDate        date
       );
/

