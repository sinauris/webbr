create Function DETECT_SESSION_T(P_SESSION_ID In VarChar2) Return VarChar2 As L_RETURN VARCHAR2(32767);
Begin
With
SS As (Select P_SESSION_ID SESSION_ID From DUAL),
SS_LEG  As (Select DETECT_SESSION_LEG(SESSION_ID) LEG_ID, SESSION_ID From SS),
SS_DLEG As (Select a.SESSION_ID, Decode(a.LEG_ID, -1, 0, Decode(b.LEG_ID, Null, 0, Decode(b.CONNECTED, Null, 0, 1))) DETECT
From SS_LEG a, NAUCRM.CALL_LEGS b Where a.SESSION_ID = b.SESSION_ID (+) And a.LEG_ID = b.LEG_ID (+)),
SS_CALL_LEGS As (Select Distinct a.SESSION_ID, Decode(b.SESSION_ID, Null, 0, 1) DETECT From SS a, NAUCRM.CALL_LEGS b Where a.SESSION_ID = b.SESSION_ID (+)),
SS_CALL_SESS As (Select Distinct a.SESSION_ID, Decode(b.SESSION_ID, Null, 0, 1) DETECT From SS a, NAUCRM.CALL_SESSIONS b Where a.SESSION_ID = b.SESSION_ID (+))
Select Decode(c.DETECT, 1, Decode(b.DETECT, 1, Decode(d.DETECT, 1, 'True', 'False'), 'False'), 'False') DETECT Into L_RETURN From SS a, SS_CALL_LEGS b, SS_CALL_SESS c, SS_DLEG d
Where a.SESSION_ID = b.SESSION_ID And a.SESSION_ID = c.SESSION_ID And a.SESSION_ID = d.SESSION_ID;
RETURN L_RETURN;
End DETECT_SESSION_T;
/

