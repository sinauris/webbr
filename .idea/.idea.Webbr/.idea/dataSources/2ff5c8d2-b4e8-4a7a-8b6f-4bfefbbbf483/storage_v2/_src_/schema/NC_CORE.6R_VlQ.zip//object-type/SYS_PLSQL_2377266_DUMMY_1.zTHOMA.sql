create type           SYS_PLSQL_2377266_DUMMY_1 as table of number;
/

