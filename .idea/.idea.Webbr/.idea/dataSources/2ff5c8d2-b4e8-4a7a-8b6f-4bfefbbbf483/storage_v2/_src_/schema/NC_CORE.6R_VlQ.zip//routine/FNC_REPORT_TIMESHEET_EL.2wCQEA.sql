create FUNCTION FNC_REPORT_TIMESHEET_EL
(
  I_DATE_START TIMESTAMP,
  I_DATE_END TIMESTAMP,
  I_PROJECT VARCHAR2 DEFAULT NULL,
  I_PROJECT_GROUP NUMBER DEFAULT 2,
  I_LOCATION VARCHAR2 DEFAULT NULL,
  I_LOGIN VARCHAR2 DEFAULT NULL,
  I_ROLETYPE VARCHAR2 DEFAULT 'operator',
  I_PLATFORMS VARCHAR2 DEFAULT NULL,
  I_REGISTRATION_TYPE  NUMBER DEFAULT 1   -- 0 - Без учета перерывов, 1 - С учетом перерывов(Полное время)
) RETURN T_REPORT_TIMESHEET PIPELINED AS

  BEGIN
  FOR GET_DATA IN
  (
    WITH
      SQ_RANGES AS
      (
        SELECT /*+ MATERIALIZE*/ START_RANGE, STOP_RANGE-INTERVAL '1' SECOND AS STOP_RANGE
        FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(
                            I_START_DATE=>I_DATE_START,
                            I_END_DATE=>I_DATE_END,
                            I_MASK => 'DD.MM.YYYY HH24:MI'))
      ),
      SQ_PROJECT_FILTER AS
      (
        SELECT /*+ MATERIALIZE*/ PROJECT_ID, CAPTION, PLATFORM_ID
        FROM table(PKG_API.GET_PROJECTS_IDS(I_PROJECT))
      ),
      SQ_LOGINS AS
      (
        SELECT /*+ MATERIALIZE*/ LOGIN, LOCATION_NAME LOCATION_CAPTION, FID_PLATFORM
        FROM TABLE(PKG_API.GET_EMPLOYEES_LOGINS('{"date_start": "", "date_end": "", "location": "'|| I_LOCATION ||'", "logins": ['|| I_LOGIN ||'], "platforms": [], "projects": "", "roletype": []}'))
      ),
      SQ_WORK_TIME AS
      (
        SELECT SR.START_RANGE, SR.STOP_RANGE,
          SUM(PKG_INTERVALS.FNC_INTERVALTOSEC(
                          GREATEST(SR.START_RANGE, EWI.START_WORK_TIME),
                          LEAST(SR.STOP_RANGE, EWI.END_WORK_TIME))) WORK_TIME,
          EWI.LOGIN
        FROM EMPLOYEES_WORK_INTERVAL EWI
          JOIN SQ_RANGES SR
            ON SR.START_RANGE < EWI.END_WORK_TIME
            AND SR.STOP_RANGE > EWI.START_WORK_TIME
        WHERE EWI.LOGIN IN (SELECT LOGIN FROM SQ_LOGINS)
          AND EWI.TIME_DELETED IS NULL
        GROUP BY SR.START_RANGE, SR.STOP_RANGE, EWI.LOGIN--, EWI.FID_PLATFORM
      ),
      SQ_LUNCH_PRP AS
      (
        SELECT  /*+ MATERIALIZE*/
                /*+ INDEX (ESS IDX_EWISS_START_STATUS)*/
                /*+ INDEX (EWI PK_EWI_ID)*/
          SR.START_RANGE, SR.STOP_RANGE,
          EWI.LOGIN,
          CASE WHEN ESS.FID_PROJECT IN ('project_not_determined', 'pnd', '{no_projects}')
                  THEN DLR.FID_PROJECT
              ELSE ESS.FID_PROJECT
          END FID_PROJECT,
          CASE WHEN ESS.FID_PROJECT IN ('project_not_determined', 'pnd', '{no_projects}')
                  THEN ESS.SUM_DURATION * DLR.RATE
              ELSE ESS.SUM_DURATION
          END LUNCH_TIME
        FROM EWI_SUM_STATUSES ESS
          JOIN SQ_RANGES SR
            ON SR.START_RANGE <= ESS.REPORT_DATE
            AND SR.STOP_RANGE > ESS.REPORT_DATE
          JOIN D_STATUSES DS ON DS.ID_STATUS = ESS.FID_STATUS
            AND DS.NAME = 'away' AND DS.REASON IN ('CustomAwayReason6', 'CustomAwayReason7')
          JOIN EMPLOYEES_WORK_INTERVAL EWI
            ON EWI.ID_WORK_INTERVAL = ESS.FID_WORK_INTERVAL
            AND EWI.LOGIN IN (SELECT LOGIN FROM SQ_LOGINS)
            AND EWI.TIME_DELETED IS NULL
          LEFT JOIN EMPLOYEES_LOGIN_RATES DLR
            ON DLR.LOGIN = EWI.LOGIN
            AND DLR.REPORT_DATE = SR.START_RANGE
            AND (DLR.FID_PROJECT, DLR.FID_PLATFORM) IN
                (SELECT PROJECT_ID, PLATFORM_ID FROM SQ_PROJECT_FILTER)
            AND ESS.FID_PROJECT IN ('project_not_determined', 'pnd', '{no_projects}')
      ),
      SQ_LUNCH AS
      (
        SELECT
            START_RANGE, STOP_RANGE, LOGIN, FID_PROJECT, SUM(LUNCH_TIME) LUNCH_TIME
        FROM SQ_LUNCH_PRP
        GROUP BY START_RANGE, STOP_RANGE, LOGIN, FID_PROJECT
      ),
      SQ_TAB_TIME AS
      (
        SELECT /*+ MATERIALIZE*/ DISTINCT
          SWT.START_RANGE, SWT.STOP_RANGE, SWT.LOGIN, DLR.FID_PLATFORM, DLR.FID_PROJECT,
          DECODE(I_PROJECT_GROUP,
                 1, NVL(DG.CAPTION, 'Без группы'),
                 DECODE(DLR.FID_PROJECT,
                        '{no_projects}', 'Без проекта',
                        'project_not_determined', 'Проект не определен',
                         VP.NAME)) PROJECT_NAME,
          SWT.WORK_TIME * DLR.RATE - DECODE(I_REGISTRATION_TYPE, 1, 0, NVL(SL.LUNCH_TIME, 0)) TAB_TIME,
          NVL(VRPE.ROLETYPE,
              DECODE(DLR.FID_PROJECT,
                     '{no_projects}', NULL,
                     'project_not_determined', NULL,
                     'operator')) ROLETYPE
        FROM SQ_WORK_TIME SWT
          LEFT JOIN EMPLOYEES_LOGIN_RATES DLR
            ON DLR.LOGIN = SWT.LOGIN
            AND DLR.REPORT_DATE = SWT.START_RANGE
            AND (DLR.FID_PROJECT, DLR.FID_PLATFORM) IN
                (SELECT PROJECT_ID, PLATFORM_ID FROM SQ_PROJECT_FILTER)
          LEFT JOIN SQ_LUNCH SL
            ON SL.START_RANGE = SWT.START_RANGE
            AND SL.STOP_RANGE = SWT.STOP_RANGE
            AND SL.LOGIN = SWT.LOGIN
            AND SL.FID_PROJECT = DLR.FID_PROJECT
          LEFT JOIN VW_PROJECTS VP
            ON VP.PROJECT_ID = DLR.FID_PROJECT
            AND VP.FID_PLATFORM = DLR.FID_PLATFORM
          LEFT JOIN VW_REL_PROJECTS_EMPLOYEES VRPE
            ON VRPE.LOGIN = DLR.LOGIN
            AND VRPE.FID_PLATFORM = DLR.FID_PLATFORM
            AND VRPE.PROJECT_ID = DLR.FID_PROJECT
            AND VRPE.ACTIVE_TILL > SWT.START_RANGE
            AND VRPE.ACTIVE_FROM < SWT.STOP_RANGE
          LEFT JOIN REL_GROUP_PROJECTS GP
            ON GP.FID_PROJECT = DLR.FID_PROJECT
            AND DLR.REPORT_DATE BETWEEN GP.CREATED AND GP.BLOCKED
          LEFT JOIN D_GROUPS DG
            ON DG.ID_GROUP = GP.FID_GROUP
      ),
      SQ_PROJECTS AS
      (
        SELECT MON, LOGIN,
          LISTAGG(PROJECT_NAME, ',') WITHIN GROUP(ORDER BY PROJECT_NAME) AS PROJECTS
        FROM (SELECT DISTINCT TO_CHAR(STT.START_RANGE, 'MM/YYYY') MON,
                STT.LOGIN, STT.FID_PLATFORM, STT.PROJECT_NAME
              FROM SQ_TAB_TIME STT
              WHERE STT.TAB_TIME > 0
                AND NVL2(I_ROLETYPE, STT.ROLETYPE, '*') = NVL(I_ROLETYPE, '*')
                AND NVL(I_PROJECT_GROUP, 2) = 0)
        GROUP BY MON, LOGIN
      ),
      SQ_DATA AS
      (
        SELECT EXTRACT(DAY FROM STT.START_RANGE) DAY_NUM,
          TO_CHAR(STT.START_RANGE, 'MM/YYYY') WORK_MONTH,
          DECODE(NVL(I_PROJECT_GROUP, 2), 0, STT.LOGIN, 'Все логины') LOGIN,
          DECODE(NVL(I_PROJECT_GROUP, 2), 0, MAX(TRIM(VWE.SURNAME)||' '||TRIM(VWE.NAME)||' '||TRIM(VWE.PATRONYMIC)), 'Все сотрудники') FIO,
          NVL(VWE.LOCATION_NAME, 'Без Площадки') LOCATION_CAPTION,
          DECODE(NVL(I_PROJECT_GROUP, 2), 0, SQP.PROJECTS, STT.PROJECT_NAME) PROJECT_NAME,
          ROUND(SUM(STT.TAB_TIME)/3600, 2) DAY_TIME
        FROM SQ_TAB_TIME STT
          LEFT JOIN SQ_PROJECTS SQP
            ON SQP.MON=TO_CHAR(STT.START_RANGE, 'MM/YYYY')
            AND SQP.LOGIN=STT.LOGIN
          LEFT JOIN VW_EMPLOYEES VWE
            ON VWE.LOGIN = STT.LOGIN
            AND VWE.FID_PLATFORM = STT.FID_PLATFORM
        WHERE STT.TAB_TIME > 0
          AND NVL2(I_ROLETYPE, STT.ROLETYPE, '*') = NVL(I_ROLETYPE, '*')
          AND NVL(VWE.LOCATION_NAME,'*') IN (SELECT NVL(LOCATION_CAPTION,'*') FROM SQ_LOGINS)
        GROUP BY EXTRACT(DAY FROM STT.START_RANGE), TO_CHAR(STT.START_RANGE, 'MM/YYYY'),
          DECODE(NVL(I_PROJECT_GROUP, 2), 0, STT.LOGIN, 'Все логины'),
          VWE.LOCATION_NAME,
          DECODE(NVL(I_PROJECT_GROUP, 2), 0, SQP.PROJECTS, STT.PROJECT_NAME)
      )
    SELECT LOGIN, FIO, LOCATION_CAPTION, WORK_MONTH, PROJECT_NAME, DAY_1, DAY_2, DAY_3,
      DAY_4, DAY_5, DAY_6, DAY_7, DAY_8, DAY_9, DAY_10, DAY_11, DAY_12, DAY_13, DAY_14,
      DAY_15, DAY_16, DAY_17, DAY_18, DAY_19, DAY_20, DAY_21, DAY_22, DAY_23, DAY_24,
      DAY_25, DAY_26, DAY_27, DAY_28, DAY_29, DAY_30, DAY_31, DAY_SUM
    FROM
    (
      SELECT DAY_NUM, WORK_MONTH, LOGIN, FIO, PROJECT_NAME, DAY_TIME, LOCATION_CAPTION
      FROM SQ_DATA
      UNION ALL
      (
        SELECT 32, WORK_MONTH, LOGIN, FIO, PROJECT_NAME, SUM(DAY_TIME), LOCATION_CAPTION
        FROM SQ_DATA
        GROUP BY WORK_MONTH, LOGIN, FIO, PROJECT_NAME, LOCATION_CAPTION
      )
    )
    PIVOT
    (
      MAX(DAY_TIME) FOR DAY_NUM IN
                        (
                          1 AS DAY_1, 2 AS DAY_2, 3 AS DAY_3, 4 AS DAY_4,
                          5 AS DAY_5, 6 AS DAY_6, 7 AS DAY_7, 8 AS DAY_8,
                          9 AS DAY_9, 10 AS DAY_10, 11 AS DAY_11, 12 AS DAY_12,
                          13 AS DAY_13, 14 AS DAY_14, 15 AS DAY_15, 16 AS DAY_16,
                          17 AS DAY_17, 18 AS DAY_18, 19 AS DAY_19, 20 AS DAY_20,
                          21 AS DAY_21, 22 AS DAY_22, 23 AS DAY_23, 24 AS DAY_24,
                          25 AS DAY_25, 26 AS DAY_26, 27 AS DAY_27, 28 AS DAY_28,
                          29 AS DAY_29, 30 AS DAY_30, 31 AS DAY_31, 32 AS DAY_SUM
                        )
    )
    ORDER BY WORK_MONTH, LOCATION_CAPTION, FIO, PROJECT_NAME
  )
  LOOP
    PIPE ROW(TR_REPORT_TIMESHEET(
              GET_DATA.LOGIN,
              GET_DATA.FIO,
              GET_DATA.LOCATION_CAPTION,
              GET_DATA.WORK_MONTH,
              GET_DATA.PROJECT_NAME,
              GET_DATA.DAY_1,
              GET_DATA.DAY_2,
              GET_DATA.DAY_3,
              GET_DATA.DAY_4,
              GET_DATA.DAY_5,
              GET_DATA.DAY_6,
              GET_DATA.DAY_7,
              GET_DATA.DAY_8,
              GET_DATA.DAY_9,
              GET_DATA.DAY_10,
              GET_DATA.DAY_11,
              GET_DATA.DAY_12,
              GET_DATA.DAY_13,
              GET_DATA.DAY_14,
              GET_DATA.DAY_15,
              GET_DATA.DAY_16,
              GET_DATA.DAY_17,
              GET_DATA.DAY_18,
              GET_DATA.DAY_19,
              GET_DATA.DAY_20,
              GET_DATA.DAY_21,
              GET_DATA.DAY_22,
              GET_DATA.DAY_23,
              GET_DATA.DAY_24,
              GET_DATA.DAY_25,
              GET_DATA.DAY_26,
              GET_DATA.DAY_27,
              GET_DATA.DAY_28,
              GET_DATA.DAY_29,
              GET_DATA.DAY_30,
              GET_DATA.DAY_31,
              GET_DATA.DAY_SUM)
            );
  END LOOP;

END FNC_REPORT_TIMESHEET_EL;
/

