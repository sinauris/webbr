create FUNCTION WFM_STATUSES (strt in timestamp, fnsh in timestamp)
RETURN wfm_type_status_table
AS
ahtt wfm_type_status_table;
BEGIN
if fnsh - INTERVAL '1510' MINUTE <= strt
then
    if fnsh>current_timestamp
    then
  SELECT wfm_type_status
        (
                aa.oper_login
            ,   aa.time_from
            ,   aa.state
            ,   aa.substate
        )
BULK COLLECT INTO ahtt
FROM
( 
    with bad_statuses as (Select 
                                    entered
                                ,   login
                                ,   status
                                ,   leaved 
from STATUS_CHANGES 
where 
            status in ('away','dnd', 'custom1','custom2', 'custom3')
        and entered between strt and fnsh+interval '1' hour
                        ),
logins as   (select login from mv_employee),

preagr as(  Select  
                sc.entered
            ,   sc.login
            ,   sc.status
            ,   sc.leaved
            ,   dur.entered          as not_shows
            ,   disturb.entered      as disturb_entered
            ,   inmiddle.leaved      as inmiddle_leaved
from STATUS_CHANGES sc
join logins 
    on
        sc.login=logins.login
left JOIN bad_statuses dur 
    on
            dur.login=sc.login
        and (dur.entered<=sc.entered and dur.leaved>sc.leaved)
left join bad_statuses disturb 
    on
            disturb.login=sc.login
        and (disturb.entered>=sc.entered and disturb.entered<sc.leaved)
left join bad_statuses inmiddle 
    on
            inmiddle.login=sc.login
        and (inmiddle.entered<sc.entered and sc.entered<inmiddle.leaved and sc.leaved>=inmiddle.leaved)
where 
        sc.entered between strt and fnsh
    and sc.STATUS not in ('speaking','ringing','wrapup', 'notavailable', 'available')
    and duration>=1)

select 
            preagr.login                                        as oper_login
        ,   coalesce(inmiddle_leaved,preagr.entered)            as time_from
        ,   case when preagr.status in ('dnd', 'away', 'accident',
                                     'standoff', 'custom1', 
                                     'custom2', 'custom3')
                 then 2 
                 when preagr.status='offline' 
                 then 0
                 else 1 end                                     as state
        ,   preagr.status                                       as substate
from preagr                      
where  
    preagr.not_shows is null
union all
select      cs.login
        ,   cs.entered
        ,   case when cs.status in ('dnd', 'away', 'accident',
                                     'standoff', 'custom1', 
                                     'custom2', 'custom3')
                 then 2 
                 when cs.status='offline' 
                 then 0
                 else 1 end                                     as state
        ,   cs.status 
from cur_statuses cs
join logins 
    on 
        cs.login = logins.login
where 
    cs.STATUS not in ('speaking','ringing','wrapup', 'notavailable', 'available'))aa;
return ahtt;

    else
SELECT wfm_type_status
        (
                aa.oper_login
            ,   aa.time_from
            ,   aa.state
            ,   aa.substate
        )
BULK COLLECT INTO ahtt
FROM
(with bad_statuses as 
        (Select 
            entered,
            login,
            status,
            leaved 
        from STATUS_CHANGES 
        where 
                status in ('away','dnd', 'custom1','custom2', 'custom3')
            and entered between strt and fnsh+interval '1' hour),

logins as (select login from mv_employee),

preagr as(
Select      sc.entered
        ,   sc.login
        ,   sc.status
        ,   sc.leaved
        ,   dur.entered         as not_shows
        ,   disturb.entered     as disturb_entered
        ,   inmiddle.leaved     as inmiddle_leaved
from STATUS_CHANGES sc
join logins 
    on 
        sc.login=logins.login
left JOIN bad_statuses dur 
    on
            dur.login=sc.login
        and (dur.entered<=sc.entered and dur.leaved>sc.leaved)
left join bad_statuses disturb 
    on
            disturb.login=sc.login
        and (disturb.entered>=sc.entered and disturb.entered<sc.leaved)
left join bad_statuses inmiddle 
    on
            inmiddle.login=sc.login
        and (inmiddle.entered<sc.entered and sc.entered<inmiddle.leaved and sc.leaved>=inmiddle.leaved)
        
where 
        sc.entered between strt and fnsh
    and sc.STATUS not in ('speaking','ringing','wrapup', 'notavailable', 'available')
    and duration>=1)

select 
            preagr.login                                            as oper_login
        ,
            coalesce(inmiddle_leaved,preagr.entered)                as time_from
        ,   case when preagr.status in ('dnd', 'away', 'accident',
                                     'standoff', 'custom1', 
                                     'custom2', 'custom3')
                 then 2 
                 when preagr.status='offline' 
                 then 0
                 else 1 end                                         as state
        ,   preagr.status                                           as substate
                 from preagr 
where  
    preagr.not_shows is null) aa;
           return ahtt;
    end if;
else return null;
end if;
END WFM_STATUSES;
/

