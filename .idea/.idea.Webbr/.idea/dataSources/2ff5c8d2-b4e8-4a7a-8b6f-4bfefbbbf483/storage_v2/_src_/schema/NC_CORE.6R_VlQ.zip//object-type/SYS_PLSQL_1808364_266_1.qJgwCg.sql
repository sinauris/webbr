create type           SYS_PLSQL_1808364_266_1 as table of "NC_CORE"."SYS_PLSQL_1808364_187_1";
/

