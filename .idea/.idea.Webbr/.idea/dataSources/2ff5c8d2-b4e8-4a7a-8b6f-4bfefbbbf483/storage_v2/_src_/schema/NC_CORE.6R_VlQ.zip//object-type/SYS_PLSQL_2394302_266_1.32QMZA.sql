create type           SYS_PLSQL_2394302_266_1 as table of "NC_CORE"."SYS_PLSQL_2394302_249_1";
/

