create FUNCTION wfm_projects
RETURN wfm_type_project_table
AS
V_Test wfm_type_project_table;
BEGIN
SELECT wfm_type_project
		( 
		tt.project_id,   
		tt.project_name, 
		tt.project_state, 
		tt.project_type
		)
BULK COLLECT INTO V_Test
FROM
	(
	select          
		        micp.uuid       	                            as  project_id,
                micp.title    	                                as  project_name,
                case
                    when micp.removed=1 
                    then 2
                    when micp.removed=0 
                        and mci0.CODE='BLOCKED'
                    then 1
                    else 0 	end                                 as  project_state,
                tcpb.DATACHANNEL 			                    as  project_type
	from    
		mv_incoming_call_project micp
	join    tbl_call_project_base tcpb 
	on 
		micp.uuid =tcpb.UUID
    left join MV_CATALOG_ITEM mci0 
    on
        micp.STATEUUID=mci0.UUID
	where           
		tcpb.DATACHANNEL!='autoinformer'
	union   all
	select          
		        mv_outcoming_call_project.uuid       	    as  project_id,
                mv_outcoming_call_project.title    	        as  project_name,
                case
                    when mv_outcoming_call_project.removed=1 
                    then 2
                    when mv_outcoming_call_project.removed=0 
                        and mci3.CODE='BLOCKED'
                    then 1
                    else 0 	end                             as  project_state,
                tcpb.DATACHANNEL 			                as  project_type
	from            
		MV_OUTCOMING_CALL_PROJECT
	join    tbl_call_project_base tcpb 
	on 
		mv_outcoming_call_project.uuid =tcpb.UUID
	join    TBL_OUTCOMING_CALL_PROJECT tocp 
	on  
		mv_outcoming_call_project.uuid =tocp.UUID
	left join  MV_CATALOG_ITEM mci 
	on 
		tocp.DIALINGMODE=mci.UUID
    left join MV_CATALOG_ITEM mci2
    on
            tocp.OUTCALLTYPE=mci2.UUID
    left join MV_CATALOG_ITEM mci3
    on
        mv_outcoming_call_project.STATEUUID=mci3.UUID
    where
                mci2.CODE!='semi-automatic'
            	and tcpb.DATACHANNEL!='autoinformer'
            	and tcpb.DATACHANNEL!='mailing'
            	and mci.CODE!='progressive'
            	and mci.CODE!='progressive_qpm') tt;
RETURN V_Test;
END;
/

