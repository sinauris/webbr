create Function Num2Hex (N In Number) Return Varchar2 Is
  H   Varchar2(128) := '';
  N1 Number           := 0;
  N2 Number           := 0;
Begin
N1 := N;

Loop
       Exit When N1 = 0;
       N2 := N1 - Trunc(N1 / 16, 0) * 16;
       N1 := Trunc(N1 / 16, 0);
       Select SubStr('0123456789ABCDEF', N2 + 1, 1)||H Into H From DUAL;
End Loop;

Select Decode(Length(H),
1,'00000000000000000'||H,
2,'0000000000000000'||H,
3,'000000000000000'||H,
4,'00000000000000'||H,
5,'0000000000000'||H,
6,'000000000000'||H,
7,'00000000000'||H,
8,'0000000000'||H,
9,'000000000'||H,
10,'00000000'||H,
11,'0000000'||H,
12,'000000'||H,
13,'00000'||H,
14,'0000'||H,
15,'000'||H,
16,'00'||H,
17,'0'||H,
H
) Into H From DUAL;

Return H;
End Num2Hex;
/

