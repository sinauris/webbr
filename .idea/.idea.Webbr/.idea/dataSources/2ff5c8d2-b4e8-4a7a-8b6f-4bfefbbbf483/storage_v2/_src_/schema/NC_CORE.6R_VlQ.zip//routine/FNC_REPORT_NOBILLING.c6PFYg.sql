create FUNCTION FNC_REPORT_NOBILLING
(
  I_DATE_START TIMESTAMP,
  I_DATE_END TIMESTAMP
) RETURN T_REPORT_NOBBILLING PIPELINED AS

BEGIN

  FOR GET_DATA IN
  (
    SELECT cs.SESSION_ID, cs.DIRECTION, cs.CREATED, cs.ENDED,
          DECODE(cs.DIRECTION, 'IN', ci.ABONENT, ci.OPERATOR) RING_FROM,
          DECODE(cs.DIRECTION, 'IN', ci.CALLED, ci.ABONENT) RING_TO,
          ci.IP_ADDRESS, ci.PORT, dp.NAME PROVIDER_NAME,
          CASE WHEN ci.FID_PROVIDER = 0 THEN 'Не определен провайдер'
               WHEN ci.FID_AREA = 0 THEN CASE WHEN cs.DIRECTION = 'IN'
                                                AND NOT (SUBSTR(ci.CALLED,0,1) = '8' AND LENGTH(ci.CALLED) = 11 OR SUBSTR(ci.CALLED,0,3) = '810' AND LENGTH(ci.CALLED) > 11 )
                                              THEN 'Вызываемый номер не соответствует шаблону нормализации'
                                              WHEN cs.DIRECTION = ANY('OUT', 'DIALER')
                                                AND NOT (SUBSTR(ci.ABONENT,0,1) = '8' AND LENGTH(ci.ABONENT) = 11 OR SUBSTR(ci.ABONENT,0,3) = '810' AND LENGTH(ci.ABONENT) > 11 )
                                              THEN 'Вызываемый номер не соответствует шаблону нормализации'
                                              ELSE 'Не определено направление (нет тарифа)'
                                         END
          END REASON
    FROM CALLS_INFO ci
    JOIN CALL_SESSIONS cs
      ON cs.SESSION_ID = ci.SESSION_ID
      AND cs.FID_PLATFORM = ci.FID_PLATFORM
    LEFT JOIN D_PROVIDERS dp
      ON dp.ID_PROVIDER = ci.FID_PROVIDER
    LEFT JOIN D_RATES dr
      ON dr.ID_RATE = ci.FID_AREA
    WHERE cs.CREATED BETWEEN I_DATE_START AND I_DATE_END
      AND ci.IP_ADDRESS != '0'
      AND ci.COST IS NULL
      AND ci.CALLED NOT LIKE '%intrusion%'
      AND (ci.IVR_CONNECTED IS NOT NULL
        OR ci.OPERATOR_CONNECTED IS NOT NULL)
    ORDER BY cs.CREATED, cs.ENDED
  )
  LOOP
    PIPE ROW(TR_REPORT_NOBBILLING(
              GET_DATA.SESSION_ID,
              GET_DATA.DIRECTION,
              GET_DATA.CREATED,
              GET_DATA.ENDED,
              GET_DATA.RING_FROM,
              GET_DATA.RING_TO,
              GET_DATA.IP_ADDRESS,
              GET_DATA.PORT,
              GET_DATA.PROVIDER_NAME,
              GET_DATA.REASON
              ));
  END LOOP;
END FNC_REPORT_NOBILLING;
/

