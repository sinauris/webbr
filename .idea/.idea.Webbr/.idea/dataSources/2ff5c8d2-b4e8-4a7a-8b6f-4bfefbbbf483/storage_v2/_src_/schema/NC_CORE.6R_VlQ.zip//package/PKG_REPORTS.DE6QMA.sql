create PACKAGE PKG_REPORTS AS
/*
------------------------------ФУНКЦИИ ДЛЯ ФИЛЬТРОВ------------------------------
  FNC_LOCATION_LIST - список всех зарегистрированных площадок. I_INCLUDE_ALL указывет на необходимость включать пункт "Все площадки"
  FNC_PROJECTS_LIST - список всех зарегистрированных проектов. I_INCLUDE_ALL указывет на необходимость включать пункт "Все проекты"
  FNC_REPORT_UR_OCC - отчет по UR и OCC
*/
  --Типы списка зарегистрованных площадок
  TYPE PTR_LOCATION_LIST IS RECORD(LOCATION_ID VARCHAR2(255 CHAR), LOCATION_NAME VARCHAR2(100 CHAR));
  TYPE PT_LOCATION_LIST IS TABLE OF PTR_LOCATION_LIST;
  --Получение списка зарегистрированных площадок
  FUNCTION FNC_LOCATION_LIST(I_INCLUDE_ALL CHAR DEFAULT 'Y') RETURN PT_LOCATION_LIST PIPELINED;

  --Типы списка зарегистрованных операторов
  TYPE PTR_EMPLOYEES_LIST IS RECORD(LOGIN VARCHAR2(50 CHAR), FIO VARCHAR2(1000 CHAR));
  TYPE PT_EMPLOYEES_LIST IS TABLE OF PTR_EMPLOYEES_LIST;
  --Получение списка зарегистрированных операторов
  FUNCTION FNC_EMPLOYEES_LIST(I_INCLUDE_ALL CHAR DEFAULT 'Y',
                              I_VIEW_LOGIN CHAR DEFAULT 'Y',
                              I_DATE_START TIMESTAMP DEFAULT NULL, --Дата начала отбора
                              I_DATE_END TIMESTAMP DEFAULT NULL, --Дата окончания отбора
                              I_PROJECT VARCHAR2 DEFAULT NULL, --Проект/группа проектов
                              I_LOCATION VARCHAR2 DEFAULT NULL) --Call-центр/площадка
    RETURN PT_EMPLOYEES_LIST PIPELINED;

  --Типы списка зарегистрованных проектов
  TYPE PTR_PROJECTS_LIST IS RECORD(PROJECT_ID VARCHAR2(2000 CHAR), PROJECT_NAME VARCHAR2(100 CHAR));
  TYPE PT_PROJECTS_LIST IS TABLE OF PTR_PROJECTS_LIST;
  --Получение списка зарегистрированных проектов
  FUNCTION FNC_PROJECTS_LIST (I_INCLUDE_ALL CHAR DEFAULT 'Y',
                              I_DIRECTION VARCHAR2 DEFAULT NULL,
                              I_PLATFORM NUMBER DEFAULT NULL,
                              I_ACTIVE NUMBER DEFAULT 1,
                              I_PROJECTS_GROUP VARCHAR2 DEFAULT NULL)
    RETURN PT_PROJECTS_LIST PIPELINED;

  --Типы списка зарегистрованных поставщиков связи
  TYPE PTR_PROVIDERS_LIST IS RECORD(PROVIDER_ID VARCHAR2(2000 CHAR), PROVIDER_NAME VARCHAR2(100 CHAR));
  TYPE PT_PROVIDERS_LIST IS TABLE OF PTR_PROVIDERS_LIST;
  --Получение списка зарегистрированных поставщиков связи
  FUNCTION FNC_PROVIDERS_LIST (I_INCLUDE_ALL CHAR DEFAULT 'Y')
    RETURN PT_PROVIDERS_LIST PIPELINED;

--------------------------------------------------------------------------------
----------------------------АДМИНИСТРАТИВНЫЕ ОТЧЕТЫ-----------------------------
--------------------------------------------------------------------------------
  --Типы для табеля
  TYPE PTR_REPORT_TIMESHEET IS RECORD(LOGIN VARCHAR2(50 CHAR),
                                      FIO VARCHAR2(250 CHAR),
                                      LOCATION_CAPTION VARCHAR2(100 CHAR),
                                      WORK_MONTH VARCHAR2(7 CHAR),
                                      PROJECT_NAME VARCHAR2(2000 CHAR),
                                      DAY_1 NUMBER(20,2),
                                      DAY_2 NUMBER(20,2),
                                      DAY_3 NUMBER(20,2),
                                      DAY_4 NUMBER(20,2),
                                      DAY_5 NUMBER(20,2),
                                      DAY_6 NUMBER(20,2),
                                      DAY_7 NUMBER(20,2),
                                      DAY_8 NUMBER(20,2),
                                      DAY_9 NUMBER(20,2),
                                      DAY_10 NUMBER(20,2),
                                      DAY_11 NUMBER(20,2),
                                      DAY_12 NUMBER(20,2),
                                      DAY_13 NUMBER(20,2),
                                      DAY_14 NUMBER(20,2),
                                      DAY_15 NUMBER(20,2),
                                      DAY_16 NUMBER(20,2),
                                      DAY_17 NUMBER(20,2),
                                      DAY_18 NUMBER(20,2),
                                      DAY_19 NUMBER(20,2),
                                      DAY_20 NUMBER(20,2),
                                      DAY_21 NUMBER(20,2),
                                      DAY_22 NUMBER(20,2),
                                      DAY_23 NUMBER(20,2),
                                      DAY_24 NUMBER(20,2),
                                      DAY_25 NUMBER(20,2),
                                      DAY_26 NUMBER(20,2),
                                      DAY_27 NUMBER(20,2),
                                      DAY_28 NUMBER(20,2),
                                      DAY_29 NUMBER(20,2),
                                      DAY_30 NUMBER(20,2),
                                      DAY_31 NUMBER(20,2),
                                      DAY_SUM NUMBER(20,2));
  TYPE PT_REPORT_TIMESHEET IS TABLE OF PTR_REPORT_TIMESHEET;

  --Отчет "Табель учета рабочего времени"
  FUNCTION FNC_REPORT_TIMESHEET (
                                  I_DATE_START TIMESTAMP,
                                  I_DATE_END TIMESTAMP,
                                  I_PROJECT VARCHAR2 DEFAULT NULL,
                                  I_PROJECT_GROUP NUMBER DEFAULT 2,
                                  I_LOCATION VARCHAR2 DEFAULT NULL,
                                  I_LOGIN VARCHAR2 DEFAULT NULL,
                                  I_ROLETYPE VARCHAR2 DEFAULT 'operator',
                                  I_PLATFORMS VARCHAR2 DEFAULT NULL
                                )
    RETURN PT_REPORT_TIMESHEET PIPELINED;

  --Типы для времени пребывания операторов в определённых состояниях
  TYPE PTR_REPORT_STATUS_CHANGES IS RECORD(
                                            LOGIN VARCHAR2(50 CHAR),
                                            FIO VARCHAR2(250 CHAR),
                                            STATUS_ENTERED VARCHAR2(20 CHAR),
                                            STATUS VARCHAR2(50 CHAR),
                                            CAPTION VARCHAR2(150 CHAR),
                                            DURATION NUMBER
                                          );
  TYPE PT_REPORT_STATUS_CHANGES IS TABLE OF PTR_REPORT_STATUS_CHANGES;

  --Отчет "Время пребывания операторов в определённых состояниях"
  FUNCTION FNC_REPORT_STATUS_CHANGES(
                                      I_DATE_START TIMESTAMP,
                                      I_DATE_END TIMESTAMP,
                                      I_PROJECT VARCHAR2 DEFAULT NULL,
                                      I_PROJECT_GROUP NUMBER DEFAULT 2,
                                      I_LOGIN VARCHAR2 DEFAULT NULL,
                                      I_PLATFORMS VARCHAR2 DEFAULT NULL
                                    )
    RETURN PT_REPORT_STATUS_CHANGES PIPELINED;

  --Типы для времени пребывания операторов в определённых состояниях суммарно
  TYPE PTR_REPORT_STATUS_CHANGES_SUM IS RECORD(
                                                LOCATION_CAPTION VARCHAR2(100 CHAR),
                                                PROJECT_NAME VARCHAR2(150 CHAR),
                                                LOGIN VARCHAR2(50 CHAR),
                                                FULL_RANGE VARCHAR2(40 CHAR),
                                                STATUS VARCHAR2(50 CHAR),
                                                CAPTION VARCHAR2(150 CHAR),
                                                DURATION NUMBER
                                              );
  TYPE PT_REPORT_STATUS_CHANGES_SUM IS TABLE OF PTR_REPORT_STATUS_CHANGES_SUM;

  --Отчет "Время пребывания операторов в определённых состояниях суммарно"
  FUNCTION FNC_REPORT_STATUS_CHANGES_SUM(
                                          I_DATE_START TIMESTAMP,
                                          I_DATE_END TIMESTAMP,
                                          I_STEP_TYPE VARCHAR2,
                                          I_PROJECT VARCHAR2 DEFAULT NULL,
                                          I_PROJECT_GROUP NUMBER DEFAULT 2,
                                          I_LOCATION VARCHAR2 DEFAULT NULL,
                                          I_LOCATION_GROUP NUMBER DEFAULT 2,
                                          I_LOGIN_GROUP CHAR DEFAULT 'Y',
                                          I_PLATFORMS VARCHAR2 DEFAULT NULL
                                        )
    RETURN PT_REPORT_STATUS_CHANGES_SUM PIPELINED;

  --Типы для переключения статусов
  TYPE PTR_REPORT_STATUS_CHANGES_LOG IS RECORD(
                                                LOGIN VARCHAR2(50 CHAR),
                                                FIO VARCHAR2(250 CHAR),
                                                STATUS_ENTERED VARCHAR2(20 CHAR),
                                                STATUS VARCHAR2(50 CHAR),
                                                CAPTION VARCHAR2(150 CHAR),
                                                DURATION NUMBER);
  TYPE PT_REPORT_STATUS_CHANGES_LOG IS TABLE OF PTR_REPORT_STATUS_CHANGES_LOG;

  --Отчет "Статистика по call-центру. Переключения статусов у операторов"
  FUNCTION FNC_REPORT_STATUS_CHANGES_LOG(
                                          I_DATE_START TIMESTAMP,
                                          I_DATE_END TIMESTAMP,
                                          I_PROJECT VARCHAR2 DEFAULT NULL,
                                          I_LOGIN VARCHAR2 DEFAULT NULL,
                                          I_PLATFORMS VARCHAR2 DEFAULT NULL
                                        )
    RETURN PT_REPORT_STATUS_CHANGES_LOG PIPELINED;

  --Типы для загрузки Call-центра по проектам
  TYPE PTR_REPORT_PROJECT_CC_LOAD IS RECORD (
                                              START_RANGE TIMESTAMP,
                                              PROJECT_NAME VARCHAR2(150 CHAR),
                                              FULL_RANGE VARCHAR2(50 CHAR),
                                              UNIC_LOGIN VARCHAR2(80 CHAR),
                                              ALOGIN VARCHAR2(100 CHAR),
                                              PROJECT_WT VARCHAR2(60 CHAR),
                                              G1 NUMBER,
                                              G2 NUMBER
                                            );
  TYPE PT_REPORT_PROJECT_CC_LOAD IS TABLE OF PTR_REPORT_PROJECT_CC_LOAD;

  --Отчет "Загрузки Call-центра по проектам"
  FUNCTION FNC_REPORT_PROJECT_CC_LOAD(
                                          I_DATE_START TIMESTAMP,
                                          I_DATE_END TIMESTAMP,
                                          I_STEP_TYPE VARCHAR2 DEFAULT 'DD',
                                          I_PROJECT VARCHAR2 DEFAULT NULL,
                                          I_PROJECT_GROUP NUMBER DEFAULT 2,
                                          I_LOCATION VARCHAR2 DEFAULT NULL,
                                          I_PLATFORMS VARCHAR2 DEFAULT NULL
                                        )
    RETURN PT_REPORT_PROJECT_CC_LOAD PIPELINED;

  --Типы для отчета по UR и ОСС
  TYPE PTR_REPORT_UR_OCC IS RECORD(
                                    FULL_RANGE VARCHAR2(100 CHAR),
                                    CC_CAPTION VARCHAR2(30 CHAR),
                                    LOCATION_CAPTION VARCHAR2(30 CHAR),
                                    PROJECT_NAME VARCHAR2(150 CHAR),
                                    PARAM_TYPE VARCHAR2(3 CHAR),
                                    H0 NUMBER,
                                    H1 NUMBER,
                                    H2 NUMBER,
                                    H3 NUMBER,
                                    H4 NUMBER,
                                    H5 NUMBER,
                                    H6 NUMBER,
                                    H7 NUMBER,
                                    H8 NUMBER,
                                    H9 NUMBER,
                                    H10 NUMBER,
                                    H11 NUMBER,
                                    H12 NUMBER,
                                    H13 NUMBER,
                                    H14 NUMBER,
                                    H15 NUMBER,
                                    H16 NUMBER,
                                    H17 NUMBER,
                                    H18 NUMBER,
                                    H19 NUMBER,
                                    H20 NUMBER,
                                    H21 NUMBER,
                                    H22 NUMBER,
                                    H23 NUMBER,
                                    HSUM NUMBER
                                  );
  TYPE PT_REPORT_UR_OCC IS TABLE OF PTR_REPORT_UR_OCC;

  --Отчет "по UR и ОСС"
  FUNCTION FNC_REPORT_UR_OCC(
                              I_DATE_START TIMESTAMP,
                              I_DATE_END TIMESTAMP,
                              I_STEP_TYPE VARCHAR2 DEFAULT 'DD',
                              I_PROJECT VARCHAR2 DEFAULT NULL,
                              I_PROJECT_GROUP NUMBER DEFAULT 2,
                              I_LOCATION VARCHAR2 DEFAULT NULL,
                              I_LOCATION_GROUP NUMBER DEFAULT 2,
                              I_PLATFORMS VARCHAR2 DEFAULT NULL
                            )
    RETURN PT_REPORT_UR_OCC PIPELINED;

  --Типы для отчета по состоянию по выбранному пользователю
  TYPE PTR_REPORT_OPERATOR_STATES IS RECORD (
                                              LOGIN VARCHAR2(70 CHAR),
                                              NAU_STATUS MV_STATUSES.NAU_STATUS%TYPE,
                                              STATUS_DURATION VARCHAR2(20)
                                            );
  TYPE PT_REPORT_OPERATOR_STATES IS TABLE OF PTR_REPORT_OPERATOR_STATES;

  --Отчет "Состояния по выбранному пользователю"
  FUNCTION FNC_REPORT_OPERATOR_STATES (
                                        I_DATE_START TIMESTAMP,
                                        I_DATE_END TIMESTAMP,
                                        I_LOGIN VARCHAR2 DEFAULT NULL,
                                        I_STATUS VARCHAR2 DEFAULT NULL,
                                        I_PLATFORMS VARCHAR2 DEFAULT NULL
                                      )
    RETURN PT_REPORT_OPERATOR_STATES PIPELINED;

  --Типы для отчета по времени входа в NAUMEN
  TYPE PTR_REPORT_LOGON_TIME IS RECORD(
                                        LOGIN VARCHAR2(70 CHAR),
                                        NAU_LOGON TIMESTAMP,
                                        NAU_LOGOUT TIMESTAMP
                                      );
  TYPE PT_REPORT_LOGON_TIME IS TABLE OF PTR_REPORT_LOGON_TIME;

  --Отчет "Время входа в наумен"
  FUNCTION FNC_REPORT_LOGON_TIME(
                                  I_DATE_START TIMESTAMP,
                                  I_DATE_END TIMESTAMP,
                                  I_PLATFORMS VARCHAR2 DEFAULT NULL
                                )
    RETURN PT_REPORT_LOGON_TIME PIPELINED;

  --Типы для операторов с последней датой звонка
  TYPE PTR_REPORT_OPR_WITH_LAST_DATE IS RECORD (LOGIN VARCHAR2(50 CHAR),
                                                RING_DATE VARCHAR2(20 CHAR),
                                                PROJECT_NAME VARCHAR2(255 CHAR));
  TYPE PT_REPORT_OPR_WITH_LAST_DATE IS TABLE OF PTR_REPORT_OPR_WITH_LAST_DATE;

  --Отчет по операторам с последней датой звонка меньше заданной
  FUNCTION FNC_REPORT_OPR_WITH_LAST_DATE (I_DATE_LAST TIMESTAMP,
                                          I_PLATFORMS VARCHAR2 DEFAULT NULL)
    RETURN PT_REPORT_OPR_WITH_LAST_DATE PIPELINED;

--------------------------------------------------------------------------------
--------------------------------ВХОДЯЩАЯ ЛИНИЯ----------------------------------
--------------------------------------------------------------------------------
  --Типы для входящих вызовов по проекту
  TYPE PTR_REPORT_PROJECT_INCCALL IS RECORD (
                                              PROJECT_NAME VARCHAR2(150 CHAR),
                                              FID_PROJECT VARCHAR2(150 CHAR),
                                              SESSION_ID VARCHAR2(200 CHAR),
                                              ABONENT VARCHAR2(50 CHAR),
                                              CALLED VARCHAR2(50 CHAR),
                                              START_CALL_TIME TIMESTAMP,
                                              OPERATOR_CONNECTED TIMESTAMP,
                                              BREAK_CALL_TIME TIMESTAMP,
                                              CALL_TIME NUMBER,
                                              LINK_ID NUMBER,
                                              OPERATOR VARCHAR2(50 CHAR),
                                              CALL_RESULT VARCHAR2(50 CHAR),
                                              REDIRECT_NUM VARCHAR2(150 CHAR),
                                              WAIT_TIME NUMBER,
                                              REACTION_TIME NUMBER,
                                              SPEAK_TIME NUMBER,
                                              OPERATOR_WRAPUP NUMBER,
                                              OPERATOR_HOLD NUMBER,
                                              SERVICE_TIME_MINC NUMBER,
                                              CALL_TYPE VARCHAR2(40 CHAR)
                                            );
  TYPE PT_REPORT_PROJECT_INCCALL IS TABLE OF PTR_REPORT_PROJECT_INCCALL;

  --Отчет "Входящие вызовы по проекту"
  FUNCTION FNC_REPORT_PROJECT_INCCALL (
                                        I_DATE_START TIMESTAMP,
                                        I_DATE_END TIMESTAMP,
                                        I_PROJECT VARCHAR2 DEFAULT NULL,
                                        I_PLATFORMS VARCHAR2 DEFAULT NULL
                                      )
    RETURN PT_REPORT_PROJECT_INCCALL PIPELINED;

  --Типы для количества и результатов звонков по проектам входящей линии
  TYPE PTR_REPORT_PROJECT_INCCALLS IS RECORD(
                                              CALL_RESULT VARCHAR2(50 CHAR),
                                              SESSION_CNT NUMBER
                                            );
  TYPE PT_REPORT_PROJECT_INCCALLS IS TABLE OF PTR_REPORT_PROJECT_INCCALLS;

  --Отчет "Количество и результат звонков по проектам входящей линии"
  FUNCTION FNC_REPORT_PROJECT_INCCALLS(
                                        I_DATE_START TIMESTAMP,
                                        I_DATE_END TIMESTAMP,
                                        I_PROJECT VARCHAR2 DEFAULT NULL,
                                        I_PLATFORMS VARCHAR2 DEFAULT NULL
                                      )
    RETURN PT_REPORT_PROJECT_INCCALLS PIPELINED;

  --Типы для QualityReport
  TYPE PTR_REPORT_QUALITYREPORT IS RECORD (
                                            PROJECT_NAME VARCHAR2(150 CHAR),
                                            FID_PROJECT VARCHAR2(150 CHAR),
                                            FULL_RANGE VARCHAR2(40 CHAR),
                                            SESSION_CNT NUMBER,
                                            SERVICE_SESSION_CNT NUMBER,
                                            OPERATORS_CNT NUMBER,
                                            P_LOST_SESSIONS NUMBER,
                                            SL NUMBER,
                                            AVG_SPEAK_TIME NUMBER,
                                            REDIRECTED_CNT NUMBER,
                                            OPR_REDIRECTED_CNT NUMBER,
                                            SERVICE_SESSION_CNT20 NUMBER,
                                            SERVICE_SESSION_CNT40 NUMBER,
                                            LOST_SESSION_CNT NUMBER,
                                            LOST_SESSION_CNT20 NUMBER,
                                            LOST_SESSION_CNT40 NUMBER,
                                            LOST_SESSION_CNTM20 NUMBER,
                                            LOST_SESSION_CNTM40 NUMBER,
                                            P_LOST_SESSION_CNTM20 NUMBER,
                                            P_LOST_SESSION_CNTM40 NUMBER,
                                            P_LOST_SESSION_CNT20 NUMBER,
                                            P_LOST_SESSION_CNT40 NUMBER,
                                            ERR_SESSION_CNT NUMBER,
                                            OPR_CONNECTS5_CNT NUMBER,
                                            ASA NUMBER,
                                            LCW NUMBER,
                                            QUEUE_LENGTH NUMBER,
                                            ATA NUMBER,
                                            MATA NUMBER,
                                            ACW NUMBER,
                                            SUM_SPEAK_TIME NUMBER,
                                            SUM_OPERATOR_WRAPUP NUMBER,
                                            ART NUMBER,
                                            MRT NUMBER,
                                            AHT NUMBER,
                                            MHT NUMBER,
                                            SST NUMBER,
                                            CSST NUMBER,
                                            REDIRECTED_TIME NUMBER,
                                            MIN_QUEUE_LENGTH NUMBER,
                                            AVG_QUEUE_LENGTH NUMBER,
                                            MIN_QUEUE_TIME NUMBER,
                                            MAX_QUEUE_TIME NUMBER,
                                            AVG_QUEUE_TIME NUMBER,
                                            OPERATOR_HOLD NUMBER
                                          );
  TYPE PT_REPORT_QUALITYREPORT IS TABLE OF PTR_REPORT_QUALITYREPORT;

  --Отчет "QualityReport"
  FUNCTION FNC_REPORT_QUALITYREPORT (
                                      I_DATE_START TIMESTAMP,
                                      I_DATE_END TIMESTAMP,
                                      I_STEP_TYPE VARCHAR2 DEFAULT 'DD',
                                      I_PROJECT VARCHAR2 DEFAULT NULL,
                                      I_PROJECT_GROUP NUMBER DEFAULT 2,
                                      I_PLATFORMS VARCHAR2 DEFAULT NULL
                                    )
    RETURN PT_REPORT_QUALITYREPORT PIPELINED;

--------------------------------------------------------------------------------
--------------------------------ИСХОДЯЩАЯ ЛИНИЯ---------------------------------
--------------------------------------------------------------------------------
  --Типы для всех вызовов на заданный номер
  TYPE PTR_REPORT_CALL_TO_NUMBER IS RECORD(
                                            OPERATOR VARCHAR2(100 CHAR),
                                            CALL_NUMBER VARCHAR2(20 CHAR),
                                            CREATED TIMESTAMP,
                                            ENDED TIMESTAMP,
                                            CALL_DURATION VARCHAR2(10 CHAR),
                                            EXIT_CODE_DISCRIPTION VARCHAR2(50 CHAR),
                                            SESSION_ID VARCHAR2(150 CHAR)
                                          );
  TYPE PT_REPORT_CALL_TO_NUMBER IS TABLE OF PTR_REPORT_CALL_TO_NUMBER;

  --Отчет "Все вызовы на заданный номер"
  FUNCTION FNC_REPORT_CALL_TO_NUMBER(
                                      I_DATE_START TIMESTAMP,
                                      I_DATE_END TIMESTAMP,
                                      I_CALLER VARCHAR2 DEFAULT NULL,
                                      I_CALLED VARCHAR2 DEFAULT NULL,
                                      I_PLATFORMS VARCHAR2 DEFAULT NULL
                                    )
    RETURN PT_REPORT_CALL_TO_NUMBER PIPELINED;

  --Типы для исходящих вызовов по проекту
  TYPE PTR_REPORT_OUTGOING_PRJ IS RECORD(
                                          OPERATOR VARCHAR2(100 CHAR),
                                          CALL_NUMBER VARCHAR2(20 CHAR),
                                          CREATED TIMESTAMP,
                                          OPERATOR_CONNECTED TIMESTAMP,
                                          ENDED TIMESTAMP,
                                          CALL_DURATION VARCHAR2(10 CHAR),
                                          CALL_DURATION_M NUMBER,
                                          STATUS VARCHAR2(20 CHAR)
                                        );
  TYPE PT_REPORT_OUTGOING_PRJ IS TABLE OF PTR_REPORT_OUTGOING_PRJ;

  --Отчет "Исходящие вызовы по проекту"
  FUNCTION FNC_REPORT_OUTGOING_PRJ(
                                    I_DATE_START TIMESTAMP,
                                    I_DATE_END TIMESTAMP,
                                    I_PROJECT VARCHAR2 DEFAULT NULL,
                                    I_STATUS NUMBER DEFAULT NULL,
                                    I_PLATFORMS VARCHAR2 DEFAULT NULL
                                  )
    RETURN PT_REPORT_OUTGOING_PRJ PIPELINED;

  --Типы для исходящих вызовов по проекту (количество звонков)
  TYPE PTR_REPORT_OUTGOING_PRJ_CNT IS RECORD(
                                              CALL_NUMBER VARCHAR2(20 CHAR),
                                              STATUS VARCHAR2(20 CHAR),
                                              CALLS_CNT NUMBER
                                            );
  TYPE PT_REPORT_OUTGOING_PRJ_CNT IS TABLE OF PTR_REPORT_OUTGOING_PRJ_CNT;

  --Отчет "Исходящие вызовы по проекту (количество звонков)"
  FUNCTION FNC_REPORT_OUTGOING_PRJ_CNT(
                                        I_DATE_START TIMESTAMP,
                                        I_DATE_END TIMESTAMP,
                                        I_PROJECT VARCHAR2 DEFAULT NULL,
                                        I_STATUS NUMBER DEFAULT NULL,
                                        I_PLATFORMS VARCHAR2 DEFAULT NULL
                                      )
    RETURN PT_REPORT_OUTGOING_PRJ_CNT PIPELINED;

  --Типы для исходящих вызовов по направлениям
  TYPE PTR_REPORT_OUTGOING_AREAS IS RECORD(
                                            PROVIDER D_PROVIDERS.NAME%TYPE,
                                            DIRRECTION VARCHAR2(150 CHAR),
                                            CALC_MIN NUMBER,
                                            CALC_MIN_30 NUMBER,
                                            CALC_MIN_60 NUMBER
                                          );
  TYPE PT_REPORT_OUTGOING_AREAS IS TABLE OF PTR_REPORT_OUTGOING_AREAS;

  --Отчет "Исходящие вызовы по направлениям"
  FUNCTION FNC_REPORT_OUTGOING_AREAS(
                                      I_DATE_START TIMESTAMP,
                                      I_DATE_END TIMESTAMP,
                                      I_PROVIDER NUMBER DEFAULT NULL,
                                      I_CITY VARCHAR2 DEFAULT NULL,
                                      I_PLATFORMS VARCHAR2 DEFAULT NULL
                                    )
    RETURN PT_REPORT_OUTGOING_AREAS PIPELINED;

END PKG_REPORTS;
/

