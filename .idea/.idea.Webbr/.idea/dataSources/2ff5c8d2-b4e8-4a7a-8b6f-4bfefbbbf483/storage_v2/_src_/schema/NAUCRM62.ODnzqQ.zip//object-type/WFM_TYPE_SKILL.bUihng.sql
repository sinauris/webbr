create TYPE wfm_type_skill FORCE AS OBJECT
    (
    oper_login        VARCHAR2(100),
    project_id        VARCHAR2(64)
    );
/

