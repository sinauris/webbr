create PACKAGE BODY PKG_API_TEST AS

  --Выборка статусов операторов
  FUNCTION GET_STATUSES(I_DATE_START TIMESTAMP, --Дата начала отбора
                        I_DATE_END TIMESTAMP, --Дата окончания отбора
                        I_PROJECT VARCHAR2 DEFAULT NULL, --Проект/группа проектов
                        I_GROUP_PROJECTS_LEVEL NUMBER DEFAULT 2, --Уровень группировки проектов
                        I_LOGIN VARCHAR2 DEFAULT NULL, --Логин оператора
                        I_LOCATION VARCHAR2 DEFAULT NULL, --Call-центр/площадка
                        I_GROUP_LOCATION NUMBER DEFAULT 2, --Группировка по Call-центру/площадке
                        I_STEP NUMBER DEFAULT 1, --Длина шага разделения по времени
                        I_STEP_TYPE VARCHAR2 DEFAULT 'DD', --Тип шаг разделения по времени
                        I_STATUSES VARCHAR2 DEFAULT NULL, --Статусы
                        I_PLATFORMS VARCHAR2 DEFAULT NULL, --Платформы
                        I_ROLETYPE VARCHAR2 DEFAULT NULL, --Роль сотрудника (оператор, супервайзер, ...)
                        I_COMPRESS CHAR DEFAULT 'Y') --Убирать offline занимающие целый диапазон
    RETURN PT_STATUS_CHANGES  PIPELINED AS

    V_LOGINS VARCHAR2(2000 CHAR) := I_LOGIN;
    V_STATUSES T_LIST_VARCHAR DEFAULT NULL;

    CURSOR GET_DATA RETURN PTR_STATUS_CHANGES
    IS
    WITH SQ_RANGES AS
      (
        SELECT /*+ MATERIALIZE*/ START_RANGE, STOP_RANGE, PKG_INTERVALS.FNC_INTERVALTOSEC(START_RANGE, STOP_RANGE) AS RANGE_LENGTH
        FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(I_DATE_START, I_DATE_END, NVL(I_STEP, 1), NVL(I_STEP_TYPE, 'DD')))
      ),
      SQ_PROJECTS AS
      (
        SELECT /*+ MATERIALIZE*/ PROJECT_ID, PLATFORM_ID
        FROM TABLE(NC_CORE.PKG_API.GET_PROJECTS_IDS(I_PROJECT))
      ),
      SQ_LOGINS AS
      (
        SELECT /*+ MATERIALIZE*/ DISTINCT LOGIN, LAST_NAME, FIRST_NAME, MIDDLE_NAME,
          DECODE(NVL(I_GROUP_LOCATION, 2), 0, '{all}', CALL_CENTRE_NAME) AS CALL_CENTRE_NAME,
          DECODE(NVL(I_GROUP_LOCATION, 2), 2, LOCATION_NAME, '{all}') AS LOCATION_NAME, FID_PLATFORM
        FROM TABLE(NC_CORE.PKG_API.GET_EMPLOYEES_LOGINS(V_LOGINS)) TL
      ),
      SQ_FILTER_STATUSES_PRP AS
      (
        SELECT ID_STATUS, SYS_CONNECT_BY_PATH(TRIM('|' FROM LOWER(NAME||'|'||REASON)),'\')||'\' AS PATHS
        FROM D_STATUSES
        START WITH FID_STATUS = 0 AND ID_STATUS > 0
        CONNECT BY PRIOR ID_STATUS = FID_STATUS
      ),
      SQ_FILTER_STATUSES AS
      (
        SELECT /*+ MATERIALIZE*/ID_STATUS
        FROM SQ_FILTER_STATUSES_PRP SQFSP
        WHERE EXISTS(
                      SELECT 1
                      FROM TABLE(V_STATUSES) FS
                      WHERE INSTR(SQFSP.PATHS, '\'||LOWER(FS.COLUMN_VALUE)||'\') > 0
                    )
      ),
      SQ_GET_PROJECT_RATES AS
      (
        SELECT DISTINCT
          DECODE(NVL(I_GROUP_PROJECTS_LEVEL, 2), 2, GREATEST(DLR.REPORT_DATE, VRPE.ACTIVE_FROM), DLR.REPORT_DATE) AS ACTIVE_FROM,
          DECODE(NVL(I_GROUP_PROJECTS_LEVEL, 2), 2, LEAST(DLR.REPORT_DATE+1, VRPE.ACTIVE_TILL), DLR.REPORT_DATE+1) AS ACTIVE_TILL,
          DECODE(NVL(I_GROUP_PROJECTS_LEVEL, 2), 0, '{all}', 1, NVL(TO_CHAR(RGP.FID_GROUP), '0'), DLR.FID_PROJECT) AS FID_PROJECT,
          DLR.LOGIN, DLR.FID_PLATFORM, AVG(DLR.RATE)OVER(PARTITION BY DLR.LOGIN, DLR.FID_PLATFORM, DLR.FID_PROJECT, DLR.REPORT_DATE) AS P_RATE,
          DLR.FID_PROJECT AS REAL_PROJECT
        FROM D_LOGIN_RATES DLR
        LEFT JOIN REL_GROUP_PROJECTS RGP ON RGP.FID_PROJECT = DLR.FID_PROJECT
                                        AND NVL(I_GROUP_PROJECTS_LEVEL, 2) = 1
        LEFT JOIN MV_REL_PRJ_EMP VRPE ON VRPE.LOGIN=DLR.LOGIN
                                            AND VRPE.FID_PLATFORM=DLR.FID_PLATFORM
                                            AND VRPE.PROJECT_ID=DLR.FID_PROJECT
                                            AND (DLR.REPORT_DATE BETWEEN VRPE.ACTIVE_FROM AND VRPE.ACTIVE_TILL
                                             OR DLR.REPORT_DATE = TRUNC(VRPE.ACTIVE_FROM))
        WHERE DLR.REPORT_DATE BETWEEN I_DATE_START AND I_DATE_END - INTERVAL '1' SECOND
          AND ( EXISTS(
                      SELECT 1
                      FROM SQ_PROJECTS FSQP
                      WHERE FSQP.PROJECT_ID = DLR.FID_PROJECT
                        AND NVL(FSQP.PLATFORM_ID, DLR.FID_PLATFORM) = DLR.FID_PLATFORM
                    )
                OR I_PROJECT IS NULL
              )
          AND EXISTS(
                      SELECT 1
                      FROM SQ_LOGINS FSQL
                      WHERE DLR.LOGIN = FSQL.LOGIN
                        AND DLR.FID_PLATFORM = NVL(FSQL.FID_PLATFORM, DLR.FID_PLATFORM)
                    )
      ),
      SQ_PROJECT_RATES AS
      (
        SELECT /*+ MATERIALIZE*/
          ACTIVE_FROM, ACTIVE_TILL-INTERVAL '1' SECOND AS ACTIVE_TILL,
          FID_PROJECT, LOGIN, FID_PLATFORM, SUM(P_RATE) AS RATE
        FROM SQ_GET_PROJECT_RATES
        GROUP BY ACTIVE_FROM, ACTIVE_TILL, FID_PROJECT, LOGIN, FID_PLATFORM
      ),
      SQ_RESULT AS
      (
        SELECT GREATEST(VES.ENTERED, SQR.START_RANGE) AS ENTERED, VES.LOGIN,
          CASE
            WHEN VES.FID_PROJECT = 'project_not_determined'
            THEN SQPR.FID_PROJECT
            ELSE DECODE(NVL(I_GROUP_PROJECTS_LEVEL, 2), 0, '{all}', 1, NVL(TO_CHAR(RGP.FID_GROUP), '0'), VES.FID_PROJECT)
          END AS PROJECT_ID,
          SQLN.LAST_NAME, SQLN.FIRST_NAME, SQLN.MIDDLE_NAME, VES.FID_NAU_STATUS AS FID_STATUS,
          DS.NAME AS STATUS, VES.REASON, DS.CAPTION,
          CASE
            WHEN VES.FID_PROJECT = 'project_not_determined'
            THEN SQPR.RATE
            ELSE 1
          END AS PROJECT_RATE,
          PKG_INTERVALS.FNC_INTERVALTOSEC(GREATEST(VES.ENTERED, SQR.START_RANGE),
                                          LEAST(SQR.STOP_RANGE, CAST(VES.ENTERED+VES.DURATION/86400 AS TIMESTAMP))) AS DURATION,
          VES.DURATION as FULL_DURATION, VES.FID_PLATFORM, SQLN.CALL_CENTRE_NAME, SQLN.LOCATION_NAME, SQR.RANGE_LENGTH
        FROM VW_EMPLOYEES_STATUSES VES
        JOIN D_STATUSES DS ON DS.ID_STATUS = VES.FID_NAU_STATUS
        LEFT JOIN REL_GROUP_PROJECTS RGP ON RGP.FID_PROJECT = VES.FID_PROJECT
                                        AND NVL(I_GROUP_PROJECTS_LEVEL, 2) = 1
                                        and VES.FID_PROJECT != 'project_not_determined'
        LEFT JOIN SQ_RANGES SQR ON VES.ENTERED BETWEEN SQR.START_RANGE AND SQR.STOP_RANGE
                                OR SQR.START_RANGE BETWEEN VES.ENTERED AND CAST(VES.ENTERED+VES.DURATION/86400 AS TIMESTAMP)
        LEFT JOIN SQ_LOGINS SQLN ON VES.LOGIN = SQLN.LOGIN
                                AND VES.FID_PLATFORM = NVL(SQLN.FID_PLATFORM, VES.FID_PLATFORM)
        LEFT JOIN SQ_PROJECT_RATES SQPR ON VES.LOGIN=SQPR.LOGIN
                                        AND VES.FID_PLATFORM=SQPR.FID_PLATFORM
                                        AND VES.FID_PROJECT = 'project_not_determined'
                                        AND GREATEST(VES.ENTERED, SQR.START_RANGE) BETWEEN SQPR.ACTIVE_FROM AND SQPR.ACTIVE_TILL
        WHERE VES.ENTERED BETWEEN I_DATE_START-1 AND I_DATE_END
          AND CAST(VES.ENTERED+VES.DURATION/86400 AS TIMESTAMP) > I_DATE_START
          AND EXISTS(
                      SELECT 1
                      FROM SQ_LOGINS FSQL
                      WHERE VES.LOGIN = FSQL.LOGIN
                        AND VES.FID_PLATFORM = NVL(FSQL.FID_PLATFORM, VES.FID_PLATFORM)
                    )
              AND ( EXISTS(
                          SELECT 1
                          FROM SQ_PROJECTS FSQP
                          WHERE VES.FID_PROJECT = FSQP.PROJECT_ID
                            AND VES.FID_PLATFORM = NVL(FSQP.PLATFORM_ID, VES.FID_PLATFORM)
                          UNION ALL
                          SELECT 1
                          FROM DUAL
                          WHERE VES.FID_PROJECT = 'project_not_determined'
                            AND SQPR.LOGIN IS NOT NULL
                        )
                   OR I_PROJECT IS NULL
                   )
              AND EXISTS(
                          SELECT 1
                          FROM SQ_FILTER_STATUSES FS
                          WHERE FS.ID_STATUS = VES.FID_NAU_STATUS
                          UNION ALL
                          SELECT 1
                          FROM DUAL
                          WHERE V_STATUSES IS NULL
                        )
      )
    SELECT ENTERED, LOGIN, PROJECT_ID, FID_STATUS, STATUS, REASON, CAPTION as STATUS_CAPTION,
      PROJECT_RATE, DURATION, FULL_DURATION, FID_PLATFORM, CALL_CENTRE_NAME AS CC_CAPTION,
      LOCATION_NAME AS LOCATION_CAPTION, NULL AS FIRST_STATUS_ENTERED, NULL AS LAST_STATUS_ENDED
    FROM SQ_RESULT
    WHERE ENTERED IS NOT NULL
      AND CASE
            WHEN UPPER(NVL(I_COMPRESS, 'Y')) = 'Y'
              AND STATUS = 'offline'
            THEN DURATION
            ELSE 0
          END < RANGE_LENGTH;

  BEGIN
    IF NVL(I_GROUP_PROJECTS_LEVEL, 2) NOT BETWEEN 0 AND 2 THEN
      RAISE_APPLICATION_ERROR(-20000, 'I_GROUP_PROJECTS_LEVEL может иметь значение от 0 до 2.');
    END IF;
    IF NVL(I_GROUP_LOCATION, 2) NOT BETWEEN 0 AND 2 THEN
      RAISE_APPLICATION_ERROR(-20001, 'I_GROUP_PROJECTS_LEVEL может иметь значение от 0 до 2.');
    END IF;

    IF I_STATUSES IS NOT NULL THEN
      V_STATUSES := T_LIST_VARCHAR();
      SELECT COLUMN_VALUE BULK COLLECT INTO V_STATUSES
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_STATUSES));
    END IF;

    IF V_LOGINS IS NULL THEN
      SELECT LOGIN INTO V_LOGINS
      FROM TABLE(PKG_API.GET_EMPLOYEES_LIST('O', 'N', I_DATE_START, I_DATE_END,
                                            I_PROJECT, I_LOCATION, I_ROLETYPE,
                                            I_PLATFORMS, I_NEW_STYLE=>'Y'));
    END IF;

    IF SUBSTR(I_PROJECT, 1, 1) = '{' AND SUBSTR(I_PROJECT, -1) = '}' THEN
      V_LOGINS := REPLACE(V_LOGINS, '"projects": ""', '"projects": '||I_PROJECT);
    ELSE
      V_LOGINS := REPLACE(V_LOGINS, '"projects": ""', '"projects": "'||I_PROJECT||'"');
    END IF;

    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END GET_STATUSES;

END PKG_API_TEST;
/

