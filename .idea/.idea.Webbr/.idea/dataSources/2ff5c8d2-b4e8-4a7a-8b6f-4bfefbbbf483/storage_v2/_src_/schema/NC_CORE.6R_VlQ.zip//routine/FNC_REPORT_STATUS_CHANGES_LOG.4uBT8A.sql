create FUNCTION FNC_REPORT_STATUS_CHANGES_LOG
(
  I_DATE_START IN TIMESTAMP,
  I_DATE_END IN TIMESTAMP,
  I_PROJECT IN VARCHAR2 DEFAULT NULL,
  I_LOGIN IN VARCHAR2 DEFAULT NULL,
  I_PLATFORMS IN VARCHAR2 DEFAULT NULL
) RETURN T_REPORT_STATUS_CHANGES_LOG PIPELINED AS

BEGIN
  FOR GET_DATA IN
  (
      WITH SQ_REZULT AS
      (
        SELECT DISTINCT
          TS.LOGIN, TRIM(MVE.SURNAME)||' '||TRIM(MVE.NAME)||' '||TRIM(MVE.PATRONYMIC) AS FIO,
          TO_CHAR(TS.ENTERED,'DD.MM.YYYY HH24:MI:SS') AS STATUS_ENTERED,
          TS. STATUS, TS.STATUS_CAPTION AS CAPTION, TS.DURATION
        FROM TABLE(PKG_API.GET_STATUSES(I_DATE_START, I_DATE_END,
                                        I_PROJECT=>I_PROJECT, I_LOGIN=>I_LOGIN,
                                        I_STEP=>2, I_STEP_TYPE=>'YY', I_ROLETYPE=>'operator',
                                        I_PLATFORMS=>I_PLATFORMS)) TS
        LEFT JOIN MV_EMPLOYEES MVE ON MVE.LOGIN = TS.LOGIN
      )
      SELECT LOGIN, FIO, STATUS_ENTERED, STATUS, CAPTION, DURATION
      FROM SQ_REZULT
      ORDER BY LOGIN, STATUS_ENTERED, DURATION
  )
  LOOP
      PIPE ROW(TR_REPORT_STATUS_CHANGES_LOG(
                                              GET_DATA.LOGIN,
                                              GET_DATA.FIO,
                                              GET_DATA.STATUS_ENTERED,
                                              GET_DATA.STATUS,
                                              GET_DATA.CAPTION,
                                              GET_DATA.DURATION
                                           )
              );
  END LOOP;
END FNC_REPORT_STATUS_CHANGES_LOG;
/

