create trigger TRG_EMPLOYEES_EDUCATIONS_ID
    before insert
    on EMPLOYEES_EDUCATIONS
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_EDUCATION" IS NULL THEN
                                 SELECT SEQ_EMPLOYEES_EDUCATIONS_ID.NEXTVAL INTO :NEW."ID_EDUCATION" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

