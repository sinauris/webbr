create type wfm_project_list
AS OBJECT 
(
    project_id varchar2(32), 
    project_name varchar2(4000)
);
/

