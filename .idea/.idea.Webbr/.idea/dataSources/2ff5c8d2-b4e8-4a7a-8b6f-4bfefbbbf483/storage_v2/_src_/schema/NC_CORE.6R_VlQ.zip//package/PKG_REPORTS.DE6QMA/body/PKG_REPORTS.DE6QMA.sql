create PACKAGE BODY PKG_REPORTS AS

--------------------------------------------------------------------------------
------------------------------ФУНКЦИИ ДЛЯ ФИЛЬТРОВ------------------------------
--------------------------------------------------------------------------------
  --Получение списка зарегистрированных площадок
  FUNCTION FNC_LOCATION_LIST(I_INCLUDE_ALL CHAR DEFAULT 'Y') RETURN PT_LOCATION_LIST PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_LOCATION_LIST
    IS
    WITH SQ_PRE_DATA AS
      (
        SELECT
          'L:' AS FLAG,
          MCI."UUID"  AS "AREAUUID",
          MCF."UUID"  AS "PARENT_UUID",
          MCI."TITLE" AS "AREANAME"
        FROM NAUCRM62.MV_CATALOG_ITEM MCI
        JOIN NAUCRM62.MV_CATALOG_FOLDER MCF ON MCF."UUID"=MCI.FOLDERUUID
        UNION
        SELECT 'C:' AS FLAG, UUID, CASE WHEN PARENTUUID != CATALOGUUID THEN PARENTUUID END AS PARENTUUID, TITLE
        FROM NAUCRM62.MV_CATALOG_FOLDER
        WHERE CATALOGCODE = 'Areas'
        UNION
        SELECT 'A:', NULL, NULL, 'Все Call-центры/площадки'
        FROM DUAL
        WHERE NVL(UPPER(I_INCLUDE_ALL),'Y') = 'Y'
      )
    SELECT
      CASE
        WHEN FLAG  NOT IN ('A:', 'C:') THEN PRIOR FLAG||PRIOR AREANAME||','
      END||FLAG||AREANAME AS LOCATION_ID,
      REPLACE(LPAD(AREANAME,LENGTH(AREANAME)+(LEVEL-1)*3,'*'),'*','&nbsp;') AS NAME
    FROM SQ_PRE_DATA
    START WITH PARENT_UUID IS NULL
        CONNECT BY PRIOR AREAUUID = PARENT_UUID
    ORDER SIBLINGS BY FLAG, AREANAME;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_LOCATION_LIST;

  --Получение списка зарегистрированных сотрудников
  FUNCTION FNC_EMPLOYEES_LIST(I_INCLUDE_ALL CHAR DEFAULT 'Y',
                              I_VIEW_LOGIN CHAR DEFAULT 'Y',
                              I_DATE_START TIMESTAMP DEFAULT NULL, --Дата начала отбора
                              I_DATE_END TIMESTAMP DEFAULT NULL, --Дата окончания отбора
                              I_PROJECT VARCHAR2 DEFAULT NULL, --Проект/группа проектов
                              I_LOCATION VARCHAR2 DEFAULT NULL) --Call-центр/площадка
    RETURN PT_EMPLOYEES_LIST PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_EMPLOYEES_LIST
    IS
    SELECT DISTINCT MVE.LOGIN, MVE.SURNAME||' '||MVE.NAME||' '||MVE.PATRONYMIC||
      DECODE(UPPER(I_VIEW_LOGIN), 'Y',' ('||MVE.LOGIN||')',NULL) AS FIO
    FROM TABLE(PKG_SERVICE.FNC_GET_LOGINS(NVL(I_DATE_START, CAST(TRUNC(ADD_MONTHS(SYSTIMESTAMP,-1)) AS TIMESTAMP)),
                                          NVL(I_DATE_END, CAST(TRUNC(SYSTIMESTAMP+1) AS TIMESTAMP)),
                                          I_PROJECT, I_LOCATION, I_ROLETYPE=>'operator')) OL
    JOIN MV_EMPLOYEES MVE ON MVE.LOGIN = OL.LOGIN
    UNION
    SELECT NULL, 'Все операторы'
    FROM DUAL
    WHERE I_INCLUDE_ALL = 'Y'
    ORDER BY LOGIN NULLS FIRST;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_EMPLOYEES_LIST;

  --Получение списка зарегистрированных проектов
  FUNCTION FNC_PROJECTS_LIST (I_INCLUDE_ALL CHAR DEFAULT 'Y',
                              I_DIRECTION VARCHAR2 DEFAULT NULL,
                              I_PLATFORM NUMBER DEFAULT NULL,
                              I_ACTIVE NUMBER DEFAULT 1,
                              I_PROJECTS_GROUP VARCHAR2 DEFAULT NULL) RETURN PT_PROJECTS_LIST PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_PROJECTS_LIST
    IS
    WITH SQ_PROJECTS AS
      (
        SELECT ID_ELEMENT, FID_GROUP
        FROM MV_PROJECTS MVP
        WHERE NVL2(I_DIRECTION, DIRECTION, '*') = NVL(UPPER(I_DIRECTION), '*')
          AND NVL2(I_PLATFORM, FID_PLATFORM, 1) = NVL(I_PLATFORM, 1)
          AND NVL2(I_ACTIVE, IS_ACTIVE, -1) = NVL(I_ACTIVE, -1)
          AND EXISTS(
                      SELECT 1
                      FROM DUAL
                      WHERE NVL2(I_PROJECTS_GROUP, MVP.ID_ELEMENT, '*') = NVL(I_PROJECTS_GROUP, '*')
                        OR NVL2(I_PROJECTS_GROUP, MVP.FID_GROUP, '*') = NVL(I_PROJECTS_GROUP, '*')
                    )
      ) ,
      SQ_GROUP_ID AS
      (
        SELECT FID_GROUP, LISTAGG(ID_ELEMENT, ',') WITHIN GROUP (ORDER BY ID_ELEMENT) AS ID_ELEMENT
        FROM SQ_PROJECTS
        WHERE FID_GROUP IS NOT NULL
        GROUP BY FID_GROUP
      ),
      SQ_RESULT AS
      (
        SELECT MVP.ID_ELEMENT, MVP.FID_GROUP, MVP.CAPTION, ORD
        FROM MV_PROJECTS MVP
        WHERE EXISTS (SELECT 1
                      FROM SQ_PROJECTS SP
                      WHERE MVP.ID_ELEMENT = SP.ID_ELEMENT
                      UNION ALL
                      SELECT 1
                      FROM SQ_PROJECTS SP
                      WHERE MVP.ID_ELEMENT = SP.FID_GROUP)
        UNION
        SELECT NULL, NULL, 'Все проекты', -1
        FROM DUAL
        WHERE NVL(UPPER(I_INCLUDE_ALL),'Y') = 'Y'
          AND I_PROJECTS_GROUP IS NULL
      )
    SELECT NVL(SGI.ID_ELEMENT, SR.ID_ELEMENT) AS ID_ELEMENT,
      REPLACE(LPAD(SR.CAPTION,LENGTH(SR.CAPTION)+(LEVEL-1)*3,'*'),'*','&nbsp;')AS CAPTION
    FROM SQ_RESULT SR
    LEFT JOIN SQ_GROUP_ID SGI ON SGI.FID_GROUP = SR.ID_ELEMENT
    START WITH SR.FID_GROUP IS NULL
    CONNECT BY PRIOR SR.ID_ELEMENT = SR.FID_GROUP
    ORDER SIBLINGS BY SR.ORD, SR.CAPTION;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_PROJECTS_LIST;

  --Получение списка зарегистрированных проектов
  FUNCTION FNC_PROVIDERS_LIST (I_INCLUDE_ALL CHAR DEFAULT 'Y')
    RETURN PT_PROVIDERS_LIST PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_PROVIDERS_LIST
    IS
    SELECT ID_PROVIDER, NAME
    FROM D_PROVIDERS
    UNION ALL
    SELECT NULL, 'Все поставщики'
    FROM DUAL
    WHERE NVL(UPPER(I_INCLUDE_ALL),'Y') = 'Y'
    ORDER BY ID_PROVIDER NULLS FIRST;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_PROVIDERS_LIST;

--------------------------------------------------------------------------------
----------------------------АДМИНИСТРАТИВНЫЕ ОТЧЕТЫ-----------------------------
--------------------------------------------------------------------------------
  --Отчет "Табель учета рабочего времени"
  FUNCTION FNC_REPORT_TIMESHEET (
                                  I_DATE_START TIMESTAMP,
                                  I_DATE_END TIMESTAMP,
                                  I_PROJECT VARCHAR2 DEFAULT NULL,
                                  I_PROJECT_GROUP NUMBER DEFAULT 2,
                                  I_LOCATION VARCHAR2 DEFAULT NULL,
                                  I_LOGIN VARCHAR2 DEFAULT NULL,
                                  I_ROLETYPE VARCHAR2 DEFAULT 'operator',
                                  I_PLATFORMS VARCHAR2 DEFAULT NULL
                                )
    RETURN PT_REPORT_TIMESHEET PIPELINED
  IS
    V_LOGINS VARCHAR2 (2000 CHAR) DEFAULT NULL;

    CURSOR GET_DATA RETURN PTR_REPORT_TIMESHEET
    IS
    WITH SQ_PROJECT_FILTER AS
      (
        SELECT /*+ MATERIALIZE*/ PROJECT_ID, CAPTION, PLATFORM_ID
        FROM table(PKG_API.GET_PROJECTS_IDS(I_PROJECT))
      ),
      SQ_PROJECTS_PRP AS
      (
        SELECT /*+ MATERIALIZE*/ DISTINCT TRUNC(DLR.REPORT_DATE) REPORT_DATE,
          DLR.LOGIN, DLR.FID_PROJECT, DLR.FID_PLATFORM, SQP.CAPTION, RATE
        FROM D_LOGIN_RATES DLR
        JOIN SQ_PROJECT_FILTER SQP ON SQP.PROJECT_ID = DLR.FID_PROJECT
                                  AND SQP.PLATFORM_ID = DLR.FID_PLATFORM
        WHERE DLR.REPORT_DATE BETWEEN I_DATE_START AND I_DATE_END - INTERVAL '1' SECOND
          AND NVL(I_LOGIN, '1') = NVL2(I_LOGIN, DLR.LOGIN, '1')
      ),
      SQ_PROJECTS AS
      (
        SELECT /*+ MATERIALIZE*/ REPORT_DATE, LOGIN, FID_PLATFORM,
          LISTAGG(CAPTION, ', ') WITHIN GROUP (ORDER BY CAPTION) AS PROJECTS
        FROM (SELECT DISTINCT TO_CHAR(REPORT_DATE,'MM/YYYY') REPORT_DATE, LOGIN, FID_PLATFORM, CAPTION
              FROM SQ_PROJECTS_PRP PRP
              WHERE NVL(I_PROJECT_GROUP, 2) = 0
                    AND EXISTS(
                                SELECT 1
                                FROM SQ_PROJECT_FILTER FSQP
                                WHERE FSQP.PROJECT_ID = PRP.FID_PROJECT
                                  AND FSQP.PLATFORM_ID = PRP.FID_PLATFORM
                              )
              )
        GROUP BY REPORT_DATE, LOGIN, FID_PLATFORM
      ),
      SQ_STATUSESS AS
      (
        SELECT TRUNC(ST.ENTERED) AS DAY_NUM, ST.LOGIN, ST.PROJECT_ID, ST.FID_PLATFORM, ST.LOCATION_CAPTION,
          ST.ENTERED, CAST(ST.ENTERED+ST.DURATION/86400 AS TIMESTAMP) AS ENDED, ST.DURATION, ST.PROJECT_RATE
        FROM TABLE(PKG_API.GET_STATUSES(I_DATE_START,I_DATE_END,
                                        null, 0,
                                        NVL(I_LOGIN, V_LOGINS),
                                        I_LOCATION, I_ROLETYPE=>'operator',
                                        I_STATUSES=>'away,normal,outcoming_calls,ringing,speaking,time_break,training,wrapup')) ST
        WHERE ST.PROJECT_ID != 'pnd'
      ),
      SQ_WORK_TIME AS
      (
        SELECT DAY_NUM, LOGIN, FID_PLATFORM, LOCATION_CAPTION,
          MIN(ENTERED) START_DAY, MAX(ENDED) STOP_DAY,
          NVL(SUM(CASE WHEN INT_BETW > 300 THEN INT_BETW END), 0) OFFLINE_DURATION
        FROM
          (
            SELECT DAY_NUM, LOGIN, FID_PLATFORM, LOCATION_CAPTION, ENTERED, ENDED,
              PKG_INTERVALS.FNC_INTERVALTOSEC(ENDED,
                                              NVL(LEAD(ENTERED)OVER(PARTITION BY DAY_NUM, LOGIN, FID_PLATFORM, LOCATION_CAPTION ORDER BY ENTERED, ENDED), ENDED)) INT_BETW
            FROM SQ_STATUSESS
          )
        GROUP BY DAY_NUM, LOGIN, FID_PLATFORM, LOCATION_CAPTION
      ),
        SQ_STATUSES AS
      (
        SELECT WT.DAY_NUM, WT.LOGIN, WT.LOCATION_CAPTION, WT.FID_PLATFORM,
          DECODE(I_PROJECT_GROUP, 0, 'Все проекты', 1, DG.CAPTION, 2, PRP.CAPTION, PRP.FID_PROJECT) PROJECT_ID,
          TRIM(VWE.SURNAME||' '||VWE.NAME||' '||VWE.PATRONYMIC) AS FIO,
          WT.START_DAY, WT.STOP_DAY, WT.OFFLINE_DURATION, PRP.FID_PROJECT, PRP.RATE,
          (PKG_INTERVALS.FNC_INTERVALTOSEC(WT.START_DAY, WT.STOP_DAY)-WT.OFFLINE_DURATION)*PRP.RATE/3600 DAY_TIME
        FROM SQ_WORK_TIME WT
          LEFT JOIN SQ_PROJECTS_PRP PRP ON PRP.LOGIN = WT.LOGIN
                                       AND PRP.FID_PLATFORM = WT.FID_PLATFORM
                                       AND PRP.REPORT_DATE = WT.DAY_NUM
          LEFT JOIN REL_GROUP_PROJECTS GP ON GP.FID_PROJECT = PRP.FID_PROJECT
                                         AND PRP.REPORT_DATE BETWEEN GP.CREATED AND GP.BLOCKED
          LEFT JOIN D_GROUPS DG ON DG.ID_GROUP = GP.FID_GROUP
          LEFT JOIN VW_EMPLOYEES VWE ON VWE.LOGIN = WT.LOGIN
                                    AND VWE.FID_PLATFORM = WT.FID_PLATFORM
      ),
      SQ_DATA AS
      (
        SELECT EXTRACT(DAY FROM SQS.DAY_NUM) AS DAY_NUM, TO_CHAR(SQS.DAY_NUM, 'MM/YYYY') AS WORK_MONTH, SQS.LOCATION_CAPTION,
          DECODE(NVL(I_PROJECT_GROUP, 2), 0, SQS.FIO, 'Все сотрудники') AS FIO,
          DECODE(NVL(I_PROJECT_GROUP, 2), 0, SQS.LOGIN, 'Все логины') AS LOGIN, NVL(SQP.PROJECTS, SQS.PROJECT_ID) AS PROJECT_NAME,
          ROUND(SUM(SQS.DAY_TIME), 2) DAY_TIME
        FROM SQ_STATUSES SQS
        LEFT JOIN SQ_PROJECTS SQP ON SQP.REPORT_DATE=TO_CHAR(SQS.DAY_NUM, 'MM/YYYY')
                                  AND SQS.LOGIN=SQP.LOGIN
                                  AND SQS.FID_PLATFORM=SQP.FID_PLATFORM
        GROUP BY EXTRACT(DAY FROM SQS.DAY_NUM), TO_CHAR(SQS.DAY_NUM, 'MM/YYYY'), SQS.LOCATION_CAPTION,
          DECODE(NVL(I_PROJECT_GROUP, 2), 0, SQS.FIO, 'Все сотрудники'),
          DECODE(NVL(I_PROJECT_GROUP, 2), 0, SQS.LOGIN, 'Все логины'),
          NVL(SQP.PROJECTS, SQS.PROJECT_ID)
      )
    SELECT LOGIN, FIO, LOCATION_CAPTION, WORK_MONTH, PROJECT_NAME, "1", "2", "3", "4", "5",
      "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19",
      "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "SUM"
    FROM (
          SELECT DAY_NUM, WORK_MONTH, LOGIN, FIO, PROJECT_NAME, DAY_TIME, LOCATION_CAPTION
          FROM SQ_DATA
          WHERE DAY_TIME > 0
          UNION ALL
          (
            SELECT 32, WORK_MONTH, LOGIN, FIO, PROJECT_NAME, SUM(DAY_TIME), LOCATION_CAPTION
            FROM SQ_DATA
            WHERE DAY_TIME > 0
            GROUP BY WORK_MONTH, LOGIN, FIO, PROJECT_NAME, LOCATION_CAPTION
          )
        )
    PIVOT
      (
        MAX(DAY_TIME) FOR DAY_NUM IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32 AS "SUM")
      )
    ORDER BY WORK_MONTH, LOCATION_CAPTION, LOGIN, PROJECT_NAME;

  BEGIN
    IF I_LOGIN IS NULL
    THEN SELECT LOGIN
         INTO V_LOGINS
         FROM TABLE(PKG_API.GET_EMPLOYEES_LIST(I_PROJECT=>I_PROJECT, I_NEW_STYLE=>'Y'))
         WHERE rownum = 1;
    END IF;

    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_TIMESHEET;

  --Отчет "Время пребывания операторов в определённых состояниях"
  FUNCTION FNC_REPORT_STATUS_CHANGES(
                                      I_DATE_START TIMESTAMP,
                                      I_DATE_END TIMESTAMP,
                                      I_PROJECT VARCHAR2 DEFAULT NULL,
                                      I_PROJECT_GROUP NUMBER DEFAULT 2,
                                      I_LOGIN VARCHAR2 DEFAULT NULL,
                                      I_PLATFORMS VARCHAR2 DEFAULT NULL
                                    )
    RETURN PT_REPORT_STATUS_CHANGES PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_REPORT_STATUS_CHANGES
    IS
    SELECT TS.LOGIN, MVE.SURNAME||' '||MVE.NAME||' '||MVE.PATRONYMIC AS FIO,
      TO_CHAR(TS.ENTERED,'DD.MM.YYYY HH24:MI:SS') AS ENTERED, DS.NAME, DS.CAPTION,
      TS.DURATION*TS.PROJECT_RATE AS STATUS_DURATION
    FROM TABLE(PKG_API.GET_STATUSES(I_DATE_START=>I_DATE_START, I_DATE_END=>I_DATE_END,
                                    I_PROJECT=>I_PROJECT, I_GROUP_PROJECTS_LEVEL=>I_PROJECT_GROUP,
                                    I_LOGIN=>I_LOGIN, I_STEP=>2, I_STEP_TYPE=>'YY',
                                    I_STATUSES=>'ringing,speaking,wrapup,normal,away,'||
                                                'work_offline,email_processing,outcoming_calls,'||
                                                'training,time_break,tech_problem',
                                    I_ROLETYPE=>'operator', I_PLATFORMS=>I_PLATFORMS)) TS
    LEFT JOIN MV_EMPLOYEES MVE ON MVE.LOGIN = TS.LOGIN
                              AND MVE.FID_PLATFORM= TS.FID_PLATFORM
    LEFT JOIN D_STATUSES DS ON DS.ID_STATUS = TS.FID_STATUS
    WHERE PROJECT_ID != 'pnd'
      AND FULL_DURATION < 43200
      AND LOWER(TS.REASON) NOT IN ('computerlocked','initializing','preparetowork')
    ORDER BY TS.LOGIN, TS.ENTERED;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_STATUS_CHANGES;

  --Отчет "Время пребывания операторов в определённых состояниях суммарно"
  FUNCTION FNC_REPORT_STATUS_CHANGES_SUM(
                                          I_DATE_START TIMESTAMP,
                                          I_DATE_END TIMESTAMP,
                                          I_STEP_TYPE VARCHAR2,
                                          I_PROJECT VARCHAR2 DEFAULT NULL,
                                          I_PROJECT_GROUP NUMBER DEFAULT 2,
                                          I_LOCATION VARCHAR2 DEFAULT NULL,
                                          I_LOCATION_GROUP NUMBER DEFAULT 2,
                                          I_LOGIN_GROUP CHAR DEFAULT 'Y',
                                          I_PLATFORMS VARCHAR2 DEFAULT NULL
                                        )
    RETURN PT_REPORT_STATUS_CHANGES_SUM PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_REPORT_STATUS_CHANGES_SUM
    IS
    WITH SQ_RANGES AS
      (
        SELECT /*+ MATERIALIZE*/ START_RANGE, STOP_RANGE-INTERVAL '1' SECOND as STOP_RANGE, FULL_RANGE
        FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(I_START_DATE=>I_DATE_START, I_END_DATE=>I_DATE_END,
                                                      I_STEP => DECODE(UPPER(I_STEP_TYPE), 'YY', 2, 1),
                                                      I_STEP_TYPE => I_STEP_TYPE, I_MASK => 'DD.MM.YYYY HH24:MI'))
      ),
      SQ_STATUS_CHANGES AS
      (
        SELECT /*+ MATERIALIZE*/ SQR.START_RANGE, TS.LOCATION_CAPTION, TS.PROJECT_ID,
          DECODE(I_LOGIN_GROUP, 'Y', TS.LOGIN, '{all}') AS LOGIN, TS.FID_STATUS,
          TS.REASON, TS.FID_PLATFORM, NVL(SUM(TS.DURATION),0) AS DURATION
        FROM TABLE(PKG_API.GET_STATUSES(I_DATE_START=>I_DATE_START, I_DATE_END=>I_DATE_END,
                                        I_PROJECT=>I_PROJECT, I_GROUP_PROJECTS_LEVEL=>I_PROJECT_GROUP,
                                        I_LOCATION=>I_LOCATION, I_GROUP_LOCATION=>I_LOCATION_GROUP,
                                        I_STEP=>DECODE(UPPER(I_STEP_TYPE), 'YY', 2, 1), I_STEP_TYPE=>I_STEP_TYPE,
                                        I_STATUSES=>'ringing,speaking,wrapup,normal,away,'||
                                                    'work_offline,email_processing,outcoming_calls,'||
                                                    'training,time_break,tech_problem',
                                        I_ROLETYPE=>'operator', I_PLATFORMS=>I_PLATFORMS)) TS
        LEFT JOIN SQ_RANGES SQR ON TS.ENTERED BETWEEN SQR.START_RANGE AND SQR.STOP_RANGE
        WHERE PROJECT_ID != 'pnd'
          AND FULL_DURATION < 43200
          AND LOWER(TS.REASON) NOT IN ('computerlocked','initializing','preparetowork')
        GROUP BY SQR.START_RANGE, TS.LOCATION_CAPTION, TS.PROJECT_ID,
          DECODE(I_LOGIN_GROUP, 'Y', TS.LOGIN, '{all}'),
          TS.FID_STATUS, TS.REASON, TS.FID_PLATFORM
      ),
      SQ_STATUSES AS
      (
        SELECT /*+ MATERIALIZE*/ DISTINCT SQR.START_RANGE, SQR.FULL_RANGE, MVS.ID_NAU_STATUS,
          MVS.NAU_STATUS, MVS.NAU_STATUS_REASON, MVS.NAU_STATUS_CAPTION, MVS.ID_PLATFORM,
          SQSC.LOCATION_CAPTION, SQSC.PROJECT_ID, SQSC.LOGIN
        FROM MV_STATUSES MVS
        CROSS JOIN SQ_RANGES SQR
        CROSS JOIN (SELECT DISTINCT LOCATION_CAPTION, PROJECT_ID, LOGIN FROM SQ_STATUS_CHANGES) SQSC
        WHERE EXISTS(
                      SELECT 1
                      FROM SQ_STATUS_CHANGES SQSC
                      WHERE SQSC.FID_PLATFORM = MVS.ID_PLATFORM
                        AND MVS.NC_STATUS IN ('training','time_break','tech_problem','normal','ringing','speaking','wrapup',
                        'work_offline','email_processing','outcoming_calls')
                    )
              AND I_DATE_START < MVS.ACTIVE_TILL AND I_DATE_END > MVS.ACTIVE_FROM
      )
    SELECT SQS.LOCATION_CAPTION, COALESCE(DG.CAPTION, MVP.NAME, SQS.PROJECT_ID) AS PROJECT_ID, SQS.LOGIN, SQS.FULL_RANGE,
      SQS.NAU_STATUS AS STATUS, SQS.NAU_STATUS_CAPTION AS CAPTION, NVL(SUM(SQSC.DURATION),0) AS DURATION
    FROM SQ_STATUSES SQS
    LEFT JOIN SQ_STATUS_CHANGES SQSC ON SQSC.START_RANGE = SQS.START_RANGE
                                    AND SQSC.FID_STATUS = SQS.ID_NAU_STATUS
                                    AND SQSC.LOCATION_CAPTION = SQS.LOCATION_CAPTION
                                    AND SQSC.PROJECT_ID = SQS.PROJECT_ID
                                    AND SQSC.LOGIN = SQS.LOGIN
    LEFT JOIN VW_PROJECTS MVP ON MVP.PROJECT_ID = SQS.PROJECT_ID
    LEFT JOIN D_GROUPS DG ON TO_CHAR(DG.ID_GROUP) = SQS.PROJECT_ID
    GROUP BY SQS.LOCATION_CAPTION, COALESCE(DG.CAPTION, MVP.NAME, SQS.PROJECT_ID), SQS.LOGIN,
      SQS.FULL_RANGE, SQS.NAU_STATUS, SQS.NAU_STATUS_CAPTION
    ORDER BY SQS.FULL_RANGE, SQS.LOCATION_CAPTION, COALESCE(DG.CAPTION, MVP.NAME, SQS.PROJECT_ID),
      SQS.LOGIN, SQS.NAU_STATUS, SQS.NAU_STATUS_CAPTION;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_STATUS_CHANGES_SUM;

  --Отчет "Статистика по call-центру. Переключения статусов у операторов"
  FUNCTION FNC_REPORT_STATUS_CHANGES_LOG(
                                          I_DATE_START TIMESTAMP,
                                          I_DATE_END TIMESTAMP,
                                          I_PROJECT VARCHAR2 DEFAULT NULL,
                                          I_LOGIN VARCHAR2 DEFAULT NULL,
                                          I_PLATFORMS VARCHAR2 DEFAULT NULL
                                        )
    RETURN PT_REPORT_STATUS_CHANGES_LOG PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_REPORT_STATUS_CHANGES_LOG
    IS
    SELECT TS.LOGIN, MVE.SURNAME||' '||MVE.NAME||' '||MVE.PATRONYMIC AS FIO,
      TO_CHAR(TS.ENTERED,'DD.MM.YYYY HH24:MI:SS') AS ENTERED, DS.NAME, DS.CAPTION,
      TS.DURATION
    FROM TABLE(PKG_API.GET_STATUSES(I_DATE_START, I_DATE_END, I_PROJECT=>I_PROJECT, I_LOGIN=>I_LOGIN,
                                    I_STEP=>2, I_STEP_TYPE=>'YY', I_ROLETYPE=>'operator', I_PLATFORMS=>I_PLATFORMS)) TS
    JOIN D_STATUSES DS ON DS.ID_STATUS = TS.FID_STATUS
    LEFT JOIN MV_EMPLOYEES MVE ON MVE.LOGIN = TS.LOGIN
    ORDER BY TS.LOGIN, TS.ENTERED;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_STATUS_CHANGES_LOG;

  --Отчет "Загрузки Call-центра по проектам"
  FUNCTION FNC_REPORT_PROJECT_CC_LOAD(
                                          I_DATE_START TIMESTAMP,
                                          I_DATE_END TIMESTAMP,
                                          I_STEP_TYPE VARCHAR2 DEFAULT 'DD',--структура передающихся данных: XXYY, где XX - это тип шага(DD - дни; HH - часы; MI - минуты);
                                                                                                                   --  YY - длина шага(если неуказана, то равена 1)
                                          I_PROJECT VARCHAR2 DEFAULT NULL,
                                          I_PROJECT_GROUP NUMBER DEFAULT 2,
                                          I_LOCATION VARCHAR2 DEFAULT NULL,
                                          I_PLATFORMS VARCHAR2 DEFAULT NULL
                                        )
    RETURN PT_REPORT_PROJECT_CC_LOAD PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_REPORT_PROJECT_CC_LOAD
    IS
    WITH SQ_RANGES AS
      (--разбиваем интервал на подинтервалы
        SELECT /*+ MATERIALIZE*/ START_RANGE, STOP_RANGE-INTERVAL '1' SECOND AS STOP_RANGE, FULL_RANGE
        FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(I_DATE_START, I_DATE_END, I_STEP=>TO_NUMBER(SUBSTR(I_STEP_TYPE,3)),
                                                      I_STEP_TYPE=>SUBSTR(I_STEP_TYPE,1,2), I_MASK=>'DD.MM.YYYY HH24:MI'))
      ),
      SQ_STATUSES AS
      (--получаем статусы
        SELECT /*+ MATERIALIZE*/ TS.LOGIN, TS.PROJECT_ID, TS.ENTERED, CAST(TS.ENTERED+TS.DURATION/86400 AS TIMESTAMP) AS ENDED, TS.DURATION, TS.PROJECT_RATE
        FROM TABLE(PKG_API.GET_STATUSES(I_DATE_START, I_DATE_END, I_STEP=>2, I_STEP_TYPE=>'YY', I_PROJECT=>I_PROJECT, I_PLATFORMS=>I_PLATFORMS,
                                        I_GROUP_PROJECTS_LEVEL=>I_PROJECT_GROUP, I_LOCATION=>I_LOCATION, I_ROLETYPE=>'operator',
                                        I_STATUSES=>'away,normal,outcoming_calls,ringing,speaking,time_break,training,wrapup')) TS
        WHERE TS.PROJECT_ID != 'pnd'
      ),
      SQ_WORK_TIME AS
      (--вычисляем начало и конец рабочего времени в интервале
        SELECT /*+ MATERIALIZE*/ distinct st.LOGIN, st.PROJECT_ID,
          min(st.ENTERED)OVER(PARTITION BY st.LOGIN, st.PROJECT_ID) FIRST_ENTERED,
          max(st.ENDED)OVER(PARTITION BY st.LOGIN, st.PROJECT_ID) LAST_ENDED
        FROM SQ_STATUSES st
      ),
      SQ_WT AS
      (--вертикальная структура начала и конца рабочего времени
        SELECT /*+ MATERIALIZE*/ LOGIN, PROJECT_ID, ACTION, ACT_TIME
        FROM SQ_WORK_TIME
        UNPIVOT (ACT_TIME FOR ACTION IN (LAST_ENDED AS 'ENDED', FIRST_ENTERED AS 'ENTERED'))
      ),
      SQ_AWAY_TIME AS
      (--вычисляем нерабочие интервалы
        SELECT /*+ MATERIALIZE*/ LOGIN, PROJECT_ID, AWAY_BEG, AWAY_END
        FROM (
          SELECT st.LOGIN, st.PROJECT_ID, st.ENDED AWAY_BEG,
            LEAD(st.ENTERED)OVER(PARTITION BY st.LOGIN, st.PROJECT_ID ORDER BY st.ENTERED, st.ENDED) AWAY_END,
            PKG_INTERVALS.FNC_INTERVALTOSEC(st.ENDED,
                                            NVL(LEAD(st.ENTERED)OVER(PARTITION BY st.LOGIN, st.PROJECT_ID ORDER BY st.ENTERED, st.ENDED),st.ENDED)) INT_BETW
          FROM SQ_STATUSES st
          )
          WHERE INT_BETW > 300
      ),
      SQ_AT AS
      (--вертикальная структура нерабочих интервалов
        SELECT /*+ MATERIALIZE*/ LOGIN, PROJECT_ID, ACTION, ACT_TIME--        PROJECT_ID, AWAY_BEG, AWAY_END
        FROM SQ_AWAY_TIME
        UNPIVOT (ACT_TIME FOR ACTION IN (AWAY_BEG AS 'ENDED', AWAY_END AS 'ENTERED'))
      ),
      SQ_WORK_LIST_PRP AS
      (--объединяем вертикальную структуру нерабочего времени и времени начала работы на проекте
        SELECT LOGIN, PROJECT_ID, ACTION, ACT_TIME
        FROM SQ_WT
        UNION
        SELECT LOGIN, PROJECT_ID, ACTION, ACT_TIME
        FROM SQ_AT
      ),
      SQ_WORK_LIST AS
      (--получаем интервалы рабочего времени
        SELECT /*+ MATERILAIZE*/ WT.LOGIN, WT.PROJECT_ID,
          SQR.START_RANGE, SQR.FULL_RANGE,
          GREATEST(WT.ENTERED,SQR.START_RANGE) AS ENTERED,
          LEAST(WT.ENDED, SQR.STOP_RANGE) AS ENDED
        FROM(
              SELECT LOGIN, PROJECT_ID, ACT_TIME AS ENTERED,
                CASE
                  WHEN ACTION = 'ENTERED' THEN LEAD(ACT_TIME)OVER(PARTITION BY LOGIN, PROJECT_ID ORDER BY ACT_TIME)
                END AS ENDED
              FROM SQ_WORK_LIST_PRP
            )WT
        JOIN SQ_RANGES SQR ON WT.ENTERED <= SQR.STOP_RANGE AND WT.ENDED >= SQR.START_RANGE
      ),
      SQ_ST_LOGINS AS
      (--подсчитываем количество сотрудников работающих одновременно друг с другом на проекте
        SELECT SQWL.*, COUNT(DISTINCT SQWLA.LOGIN)OVER(PARTITION BY SQWL.START_RANGE, SQWL.PROJECT_ID, SQWL.LOGIN) AS ALOGIN
        FROM SQ_WORK_LIST SQWL
        LEFT JOIN SQ_WORK_LIST SQWLA ON SQWLA.PROJECT_ID = SQWL.PROJECT_ID
                                    AND SQWLA.LOGIN != SQWL.LOGIN
                                    AND SQWLA.ENTERED <= SQWL.ENDED AND SQWLA.ENDED >= SQWL.ENTERED
      ),
      SQ_ST_INFO AS
      (--получаем максимальное количество сотрудников работающих одновременно друг с другом на проекте и подводим итог
        SELECT /*+ MATERILAIZE*/ START_RANGE, FULL_RANGE,
          DECODE(GROUPING(PROJECT_ID),1,'Максимальное количество одновременно работающих за '||DECODE(GROUPING(FULL_RANGE),1,'период: ','интервал: '),'')||TO_CHAR(MAX(ALOGIN+1)) AS ALOGIN,
          DECODE(GROUPING(PROJECT_ID),1,'Итого за '||DECODE(GROUPING(FULL_RANGE),1,'период:','интервал:'),PROJECT_ID) AS PROJECT_ID
        FROM SQ_ST_LOGINS
        GROUP BY ROLLUP(START_RANGE, FULL_RANGE, PROJECT_ID)
      ),
      SQ_REPORT_DATA AS
      (--подсичтываем сколько различных сотрудников работало на каждом из проектов и затраченное ими рабочее время суммарно, а также подводим итоги по подсчетам
        SELECT /*+ MATERIALIZE*/ START_RANGE, FULL_RANGE,
          DECODE(GROUPING(PROJECT_ID),1,'Итого за '||DECODE(GROUPING(FULL_RANGE),1,'период:','интервал:'),PROJECT_ID) AS PROJECT_ID,
          DECODE(GROUPING(PROJECT_ID),1,'Всего человеко-часов за '||DECODE(GROUPING(FULL_RANGE),1,'период: ','интервал: '),'')||TRIM(TO_CHAR(SUM(DURATION*PROJECT_RATE)/3600,'9999999990D00')) AS PROJECT_WT,
          DECODE(GROUPING(PROJECT_ID),1,'Всего различных операторов за '||DECODE(GROUPING(FULL_RANGE),1,'период: ','интервал: '),'')||TO_CHAR(COUNT(DISTINCT LOGIN)) AS UNIC_LOGIN,
          GROUPING(PROJECT_ID) as g1,GROUPING(FULL_RANGE) as g2
        FROM SQ_STATUSES TS
        LEFT JOIN SQ_RANGES SQR ON SQR.START_RANGE <= TS.ENDED AND SQR.STOP_RANGE >= TS.ENTERED
        GROUP BY ROLLUP(START_RANGE, FULL_RANGE, PROJECT_ID)
      ),
      SQ_REPORT AS
      (--объединяем все данные, необходимы для отчета в одну структуру, а так же подменяем код проекта на его наименование
        SELECT SQRD.START_RANGE, NVL(MVP.CAPTION, SQRD.PROJECT_ID) AS PROJECT_NAME, SQRD.FULL_RANGE,
          SQRD.UNIC_LOGIN, SQSI.ALOGIN, SQRD.PROJECT_WT, SQRD.G1, SQRD.G2
        FROM SQ_REPORT_DATA SQRD
        LEFT JOIN SQ_ST_INFO SQSI ON NVL(SQSI.START_RANGE,SYSDATE) = NVL(SQRD.START_RANGE,SYSDATE)
                                 AND NVL(SQSI.FULL_RANGE,'*') = NVL(SQRD.FULL_RANGE,'*')
                                 AND NVL(SQSI.PROJECT_ID,'*') = NVL(SQRD.PROJECT_ID,'*')
        LEFT JOIN MV_PROJECTS MVP ON MVP.ID_ELEMENT = SQRD.PROJECT_ID
        WHERE SQRD.FULL_RANGE IS NOT NULL OR SQRD.START_RANGE IS NULL
        ORDER BY SQRD.START_RANGE, SQRD.G1, SQRD.G2
      ),
      SQ_DEVIDER AS
      (--формируем разделитель итоговых строк от данных
        SELECT
          LPAD('=',MAX(LENGTH(PROJECT_NAME)),'=') AS PROJECT_NAME,
          LPAD('=',MAX(LENGTH(FULL_RANGE)),'=') AS FULL_RANGE,
          LPAD('=',MAX(LENGTH(UNIC_LOGIN)),'=') AS UNIC_LOGIN,
          LPAD('=',MAX(LENGTH(ALOGIN)),'=') AS ALOGIN,
          LPAD('=',MAX(LENGTH(PROJECT_WT)),'=') AS PROJECT_WT
        FROM SQ_REPORT
      ),
      SQ_DEVIDERS AS
      (--формируем список разделителей
        SELECT /*+ MATERIALIZE*/
          SQR.START_RANGE, SQD.PROJECT_NAME, SQD.FULL_RANGE,
          SQD.UNIC_LOGIN, SQD.ALOGIN, SQD.PROJECT_WT, 0.9 AS G1
        FROM SQ_REPORT SQR
        CROSS JOIN SQ_DEVIDER SQD
        WHERE G1 = 1 AND G2 = 0
        UNION ALL
        SELECT
          SQR.START_RANGE, SQD.PROJECT_NAME, SQD.FULL_RANGE,
          SQD.UNIC_LOGIN, SQD.ALOGIN, SQD.PROJECT_WT, 1.1 AS G1
        FROM SQ_REPORT SQR
        CROSS JOIN SQ_DEVIDER SQD
        WHERE G1 = 1 AND G2 = 0
      )
    --формируем сам отчет с сортировкой и разделителям
    SELECT START_RANGE, DECODE(PROJECT_NAME,'{no_projects}','Без проекта',PROJECT_NAME) as PROJECT_NAME,
      NVL(FULL_RANGE, TO_CHAR(I_DATE_START, 'DD.MM.YYYY HH24:MI')||' - '||TO_CHAR(I_DATE_END, 'DD.MM.YYYY HH24:MI')) AS FULL_RANGE,
      UNIC_LOGIN, ALOGIN, PROJECT_WT, G1, G2
    FROM SQ_REPORT
    UNION ALL
    SELECT START_RANGE, PROJECT_NAME,
      NVL(FULL_RANGE, TO_CHAR(I_DATE_START, 'DD.MM.YYYY HH24:MI')||' - '||TO_CHAR(I_DATE_END, 'DD.MM.YYYY HH24:MI')) AS FULL_RANGE,
      UNIC_LOGIN, ALOGIN, PROJECT_WT, G1, 0
    FROM SQ_DEVIDERS
    ORDER BY START_RANGE, G1, G2, PROJECT_NAME;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_PROJECT_CC_LOAD;

  --Отчет "по UR и ОСС"
  FUNCTION FNC_REPORT_UR_OCC(
                              I_DATE_START TIMESTAMP,
                              I_DATE_END TIMESTAMP,
                              I_STEP_TYPE VARCHAR2 DEFAULT 'DD',
                              I_PROJECT VARCHAR2 DEFAULT NULL,
                              I_PROJECT_GROUP NUMBER DEFAULT 2,
                              I_LOCATION VARCHAR2 DEFAULT NULL,
                              I_LOCATION_GROUP NUMBER DEFAULT 2,
                              I_PLATFORMS VARCHAR2 DEFAULT NULL
                            )
    RETURN PT_REPORT_UR_OCC PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_REPORT_UR_OCC
    IS
    WITH SQ_RANGES AS
      (
        SELECT /*+ MATERIALIZE*/ START_RANGE, STOP_RANGE-INTERVAL '1' SECOND AS STOP_RANGE, FULL_RANGE
        FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(I_START_DATE=>I_DATE_START, I_END_DATE=>I_DATE_END,
                                                      I_STEP => 1, I_STEP_TYPE => I_STEP_TYPE, I_MASK => 'DD.MM.YYYY HH24:MI'))
      ),
      SQ_REPORT_DATA AS
      (
        SELECT /*+ MATERIALIZE*/ SQR.FULL_RANGE, TS.CC_CAPTION, DECODE(TS.LOCATION_CAPTION,'{all}','Все площадки',TS.LOCATION_CAPTION) AS LOCATION_CAPTION,
          NVL(MVP.CAPTION, DECODE(TS.PROJECT_ID,'{no_projects}','Без проекта',TS.PROJECT_ID)) AS PROJECT_NAME,
          DECODE(GROUPING(EXTRACT(HOUR FROM TS.ENTERED)),1,24,EXTRACT(HOUR FROM TS.ENTERED)) AS REPORT_HOUR,
          NVL(
              SUM(CASE
                    WHEN TS.STATUS IN ('ringing','speaking','wrapup')
                      OR (TS.STATUS = 'away' AND TS.REASON = 'CustomAwayReason16')
                    THEN TS.DURATION*TS.PROJECT_RATE
                  END),0) AS ACTIVE_TIME,
          NVL(
              SUM(CASE
                    WHEN TS.STATUS IN ('ringing','speaking','wrapup','normal')
                      OR (TS.STATUS = 'away' AND TS.REASON = 'CustomAwayReason16')
                    THEN TS.DURATION*TS.PROJECT_RATE
                  END),0) AS LOGIN_TIME,
          SUM(TS.DURATION*TS.PROJECT_RATE) AS FULL_TIME
        FROM TABLE(PKG_API.GET_STATUSES(I_DATE_START, I_DATE_END, I_PROJECT=>I_PROJECT, I_GROUP_PROJECTS_LEVEL=>I_PROJECT_GROUP,
                                                I_LOCATION=>I_LOCATION, I_GROUP_LOCATION=>I_LOCATION_GROUP, I_STEP_TYPE=>I_STEP_TYPE,
                                                I_STATUSES=>'away,custom1,custom2,custom3,normal,'||
                                                            'ringing,speaking,wrapup,training,time_break,tech_problem',
                                                I_ROLETYPE=>'operator', I_PLATFORMS=>I_PLATFORMS)) TS
        RIGHT JOIN SQ_RANGES SQR ON TS.ENTERED BETWEEN SQR.START_RANGE AND SQR.STOP_RANGE
        LEFT JOIN MV_PROJECTS MVP ON MVP.ID_ELEMENT = TS.PROJECT_ID
        WHERE TS.REASON NOT IN ('CustomAwayReason3','CustomAwayReason11','CustomAwayReason12','CustomAwayReason17',
                'CustomAwayReason18','CustomAwayReason19','CustomAwayReason20','CustomAwayReason21','CustomAwayReason22')
        GROUP BY ROLLUP(SQR.FULL_RANGE, TS.CC_CAPTION, TS.LOCATION_CAPTION,
          NVL(MVP.CAPTION, DECODE(TS.PROJECT_ID,'{no_projects}','Без проекта',TS.PROJECT_ID))),
          ROLLUP(EXTRACT(HOUR FROM TS.ENTERED))
      ),
      SQ_CALC_UR_OCC AS
      (
        SELECT FULL_RANGE, CC_CAPTION, LOCATION_CAPTION, PROJECT_NAME, REPORT_HOUR,
          ROUND(ACTIVE_TIME/DECODE(LOGIN_TIME,0,1,LOGIN_TIME)*100,2) AS VAL, 'OCC' AS PARAM_TYPE
        FROM SQ_REPORT_DATA
        UNION
        SELECT FULL_RANGE, CC_CAPTION, LOCATION_CAPTION, PROJECT_NAME, REPORT_HOUR,
          ROUND(LOGIN_TIME/DECODE(FULL_TIME, 0, 1, FULL_TIME)*100,2) AS VAL, 'UR' AS PARAM_TYPE
        FROM SQ_REPORT_DATA
      ),
      SQ_REPORT_BODY AS
      (
        SELECT /*+ MATERIALIZE*/ FULL_RANGE, CC_CAPTION, LOCATION_CAPTION, PROJECT_NAME,
          PARAM_TYPE, H0, H1, H2, H3, H4, H5, H6, H7, H8, H9, H10, H11, H12, H13, H14,
          H15, H16, H17, H18, H19, H20, H21, H22, H23, HSUM, ROWNUM AS ORDER_ROW
        FROM SQ_CALC_UR_OCC
        PIVOT
        (MAX(VAL) FOR REPORT_HOUR IN ('0' AS H0,'1' AS H1,'2' AS H2,'3' AS H3,'4' AS H4,'5' AS H5,
            '6' AS H6,'7' AS H7,'8' AS H8,'9' AS H9,'10' AS H10,'11' AS H11,'12' AS H12, '13' AS H13,
            '14' AS H14,'15' AS H15,'16' AS H16,'17' AS H17,'18' AS H18, '19' AS H19,'20' AS H20,
            '21' AS H21,'22' AS H22,'23' AS H23,'24' AS HSUM))
      )
    SELECT CASE WHEN PROJECT_NAME IS NULL THEN 'Итого за период: ' END||
      NVL(FULL_RANGE, TO_CHAR(I_DATE_START,'DD.MM.YYYY HH24:MI')||' - '||TO_CHAR(I_DATE_END,'DD.MM.YYYY HH24:MI')) as FULL_RANGE,
      CC_CAPTION, LOCATION_CAPTION, PROJECT_NAME, PARAM_TYPE, NVL(H0,0) AS H0, NVL(H1,0) AS H1, NVL(H2,0) AS H2,
      NVL(H3,0) AS H3, NVL(H4,0) AS H4, NVL(H5,0) AS H5, NVL(H6,0) AS H6, NVL(H7,0) AS H7, NVL(H8,0) AS H8,
      NVL(H9,0) AS H9, NVL(H10,0) AS H10, NVL(H11,0) AS H11, NVL(H12,0) AS H12, NVL(H13,0) AS H13,
      NVL(H14,0) AS H14, NVL(H15,0) AS H15, NVL(H16,0) AS H16, NVL(H17,0) AS H17, NVL(H18,0) AS H18,
      NVL(H19,0) AS H19, NVL(H20,0) AS H20, NVL(H21,0) AS H21, NVL(H22,0) AS H22, NVL(H23,0) AS H23,
      NVL(HSUM,0) AS HSUM
    FROM SQ_REPORT_BODY
    ORDER BY ORDER_ROW;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_UR_OCC;

  --Отчет "Состояния по выбранному пользователю"
  FUNCTION FNC_REPORT_OPERATOR_STATES (
                                        I_DATE_START TIMESTAMP,
                                        I_DATE_END TIMESTAMP,
                                        I_LOGIN VARCHAR2 DEFAULT NULL,
                                        I_STATUS VARCHAR2 DEFAULT NULL,
                                        I_PLATFORMS VARCHAR2 DEFAULT NULL
                                      )
    RETURN PT_REPORT_OPERATOR_STATES PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_REPORT_OPERATOR_STATES
    IS
    SELECT TS.LOGIN, MVS.NAU_STATUS,
      PKG_INTERVALS.FNC_INTERVALTOCHAR(NUMTODSINTERVAL(TS.DURATION,'second'),'HH24:MI:SS') AS STATUS_DURATION
    FROM TABLE(PKG_API.GET_STATUSES(I_DATE_START=>I_DATE_START, I_DATE_END=>I_DATE_END,
                                    I_LOGIN=>I_LOGIN, I_ROLETYPE=>'operator', I_PLATFORMS=>I_PLATFORMS)) TS
    JOIN MV_STATUSES MVS ON MVS.ID_NAU_STATUS = TS.FID_STATUS
                        AND MVS.NAU_STATUS LIKE NVL(I_STATUS, '%')
    ORDER BY TS.LOGIN, TS.ENTERED;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_OPERATOR_STATES;

  --Отчет "Время входа в наумен"
  FUNCTION FNC_REPORT_LOGON_TIME(
                                  I_DATE_START TIMESTAMP,
                                  I_DATE_END TIMESTAMP,
                                  I_PLATFORMS VARCHAR2 DEFAULT NULL
                                )
    RETURN PT_REPORT_LOGON_TIME PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_REPORT_LOGON_TIME
    IS
    WITH SQ_PRP_STATUSES AS
      (
        SELECT DISTINCT
          MIN(TS.ENTERED)OVER(PARTITION BY TS.LOGIN) AS START_WORK,
          FIRST_VALUE(MVS.NAU_STATUS)OVER(PARTITION BY TS.LOGIN ORDER BY TS.ENTERED) AS START_STATUS,
          CAST(ENTERED+DURATION/86400 AS TIMESTAMP) AS ENDED,
          TS.LOGIN, TS.DURATION, TS.ENTERED, MVS.NAU_STATUS
        FROM TABLE(PKG_API.GET_STATUSES(I_DATE_START=>I_DATE_START, I_DATE_END=>I_DATE_END+1,
                                        I_STEP=>2, I_STEP_TYPE=> 'YY', I_ROLETYPE=>'operator',
                                        I_PLATFORMS=>I_PLATFORMS)) TS
        JOIN MV_STATUSES MVS ON MVS.ID_NAU_STATUS=TS.FID_STATUS
      ),
      SQ_REPORT AS
      (
        SELECT LOGIN,
          CASE
            WHEN NAU_STATUS = 'offline'
            THEN CAST(ENTERED+DURATION/86400 AS TIMESTAMP)
            ELSE ENTERED
          END AS NAU_LOGON,
          LEAD(DECODE(NAU_STATUS, 'offline', ENTERED, NULL)IGNORE NULLS)
            OVER(PARTITION BY LOGIN ORDER BY ENTERED) AS NAU_LOGOUT
        FROM SQ_PRP_STATUSES
        WHERE NAU_STATUS = 'offline'
          OR (START_WORK = ENTERED
              AND START_STATUS = NAU_STATUS)
      )
    SELECT DISTINCT LOGIN, NAU_LOGON, NAU_LOGOUT
    FROM SQ_REPORT
    WHERE NAU_LOGON < I_DATE_END;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_LOGON_TIME;

  --Отчет по операторам с последней датой звонка меньше заданной
  FUNCTION FNC_REPORT_OPR_WITH_LAST_DATE (I_DATE_LAST TIMESTAMP,
                                          I_PLATFORMS VARCHAR2 DEFAULT NULL)
    RETURN PT_REPORT_OPR_WITH_LAST_DATE PIPELINED
  AS
    CURSOR GET_DATA RETURN PTR_REPORT_OPR_WITH_LAST_DATE
    IS
    WITH SQ_LOGINS AS
      (
        SELECT /*+ MATERIALIZE*/ LOGIN, FID_PLATFORM
        FROM TABLE(PKG_SERVICE.FNC_GET_LOGINS(ADD_MONTHS(I_DATE_LAST,-8), I_DATE_LAST, I_PLATFORMS=>I_PLATFORMS, I_ROLETYPE=>'operator')) OPR
      ),
      SQ_DATA AS
      (
        SELECT VWES.ENTERED, VWES.LOGIN, VWES.FID_PLATFORM,
          FIRST_VALUE(VWES.FID_PROJECT)
            OVER(PARTITION BY VWES.LOGIN
                  ORDER BY VWES.ENTERED DESC)AS FID_PROJECT
        FROM VW_EMPLOYEES_STATUSES VWES
        JOIN MV_STATUSES MVS ON VWES.FID_NAU_STATUS = MVS.ID_NAU_STATUS
                            AND MVS.NAU_STATUS IN ('ringing','speaking')
        WHERE ENTERED BETWEEN ADD_MONTHS(I_DATE_LAST,-8) AND I_DATE_LAST-INTERVAL '1' SECOND
          AND EXISTS(
                      SELECT 1
                      FROM SQ_LOGINS SQE
                      WHERE SQE.LOGIN = VWES.LOGIN
                        AND SQE.FID_PLATFORM = VWES.FID_PLATFORM
                    )
      )
    SELECT SQE.LOGIN,
      NVL(TO_CHAR(MAX(SQD.ENTERED),'DD.MM.YYYY'),'Звонков не было') AS LAST_DATE,
      NVL(MVP.CAPTION,
          DECODE(SQD.FID_PROJECT,
                  '{no_projects}', 'Без проекта',
                  SQD.FID_PROJECT)) AS PROJECT_NAME
    FROM SQ_DATA SQD
    LEFT JOIN MV_PROJECTS MVP ON MVP.ID_ELEMENT = SQD.FID_PROJECT
    RIGHT JOIN SQ_LOGINS SQE ON SQE.LOGIN = SQD.LOGIN AND SQE.FID_PLATFORM = SQD.FID_PLATFORM
    GROUP BY SQE.LOGIN,
      NVL(MVP.CAPTION,
          DECODE(SQD.FID_PROJECT,
                  '{no_projects}', 'Без проекта',
                  SQD.FID_PROJECT))
    ORDER BY SQE.LOGIN;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_OPR_WITH_LAST_DATE;

--------------------------------------------------------------------------------
--------------------------------ВХОДЯЩАЯ ЛИНИЯ----------------------------------
--------------------------------------------------------------------------------
  --Отчет "Входящие вызовы по проекту"
  FUNCTION FNC_REPORT_PROJECT_INCCALL(
                                      I_DATE_START TIMESTAMP,
                                      I_DATE_END TIMESTAMP,
                                      I_PROJECT VARCHAR2 DEFAULT NULL,
                                      I_PLATFORMS VARCHAR2 DEFAULT NULL
                                    )
    RETURN PT_REPORT_PROJECT_INCCALL PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_REPORT_PROJECT_INCCALL
    IS
    SELECT RPT.PROJECT_NAME,
      RPT.FID_PROJECT,
      RPT.SESSION_ID,
      RPT.ABONENT,
      RPT.CALLED,
      RPT.START_CALL_TIME,
      CASE
        WHEN RPT.OPERATOR_RESULT='Вызов принят оператором'
        THEN CAST(RPT.OPERATOR_CREATED+RPT.REACTION_TIME/86400 AS TIMESTAMP)
      END AS OPERATOR_CONNECTED,
      RPT.BREAK_CALL_TIME,
      PKG_INTERVALS.FNC_INTERVALTOSEC(RPT.START_CALL_TIME, RPT.BREAK_CALL_TIME) AS CALL_TIME,
      RPT.LINK_ID,
      RPT.OPERATOR,
      CASE
        WHEN RPT.IVR_RESULT IN ('ServiceinIVR','Переведен вовне из IVR')
        THEN 'Вызов принят без участия оператора (Респешн)'
        WHEN RPT.REDIRECT_RESULT='Звонок переведен' THEN 'Вызов перенаправлен'
        WHEN RPT.OPERATOR_RESULT='Вызов принят оператором' THEN 'Вызов принят'
        WHEN RPT.OPERATOR_RESULT='Потерян в ringing' THEN 'Вызов пропущен оператором'
        WHEN RPT.OPERATOR_RESULT = 'Потерян в очереди' OR RPT.IVR_RESULT='Завершен в IVR'
        THEN 'Вызов завершён на IVR'
        ELSE RPT.OPERATOR_RESULT--,RPT.IVR_RESULT)
      END AS CALL_RESULT,
      RPT.REDIRECT_NUM,
      RPT.WAIT_TIME,
      RPT.REACTION_TIME,
      RPT.SPEAK_TIME,
      RPT.OPERATOR_WRAPUP,
      RPT.OPERATOR_HOLD,
      CEIL(SERVICE_TIME/60) AS SERVICE_TIME_MINC,
      'Вызов из внешней среды' AS CALL_TYPE
    FROM TABLE(FNC_REPORT_DETAIL_INCCALL(I_DATE_START, I_DATE_END, I_PROJECT, I_PLATFORMS)) RPT;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_PROJECT_INCCALL;

  --Отчет "Количество и результат звонков по проектам входящей линии"
  FUNCTION FNC_REPORT_PROJECT_INCCALLS(
                                        I_DATE_START TIMESTAMP,
                                        I_DATE_END TIMESTAMP,
                                        I_PROJECT VARCHAR2 DEFAULT NULL,
                                        I_PLATFORMS VARCHAR2 DEFAULT NULL
                                      )
    RETURN PT_REPORT_PROJECT_INCCALLS PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_REPORT_PROJECT_INCCALLS
    IS
    SELECT CALL_RESULT, COUNT(DISTINCT SESSION_ID) AS SESSION_CNT
    FROM TABLE(FNC_REPORT_PROJECT_INCCALL(I_DATE_START, I_DATE_END, I_PROJECT, I_PLATFORMS))
    GROUP BY CALL_RESULT;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_PROJECT_INCCALLS;

  --Отчет "QualityReport "
  FUNCTION FNC_REPORT_QUALITYREPORT (
                                      I_DATE_START TIMESTAMP,
                                      I_DATE_END TIMESTAMP,
                                      I_STEP_TYPE VARCHAR2 DEFAULT 'DD',
                                      I_PROJECT VARCHAR2 DEFAULT NULL,
                                      I_PROJECT_GROUP NUMBER DEFAULT 2,
                                      I_PLATFORMS VARCHAR2 DEFAULT NULL
                                    )
    RETURN PT_REPORT_QUALITYREPORT PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_REPORT_QUALITYREPORT
    IS
    WITH SQ_RANGES AS
      (--разбиваем интервал на подинтервалы
        SELECT /*+ MATERIALIZE*/ START_RANGE, STOP_RANGE-INTERVAL '1' SECOND AS STOP_RANGE, FULL_RANGE
        FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(I_DATE_START,I_DATE_END,I_STEP=>NVL(PKG_STRINGS.FNC_TONUMBER(SUBSTR(I_STEP_TYPE,3)),1),
                                                      I_STEP_TYPE=>SUBSTR(I_STEP_TYPE,1,2), I_MASK=>'DD.MM.YYYY HH24:MI'))
      ),
      SQ_STATUSES_PRP AS
      (
        SELECT SQR.FULL_RANGE, ST.LOGIN, ST.FID_PLATFORM,
          NVL(DECODE(NVL(I_PROJECT_GROUP,2), 1, MVP.FID_GROUP), ST.PROJECT_ID) FID_PROJECT
        FROM TABLE(PKG_API.GET_STATUSES(I_DATE_START, I_DATE_END, I_PROJECT, I_ROLETYPE => 'operator')) ST
          JOIN SQ_RANGES SQR ON SQR.START_RANGE < ST.ENTERED + ST.DURATION / 86400 AND SQR.STOP_RANGE > ST.ENTERED
          JOIN MV_PROJECTS MVP ON MVP.ID_ELEMENT = ST.PROJECT_ID AND MVP.FID_PLATFORM = ST.FID_PLATFORM
        WHERE ST.STATUS = 'available'
      ),
      SQ_STATUSES AS
      (
        SELECT /*+ MATERIALIZE*/ FULL_RANGE, FID_PROJECT, FID_PLATFORM, COUNT(DISTINCT LOGIN) OPERATORS_CNT
        FROM SQ_STATUSES_PRP
        GROUP BY FULL_RANGE, FID_PROJECT, FID_PLATFORM
      ),
      SQ_CALLS_PRP AS
      (
        SELECT /*+ MATERIALIZE*/ DISTINCT SQR.FULL_RANGE, CI.SESSION_ID, CI.FINAL_STAGE,
          NVL(DECODE(NVL(I_PROJECT_GROUP,2), 1, MVP.FID_GROUP), CI.FID_PROJECT) AS FID_PROJECT,
          DECODE(CI.FID_PROJECT, 'project_not_determined', 0, CI.FID_PLATFORM) AS FID_PLATFORM,
          CASE
            WHEN MAX(CI.OPERATOR_CONNECTED)OVER(PARTITION BY SQR.FULL_RANGE, NVL(DECODE(NVL(I_PROJECT_GROUP,2), 1, MVP.FID_GROUP), CI.FID_PROJECT), CI.SESSION_ID)IS NULL
            THEN PKG_INTERVALS.FNC_INTERVALTOSEC(NVL(CI.OPERATOR_CREATED, CI.CREATED),NVL(CI.OPERATOR_ENDED,CI.ENDED))
          END AS TIME_TO_LOST, --Время до потери вызова
          CASE
            WHEN CI.FINAL_STAGE = 'ivr'
            THEN 1
          END AS SERVICE_IVR, --Вызов обслужен в IVR
          PKG_INTERVALS.FNC_INTERVALTOSEC(CI.UNBLOCKED_TIME,
              MIN(CI.OPERATOR_CONNECTED)OVER(PARTITION BY SQR.FULL_RANGE, NVL(DECODE(NVL(I_PROJECT_GROUP,2), 1, MVP.FID_GROUP), CI.FID_PROJECT), CI.SESSION_ID)) AS ASA,
          NVL(PKG_INTERVALS.FNC_INTERVALTOSEC(
              CI.UNBLOCKED_TIME,
              NVL(MIN(CI.OPERATOR_CONNECTED)OVER(PARTITION BY SQR.FULL_RANGE, NVL(DECODE(NVL(I_PROJECT_GROUP,2), 1, MVP.FID_GROUP), CI.FID_PROJECT), CI.SESSION_ID),
                  CI.DEQUEUED_TIME)), 0) AS WAIT_TIME,
          CASE
            WHEN CI.FINAL_STAGE LIKE 'operator%'
            THEN PKG_INTERVALS.FNC_INTERVALTOSEC(CI.OPERATOR_CREATED,CI.OPERATOR_CONNECTED)
          END AS REACTION_TIME, --Время реакции на вызов
          CASE
            WHEN CI.FINAL_STAGE LIKE 'operator%'
            THEN PKG_INTERVALS.FNC_INTERVALTOSEC(CI.OPERATOR_CONNECTED,CI.OPERATOR_ENDED)
          END AS SPEAK_TIME, --Время разговора оператора
          CASE
            WHEN CI.FINAL_STAGE LIKE 'operator%'
            THEN CI.OPERATOR_WRAPUP
          END AS OPERATOR_WRAPUP, --Время поствызывной обработки
          CASE
            WHEN CI.FINAL_STAGE LIKE 'operator%'
            THEN PKG_INTERVALS.FNC_INTERVALTOSEC(CI.OPERATOR_CREATED,CI.OPERATOR_ENDED)+CI.OPERATOR_WRAPUP
          END AS SERVICE_TIME, --Время обслуживания звонка оператором
          CASE
            WHEN CI.FINAL_STAGE LIKE 'operator%'
            THEN CI.OPERATOR_HOLD
          END AS OPERATOR_HOLD, --Время удержания вызова
          PKG_INTERVALS.FNC_INTERVALTOSEC(CI.IVR_CREATED,NVL(CI.OPERATOR_CONNECTED,CI.IVR_ENDED)) AS IVR_TIME, --Время нахождения вызова в IVR
          CASE
            WHEN CI.FINAL_STAGE = 'redirected'
              AND LAG(CASE WHEN CI.FINAL_STAGE LIKE 'operator%' THEN CI.OPERATOR_ENDED END IGNORE NULLS)
                    OVER(PARTITION BY SQR.FULL_RANGE, NVL(DECODE(NVL(I_PROJECT_GROUP,2), 1, MVP.FID_GROUP), CI.FID_PROJECT), CI.SESSION_ID ORDER BY CI.LINK_ID) < CI.OPERATOR_ENDED
            THEN 1
            WHEN CI.FINAL_STAGE = 'redirected'
              AND LAG(CASE WHEN CI.FINAL_STAGE LIKE 'operator%' THEN CI.OPERATOR_ENDED END IGNORE NULLS)
                    OVER(PARTITION BY SQR.FULL_RANGE, NVL(DECODE(NVL(I_PROJECT_GROUP,2), 1, MVP.FID_GROUP), CI.FID_PROJECT), CI.SESSION_ID ORDER BY CI.LINK_ID) IS NULL
            THEN 2
          END AS IS_REDIRECTED, --Звонок переведен
          CASE
            WHEN CI.FINAL_STAGE = 'redirected'
              AND (
                    LAG(CASE WHEN CI.FINAL_STAGE LIKE 'operator%' THEN CI.OPERATOR_ENDED END IGNORE NULLS)
                      OVER(PARTITION BY SQR.FULL_RANGE, NVL(DECODE(NVL(I_PROJECT_GROUP,2), 1, MVP.FID_GROUP), CI.FID_PROJECT), CI.SESSION_ID ORDER BY CI.LINK_ID) < CI.OPERATOR_ENDED
                    OR LAG(CASE WHEN CI.FINAL_STAGE LIKE 'operator%' THEN CI.OPERATOR_ENDED END IGNORE NULLS)
                      OVER(PARTITION BY SQR.FULL_RANGE, NVL(DECODE(NVL(I_PROJECT_GROUP,2), 1, MVP.FID_GROUP), CI.FID_PROJECT), CI.SESSION_ID ORDER BY CI.LINK_ID) IS NULL
                  )
            THEN NVL(PKG_INTERVALS.FNC_INTERVALTOSEC(CI.OPERATOR_CONNECTED,CI.OPERATOR_ENDED), 0)
          END AS REDIRECTED_TIME,
          CI.IS_WORK_TIME AS INCORRECT_CALL_TIME, --Отбой звонка из-за некорректного времени поступления
          MIN(CI.UNBLOCKED_TIME)OVER(PARTITION BY SQR.FULL_RANGE, CI.FID_PROJECT, CI.SESSION_ID, CI.IVR_NUMBER) AS QUEUE_START,
          NVL(MAX(NVL2(CI.OPERATOR_CONNECTED, CI.OPERATOR_CREATED,NULL))OVER(PARTITION BY SQR.FULL_RANGE, CI.FID_PROJECT, CI.SESSION_ID, CI.IVR_NUMBER),
              MAX(CI.DEQUEUED_TIME)OVER(PARTITION BY SQR.FULL_RANGE, CI.FID_PROJECT, CI.SESSION_ID, CI.IVR_NUMBER)) AS QUEUE_STOP,
          CI.IVR_NUMBER
        FROM TABLE(PKG_API.GET_CALL_LINKS(I_DATE_START, I_DATE_END, I_PROJECT, 'IN', I_PLATFORMS)) CI
        LEFT JOIN SQ_RANGES SQR ON CI.CREATED BETWEEN SQR.START_RANGE AND SQR.STOP_RANGE
        LEFT JOIN MV_PROJECTS MVP ON MVP.ID_ELEMENT = CI.FID_PROJECT AND MVP.FID_PLATFORM = CI.FID_PLATFORM
        WHERE CI.FINAL_STAGE NOT LIKE 'intrusion%'
      ),
      SQ_CALLS AS
      (
        SELECT FULL_RANGE, SESSION_ID, FID_PROJECT, FINAL_STAGE,
          TIME_TO_LOST, SERVICE_IVR, ASA, WAIT_TIME, REACTION_TIME, SPEAK_TIME,
          OPERATOR_WRAPUP, SERVICE_TIME, OPERATOR_HOLD, IVR_TIME, IS_REDIRECTED,
          REDIRECTED_TIME, INCORRECT_CALL_TIME, FID_PLATFORM,
          COUNT(SESSION_ID)OVER(PARTITION BY FULL_RANGE, FID_PROJECT, IVR_NUMBER
            ORDER BY CAST(QUEUE_START AS DATE) RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)-
            COUNT(SESSION_ID)OVER(PARTITION BY FULL_RANGE, FID_PROJECT, IVR_NUMBER
              ORDER BY CAST(QUEUE_START AS DATE) RANGE BETWEEN UNBOUNDED PRECEDING AND COALESCE(PKG_INTERVALS.FNC_INTERVALTOSEC(QUEUE_START, QUEUE_STOP), 0)/24/60/60 PRECEDING) AS QUEUE_LENGTH,
          PKG_INTERVALS.FNC_INTERVALTOSEC(QUEUE_START, QUEUE_STOP) AS QUEUE_TIME
        FROM SQ_CALLS_PRP
        UNION ALL
        SELECT SQR.FULL_RANGE, NULL, PRJS.FID_PROJECT, NULL, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, PRJS.FID_PLATFORM, 0, NULL
        FROM SQ_RANGES SQR
        CROSS JOIN (
                    SELECT DISTINCT FID_PROJECT, FID_PLATFORM FROM SQ_CALLS_PRP
                  ) PRJS
        WHERE NOT EXISTS(
                          SELECT DISTINCT FID_PROJECT, FID_PLATFORM, FULL_RANGE
                          FROM SQ_CALLS_PRP SQCP
                          WHERE SQCP.FULL_RANGE = SQR.FULL_RANGE
                            AND SQCP.FID_PROJECT = PRJS.FID_PROJECT
                            AND SQCP.FID_PLATFORM = PRJS.FID_PLATFORM
                        )
      ),
      SQ_CALLS_SUM AS
      (
        SELECT FULL_RANGE, SESSION_ID, FID_PROJECT, FID_PLATFORM,
          SUM(TIME_TO_LOST) AS TIME_TO_LOST, MAX(SERVICE_IVR) AS SERVICE_IVR,
          SUM(WAIT_TIME) AS WAIT_TIME, AVG(ASA) AS ASA, AVG(ASA) AS AVG_ASA,
          SUM(REACTION_TIME) AS REACTION_TIME, AVG(REACTION_TIME) AS AVG_REACTION_TIME,
          SUM(SPEAK_TIME) AS SPEAK_TIME, AVG(SPEAK_TIME) AS AVG_SPEAK_TIME,
          SUM(CASE WHEN TIME_TO_LOST IS NULL THEN OPERATOR_WRAPUP END) AS OPERATOR_WRAPUP,
          AVG(CASE WHEN TIME_TO_LOST IS NULL THEN OPERATOR_WRAPUP END) AS ACW,
          SUM(CASE WHEN TIME_TO_LOST IS NULL THEN SERVICE_TIME END) AS SERVICE_TIME,
          AVG(CASE WHEN TIME_TO_LOST IS NULL THEN SERVICE_TIME END) AS AVG_SERVICE_TIME,
          SUM(OPERATOR_HOLD) AS OPERATOR_HOLD, SUM(IVR_TIME) AS IVR_TIME,
          MAX(IS_REDIRECTED) AS IS_REDIRECTED, MAX(INCORRECT_CALL_TIME) AS INCORRECT_CALL_TIME,
          SUM(REDIRECTED_TIME) AS REDIRECTED_TIME, MAX(QUEUE_LENGTH) AS QUEUE_LENGTH,
          MIN(QUEUE_LENGTH) AS MIN_QUEUE_LENGTH, AVG(QUEUE_LENGTH) AS AVG_QUEUE_LENGTH,
          MIN(QUEUE_TIME) AS MIN_QUEUE_TIME, MAX(QUEUE_TIME) AS MAX_QUEUE_TIME, AVG(QUEUE_TIME) AS AVG_QUEUE_TIME
        FROM SQ_CALLS
        GROUP BY FULL_RANGE, SESSION_ID, FID_PROJECT, FID_PLATFORM
      ),
      SQ_RESULT AS
      (
        SELECT FULL_RANGE, FID_PROJECT, FID_PLATFORM,
          COUNT(DISTINCT CASE WHEN SERVICE_IVR IS NULL THEN SESSION_ID END) AS SESSION_CNT,--Общее число сессий
          COUNT(DISTINCT CASE WHEN TIME_TO_LOST IS NULL
                              OR MIN_QUEUE_TIME IS NOT NULL THEN SESSION_ID END) AS QUEUED_SESSION_CNT,--Число распределенных в очередь
          COUNT(DISTINCT CASE WHEN SERVICE_IVR IS NULL AND TIME_TO_LOST IS NULL
                              THEN SESSION_ID END) AS SERVICE_SESSION_CNT, --Число обслуженных сессий
          ROUND(NVL(AVG(AVG_SPEAK_TIME),0),4) AS AVG_SPEAK_TIME, --Среднее время разговора
          COUNT(DISTINCT NVL2(IS_REDIRECTED, SESSION_ID, NULL)) AS REDIRECTED_CNT, --Число перенаправленных вызовов
          COUNT(DISTINCT DECODE(IS_REDIRECTED,1, SESSION_ID, NULL)) AS OPR_REDIRECTED_CNT, --Число перенаправленных вызовов оператором
          COUNT(DISTINCT CASE WHEN WAIT_TIME < 20 AND SERVICE_IVR IS NULL AND TIME_TO_LOST IS NULL
                              THEN SESSION_ID END) AS SERVICE_SESSION_CNT20, --Число обслуженных вызовов при ожидании менее 20 секунд
          COUNT(DISTINCT CASE WHEN WAIT_TIME < 40 AND SERVICE_IVR IS NULL AND TIME_TO_LOST IS NULL
                              THEN SESSION_ID END) AS SERVICE_SESSION_CNT40, --Число обслуженных вызовов при ожидании менее 40 секунд
          COUNT(DISTINCT CASE WHEN SERVICE_IVR IS NULL AND TIME_TO_LOST IS NOT NULL
                              THEN SESSION_ID END) AS LOST_SESSION_CNT, --Число потерянных вызовов
          COUNT(DISTINCT CASE WHEN SERVICE_IVR IS NULL AND TIME_TO_LOST IS NOT NULL
                                AND TIME_TO_LOST < 5 THEN SESSION_ID END) AS LOST_SESSION_CNT5, --Число потерянных вызовов при ожидании менее 5 секунд
          COUNT(DISTINCT CASE WHEN SERVICE_IVR IS NULL AND TIME_TO_LOST IS NOt NULL
                                AND TIME_TO_LOST > 5 THEN SESSION_ID END) AS LOST_SESSION_CNTM5, --Число потерянных вызовов при ожидании более 5 секунд
          COUNT(DISTINCT CASE WHEN SERVICE_IVR IS NULL AND TIME_TO_LOST IS NOT NULL
                                AND TIME_TO_LOST <= 20 THEN SESSION_ID END) AS LOST_SESSION_CNT20, --Число потерянных вызовов при ожидании менее 20 секунд
          COUNT(DISTINCT CASE WHEN SERVICE_IVR IS NULL AND TIME_TO_LOST IS NOT NULL
                                AND TIME_TO_LOST <= 40 THEN SESSION_ID END) AS LOST_SESSION_CNT40, --Число потерянных вызовов при ожидании менее 40 секунд
          COUNT(DISTINCT CASE WHEN SERVICE_IVR IS NULL AND TIME_TO_LOST IS NOT NULL
                                AND TIME_TO_LOST > 20 THEN SESSION_ID END) AS LOST_SESSION_CNTM20, --Число потерянных вызовов при ожидании более 20 секунд
          COUNT(DISTINCT CASE WHEN SERVICE_IVR IS NULL AND TIME_TO_LOST IS NOT NULL
                                AND TIME_TO_LOST > 40 THEN SESSION_ID END) AS LOST_SESSION_CNTM40, --Число потерянных вызовов при ожидании более 40 секунд
          COUNT(DISTINCT CASE WHEN SERVICE_IVR IS NULL AND INCORRECT_CALL_TIME = 1 THEN SESSION_ID END) AS ERR_SESSION_CNT, --Число отбоев
          COUNT(DISTINCT CASE WHEN SERVICE_IVR IS NULL AND SPEAK_TIME < 5 THEN SESSION_ID END) AS OPR_CONNECTS5_CNT, --Соединений, длительностью до 5 секунд
          ROUND(AVG(ASA),4) AS ASA, --Средняя скорость ответа "ASA"
          MAX(ASA) AS LCW, --Максимальная задержка с ответом,"LCW"
          MAX(QUEUE_LENGTH) AS QUEUE_LENGTH, --Максимальнное количество вызовов, находящихся в очереди
          MIN(MIN_QUEUE_LENGTH) AS MIN_QUEUE_LENGTH, --Минимальное количество вызовов, находящихся в очереди
          CEIL(NVL(AVG(AVG_QUEUE_LENGTH),0)) AS AVG_QUEUE_LENGTH, --Среднее количество вызовов, находящихся в очереди
          MIN(MIN_QUEUE_TIME) AS MIN_QUEUE_TIME, --Минимальное время нахождения в очереди
          MAX(MAX_QUEUE_TIME) AS MAX_QUEUE_TIME, --Максимальное время нахождения в очереди
          ROUND(NVL(AVG(AVG_QUEUE_TIME),0),4) AS AVG_QUEUE_TIME, --Среднее время нахождения в очереди
          NVL(ROUND(AVG(TIME_TO_LOST),4),0) AS ATA, --Среднее время ожидания до потери вызова "ATA"
          NVL(MAX(TIME_TO_LOST),0) AS MATA,--Максимальное время ожидания до потери вызова, сек.
          ROUND(AVG(ACW),4) AS ACW, --Среднее время поствызывной обработки "ACW"
          SUM(SPEAK_TIME) AS SUM_SPEAK_TIME, --Суммарное время разговора
          SUM(OPERATOR_WRAPUP) AS SUM_OPERATOR_WRAPUP, --Суммарное время поствызывной обработки
          ROUND(AVG(AVG_REACTION_TIME),4) AS ART, --Среднее время реакции на вызов, сек.
          MAX(REACTION_TIME) AS MRT, --Максимальное время реакции на вызов, сек.
          ROUND(AVG(AVG_SERVICE_TIME),4) AS AHT, --Среднее время обслуживания вызова "AHT", сек.
          MAX(SERVICE_TIME) AS MHT, --Максимальное время обслуживания вызова "MHT", сек.
          SUM(SERVICE_TIME) AS SST, --Суммарная длительность обслуживания вызова, сек.
          CEIL(SUM(SERVICE_TIME)/60) AS CSST, --Суммарная длительность обслуживания вызова, мин.
          CEIL(SUM(REDIRECTED_TIME)/60) AS REDIRECTED_TIME, --Суммарная длительность разговора при перенаправлении, мин.
          SUM(OPERATOR_HOLD) AS OPERATOR_HOLD
        FROM SQ_CALLS_SUM
        GROUP BY FULL_RANGE, FID_PROJECT, FID_PLATFORM
      )
    SELECT DISTINCT NVL(MVP.CAPTION, SQR.FID_PROJECT) AS PROJECT_NAME, SQR.FID_PROJECT,
      SQR.FULL_RANGE, SQR.SESSION_CNT, SQR.SERVICE_SESSION_CNT, NVL(SS.OPERATORS_CNT, 0) OPERATORS_CNT,
      ROUND((SQR.LOST_SESSION_CNTM5)/DECODE(SQR.QUEUED_SESSION_CNT,0,1,SQR.QUEUED_SESSION_CNT)*100,2) AS P_LOST_SESSIONS,
      ROUND(SQR.SERVICE_SESSION_CNT20/DECODE(SQR.QUEUED_SESSION_CNT-SQR.LOST_SESSION_CNT5,0,1,SQR.QUEUED_SESSION_CNT-SQR.LOST_SESSION_CNT5)*100,2) AS SL,
      SQR.AVG_SPEAK_TIME, SQR.REDIRECTED_CNT, SQR.OPR_REDIRECTED_CNT, SQR.SERVICE_SESSION_CNT20, SQR.SERVICE_SESSION_CNT40,
      SQR.LOST_SESSION_CNT, SQR.LOST_SESSION_CNT20, SQR.LOST_SESSION_CNT40, SQR.LOST_SESSION_CNTM20, SQR.LOST_SESSION_CNTM40,
      ROUND(SQR.LOST_SESSION_CNTM20/DECODE(SQR.QUEUED_SESSION_CNT,0,1,SQR.QUEUED_SESSION_CNT)*100,2) AS P_LOST_SESSION_CNTM20,
      ROUND(SQR.LOST_SESSION_CNTM40/DECODE(SQR.QUEUED_SESSION_CNT,0,1,SQR.QUEUED_SESSION_CNT)*100,2) AS P_LOST_SESSION_CNTM40,
      ROUND(SQR.LOST_SESSION_CNT20/DECODE(SQR.QUEUED_SESSION_CNT,0,1,SQR.QUEUED_SESSION_CNT)*100,2) AS P_LOST_SESSION_CNT20,
      ROUND(SQR.LOST_SESSION_CNT40/DECODE(SQR.QUEUED_SESSION_CNT,0,1,SQR.QUEUED_SESSION_CNT)*100,2) AS P_LOST_SESSION_CNT40,
      SQR.ERR_SESSION_CNT, SQR.OPR_CONNECTS5_CNT, SQR.ASA, SQR.LCW, SQR.QUEUE_LENGTH, SQR.ATA, SQR.MATA, SQR.ACW,
      SQR.SUM_SPEAK_TIME, SQR.SUM_OPERATOR_WRAPUP, SQR.ART, SQR.MRT, SQR.AHT, SQR.MHT, SQR.SST, SQR.CSST, SQR.REDIRECTED_TIME,
      SQR.MIN_QUEUE_LENGTH, SQR.AVG_QUEUE_LENGTH, SQR.MIN_QUEUE_TIME, SQR.MAX_QUEUE_TIME, SQR.AVG_QUEUE_TIME, SQR.OPERATOR_HOLD
    FROM SQ_RESULT SQR
    LEFT JOIN SQ_STATUSES SS ON SS.FULL_RANGE = SQR.FULL_RANGE AND SS.FID_PROJECT = SQR.FID_PROJECT AND SS.FID_PLATFORM = SQR.FID_PLATFORM
    LEFT JOIN MV_PROJECTS MVP ON MVP.ID_ELEMENT = SQR.FID_PROJECT AND MVP.FID_PLATFORM = SQR.FID_PLATFORM
    ORDER BY NVL(MVP.CAPTION, SQR.FID_PROJECT), SQR.FULL_RANGE;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_QUALITYREPORT;

--------------------------------------------------------------------------------
--------------------------------ИСХОДЯЩАЯ ЛИНИЯ---------------------------------
--------------------------------------------------------------------------------
  --Отчет "Все вызовы на заданный номер"
  FUNCTION FNC_REPORT_CALL_TO_NUMBER(
                                      I_DATE_START TIMESTAMP,
                                      I_DATE_END TIMESTAMP,
                                      I_CALLER VARCHAR2 DEFAULT NULL,
                                      I_CALLED VARCHAR2 DEFAULT NULL,
                                      I_PLATFORMS VARCHAR2 DEFAULT NULL
                                    )
    RETURN PT_REPORT_CALL_TO_NUMBER PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_REPORT_CALL_TO_NUMBER
    IS
    SELECT
      DECODE(OPERATOR, '{no_operator}', 'system', OPERATOR) AS OPERATOR,
      LISTAGG(ABONENT, ', ') WITHIN GROUP (ORDER BY LINK_ID) AS CALL_NUMBER,
      CREATED, ENDED, PKG_INTERVALS.FNC_INTERVALTOCHAR(CREATED, ENDED) AS CALL_DURATION,
      DECODE(EXIT_CODE_DISCRIPTION, 'abonent', 'На стороне клиента', 'caller', 'На стороне оператора', 'Не определено') AS EXIT_CODE_DISCRIPTION, SESSION_ID
    FROM TABLE(PKG_API.GET_CALL_LINKS(I_DATE_START, I_DATE_END, NULL, 'OUT,DIALER', I_PLATFORMS,
                                      TRIM(',' FROM I_CALLER||','||I_CALLED), 1, 0)) CI
    WHERE FINAL_STAGE NOT LIKE '%intrusion%'
      AND CALLED LIKE NVL(I_CALLED, '%')
      AND CALLER LIKE NVL(I_CALLER, '%')
      AND FID_PROJECT != '{no_projects}'
    GROUP BY SESSION_ID, CREATED, ENDED,
      EXIT_CODE_DISCRIPTION, OPERATOR;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_CALL_TO_NUMBER;

  --Отчет "Исходящие вызовы по проекту"
  FUNCTION FNC_REPORT_OUTGOING_PRJ(
                                    I_DATE_START TIMESTAMP,
                                    I_DATE_END TIMESTAMP,
                                    I_PROJECT VARCHAR2 DEFAULT NULL,
                                    I_STATUS NUMBER DEFAULT NULL,
                                    I_PLATFORMS VARCHAR2 DEFAULT NULL
                                  )
    RETURN PT_REPORT_OUTGOING_PRJ PIPELINED
  IS

    CURSOR GET_DATA RETURN PTR_REPORT_OUTGOING_PRJ
    IS
    SELECT NVL(TRIM(MVE.SURNAME||' '||MVE.NAME||' '||MVE.PATRONYMIC),CS.OPERATOR) AS OPERATOR,
      CS.ABONENT, CS.CREATED, CS.OPERATOR_CONNECTED, CS.ENDED,
      PKG_INTERVALS.FNC_INTERVALTOCHAR(NVL(CS.OPERATOR_CONNECTED, CS.ENDED), CS.ENDED) AS CALL_DURATION,
      PKG_INTERVALS.FNC_INTERVALTOMIN(NVL(CS.OPERATOR_CONNECTED, CS.ENDED), CS.ENDED, 0) AS CALL_DURATION_M,
      NVL2(CS.OPERATOR_CONNECTED, 'Было соединение', 'Не было соединения') AS STATUS
    FROM TABLE(PKG_API.GET_CALL_LINKS(I_DATE_START, I_DATE_END, I_PROJECT, 'OUT,DIALER', I_PLATFORMS)) CS
    LEFT JOIN MV_EMPLOYEES MVE ON MVE.LOGIN = CS.OPERATOR AND MVE.FID_PLATFORM = CS.FID_PLATFORM
    WHERE CS.FINAL_STAGE NOT LIKE '%intrusion%' AND CS.LINK_ID = 1 AND CS.FID_PROJECT != '{no_projects}'
      AND CS.FID_PROJECT != 'project_not_determined'
      AND NVL2(I_STATUS, DECODE(CS.OPERATOR_CONNECTED, NULL, 1, 2), 0) = NVL(I_STATUS, 0)
      AND EXISTS(
                  SELECT 1
                  FROM TABLE(PKG_SERVICE.FNC_GET_LOGINS(I_DATE_START, I_DATE_END,
                                                        I_PROJECT, I_ROLETYPE=>'operator')) OL
                  WHERE OL.LOGIN = MVE.LOGIN
                )
    ORDER BY CS.CREATED;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_OUTGOING_PRJ;

  --Отчет "Исходящие вызовы по проекту (количество звонков)"
  FUNCTION FNC_REPORT_OUTGOING_PRJ_CNT(
                                        I_DATE_START TIMESTAMP,
                                        I_DATE_END TIMESTAMP,
                                        I_PROJECT VARCHAR2 DEFAULT NULL,
                                        I_STATUS NUMBER DEFAULT NULL,
                                        I_PLATFORMS VARCHAR2 DEFAULT NULL
                                      )
    RETURN PT_REPORT_OUTGOING_PRJ_CNT PIPELINED
  IS

    CURSOR GET_DATA RETURN PTR_REPORT_OUTGOING_PRJ_CNT
    IS
    WITH SQ_REPORT AS
      (
        SELECT CS.ABONENT,
          MAX(NVL2(CS.OPERATOR_CONNECTED, 2, 1)) AS STATUS,
          COUNT(DISTINCT CS.SESSION_ID) AS CALLS_CNT
        FROM TABLE(PKG_API.GET_CALL_LINKS(I_DATE_START, I_DATE_END, I_PROJECT, 'OUT,DIALER', I_PLATFORMS)) CS
        WHERE CS.FINAL_STAGE NOT LIKE '%intrusion%' AND CS.LINK_ID = 1 AND CS.FID_PROJECT != '{no_projects}'
          AND EXISTS(
                      SELECT 1
                      FROM TABLE(PKG_SERVICE.FNC_GET_LOGINS(I_DATE_START, I_DATE_END,
                                                            I_PROJECT, I_ROLETYPE=>'operator')) OL
                      WHERE OL.LOGIN = CS.OPERATOR
                    )
        GROUP BY CS.ABONENT
      )
    SELECT ABONENT,
      DECODE(STATUS, 2, 'Было соединение', 'Не было соединения') AS STATUS,
      CALLS_CNT
    FROM SQ_REPORT
    WHERE NVL2(I_STATUS, STATUS, 0) = NVL(I_STATUS, 0)
    ORDER BY ABONENT;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_OUTGOING_PRJ_CNT;

  --Отчет "Исходящие вызовы по направлениям"
  FUNCTION FNC_REPORT_OUTGOING_AREAS(
                                      I_DATE_START TIMESTAMP,
                                      I_DATE_END TIMESTAMP,
                                      I_PROVIDER NUMBER DEFAULT NULL,
                                      I_CITY VARCHAR2 DEFAULT NULL,
                                      I_PLATFORMS VARCHAR2 DEFAULT NULL
                                    )
    RETURN PT_REPORT_OUTGOING_AREAS PIPELINED
  IS

    CURSOR GET_DATA RETURN PTR_REPORT_OUTGOING_AREAS
    IS
    WITH SQ_ABONENTS AS
      (
        SELECT /*+ MATERIALIZE*/ PKG_STRINGS.FNC_TONUMBER(CASE WHEN LENGTH(CI.ABONENT)>10
                                                               THEN SUBSTR(CI.ABONENT,LENGTH(CI.ABONENT)-9)
                                                               ELSE CI.ABONENT END) AS ABONENT,
          CI.CREATED, CI.FID_PROVIDER,
          NVL(PKG_INTERVALS.FNC_INTERVALTOMIN(CI.OPERATOR_CONNECTED, CI.OPERATOR_ENDED, 5),0) AS CALC_MIN
        FROM TABLE(PKG_API.GET_CALL_LINKS(I_DATE_START, I_DATE_END, NULL, 'OUT,DIALER', I_PLATFORMS)) CI
        WHERE CI.FINAL_STAGE NOT LIKE '%intrusion%' AND CI.LINK_ID = 1
          AND NVL2(I_PROVIDER, CI.FID_PROVIDER, 0) = NVL(I_PROVIDER, 0)
          AND CI.OPERATOR_CONNECTED IS NOT NULL
      ),
      SQ_REPORT AS
      (
        SELECT DP.NAME AS PROVIDER,
          CASE
            WHEN LOWER(DPHC.AREA) LIKE '%санкт%петербург%'
            THEN 'г. Санкт-Петербург'||DECODE(SUBSTR(TO_CHAR(DPHC.FIRST_CODE), 1, 1), '9',', моб.')
            WHEN LOWER(DPHC.AREA) LIKE '%москва%'
            THEN 'г. Москва'||DECODE(SUBSTR(TO_CHAR(DPHC.FIRST_CODE), 1,  1), '9',', моб.')
            WHEN LOWER(DPHC.AREA) LIKE '%московская%обл%'
            THEN 'Московская область'||DECODE(SUBSTR(TO_CHAR(DPHC.FIRST_CODE), 1, 1), '9',', моб.')
            WHEN SUBSTR(TO_CHAR(DPHC.FIRST_CODE), 1, 1) LIKE '9%' THEN 'РФ, моб.'
            WHEN UPPER(DPHC.REGION) = 'ЦЕНТРАЛЬНЫЙ РЕГИОН' THEN DPHC.REGION --ЦЕНТРАЛЬНЫЙ РЕГИОН
            WHEN NOT TO_CHAR(DPHC.FIRST_CODE) LIKE '9%' THEN 'Остальная Россия' --вся россия стационарные
            ELSE 'Направление неопределено'
          END AS DIRRECTION,
          CALC_MIN
        FROM SQ_ABONENTS SQA
        LEFT JOIN D_PHONECODES DPHC ON FLOOR(DPHC.FIRST_CODE/10000000) = FLOOR(SQA.ABONENT/10000000)
                                    AND SQA.ABONENT BETWEEN DPHC.FIRST_CODE AND DPHC.LAST_CODE
                                    AND SQA.CREATED BETWEEN DPHC.CREATED AND DPHC.BLOCKED
                                    AND DPHC.ID_PHONECODE > 0
        LEFT JOIN D_PROVIDERS DP ON DP.ID_PROVIDER = SQA.FID_PROVIDER
        WHERE (I_CITY IS NULL
          OR LOWER(DPHC.AREA) LIKE LOWER('%'||I_CITY||'%'))
          AND SQA.CALC_MIN > 0
      )
    SELECT PROVIDER, DIRRECTION,
      ROUND(SUM(CALC_MIN), 2) AS CALC_MIN,
      SUM(CASE WHEN CALC_MIN-FLOOR(CALC_MIN) < 0.5
               THEN FLOOR(CALC_MIN)+0.5
               ELSE CEIL(CALC_MIN)
          END) AS CALC_MIN_30,
      SUM(CEIL(CALC_MIN)) AS CALC_MIN_60
    FROM SQ_REPORT
    GROUP BY PROVIDER, DIRRECTION
    ORDER BY PROVIDER, DIRRECTION;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END FNC_REPORT_OUTGOING_AREAS;

END PKG_REPORTS;
/

