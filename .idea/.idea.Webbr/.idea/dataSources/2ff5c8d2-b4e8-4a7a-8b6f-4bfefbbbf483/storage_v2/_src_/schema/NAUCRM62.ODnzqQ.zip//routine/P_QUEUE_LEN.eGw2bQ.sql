create function p_queue_len(START_TIME in TIMESTAMP, STOP_TIME in TIMESTAMP)
return t_queue_len_table
PIPELINED
is
line t_queue_len := t_queue_len(' ',null,0);
begin
  for i in (
    select
      PROJECT_ID as PROJECT_ID,
      CHANGED as CHANGED,
      COUNTER as COUNTER
    from
    (
      select
        que.PROJECT_ID as PROJECT_ID,
        que.unblocked_time as changed,
        1 as counter
      from
          queued_calls que
          where
              que.UNBLOCKED_TIME is not null
      union all
      select
        que.PROJECT_ID as PROJECT_ID,
        que.dequeued_time as changed,
        -1 as counter
      from
          queued_calls que
          where
                que.UNBLOCKED_TIME is not null
    )
    where changed between START_TIME and STOP_TIME
    order by PROJECT_ID, CHANGED, COUNTER desc)
    loop
        if (line.PROJECT_ID <> i.PROJECT_ID)
        then
            begin
                line := t_queue_len(' ',null,0);
            end;
        end if;

        line.PROJECT_ID := i.PROJECT_ID;
        line.CHANGED := i.CHANGED;
        line.AMOUNT := line.AMOUNT + i.COUNTER;
        pipe row(line);
    end loop;
  return;
end;
/

