create type           SYS_PLSQL_1808372_1811_1 as table of "NC_CORE"."SYS_PLSQL_1808372_1759_1";
/

