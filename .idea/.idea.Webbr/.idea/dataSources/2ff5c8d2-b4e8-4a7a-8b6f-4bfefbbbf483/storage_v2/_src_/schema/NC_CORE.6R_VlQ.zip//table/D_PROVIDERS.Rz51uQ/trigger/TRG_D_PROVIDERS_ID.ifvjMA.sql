create trigger TRG_D_PROVIDERS_ID
    before insert
    on D_PROVIDERS
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_PROVIDER" IS NULL THEN
                                 SELECT SEQ_D_PROVIDERS_ID.NEXTVAL INTO :NEW."ID_PROVIDER" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

