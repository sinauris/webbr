create type           SYS_PLSQL_2394302_DUMMY_1 as table of number;
/

