create view CALLS_PROJECT_ID_LAST as
Select
    session_id, project_id, changed
From
    calls_project_id_all projectid
/

