create view CALLS_PROJECT_INCOMING as
Select
    abonent.session_id as sessionid,
    abonent.project_id as parentuid,
    case
        when unblocked.changed is null then null
        else abonent.abonent
    end as operatorlogin,
    initiator.src_id as phonenumber,
    initiator.dst_id as receiverphonenumber,
    ivr.created as incomingtime,
    abonent.connected as connectiontime,
    abonent.ended as disconnectiontime,
    intervaltosec( nvl( abonent.connected, ivr.ended ) - ivr.created ) as waittime,
    case
        when unblocked.changed is null then abonent.abonent
        else redirection.dst_abonent
    end as redirectionlogin,
    case
        when unblocked.changed is null then abonent.id
        else redirection.dst_id
    end as redirectionnumber,
    speak_time.speaktime as speaktime,
    intervaltosec( nvl( unblocked.changed, ivr.ended ) - ivr.created ) as ivrmessagetime,
    intervaltosec( nvl( abonent.connected, ivr.ended ) - unblocked.changed ) as queuetime,
    case
        when unblocked.changed is null then null
        else intervaltosec( abonent.ended - abonent.connected )
    end as operatortime,
    case
        when unblocked.changed is null then  intervaltosec( abonent.ended - abonent.connected )
        else intervaltosec( redirection.ended - redirection.connected )
    end as redirecttime,
    1 as isindirection,
    case
        when ( unblocked.changed is null and abonent.id is not null ) then 5
        when unblocked.changed is null then 1
        when abonent.abonent is null then 2
        when redirection.dst_id is null then 3
        else 4
    end as finalstage
From
    calls_project_abonents_first abonent inner join
    call_legs initiator on
    (
        initiator.incoming = '1' and
        (initiator.src_abonent_type = 'IVR' or initiator.src_abonent is NULL) and
        initiator.session_id = abonent.session_id
    ) left join
        call_legs ivr on
    (
        ivr.dst_abonent_type = 'IVR' and
                abonent.project_id_changed between ivr.created and ivr.connected and
                (abonent.connected between ivr.created and ivr.ended or abonent.connected is null) and
        ivr.session_id = abonent.session_id
    ) left join
    sessions_speak_time_temp speak_time on
    (
        speak_time.session_id = abonent.session_id
    ) left join
    call_params unblocked on
    (
        unblocked.session_id = abonent.session_id and
        unblocked.param_name = 'Blocked' and
        unblocked.param_value = 'false' and
                unblocked.changed between ivr.created and ivr.ended and
        ( ( unblocked.changed <= abonent.connected ) or ( abonent.connected is null ) )
    ) left join
    call_legs redirection on
    (
                redirection.intrusion = '0' and
                redirection.session_id = abonent.session_id and
                redirection.incoming = '0' and
                redirection.connected > abonent.connected and
                redirection.connected <= abonent.ended and
                redirection.ended > abonent.ended and
                redirection.connected is not null
    )
/

