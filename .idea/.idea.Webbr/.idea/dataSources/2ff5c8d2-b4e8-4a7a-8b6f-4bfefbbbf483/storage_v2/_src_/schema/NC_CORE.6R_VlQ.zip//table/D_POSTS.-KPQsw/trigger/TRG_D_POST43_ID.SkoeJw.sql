create trigger TRG_D_POST43_ID
    before insert
    on D_POSTS
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_POST" IS NULL THEN
                                 SELECT SEQ_D_POST43_ID.NEXTVAL INTO :NEW."ID_POST" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

