create trigger TRG_EMPLOYEES_TEACH_PROJ_ID
    before insert
    on EMPLOYEES_TEACH_PROJ
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_TEACH_PROJECT" IS NULL THEN
                                 SELECT SEQ_EMPLOYEES_TEACH_PROJ_ID.NEXTVAL INTO :NEW."ID_TEACH_PROJECT" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

