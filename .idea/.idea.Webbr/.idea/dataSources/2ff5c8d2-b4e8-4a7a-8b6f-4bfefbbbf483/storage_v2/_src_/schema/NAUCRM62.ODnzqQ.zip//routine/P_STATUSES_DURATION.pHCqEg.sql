create function P_STATUSES_DURATION(START_TIME in TIMESTAMP, STOP_TIME in TIMESTAMP)
return T_STATUSES_TABLE
PIPELINED
is
LINE T_STATUSES:=T_STATUSES(null,' ',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
LEN NUMBER:=0;
begin
  for i in (select LOGIN, ENTERED, DURATION, STATUS, REASON
            from V_STATUS_CHANGES
            where
            ENTERED <= STOP_TIME
            and
            cast(ENTERED + DURATION/86400 as TIMESTAMP) >= START_TIME
            order by LOGIN)
    loop
        if (LINE.LOGIN <> i.LOGIN)
        then
            begin
                if (LINE.LOGIN != ' ') then pipe row(LINE); end if;
                LINE:=T_STATUSES(null,i.LOGIN,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
            end;
        end if;

    LEN:=0;
        if (i.ENTERED >= START_TIME) and (cast(i.ENTERED + i.DURATION/24/3600 as TIMESTAMP) <= STOP_TIME) then LEN:=i.DURATION;
    elsif (i.ENTERED <= START_TIME) and (cast(i.ENTERED + i.DURATION/24/3600 as TIMESTAMP) >= STOP_TIME) then LEN:=INTERVALTOSEC(STOP_TIME - START_TIME);
    elsif (i.ENTERED <= START_TIME) and (cast(i.ENTERED + i.DURATION/24/3600 as TIMESTAMP) <= STOP_TIME) then LEN:=INTERVALTOSEC(i.ENTERED + i.DURATION/24/3600 - START_TIME);
        elsif (i.ENTERED >= START_TIME) and (cast(i.ENTERED + i.DURATION/24/3600 as TIMESTAMP) >= STOP_TIME) then LEN:=INTERVALTOSEC(STOP_TIME - i.ENTERED); end if;
        if (i.STATUS = 'accident') then LINE.ACCIDENT := LINE.ACCIDENT + LEN;
        elsif (i.STATUS = 'available') then LINE.AVAILABLE := LINE.AVAILABLE + LEN;
        elsif (i.STATUS = 'away') then
            begin
                if (i.REASON = 'Dinner') then LINE.AWAY_DINNER := LINE.AWAY_DINNER + LEN;
                elsif (i.REASON = 'TechnicalBreak') then LINE.AWAY_TECHNICALBREAK := LINE.AWAY_TECHNICALBREAK + LEN;
                elsif (i.REASON = 'CustomAwayReason1') then LINE.AWAY_CUSTOM_REASON1 := LINE.AWAY_CUSTOM_REASON1 + LEN;
                elsif (i.REASON = 'CustomAwayReason2') then LINE.AWAY_CUSTOM_REASON2 := LINE.AWAY_CUSTOM_REASON2 + LEN;
                elsif (i.REASON = 'CustomAwayReason3') then LINE.AWAY_CUSTOM_REASON3 := LINE.AWAY_CUSTOM_REASON3 + LEN;
                elsif (i.REASON = 'CustomAwayReason4') then LINE.AWAY_CUSTOM_REASON4 := LINE.AWAY_CUSTOM_REASON4 + LEN;
                elsif (i.REASON = 'CustomAwayReason5') then LINE.AWAY_CUSTOM_REASON5 := LINE.AWAY_CUSTOM_REASON5 + LEN;
                elsif (i.REASON = 'CustomAwayReason6') then LINE.AWAY_CUSTOM_REASON6 := LINE.AWAY_CUSTOM_REASON6 + LEN;
                elsif (i.REASON = 'CustomAwayReason7') then LINE.AWAY_CUSTOM_REASON7 := LINE.AWAY_CUSTOM_REASON7 + LEN;
                elsif (i.REASON = 'CustomAwayReason8') then LINE.AWAY_CUSTOM_REASON8 := LINE.AWAY_CUSTOM_REASON8 + LEN;
                elsif (i.REASON = 'CustomAwayReason9') then LINE.AWAY_CUSTOM_REASON9 := LINE.AWAY_CUSTOM_REASON9 + LEN;
                elsif (i.REASON = 'CustomAwayReason10') then LINE.AWAY_CUSTOM_REASON10 := LINE.AWAY_CUSTOM_REASON10 + LEN;
                else LINE.AWAY := LINE.AWAY + LEN;
                end if;
            end;
        elsif (i.STATUS = 'custom1') then LINE.CUSTOM1 := LINE.CUSTOM1 + LEN;
        elsif (i.STATUS = 'custom2') then LINE.CUSTOM2 := LINE.CUSTOM2 + LEN;
        elsif (i.STATUS = 'custom3') then LINE.CUSTOM3 := LINE.CUSTOM3 + LEN;
        elsif (i.STATUS = 'dnd') then LINE.DND := LINE.DND + LEN;
        elsif (i.STATUS = 'normal') then LINE.NORMAL := LINE.NORMAL + LEN;
        elsif (i.STATUS = 'notavailable') then LINE.NOTAVAILABLE := LINE.NOTAVAILABLE + LEN;
        elsif (i.STATUS = 'offline') then LINE.OFF := LINE.OFF + LEN;
        elsif (i.STATUS = 'redirect') then LINE.REDIRECT := LINE.REDIRECT + LEN;
        elsif (i.STATUS = 'ringing') then LINE.RINGING := LINE.RINGING + LEN;
        elsif (i.STATUS = 'speaking') then LINE.SPEAKING := LINE.SPEAKING + LEN;
        elsif (i.STATUS = 'standoff') then LINE.STANDOFF := LINE.STANDOFF + LEN;
        elsif (i.STATUS = 'wrapup') then LINE.WRAPUP := LINE.WRAPUP + LEN;
        end if;
    end loop;
    pipe row(LINE);
  return;
end;
/

