create PACKAGE PKG_API_TEST AS

  --Типы данных статусов операторов
  TYPE PTR_STATUS_CHANGES IS RECORD (
                                      ENTERED TIMESTAMP,
                                      LOGIN VARCHAR2(50 CHAR),
                                      PROJECT_ID VARCHAR2(150 CHAR),
                                      FID_STATUS NUMBER,
                                      STATUS VARCHAR2(50 CHAR),
                                      REASON VARCHAR2(500 CHAR),
                                      STATUS_CAPTION VARCHAR2(150 CHAR),
                                      PROJECT_RATE NUMBER(6,5),
                                      DURATION NUMBER(25,5),
                                      FULL_DURATION NUMBER,
                                      FID_PLATFORM NUMBER(2),
                                      CC_CAPTION VARCHAR2(150 CHAR),
                                      LOCATION_CAPTION VARCHAR2(150 CHAR),
                                      FIRST_STATUS_ENTERED TIMESTAMP,
                                      LAST_STATUS_ENDED TIMESTAMP
                                    );
  TYPE PT_STATUS_CHANGES IS TABLE OF PTR_STATUS_CHANGES;

  --Выборка статусов операторов
  FUNCTION GET_STATUSES(I_DATE_START TIMESTAMP, --Дата начала отбора
                        I_DATE_END TIMESTAMP, --Дата окончания отбора
                        I_PROJECT VARCHAR2 DEFAULT NULL, --Проект/группа проектов
                        I_GROUP_PROJECTS_LEVEL NUMBER DEFAULT 2, --Уровень группировки проектов
                        I_LOGIN VARCHAR2 DEFAULT NULL, --Логин оператора
                        I_LOCATION VARCHAR2 DEFAULT NULL, --Call-центр/площадка
                        I_GROUP_LOCATION NUMBER DEFAULT 2, --Группировка по Call-центру/площадке
                        I_STEP NUMBER DEFAULT 1, --Длина шага разделения по времени
                        I_STEP_TYPE VARCHAR2 DEFAULT 'DD', --Тип шаг разделения по времени
                        I_STATUSES VARCHAR2 DEFAULT NULL, --Статусы
                        I_PLATFORMS VARCHAR2 DEFAULT NULL, --Платформы
                        I_ROLETYPE VARCHAR2 DEFAULT NULL, --Роль сотрудника (оператор, супервайзер, ...)
                        I_COMPRESS CHAR DEFAULT 'Y') --Убирать offline занимающие целый диапазон
    RETURN PT_STATUS_CHANGES PIPELINED;

END PKG_API_TEST;
/

