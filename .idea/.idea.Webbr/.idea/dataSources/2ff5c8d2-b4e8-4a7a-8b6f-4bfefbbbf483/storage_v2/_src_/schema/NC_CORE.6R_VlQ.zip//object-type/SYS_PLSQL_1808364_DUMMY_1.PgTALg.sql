create type           SYS_PLSQL_1808364_DUMMY_1 as table of number;
/

