create PACKAGE PKG_API AS

  --Типы списка зарегистрованных площадок
  TYPE PTR_LOCATION_LIST IS RECORD(LOCATION_ID VARCHAR2(255 CHAR), LOCATION_NAME VARCHAR2(100 CHAR));
  TYPE PT_LOCATION_LIST IS TABLE OF PTR_LOCATION_LIST;
  --Получение списка зарегистрированных площадок
  FUNCTION GET_LOCATION_LIST(I_INCLUDE_ALL CHAR DEFAULT 'Y') RETURN PT_LOCATION_LIST PIPELINED;


  --Типы списка сотрудников
  TYPE PTR_EMPLOYEES_LOGINS IS RECORD(LOGIN VW_EMPLOYEES.LOGIN%TYPE,
                              LAST_NAME VW_EMPLOYEES.SURNAME%TYPE,
                              FIRST_NAME VW_EMPLOYEES.NAME%TYPE,
                              MIDDLE_NAME VW_EMPLOYEES.PATRONYMIC%TYPE,
                              CALL_CENTRE_NAME VW_EMPLOYEES.CALL_CENTRE_NAME%TYPE,
                              LOCATION_NAME VW_EMPLOYEES.LOCATION_NAME%TYPE,
                              FID_PLATFORM VW_EMPLOYEES.FID_PLATFORM%TYPE);
  TYPE PT_EMPLOYEES_LOGINS IS TABLE OF PTR_EMPLOYEES_LOGINS;
  --Список сотрудников
  FUNCTION GET_EMPLOYEES_LOGINS(I_JSON VARCHAR2) RETURN PT_EMPLOYEES_LOGINS PIPELINED;

  TYPE PTR_EMPLOYEES_LIST IS RECORD(LOGIN VARCHAR2(2000 CHAR), FIO VARCHAR2(1000 CHAR));
  TYPE PT_EMPLOYEES_LIST IS TABLE OF PTR_EMPLOYEES_LIST;
  --Получение списка зарегистрированных операторов (новое)
  FUNCTION GET_EMPLOYEES_LIST(I_INCLUDE_ALL CHAR DEFAULT 'Y',
                              I_VIEW_LOGIN CHAR DEFAULT 'Y',
                              I_DATE_START TIMESTAMP DEFAULT NULL, --Дата начала отбора
                              I_DATE_END TIMESTAMP DEFAULT NULL, --Дата окончания отбора
                              I_PROJECT VARCHAR2 DEFAULT NULL, --Список проектов
                              I_LOCATION VARCHAR2 DEFAULT NULL, --Call-центр/площадка
                              I_ROLETYPE VARCHAR2 DEFAULT 'operator', --Список ролей сотрудников
                              I_PLATFORM VARCHAR2 DEFAULT NULL, --Список платформ
                              I_NEW_STYLE CHAR DEFAULT 'N')
    RETURN PT_EMPLOYEES_LIST PIPELINED;

  --Типы списка проектов
  TYPE PTR_PROJECTS_IDS IS RECORD(PROJECT_ID MV_PROJECTS.ID_ELEMENT%TYPE,
                              CAPTION MV_PROJECTS.CAPTION%TYPE,
                              PLATFORM_ID MV_PROJECTS.FID_PLATFORM%TYPE);
  TYPE PT_PROJECTS_IDS IS TABLE OF PTR_PROJECTS_IDS;
  --Список проектов
  FUNCTION GET_PROJECTS_IDS(I_JSON VARCHAR2) RETURN PT_PROJECTS_IDS PIPELINED;

  --Типы списка зарегистрованных проектов
  TYPE PTR_PROJECTS_LIST IS RECORD(PROJECT_ID VARCHAR2(2000 CHAR), PROJECT_NAME VARCHAR2(300 CHAR));
  TYPE PT_PROJECTS_LIST IS TABLE OF PTR_PROJECTS_LIST;/*
  --Получение списка зарегистрированных проектов
  FUNCTION GET_PROJECTS_LIST (I_INCLUDE_ALL CHAR DEFAULT 'Y',
                              I_DIRECTION T_LIST_VARCHAR DEFAULT NULL,
                              I_PLATFORM T_LIST_INTEGER DEFAULT NULL,
                              I_ACTIVE NUMBER DEFAULT 1,
                              I_VIEW_GROUPS CHAR DEFAULT 'Y',
                              I_GROUP_PLATFORM CHAR DEFAULT 'N',
                              I_LIST_GROUPS T_LIST_VARCHAR DEFAULT NULL,
                              I_INDENT VARCHAR2 DEFAULT ' ',
                              I_INDENT_COUNT NUMBER DEFAULT 3)
    RETURN PT_PROJECTS_LIST PIPELINED;*/
  FUNCTION GET_PROJECTS_LIST (I_INCLUDE_ALL CHAR,
                              I_DIRECTION VARCHAR2 DEFAULT NULL,
                              I_PLATFORM VARCHAR2 DEFAULT NULL,
                              I_ACTIVE NUMBER DEFAULT 1,
                              I_VIEW_GROUPS CHAR DEFAULT 'Y',
                              I_GROUP_PLATFORM CHAR DEFAULT 'N',
                              I_LIST_GROUPS VARCHAR2 DEFAULT NULL,
                              I_INDENT VARCHAR2 DEFAULT ' ',
                              I_INDENT_COUNT NUMBER DEFAULT 3,
                              I_VIEW_PLATFORM CHAR DEFAULT 'N',
                              I_NEW_STYLE CHAR DEFAULT 'N')
    RETURN PT_PROJECTS_LIST PIPELINED;

  --Типы списка зарегистрованных поставщиков связи
  TYPE PTR_PROVIDERS_LIST IS RECORD(PROVIDER_ID VARCHAR2(2000 CHAR), PROVIDER_NAME VARCHAR2(100 CHAR));
  TYPE PT_PROVIDERS_LIST IS TABLE OF PTR_PROVIDERS_LIST;
  --Получение списка зарегистрированных поставщиков связи
  FUNCTION GET_PROVIDERS_LIST (I_INCLUDE_ALL CHAR DEFAULT 'Y')
    RETURN PT_PROVIDERS_LIST PIPELINED;

  --Типы данных статусов операторов
  TYPE PTR_STATUS_CHANGES IS RECORD (
                                      ENTERED TIMESTAMP,
                                      LOGIN VARCHAR2(50 CHAR),
                                      PROJECT_ID VARCHAR2(150 CHAR),
                                      FID_STATUS NUMBER,
                                      STATUS VARCHAR2(50 CHAR),
                                      REASON VARCHAR2(500 CHAR),
                                      STATUS_CAPTION VARCHAR2(150 CHAR),
                                      PROJECT_RATE NUMBER(6,5),
                                      DURATION NUMBER(25,5),
                                      FULL_DURATION NUMBER,
                                      FID_PLATFORM NUMBER(2),
                                      CC_CAPTION VARCHAR2(150 CHAR),
                                      LOCATION_CAPTION VARCHAR2(150 CHAR),
                                      FIRST_STATUS_ENTERED TIMESTAMP,
                                      LAST_STATUS_ENDED TIMESTAMP
                                    );
  TYPE PT_STATUS_CHANGES IS TABLE OF PTR_STATUS_CHANGES;

  --Выборка статусов операторов
  FUNCTION GET_STATUSES(I_DATE_START TIMESTAMP, --Дата начала отбора
                        I_DATE_END TIMESTAMP, --Дата окончания отбора
                        I_PROJECT VARCHAR2 DEFAULT NULL, --Проект/группа проектов
                        I_GROUP_PROJECTS_LEVEL NUMBER DEFAULT 2, --Уровень группировки проектов
                        I_LOGIN VARCHAR2 DEFAULT NULL, --Логин оператора
                        I_LOCATION VARCHAR2 DEFAULT NULL, --Call-центр/площадка
                        I_GROUP_LOCATION NUMBER DEFAULT 2, --Группировка по Call-центру/площадке
                        I_STEP NUMBER DEFAULT 1, --Длина шага разделения по времени
                        I_STEP_TYPE VARCHAR2 DEFAULT 'DD', --Тип шаг разделения по времени
                        I_STATUSES VARCHAR2 DEFAULT NULL, --Статусы
                        I_PLATFORMS VARCHAR2 DEFAULT NULL, --Платформы
                        I_ROLETYPE VARCHAR2 DEFAULT NULL, --Роль сотрудника (оператор, супервайзер, ...)
                        I_COMPRESS CHAR DEFAULT 'Y') --Убирать offline занимающие целый диапазон
    RETURN PT_STATUS_CHANGES PIPELINED;

  --Тип списка сессий
  TYPE PT_CALL_SESSIONS IS TABLE OF CALL_SESSIONS%ROWTYPE;

  --Выборка списка сессий
  FUNCTION GET_CALL_SESSIONS (I_DATE_START TIMESTAMP, --Дата начала отбора
                              I_DATE_END TIMESTAMP, --Дата окончания отбора
                              I_PROJECTS T_LIST_VARCHAR DEFAULT NULL,
                              I_DIRECTION T_LIST_VARCHAR DEFAULT NULL,
                              I_PLATFORM T_LIST_INTEGER DEFAULT NULL,
                              I_ABONENT T_LIST_VARCHAR DEFAULT NULL,
                              I_SELECT_ABONENTS NUMBER DEFAULT 1)
    RETURN PT_CALL_SESSIONS PIPELINED;
  --Выборка списка сессий
  FUNCTION GET_CALL_SESSIONS (I_DATE_START TIMESTAMP, --Дата начала отбора
                              I_DATE_END TIMESTAMP, --Дата окончания отбора
                              I_PROJECTS VARCHAR2 DEFAULT NULL,
                              I_DIRECTION VARCHAR2 DEFAULT NULL,
                              I_PLATFORM VARCHAR2 DEFAULT NULL,
                              I_ABONENT VARCHAR2 DEFAULT NULL,
                              I_SELECT_ABONENTS NUMBER DEFAULT 1)
    RETURN PT_CALL_SESSIONS PIPELINED;

  --Тип списка соединений в сессиях
  TYPE PTR_CALL_LINKS IS RECORD(SESSION_ID CALL_SESSIONS.SESSION_ID%TYPE,
                                FID_PLATFORM CALL_SESSIONS.FID_PLATFORM%TYPE,
                                CREATED CALL_SESSIONS.CREATED%TYPE,
                                ENDED CALL_SESSIONS.ENDED%TYPE,
                                DIRECTION CALL_SESSIONS.DIRECTION%TYPE,
                                FID_PROVIDER CALLS_INFO.FID_PROVIDER%TYPE,
                                PROVIDER_CAPTION D_PROVIDERS.NAME%TYPE,
                                FID_AREA CALLS_INFO.FID_AREA%TYPE,
                                AREA_CAPTION D_RATES.AREA_CAPTION%TYPE,
                                EXIT_CODE CALL_SESSIONS.EXIT_CODE%TYPE,
                                EXIT_CODE_DISCRIPTION CALL_SESSIONS.EXIT_CODE_DISCRIPTION%TYPE,
                                IS_WORK_TIME CALL_SESSIONS.IS_WORK_TIME%TYPE,
                                LINK_ID CALLS_INFO.LINK_ID%TYPE,
                                FID_PROJECT CALLS_INFO.FID_PROJECT%TYPE,
                                FINAL_STAGE CALLS_INFO.FINAL_STAGE%TYPE,
                                ABONENT CALLS_INFO.ABONENT%TYPE,
                                CALLER CALLS_INFO.CALLER%TYPE,
                                CALLED CALLS_INFO.CALLED%TYPE,
                                IVR_NUMBER CALLS_INFO.IVR_NUMBER%TYPE,
                                IVR_CREATED CALLS_INFO.IVR_CREATED%TYPE,
                                IVR_CONNECTED CALLS_INFO.IVR_CONNECTED%TYPE,
                                IVR_ENDED CALLS_INFO.IVR_ENDED%TYPE,
                                ENQUEUED_TIME CALLS_INFO.ENQUEUED_TIME%TYPE,
                                UNBLOCKED_TIME CALLS_INFO.UNBLOCKED_TIME%TYPE,
                                DEQUEUED_TIME CALLS_INFO.DEQUEUED_TIME%TYPE,
                                OPERATOR CALLS_INFO.OPERATOR%TYPE,
                                OPERATOR_CREATED CALLS_INFO.OPERATOR_CREATED%TYPE,
                                OPERATOR_CONNECTED CALLS_INFO.OPERATOR_CONNECTED%TYPE,
                                OPERATOR_ENDED CALLS_INFO.OPERATOR_ENDED%TYPE,
                                OPERATOR_HOLD CALLS_INFO.OPERATOR_HOLD%TYPE,
                                OPERATOR_WRAPUP CALLS_INFO.OPERATOR_WRAPUP%TYPE,
                                SPEAK_SEGMENTS CALLS_INFO.SPEAK_SEGMENTS%TYPE,
                                IS_QUALITY_CONTROL CALLS_INFO.IS_QUALITY_CONTROL%TYPE,
                                BRAKE_CALL CALLS_INFO.BRAKE_CALL%TYPE,
                                COST CALLS_INFO."COST"%TYPE);
  TYPE PT_CALL_LINKS IS TABLE OF PTR_CALL_LINKS;
  --Выборка списка соединений в сессиях
  FUNCTION GET_CALL_LINKS(I_DATE_START TIMESTAMP, --Дата начала отбора
                          I_DATE_END TIMESTAMP, --Дата окончания отбора
                          I_PROJECTS T_LIST_VARCHAR DEFAULT NULL,--Список необходимых проектов
                          I_DIRECTION T_LIST_VARCHAR DEFAULT NULL,--Список направлений
                          I_PLATFORM T_LIST_INTEGER DEFAULT NULL,--Список платформ
                          I_ABONENT T_LIST_VARCHAR DEFAULT NULL,--Список необходимых абонентов/операторов. Возможно использование символов % и _ для нечеткого поиска
                          I_SELECT_ABONENTS NUMBER DEFAULT 1,--Флаг фильтрации абонентов/опереторов переданных в I_ABONENT. 0 - исключать; 1 - выбрать только переданных в I_ABONENT
                          I_QUALITY_CONTROL NUMBER DEFAULT NULL)--Флаг необходимости выгружать IVR оценки качества: 1 - только IVR оценки качества; 0 - исключить IVR оценки качества; NULL - не использовать фильтр
    RETURN PT_CALL_LINKS PIPELINED;
  --Выборка списка соединений в сессиях
  FUNCTION GET_CALL_LINKS(I_DATE_START TIMESTAMP, --Дата начала отбора
                          I_DATE_END TIMESTAMP, --Дата окончания отбора
                          I_PROJECTS VARCHAR2 DEFAULT NULL,
                          I_DIRECTION VARCHAR2 DEFAULT NULL,
                          I_PLATFORM VARCHAR2 DEFAULT NULL,
                          I_ABONENT VARCHAR2 DEFAULT NULL,
                          I_SELECT_ABONENTS NUMBER DEFAULT 1,
                          I_QUALITY_CONTROL NUMBER DEFAULT NULL)
    RETURN PT_CALL_LINKS PIPELINED;

END PKG_API;
/

