create function p_log_in_out(START_TIME in DATE, STOP_TIME in DATE, START_WINDOW CHAR default '00:00', STOP_WINDOW CHAR default '23:59')
return t_offline_table
PIPELINED
is
line t_offline:=t_offline(null,null,null,null);
LEN NUMBER:=0;
begin
  for i in (
              select
                int.S as DT,
                nvl(log_in.LOGIN, log_out.LOGIN) as LOGIN,
                log_in.LOG_IN as LOG_IN,
                log_out.LOG_OUT as LOG_OUT
              from
              table(INTERVALIZE(START_TIME, STOP_TIME, 'DD', 1)) int
              left join
              (
                select
                  CHANGE_DATE as CHANGE_DATE,
                  LOGIN as LOGIN,
                  min(CHANGE_TIME) as LOG_IN
                from v_offline_changed
                where
                  DIRECTION = 'out'
                  and CHANGE_TIME between START_TIME and STOP_TIME
                  and (
                    (
                            windowtotimestamp(CHANGE_TIME, START_WINDOW) <= windowtotimestamp(CHANGE_TIME, STOP_WINDOW) and
                            CHANGE_TIME between windowtotimestamp(CHANGE_TIME, START_WINDOW) and windowtotimestamp(CHANGE_TIME, STOP_WINDOW)
                        ) or
                    (
                            windowtotimestamp(CHANGE_TIME, START_WINDOW) > windowtotimestamp(CHANGE_TIME, STOP_WINDOW) and
                            CHANGE_TIME between windowtotimestamp(CHANGE_TIME, START_WINDOW) and windowtotimestamp(CHANGE_TIME+1, STOP_WINDOW)
                        )
                      )
                group by CHANGE_DATE, LOGIN
              ) log_in on (log_in.CHANGE_DATE = int.S)
              left join
              (
                select
                  CHANGE_DATE as CHANGE_DATE,
                  LOGIN as LOGIN,
                  max(CHANGE_TIME) as LOG_OUT
                from v_offline_changed
                where
                  DIRECTION = 'in'
                  and CHANGE_TIME between START_TIME and STOP_TIME
                  and (
                    (
                            windowtotimestamp(CHANGE_TIME, START_WINDOW) <= windowtotimestamp(CHANGE_TIME, STOP_WINDOW) and
                            CHANGE_TIME between windowtotimestamp(CHANGE_TIME, START_WINDOW) and windowtotimestamp(CHANGE_TIME, STOP_WINDOW)
                        ) or
                    (
                            windowtotimestamp(CHANGE_TIME, START_WINDOW) > windowtotimestamp(CHANGE_TIME, STOP_WINDOW) and
                            CHANGE_TIME between windowtotimestamp(CHANGE_TIME, START_WINDOW) and windowtotimestamp(CHANGE_TIME+1, STOP_WINDOW)
                        )
                      )
                group by CHANGE_DATE, LOGIN
              ) log_out on (log_out.CHANGE_DATE = int.S and log_out.LOGIN = log_in.LOGIN and log_out.LOG_OUT >= log_in.LOG_IN)
            )
    loop
      line := t_offline(i.DT, i.LOGIN, i.LOG_IN, i.LOG_OUT);
      pipe row(line);
    end loop;
  return;
end;
/

