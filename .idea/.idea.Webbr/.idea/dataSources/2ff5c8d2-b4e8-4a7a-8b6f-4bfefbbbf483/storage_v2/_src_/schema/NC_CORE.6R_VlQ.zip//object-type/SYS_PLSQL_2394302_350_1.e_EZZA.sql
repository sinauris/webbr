create type           SYS_PLSQL_2394302_350_1 as table of "NC_CORE"."SYS_PLSQL_2394302_333_1";
/

