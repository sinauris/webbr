create view V_ALL_OPERATOR_CALLS as
    select
  cl.SESSION_ID as SESSION_ID,
  cl.LEG_ID as LEG_ID,
  p.PARAM_VALUE as PARENTUUID,
  cl.SRC_ABONENT as LOGIN,
  cl.DST_ID as ABONENT,
  cl.CREATED as CREATED,
  cl.CONNECTED as CONNECTED,
  cl.ENDED as ENDED,
  cl.VOIP_REASON as VOIP_REASON,
  cl.INTERNAL_REASON as INTERNAL_REASON,
  case when cl.CONNECTED is not NULL then intervaltosec(cl.CONNECTED-cl.CREATED) else 0 end as PICKUP_TIME,
  case when cl.CONNECTED is not NULL then intervaltosec(cl.ENDED-cl.CONNECTED) else 0 end as SPEAKING_TIME,
  intervaltosec(cl.ENDED-cl.CREATED) as TOTAL_TIME,
  'out' as DIRECTION
from call_legs cl
left join call_params p on (p.session_id = cl.session_id and p.param_name in ('case_uuid','npcp-dialer-client-ext-id'))
where cl.src_abonent_type = 'SP'
and cl.incoming = 1
and cl.intrusion = 0
UNION ALL
select
  cl.SESSION_ID as SESSION_ID,
  cl.LEG_ID as LEG_ID,
  p.PROJECT_ID as PARENTUUID,
  cl.DST_ABONENT as LOGIN,
  cl.SRC_ID as ABONENT,
  cl.CREATED as CREATED,
  cl.CONNECTED as CONNECTED,
  cl.ENDED as ENDED,
  cl.VOIP_REASON as VOIP_REASON,
  cl.INTERNAL_REASON as INTERNAL_REASON,
  case when cl.CONNECTED is not NULL then intervaltosec(cl.CONNECTED-cl.CREATED) else 0 end as PICKUP_TIME,
  case when cl.CONNECTED is not NULL then intervaltosec(cl.ENDED-cl.CONNECTED) else 0 end as SPEAKING_TIME,
  intervaltosec(cl.ENDED-cl.CREATED) as TOTAL_TIME,
  'in' as DIRECTION
from call_legs cl
LEFT JOIN queued_calls p ON (p.session_id = cl.session_id AND cl.created >= p.unblocked_time AND cl.created <= p.dequeued_time)
where cl.dst_abonent_type = 'SP'
and cl.incoming = 0
and cl.intrusion = 0
/

