create materialized view MV_STATUSES
    refresh complete on demand
as
SELECT
    ds_parent.id_status  AS id_nc_status ,
    ds_parent.name            AS nc_status ,
    ds_parent.caption         AS nc_status_caption ,
    ds_parent.is_avaliable    AS nc_status_is_avaliable ,
    ds_child.id_status        AS id_nau_status ,
    ds_child.name             AS nau_status ,
    nvl(ds_child.reason, '*') AS nau_status_reason ,
    ds_child.caption          AS nau_status_caption ,
    ds_child.is_avaliable     AS nau_status_is_avaliable ,
    dm.id_module              AS id_platform ,
    dm.caption AS platform,
    greatest(ds_parent.CREATED, ds_child.CREATED) AS active_from,
    least(ds_parent.BLOCKED, ds_child.BLOCKED) AS active_till
FROM d_statuses ds_parent
  JOIN d_statuses ds_child
    ON ds_child.fid_status = ds_parent.id_status
  JOIN d_modules dm
    ON dm.id_module = ds_child.fid_module AND lower(dm.name) IN ('no_platform', 'naumen6')
WHERE ds_parent.fid_status = 0
AND ds_parent.name NOT IN ('available', 'notavailable')
/

