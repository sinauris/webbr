create trigger TRG_D_PHONECODES_ID
    before insert
    on D_PHONECODES
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_PHONECODE" IS NULL THEN
                                 SELECT SEQ_D_PHONECODES_ID.NEXTVAL INTO :NEW."ID_PHONECODE" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

