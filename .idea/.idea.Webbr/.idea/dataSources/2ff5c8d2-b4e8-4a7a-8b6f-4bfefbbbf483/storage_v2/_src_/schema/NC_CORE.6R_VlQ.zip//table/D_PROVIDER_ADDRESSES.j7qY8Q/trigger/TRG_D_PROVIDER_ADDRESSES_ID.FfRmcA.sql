create trigger TRG_D_PROVIDER_ADDRESSES_ID
    before insert
    on D_PROVIDER_ADDRESSES
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_PROVIDER_ADDRESS" IS NULL THEN
                                 SELECT SEQ_D_PROVIDER_ADDRESSES_ID.NEXTVAL INTO :NEW."ID_PROVIDER_ADDRESS" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

