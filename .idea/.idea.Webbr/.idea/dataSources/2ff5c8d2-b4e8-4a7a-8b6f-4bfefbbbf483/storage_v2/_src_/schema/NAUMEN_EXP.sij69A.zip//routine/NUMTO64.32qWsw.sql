create Function NumTo64 (N In Number) Return Varchar2 Is
  H   Varchar2(128) := '';
  N1 Number           := 0;
  N2 Number           := 0;
Begin
N1 := N;

Loop
       Exit When N1 = 0;
       N2 := N1 - Trunc(N1 / 64, 0) * 64;
       N1 := Trunc(N1 / 64, 0);
       Select SubStr('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-', N2 + 1, 1)||H Into H From DUAL;
End Loop;

Select Decode(Length(H),
1,'S0000000000000'||H,
2,'S000000000000'||H,
3,'S00000000000'||H,
4,'S0000000000'||H,
5,'S000000000'||H,
6,'S00000000'||H,
7,'S0000000'||H,
8,'S000000'||H,
9,'S00000'||H,
10,'S0000'||H,
11,'S000'||H,
12,'S00'||H,
13,'S0'||H,
14,'S'||H,
H
) Into H From DUAL;

Return H;
End NumTo64;
/

