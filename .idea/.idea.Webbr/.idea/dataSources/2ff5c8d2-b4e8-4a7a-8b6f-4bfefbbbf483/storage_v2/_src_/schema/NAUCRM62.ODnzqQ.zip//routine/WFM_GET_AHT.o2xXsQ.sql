create FUNCTION WFM_get_aht (strt in timestamp, fnsh in timestamp)
RETURN wfm_type_aht_table
AS
ahtt wfm_type_aht_table;
today timestamp;
BEGIN
today:=to_timestamp(to_char(current_date));
if fnsh - INTERVAL '24' HOUR <= strt
then
if fnsh<=today
then
SELECT wfm_type_aht
        (
                aa.ZN_TM
            ,   aa.project_id
            ,   aa.value
            ,   aa.aht
        )
BULK COLLECT INTO ahtt
FROM
(select * from wfm_aht_table where ZN_TM between strt and fnsh) aa;
return ahtt;

else
SELECT wfm_type_aht
        (
                aa.ZN_TM
            ,   aa.project_id
            ,   aa.value
            ,   aa.aht
        )
BULK COLLECT INTO ahtt
FROM
(select * from table (WFM_AHT(strt,fnsh))) aa;
return ahtt;
end if;
else 
if fnsh<=today
then
SELECT wfm_type_aht
        (
                aa.ZN_TM
            ,   aa.project_id
            ,   aa.value
            ,   aa.aht
        )
BULK COLLECT INTO ahtt
FROM
(select * from wfm_aht_table where ZN_TM between strt and fnsh) aa;
return ahtt;
else
SELECT wfm_type_aht
        (
                aa.ZN_TM
            ,   aa.project_id
            ,   aa.value
            ,   aa.aht
        )
BULK COLLECT INTO ahtt
FROM
( select * from wfm_aht_table where ZN_TM between strt and today
union all
select * from table (wfm_aht(today, fnsh))) aa;
return ahtt;
end if;
END if;
end;
/

