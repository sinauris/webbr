create FUNCTION FNC_REPORT_UTZ
(
  I_DATE_START TIMESTAMP,
  I_DATE_END TIMESTAMP,
  I_PROJECT VARCHAR2 DEFAULT NULL,
  I_PROJECT_GROUP NUMBER DEFAULT 2,
  I_LOGIN VARCHAR2 DEFAULT NULL,
  I_PLATFORMS VARCHAR2 DEFAULT NULL
) RETURN T_REPORT_UTZ PIPELINED AS

BEGIN

  FOR GET_DATA IN
  (
    WITH
    SQ_RANGES AS
    (
      SELECT /*+ MATERIALIZE*/ START_RANGE, STOP_RANGE-INTERVAL '1' SECOND AS STOP_RANGE
      FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(I_START_DATE=>I_DATE_START, I_END_DATE=>I_DATE_END,
                                                    I_MASK => 'DD.MM.YYYY HH24:MI'))
    ),
    SQ_REPORT_DATA AS
    (
      SELECT /*+ MATERIALIZE*/ SQR.START_RANGE, TS.LOGIN,
        TRIM(MVE.SURNAME||' '||MVE.NAME||' '||MVE.PATRONYMIC) AS FIO,
        DECODE(TS.PROJECT_ID,'{no_projects}','Без проекта',TS.PROJECT_ID) AS PROJECT_NAME,
        NVL(
            SUM(CASE
                  WHEN TS.STATUS IN ('ringing','speaking','wrapup','normal')
                    OR (TS.STATUS = 'away' AND TS.REASON = 'CustomAwayReason16')
                  THEN TS.DURATION*TS.PROJECT_RATE
                END),0) AS LOGIN_TIME,
        SUM(TS.DURATION*TS.PROJECT_RATE) AS FULL_TIME
      FROM TABLE(PKG_API.GET_STATUSES(I_DATE_START, I_DATE_END, I_PROJECT=>I_PROJECT, I_LOGIN=>I_LOGIN,
                                      I_GROUP_PROJECTS_LEVEL=>I_PROJECT_GROUP, I_PLATFORMS=>I_PLATFORMS,
                                      I_STATUSES=>'away,custom1,custom2,custom3,normal,'||
                                                  'ringing,speaking,wrapup,training,time_break,tech_problem',
                                      I_ROLETYPE=>'operator')) TS
      LEFT JOIN SQ_RANGES SQR ON TS.ENTERED BETWEEN SQR.START_RANGE AND SQR.STOP_RANGE
      LEFT JOIN MV_EMPLOYEES MVE ON MVE.LOGIN = TS.LOGIN AND MVE.FID_PLATFORM = TS.FID_PLATFORM
      WHERE TS.REASON NOT IN ('CustomAwayReason3','CustomAwayReason11','CustomAwayReason12','CustomAwayReason17',
              'CustomAwayReason18','CustomAwayReason19','CustomAwayReason20','CustomAwayReason21','CustomAwayReason22')
      GROUP BY SQR.START_RANGE, TS.LOGIN, TRIM(MVE.SURNAME||' '||MVE.NAME||' '||MVE.PATRONYMIC),
        DECODE(TS.PROJECT_ID,'{no_projects}','Без проекта',TS.PROJECT_ID)
    ),
    SQ_GROUP_PROJECTS AS
    (
      SELECT START_RANGE, LOGIN, FIO, EXTRACT(DAY FROM START_RANGE) AS REPORT_DAY,
        LISTAGG(PROJECT_NAME, ',') WITHIN GROUP (ORDER BY PROJECT_NAME) AS PROJECT_NAME,
        SUM(LOGIN_TIME) AS LOGIN_TIME, DECODE(SUM(FULL_TIME), 0, 1, SUM(FULL_TIME)) AS FULL_TIME
      FROM SQ_REPORT_DATA
      GROUP BY START_RANGE, LOGIN, FIO
    )
    SELECT LOGIN, FIO, PROJECT_NAME, REPORT_MONTH, H1, H2, H3, H4, H5, H6,
      H7, H8, H9, H10, H11, H12, H13, H14, H15, H16, H17, H18, H19, H20, H21,
      H22, H23, H24, H25, H26, H27, H28, H29, H30, H31, AVG_UTL
    FROM(
          SELECT LOGIN, FIO, REPORT_DAY,
            PKG_STRINGS.FNC_DISTINCT(
              LISTAGG(PROJECT_NAME, ',') WITHIN GROUP (ORDER BY PROJECT_NAME)OVER
                (PARTITION BY LOGIN, TO_CHAR(START_RANGE,'MM/YYYY'))) AS PROJECT_NAME,
            TO_CHAR(START_RANGE,'MM/YYYY') AS REPORT_MONTH,
            ROUND(LOGIN_TIME/FULL_TIME*100,2) AS UTL,
            ROUND(
                  AVG(LOGIN_TIME/FULL_TIME*100)OVER
                    (PARTITION BY LOGIN, TO_CHAR(START_RANGE,'MM/YYYY')),2) AS AVG_UTL
          FROM SQ_GROUP_PROJECTS
        )
    PIVOT
      (MAX(UTL) FOR REPORT_DAY IN ('1' AS H1,'2' AS H2,'3' AS H3,'4' AS H4,'5' AS H5,
          '6' AS H6,'7' AS H7,'8' AS H8,'9' AS H9,'10' AS H10,'11' AS H11,'12' AS H12,
          '13' AS H13, '14' AS H14,'15' AS H15,'16' AS H16,'17' AS H17,'18' AS H18,
          '19' AS H19,'20' AS H20, '21' AS H21,'22' AS H22,'23' AS H23,'24' AS H24,
          '25' AS H25,'26' AS H26, '27' AS H27, '28' AS H28,'29' AS H29,'30' AS H30,
          '31' AS H31))
  )
  LOOP
    PIPE ROW(TR_REPORT_UTZ(
              GET_DATA.LOGIN,
              GET_DATA.FIO,
              GET_DATA.PROJECT_NAME,
              GET_DATA.REPORT_MONTH,
              GET_DATA.H1,
              GET_DATA.H2,
              GET_DATA.H3,
              GET_DATA.H4,
              GET_DATA.H5,
              GET_DATA.H6,
              GET_DATA.H7,
              GET_DATA.H8,
              GET_DATA.H9,
              GET_DATA.H10,
              GET_DATA.H11,
              GET_DATA.H12,
              GET_DATA.H13,
              GET_DATA.H14,
              GET_DATA.H15,
              GET_DATA.H16,
              GET_DATA.H17,
              GET_DATA.H18,
              GET_DATA.H19,
              GET_DATA.H20,
              GET_DATA.H21,
              GET_DATA.H22,
              GET_DATA.H23,
              GET_DATA.H24,
              GET_DATA.H25,
              GET_DATA.H26,
              GET_DATA.H27,
              GET_DATA.H28,
              GET_DATA.H29,
              GET_DATA.H30,
              GET_DATA.H31,
              GET_DATA.AVG_UTL
              ));
  END LOOP;
END FNC_REPORT_UTZ;
/

