create type           SYS_PLSQL_45041268_116_1 as table of "NC_CORE"."SYS_PLSQL_45041268_9_1";
/

