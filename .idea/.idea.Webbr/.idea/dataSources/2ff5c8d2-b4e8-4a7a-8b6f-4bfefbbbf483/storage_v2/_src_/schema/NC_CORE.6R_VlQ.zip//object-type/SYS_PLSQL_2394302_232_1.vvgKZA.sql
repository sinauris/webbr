create type           SYS_PLSQL_2394302_232_1 as table of "NC_CORE"."SYS_PLSQL_2394302_202_1";
/

