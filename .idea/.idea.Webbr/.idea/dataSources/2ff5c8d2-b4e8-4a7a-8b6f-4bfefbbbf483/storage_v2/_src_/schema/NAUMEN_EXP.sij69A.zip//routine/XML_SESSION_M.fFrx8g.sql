create Function XML_SESSION_M(P_SESSION_ID In VarChar2) Return VarChar2 As L_RETURN VarChar2(32767);
Begin
With
T_SES As (Select P_SESSION_ID SESSION_ID From DUAL),

T1 As (Select a.SESSION_ID, a.LEG_ID, a.SRC_ID, a.DST_ID From NAUCRM.CALL_LEGS a, T_SES b Where a.SESSION_ID = b.SESSION_ID),
T2 As (Select Min(LEG_ID) LEG_ID_MIN From T1),
T3 As (Select a.SESSION_ID, a.LEG_ID, a.SRC_ID, a.DST_ID From T1 a, T2 b Where a.LEG_ID = b.LEG_ID_MIN),

N2 As (Select a.LEG_ID, a.SRC_ID, a.SESSION_ID From NAUCRM.CALL_LEGS a, T_SES b Where a.SESSION_ID = b.SESSION_ID And a.CONNECTED Is Not Null),
N3 As (Select a.LEG_ID, a.DST_ID, a.SESSION_ID From NAUCRM.CALL_LEGS a, T_SES b Where a.SESSION_ID = b.SESSION_ID And a.CONNECTED Is Not Null),
N4 As (Select LEG_ID, LOGIN, NUMS, SESSION_ID From (Select LEG_ID, SRC_ID LOGIN, 1 NUMS, SESSION_ID From N2 Union All Select LEG_ID, DST_ID LOGIN, 2 NUMS, SESSION_ID From N3)),
N5 As (Select a.LEG_ID, a.LOGIN, a.NUMS, a.SESSION_ID, b.NAME LOGIN_NAME From N4 a, NAUCRM.ABONENTS b Where a.LOGIN = b.LOGIN),
N6 As (Select Min(LEG_ID) LEG_ID_MIN From N5),
N7 As (Select a.LEG_ID, a.LOGIN, a.NUMS, a.SESSION_ID, a.LOGIN_NAME From N5 a, N6 b Where a.LEG_ID = b.LEG_ID_MIN),
N8 As (Select a.LOGIN, a.LOGIN_NAME, a.SESSION_ID, b.TEL From N7 a, NAUMEN_EXP.LOGIN_TEL b Where a.LOGIN = b.LOGIN (+)),

T_RES As (Select a.SESSION_ID, Min(a.CREATED) CREATED, Max(a.ENDED) ENDED From NAUCRM.CALL_LEGS a, T_SES b Where a.SESSION_ID = b.SESSION_ID Group By a.SESSION_ID),
T_REZ As (Select a.SESSION_ID, a.CREATED, a.ENDED,
Round(24 * 60 * 60 * (To_Date(To_Char(a.ENDED,'dd.mm.yyyy hh24:mi:ss'), 'dd.mm.yyyy hh24:mi:ss') - To_Date(To_Char(a.CREATED,'dd.mm.yyyy hh24:mi:ss'), 'dd.mm.yyyy hh24:mi:ss'))) VR,
Replace(To_Char(a.CREATED - Interval '3' Hour, 'yyyy-mm-dd hh24:mi:ss'),' ','T') DATS,
Decode(b.LOGIN,Null,'None',b.LOGIN) LOGIN, Decode(b.LOGIN_NAME,Null,'None',b.LOGIN_NAME) LOGIN_NAMES, Decode(b.TEL,Null,'None',b.TEL) TEL,
Decode(c.SRC_ID, Null, 'None', c.SRC_ID) SRC_ID, Decode(c.DST_ID, Null, 'None', c.DST_ID) DST_ID
From T_RES a, N8 b, T3 c
Where a.SESSION_ID = b.SESSION_ID (+) And a.SESSION_ID = c.SESSION_ID (+))

Select
utl_raw.cast_to_varchar2(utl_encode.base64_encode(utl_raw.cast_to_raw(
'<?xml version="1.0" encoding="utf-8"?>'||Chr(13)||Chr(10)||
'<Call xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">'||Chr(13)||Chr(10)||
'  <Data>'||Chr(13)||Chr(10)||
'    <audio>'||Chr(13)||Chr(10)||
'      <audio_segement>'||Chr(13)||Chr(10)||
'        <channel_id>0</channel_id>'||Chr(13)||Chr(10)||
'        <recording_order>1</recording_order>'||Chr(13)||Chr(10)||
'        <audio_url>'||lower('\\dc1-gvrprd\newcontact\'||To_Char(CREATED,'yyyy')||'\'||To_Char(CREATED,'mm')||'\'||To_Char(CREATED,'dd')||'\'||SESSION_ID||'_L.wav')||'</audio_url>'||Chr(13)||Chr(10)||
'        <StartTime>'||To_Char(CREATED,'yyyy-mm-dd')||'T'||To_Char(CREATED,'hh24:mi:ss')||'</StartTime>'||Chr(13)||Chr(10)||
'        <Duration>'||To_Char(VR)||'</Duration>'||Chr(13)||Chr(10)||
'      </audio_segement>'||Chr(13)||Chr(10)||
'    </audio>'||Chr(13)||Chr(10)||
'    <direction>1</direction>'||Chr(13)||Chr(10)||
'    <time_offset>0</time_offset>'||Chr(13)||Chr(10)||
'    <ani>'||SubStr(To_Char(SRC_ID),1,15)||'</ani>'||Chr(13)||Chr(10)||
'    <dnis>'||SubStr(To_Char(DST_ID),1,15)||'</dnis>'||Chr(13)||Chr(10)||
'    <pbx_login_id>'||SubStr(LOGIN,1,255)||'</pbx_login_id>'||Chr(13)||Chr(10)||
'    <agent_name>'||SubStr(LOGIN_NAMES,1,32)||'</agent_name>'||Chr(13)||Chr(10)||
'    <group_name>'||SubStr('Newcontact',1,50)||'</group_name>'||Chr(13)||Chr(10)||
'    <unique_identifier>'||SESSION_ID||'</unique_identifier>'||Chr(13)||Chr(10)||
'  </Data>'||Chr(13)||Chr(10)||
'</Call>'||Chr(13)||Chr(10)
)))
XMLS Into L_RETURN
From T_REZ;
RETURN L_RETURN;
End XML_SESSION_M;
/

