create trigger TRG_D_INTERVIEW_CALL_RESULT_ID
    before insert
    on D_INTERVIEW_CALL_RESULT
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_CALL_RESULT" IS NULL THEN
                                 SELECT SEQ_D_INTERVIEW_CALL_RESULT_ID.NEXTVAL INTO :NEW."ID_CALL_RESULT" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

