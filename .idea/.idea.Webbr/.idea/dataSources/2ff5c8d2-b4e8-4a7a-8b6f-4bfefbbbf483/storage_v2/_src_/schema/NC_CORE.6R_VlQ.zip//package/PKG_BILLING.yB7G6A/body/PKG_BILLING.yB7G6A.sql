create PACKAGE BODY PKG_BILLING AS
  --Тип для формирования отчета в XML
  TYPE LT_RESULT IS RECORD(
                            WORK_START TIMESTAMP,
                            WORK_LOG CLOB,
                            RESULT_NUM NUMBER,
                            RESULT_TXT VARCHAR2(1500),
                            IS_ERROR NUMBER(1)
                          );

  --Процедура обновления стоимости соединений
  PROCEDURE SP_UPDATE_COSTS(I_DATE_START TIMESTAMP,
                            I_DATE_END TIMESTAMP,
                            I_FORCE CHAR DEFAULT 'N')
  IS
    V_RESULT LT_RESULT;
    V_WORK LT_RESULT;

    --Шаги по заливке
    FUNCTION STEP_LOAD(I_STEP NUMBER) RETURN LT_RESULT IS
      V_RESULT LT_RESULT;
    BEGIN
      V_RESULT.WORK_START := SYSTIMESTAMP;
      V_RESULT.WORK_LOG := '<action id="'||TO_CHAR(I_STEP)||'" time="{time}" {cnt}="{val}">{text}</action>';
      V_RESULT.IS_ERROR := 0;
      BEGIN
        IF I_STEP = 1 THEN
          V_RESULT.RESULT_TXT := 'Обновление кодов стоимости звонка';
          MERGE INTO CALLS_INFO CI USING
          (
            WITH SQ_SESSIONS AS
              (
                SELECT /*+ MATERIALIZE*/
                  DECODE(CI.OPERATOR, '{ext_operator}',
                          DECODE(INSTR(CI.CALLED, '810'), 1, CI.CALLED, '8'||SUBSTR(CI.CALLED, -10)),
                          CI.ABONENT) AS ABONENT, CI.FID_PROVIDER, CS.CREATED, CI.ROWID AS SYS_ROWID,
                  SUBSTR(DECODE(CI.OPERATOR, '{ext_operator}',
                                DECODE(INSTR(CI.CALLED, '810'), 1, CI.CALLED, '8'||SUBSTR(CI.CALLED, -10)),
                                CI.ABONENT), 1, 6) AS F6,
                  SUBSTR(DECODE(CI.OPERATOR, '{ext_operator}',
                                DECODE(INSTR(CI.CALLED, '810'), 1, CI.CALLED, '8'||SUBSTR(CI.CALLED, -10)),
                                CI.ABONENT), 1, 5) AS F5,
                  SUBSTR(DECODE(CI.OPERATOR, '{ext_operator}',
                                DECODE(INSTR(CI.CALLED, '810'), 1, CI.CALLED, '8'||SUBSTR(CI.CALLED, -10)),
                                CI.ABONENT), 1, 4) AS F4,
                  SUBSTR(DECODE(CI.OPERATOR, '{ext_operator}',
                                DECODE(INSTR(CI.CALLED, '810'), 1, CI.CALLED, '8'||SUBSTR(CI.CALLED, -10)),
                                CI.ABONENT), 1, 3) AS F3,
                  SUBSTR(DECODE(CI.OPERATOR, '{ext_operator}',
                                DECODE(INSTR(CI.CALLED, '810'), 1, CI.CALLED, '8'||SUBSTR(CI.CALLED, -10)),
                                CI.ABONENT), 1, 2) AS F2,
                  SUBSTR(DECODE(CI.OPERATOR, '{ext_operator}',
                                DECODE(INSTR(CI.CALLED, '810'), 1, CI.CALLED, '8'||SUBSTR(CI.CALLED, -10)),
                                CI.ABONENT), 1, 1) AS F1
                FROM CALL_SESSIONS CS
                JOIN CALLS_INFO CI ON CS.SESSION_ID=CI.SESSION_ID
                                  AND CS.FID_PLATFORM=CI.FID_PLATFORM
                                  AND DECODE(UPPER(NVL(I_FORCE, 'N')), 'N', CI.FID_AREA, 0) = 0
                                  AND CI.FID_PROVIDER > 0
                                  AND LENGTH(DECODE(CI.OPERATOR, '{ext_operator}', CI.CALLED, CI.ABONENT)) >= 10
                                  AND REGEXP_REPLACE(DECODE(CI.OPERATOR, '{ext_operator}', CI.CALLED, CI.ABONENT),'[^[[:digit:]]]*') IS NOT NULL
                WHERE CS.CREATED BETWEEN I_DATE_START AND I_DATE_END
              ),
              SQ_RATES AS
              (
                SELECT
                  DISTINCT SQS.SYS_ROWID, DR.PHONE_CODE, DR.ID_RATE
                FROM SQ_SESSIONS SQS
                JOIN D_RATES DR ON SUBSTR(DR.PHONE_CODE, 1, 6) = SQS.F6
                                AND DR.FID_PROVIDER=SQS.FID_PROVIDER
                                AND SQS.CREATED BETWEEN DR.CREATED_AT AND DR.BLOCKED_AT
                                AND DR.PHONE_CODE = SUBSTR(SQS.ABONENT, 1, LENGTH(DR.PHONE_CODE))
                UNION ALL
                SELECT
                  DISTINCT SQS.SYS_ROWID, DR.PHONE_CODE, DR.ID_RATE
                FROM SQ_SESSIONS SQS
                JOIN D_RATES DR ON SUBSTR(DR.PHONE_CODE, 1, 6) = SQS.F5
                                AND DR.FID_PROVIDER=SQS.FID_PROVIDER
                                AND SQS.CREATED BETWEEN DR.CREATED_AT AND DR.BLOCKED_AT
                                AND DR.PHONE_CODE = SUBSTR(SQS.ABONENT, 1, LENGTH(DR.PHONE_CODE))
                UNION ALL
                SELECT
                  DISTINCT SQS.SYS_ROWID, DR.PHONE_CODE, DR.ID_RATE
                FROM SQ_SESSIONS SQS
                JOIN D_RATES DR ON SUBSTR(DR.PHONE_CODE, 1, 6) = SQS.F4
                                AND DR.FID_PROVIDER=SQS.FID_PROVIDER
                                AND SQS.CREATED BETWEEN DR.CREATED_AT AND DR.BLOCKED_AT
                                AND DR.PHONE_CODE = SUBSTR(SQS.ABONENT, 1, LENGTH(DR.PHONE_CODE))
                UNION ALL
                SELECT
                  DISTINCT SQS.SYS_ROWID, DR.PHONE_CODE, DR.ID_RATE
                FROM SQ_SESSIONS SQS
                JOIN D_RATES DR ON SUBSTR(DR.PHONE_CODE, 1, 6) = SQS.F3
                                AND DR.FID_PROVIDER=SQS.FID_PROVIDER
                                AND SQS.CREATED BETWEEN DR.CREATED_AT AND DR.BLOCKED_AT
                                AND DR.PHONE_CODE = SUBSTR(SQS.ABONENT, 1, LENGTH(DR.PHONE_CODE))
                UNION ALL
                SELECT
                  DISTINCT SQS.SYS_ROWID, DR.PHONE_CODE, DR.ID_RATE
                FROM SQ_SESSIONS SQS
                JOIN D_RATES DR ON SUBSTR(DR.PHONE_CODE, 1, 6) = SQS.F2
                                AND DR.FID_PROVIDER=SQS.FID_PROVIDER
                                AND SQS.CREATED BETWEEN DR.CREATED_AT AND DR.BLOCKED_AT
                                AND DR.PHONE_CODE = SUBSTR(SQS.ABONENT, 1, LENGTH(DR.PHONE_CODE))
                UNION ALL
                SELECT
                  DISTINCT SQS.SYS_ROWID, DR.PHONE_CODE, DR.ID_RATE
                FROM SQ_SESSIONS SQS
                JOIN D_RATES DR ON SUBSTR(DR.PHONE_CODE, 1, 6) = SQS.F1
                                AND DR.FID_PROVIDER=SQS.FID_PROVIDER
                                AND SQS.CREATED BETWEEN DR.CREATED_AT AND DR.BLOCKED_AT
                                AND DR.PHONE_CODE = SUBSTR(SQS.ABONENT, 1, LENGTH(DR.PHONE_CODE))
              ),
              SQ_RESULT AS
              (
                SELECT /*+ MATERIALIZE*/ DISTINCT SYS_ROWID,
                  FIRST_VALUE(ID_RATE)OVER(PARTITION BY SYS_ROWID ORDER BY LENGTH(PHONE_CODE) DESC) AS FID_AREA
                FROM SQ_RATES
              )
              SELECT *
              FROM SQ_RESULT
          )TMP
          ON(CI.ROWID = TMP.SYS_ROWID)
          WHEN MATCHED THEN
            UPDATE SET CI.FID_AREA = TMP.FID_AREA;

          V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
        ELSIF I_STEP = 2 THEN
          V_RESULT.RESULT_TXT := 'Обновление стоимости соединений';
          MERGE INTO CALLS_INFO CI USING
          (
            WITH SQ_DATA AS
              (
                SELECT /*+ MATERIALIZE*/ CI.ROWID AS SYS_ROWID,
                  NVL(
                      CASE
                        WHEN PKG_INTERVALS.FNC_INTERVALTOSEC(NVL(CI.IVR_CONNECTED, CI.OPERATOR_CONNECTED), NVL(CI.OPERATOR_ENDED, CI.IVR_ENDED)) > DR.TARIF_SECOND
                        THEN ROUND(CEIL(PKG_INTERVALS.FNC_INTERVALTOSEC(NVL(CI.IVR_CONNECTED, CI.OPERATOR_CONNECTED), NVL(CI.OPERATOR_ENDED, CI.IVR_ENDED))/GREATEST(DR.TARIF, 1))*(DR.RATE/60*GREATEST(DR.TARIF, 1)), 2)
                      END, 0
                     )AS "COST"
                FROM CALL_SESSIONS CS
                JOIN CALLS_INFO CI ON CS.SESSION_ID=CI.SESSION_ID
                                  AND CS.FID_PLATFORM=CI.FID_PLATFORM
                                  AND NVL(CI.IVR_CONNECTED, CI.OPERATOR_CONNECTED) IS NOT NULL
                                  AND CI.FID_AREA > 0
                                  AND DECODE(UPPER(NVL(I_FORCE, 'N')), 'N', CI."COST") IS NULL
                JOIN D_RATES DR ON DR.ID_RATE=CI.FID_AREA
                WHERE CS.CREATED BETWEEN I_DATE_START AND I_DATE_END
              )
            SELECT *
            FROM SQ_DATA
          )TMP
          ON(CI.ROWID = TMP.SYS_ROWID)
          WHEN MATCHED THEN
            UPDATE SET CI."COST" = TMP."COST";

          V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          V_RESULT.RESULT_NUM := SQLCODE;
          V_RESULT.RESULT_TXT := V_RESULT.RESULT_TXT||': '||SQLERRM;
          V_RESULT.IS_ERROR := 1;
      END;
      --Результируем время выполнения шага
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
      --Плучаем цифровой результат
      IF V_RESULT.IS_ERROR = 1 THEN
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','error');
      ELSE
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','cnt');
      END IF;
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{val}',TO_CHAR(V_RESULT.RESULT_NUM));
      --Выводим текст шага
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{text}',V_RESULT.RESULT_TXT);
      RETURN V_RESULT;
    END;--Шаги по заливке

  BEGIN
    V_RESULT.WORK_START := SYSTIMESTAMP; --Начинаем работу по заливке
    FOR I IN 1..2 LOOP
      EXIT WHEN V_WORK.IS_ERROR = 1;
      V_WORK := STEP_LOAD(I);
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
    END LOOP;
    V_RESULT.IS_ERROR := V_WORK.IS_ERROR;
    IF V_WORK.IS_ERROR = 1 THEN ROLLBACK; END IF;
    --Формируем лог событий
    V_RESULT.WORK_LOG := '<UPDATE_COST time="{time}" filter_date_start="{date_start}" filter_date_stop="{date_stop}" force="{force}">'||V_RESULT.WORK_LOG||'</UPDATE_COST>';
    V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
    V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_start}',to_char(I_DATE_START,'DD.MM.YYYY HH24:MI:SS'));
    V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_stop}',to_char(I_DATE_END,'DD.MM.YYYY HH24:MI:SS'));
    V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{force}',I_FORCE);

    INSERT INTO LOG_ACTIONS (LOG_TIME, ACT_USER, OPERATION, DISCRIPTION, "RESULT")
    SELECT V_RESULT.WORK_START, USER, 'UPDATE_COSTS', XMLTYPE(V_RESULT.WORK_LOG), DECODE(V_RESULT.IS_ERROR, 0, 'OK', 'Error')
    FROM DUAL;

    COMMIT;
  END SP_UPDATE_COSTS;

END PKG_BILLING;
/

