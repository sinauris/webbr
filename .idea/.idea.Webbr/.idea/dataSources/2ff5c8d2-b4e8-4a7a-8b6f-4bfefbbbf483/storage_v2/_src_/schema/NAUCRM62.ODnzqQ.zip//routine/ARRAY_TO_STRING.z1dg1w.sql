create function array_to_string(p_array in string_array, sep in varchar2) 
return varchar2 as l_string varchar2(256);
  i binary_integer;
    begin
      i := p_array.first();
      while i is not null loop
        if p_array(i) is not null then
          l_string := l_string || p_array(i) || sep;
        end if;
        i := p_array.next(i);
      end loop;
      l_string := rtrim(l_string, sep);
      return l_string;
    end;
/

