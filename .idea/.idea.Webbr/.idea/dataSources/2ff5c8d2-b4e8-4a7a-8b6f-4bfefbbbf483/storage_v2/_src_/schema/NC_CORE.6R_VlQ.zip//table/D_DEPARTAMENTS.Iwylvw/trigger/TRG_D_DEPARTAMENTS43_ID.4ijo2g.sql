create trigger TRG_D_DEPARTAMENTS43_ID
    before insert
    on D_DEPARTAMENTS
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_DEPARTAMENT" IS NULL THEN
                                 SELECT SEQ_D_DEPARTAMENTS43_ID.NEXTVAL INTO :NEW."ID_DEPARTAMENT" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

