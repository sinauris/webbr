create view CALLS_PROJECT_ID_ALL as
Select
    session_id,
    param_value as project_id,
    changed
From
    call_params
Where
    param_name = 'ProjectId'
/

