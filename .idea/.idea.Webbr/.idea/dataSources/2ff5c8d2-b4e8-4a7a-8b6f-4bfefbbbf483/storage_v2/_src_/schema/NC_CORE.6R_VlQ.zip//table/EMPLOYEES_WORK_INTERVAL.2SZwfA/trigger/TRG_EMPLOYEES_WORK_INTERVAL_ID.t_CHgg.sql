create trigger TRG_EMPLOYEES_WORK_INTERVAL_ID
    before insert
    on EMPLOYEES_WORK_INTERVAL
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW.ID_WORK_INTERVAL IS NULL THEN
                                 SELECT SEQ_EMPLOYEES_WORK_INTERVAL_ID.NEXTVAL INTO :NEW.ID_WORK_INTERVAL FROM DUAL;
                              END IF;
                           END IF;
                        END;
/

