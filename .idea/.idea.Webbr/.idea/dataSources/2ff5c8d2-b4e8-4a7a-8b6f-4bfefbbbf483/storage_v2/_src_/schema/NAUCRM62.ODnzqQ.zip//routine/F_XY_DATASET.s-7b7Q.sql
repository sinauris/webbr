create function f_xy_dataset(f varchar2, xmin double precision, xmax double precision, n number) return xy_dataset_type pipelined as r xy_record_type := xy_record_type(0, 0);     m number;     deltax double precision; begin     m := n;     if m > 2 then        m := m - 1;     end if;     deltax := (xmax - xmin)/m;     for i in 0..m loop         r.x := xmin + i*deltax;         r.y := eval(replace(f, '$x', '(' || r.x || ')'));         pipe row(r);     end loop;   return; end;
/

