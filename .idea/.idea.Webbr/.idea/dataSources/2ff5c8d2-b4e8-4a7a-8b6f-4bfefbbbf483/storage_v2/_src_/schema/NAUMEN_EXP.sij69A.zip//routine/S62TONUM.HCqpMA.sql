create Function S62ToNum(N In Varchar2) Return Varchar2 Is
  H   Varchar2(128) := '';
  N1 Number           := 0; -- Длинна строки.
  N2 Number           := 0; -- Счетчик возведения в степень.
  N3 Number           := 0; -- Аргумент операции.
  N4 Number           := 0; -- Результат преобразования.
Begin
N1 := Length(N);
N2 := 0;

Loop
       Exit When N1 = 1;
       
       Select Decode(NUMS, Null, 0, NUMS) Into N3 From(Select InStr('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz', SubStr(N, N1, 1) ,1,1) - 1 NUMS From DUAL);
       
       N4 := N4 + Power(62,N2) * N3;
       
       N1 := N1 - 1;
       N2 := N2 + 1;
End Loop;

Select To_Char(N4) Into H From DUAL;

--9999999999999999999999
--0000000000000000000000

Select Decode(H,'','0000000000000000000000',Decode(Length(H),
01,'000000000000000000000'||H,
02,'00000000000000000000'||H,
03,'0000000000000000000'||H,
04,'000000000000000000'||H,
05,'00000000000000000'||H,
06,'0000000000000000'||H,
07,'000000000000000'||H,
08,'00000000000000'||H,
09,'0000000000000'||H,
10,'000000000000'||H,
11,'00000000000'||H,
12,'0000000000'||H,
13,'000000000'||H,
14,'00000000'||H,
15,'0000000'||H,
16,'000000'||H,
17,'00000'||H,
18,'0000'||H,
19,'000'||H,
20,'00'||H,
21,'0'||H,
H
)) Into H From DUAL;

--nauss99_1456121176_796_2128082
--nauss99_9999999999_999_9999999

Select 'nauss'||Decode(S1,0,Null,To_Char(S1))||'_'||To_Char(S2)||'_'||To_Char(S3)||'_'||To_Char(S4)  Into H From
(Select To_Number(SubStr(H, 1, 2)) S1, To_Number(SubStr(H, 3, 10)) S2, To_Number(SubStr(H, 13, 3)) S3, To_Number(SubStr(H, 16, 7)) S4 From DUAL);

Return H;
End S62ToNum;
/

