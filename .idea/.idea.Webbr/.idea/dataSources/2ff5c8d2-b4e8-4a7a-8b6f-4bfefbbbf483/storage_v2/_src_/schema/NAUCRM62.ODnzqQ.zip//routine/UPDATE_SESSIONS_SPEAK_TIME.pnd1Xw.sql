create Procedure update_sessions_speak_time As
Begin
    Insert Into sessions_speak_time_temp
    Select
        sessions.session_id,
        nvl( speak_times.speaktime, 0 ) as speaktime
    From
        sessions_for_update sessions left join
        (
            Select
                sessions.session_id,
                sum ( intervaltosec( links.ended - links.created ) ) as speaktime
            From
                sessions_for_update sessions inner join
                call_legs src_legs on ( src_legs.session_id = sessions.session_id ) inner join
                audio_links links on ( src_legs.id = links.src_leg ) inner join
                call_legs dst_legs on ( dst_legs.id = links.dst_leg )
            Where
                src_legs.leg_id > dst_legs.leg_id and
                src_legs.dst_abonent_type != 'IVR' and
                dst_legs.dst_abonent_type != 'IVR' and
                src_legs.intrusion = '0' and
                dst_legs.intrusion = '0'
            Group By
                sessions.session_id
        ) speak_times on ( sessions.session_id = speak_times.session_id );
End;
/

