create type           SYS_PLSQL_1808372_1407_1 as table of "NC_CORE"."SYS_PLSQL_1808372_1280_1";
/

