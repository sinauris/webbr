create TYPE wfm_type_status FORCE AS OBJECT
    (
    oper_login              varchar2(50),
    time_from               timestamp,
    state                   int(1),
    substate                varchar2(25)
    );
/

