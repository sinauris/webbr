create trigger TRG_D_INTERVIEW_DECORATED_ID
    before insert
    on D_INTERVIEW_DECORATED
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_INTERVIEW_DECORATED" IS NULL THEN
                                 SELECT SEQ_D_INTERVIEW_DECORATED_ID.NEXTVAL INTO :NEW."ID_INTERVIEW_DECORATED" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

