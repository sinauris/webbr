create trigger TRG_EMPLOYEES_CONTACTS_ID
    before insert
    on EMPLOYEES_CONTACTS
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_CONTACT" IS NULL THEN
                                 SELECT SEQ_EMPLOYEES_CONTACTS_ID.NEXTVAL INTO :NEW."ID_CONTACT" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

