create trigger TRG_REL_DPTS_POSTS43_ID
    before insert
    on REL_DPTS_POSTS
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_RELATION" IS NULL THEN
                                 SELECT SEQ_REL_DPTS_POSTS43_ID.NEXTVAL INTO :NEW."ID_RELATION" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

