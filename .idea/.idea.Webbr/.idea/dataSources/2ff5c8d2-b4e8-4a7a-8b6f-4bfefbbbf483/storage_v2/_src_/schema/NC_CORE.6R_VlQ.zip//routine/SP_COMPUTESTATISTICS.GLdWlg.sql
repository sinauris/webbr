create PROCEDURE SP_COMPUTESTATISTICS AS 
begin
  FOR LP IN  (SELECT  OWNER, TABLE_NAME 
              FROM ALL_TABLES 
              WHERE OWNER  NOT IN ('ALEX', 'SYS', 'BASEPREP', 'SYSTEM', 'OUTLN')
                AND TEMPORARY = 'N') 
  LOOP
     begin
       DBMS_STATS.GATHER_TABLE_STATS(LP.OWNER, LP.TABLE_NAME, method_opt => 'FOR ALL COLUMNS SIZE AUTO', cascade => TRUE);    
       EXCEPTION when OTHERS then null;
     end;     
  end LOOP ;   
END SP_COMPUTESTATISTICS;
/

