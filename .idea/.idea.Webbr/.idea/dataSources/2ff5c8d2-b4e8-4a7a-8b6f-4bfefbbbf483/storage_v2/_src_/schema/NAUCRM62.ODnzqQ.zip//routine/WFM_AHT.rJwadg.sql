create FUNCTION WFM_AHT (strt in timestamp, fnsh in timestamp)
RETURN wfm_type_aht_table
AS
ahtt wfm_type_aht_table; 
BEGIN
if fnsh - INTERVAL '1510' MINUTE <= strt
then
  SELECT wfm_type_aht
        (
                aa.ZN_TM,   
                aa.project_id,
                aa.value, 
                aa.AHT
        )
BULK COLLECT INTO ahtt
FROM
(with   intrvl as   ( 
            SELECT * FROM TABLE(intervalize(strt, fnsh, 'MI', 15))
            ),
all_calls   as  (select
                            call_legs.created                               as  ringing_from,
                            coalesce(
                                        call_legs.connected,
                                        call_legs.ended     
                                    )                                       as  ringing_till,
                            call_legs.connected                             as  speaking_from,
                            case
                                    when    call_legs.connected is null then null
                                    else    call_legs.ended
                                    end                                     as  speaking_till,
                            call_legs.dst_abonent                           as  login,
                            call_legs.session_id                            as  session_id,
                            call_legs.leg_id                                as  leg_id
                    from            call_legs
                    where
                                call_legs.connected         >= strt
                            and call_legs.connected         <  fnsh
                            and call_legs.dst_abonent_type  =  'SP'
            ),
wrapup      as  (select
                                status_changes.entered                       as  dt_from,
                                status_changes.leaved                        as  dt_till,
                                status_changes.login                         as  login,
                                status_changes.reason                        as  session_id
                    from            status_changes
                    where
                            status_changes.entered              >=  strt
                        and status_changes.entered              <   fnsh
                        and status_changes.status               =   'wrapup'
            ),
q_calls         as  (select
                                queued_calls.session_id                      as session_id,
                                queued_calls.unblocked_time                  as unblocked_time,
                                queued_calls.project_id                      as project_id,
                                queued_calls.next_leg_id                     as nextleg
                    from            queued_calls
                    where
                                queued_calls.enqueued_time     >= strt   
                            and queued_calls.enqueued_time     <  fnsh
                            and     (queued_calls.final_stage  =  'operator' 
                                    or queued_calls.final_stage='queue' )
                            and queued_calls.unblocked_time is not null
                ),
projects as (select 
                            project_id
                        ,   project_type 
            from table( wfm_projects)
            ),
immessages as(select
                            mbstat_message_handlings.mb_session_id                  as  session_id
                        ,   mbstat_message_handlings.project_id                     as  project_id
                        ,   mbstat_message_handlings.operator                       as  login
                        ,   mbstat_message_handlings.unblocked_time                 as unblocked_time
                        ,   mbstat_message_handlings.distributed_time               as  started
                        ,   mbstat_message_handlings.ended_time                     as  finished
                        ,   intervaltosec(
                                        mbstat_message_handlings.ended_time-
                                        mbstat_message_handlings.distributed_time) as im_duration
                from            mbstat_message_handlings
                join projects
                    on 
                        projects.project_id=mbstat_message_handlings.project_id 
                where
                            mbstat_message_handlings.unblocked_time                 is  not null
                        and mbstat_message_handlings.distributed_time           between strt and fnsh
                        and projects.project_type                                   ='im'
                ),
discrmessages as (select 
                            mmh.message_id                                      as session_id
                        ,   mmh.project_id                                      as project_id 
                        ,   mmh.operator                                        as login
                        ,   mmh.unblocked_time                                  as unblocked_time
                        ,   mmh.distributed_time                                as started
                        ,   mmh.ended_time                                      as finished
                        ,   intervaltosec(
                                         mmh.ended_time
                                        -mmh.distributed_time
                                         )                                      as discr_duration
                    from MBSTAT_MESSAGE_HANDLINGS mmh
                    join projects
                        on projects.project_id=mmh.project_id
                    where   
                            (projects.project_type                              ='email' 
                            or projects.project_type                            ='sms'
                            or projects.project_type                            ='socialnet')
                        and mmh.distributed_time                                between strt and fnsh
                            ),

presummary  as  (select
                                q_calls.session_id                              as session_id,
                                mv_incoming_call_project.title                  as project_title,
                                q_calls.project_id                              as project_id,
                                all_calls.login                                 as login,
                                q_calls.unblocked_time                          as unblocked_time,
                                all_calls.ringing_from                          as ringing_from,     
                                all_calls.ringing_till                          as ringing_till,
                                all_calls.speaking_from                         as speaking_from,
                                all_calls.speaking_till                         as speaking_till,
                                wrapup.dt_from                                  as wrapup_from,
                                wrapup.dt_till                                  as wrapup_till,
                                'voice inbound'                                 as project_type
                    from            q_calls
                    left join   mv_incoming_call_project                               
                        on  
                mv_incoming_call_project.uuid   =   q_calls.project_id
                    left join    all_calls
                        on   
                all_calls.session_id=q_calls.session_id
                                and  all_calls.leg_id=q_calls.nextleg
                    left join   wrapup
                        on  
                wrapup.session_id=q_calls.session_id
                                and wrapup.login=all_calls.login
            ),
itogi       as  (select
                            presummary.session_id                                   as  session_id,
                            presummary.project_id                                   as  project_uuid,
                            presummary.unblocked_time                               as  unblocked_time,
                            presummary.login                                        as  employee_login,
                            presummary.ringing_from                                 as  handling_from,
                            greatest    (   
                                        coalesce(presummary.wrapup_till,
                                        presummary.speaking_till),
                                        presummary.speaking_till,
                                        presummary.ringing_till  
                                        )                                           as  handling_till,
                            intervaltosec(
                                            coalesce(presummary.wrapup_till,
                                                     presummary.speaking_till)
                                                    -presummary.ringing_from
                                        )                                          as handling_duration      
                    from            presummary
                    left join   mv_employee                                             
            on      
                mv_employee.login=presummary.login
            union all
                    select
                                    session_id
                                ,   project_id
                                ,   unblocked_time
                                ,   login
                                ,   started
                                ,   finished
                                ,   discr_duration
                    from        discrmessages
            union all
                    select
                                    session_id
                                ,   project_id
                                ,   unblocked_time
                                ,   login
                                ,   started
                                ,   finished
                                ,   im_duration
                    from             immessages
                    )

select 
                    intrvl.S                                                        as Zn_tm, 
                    itogi.project_uuid                                              as project_id, 
                    count(itogi.session_id)                                         as value, 
                    avg(handling_duration)                                          as Aht
from    itogi
            
join intrvl 
on 

        itogi.unblocked_time>intrvl.S
        and itogi.unblocked_time<=intrvl.F
group by intrvl.S, itogi.project_uuid
order by intrvl.S 
) aa;
return ahtt;
else return null;
end if;
END WFM_AHT;
/

