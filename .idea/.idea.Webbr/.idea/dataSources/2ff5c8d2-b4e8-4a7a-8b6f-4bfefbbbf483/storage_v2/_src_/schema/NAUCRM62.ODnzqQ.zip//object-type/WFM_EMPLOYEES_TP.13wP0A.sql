create type wfm_employees_tp
AS OBJECT 
(
  oper_id varchar2(32),
  first_name varchar2(512),
  last_name varchar2(512),
  middlename varchar2(512),
  phone varchar2(512),
  dateOfBirth date,
  firingDate date,
  hiringDate date
);
/

