create view CALLS_CASE_OUTGOING as
Select
    case_uuid.session_id as sessionId,
    case_uuid.case_uuid as parentUid,
    initiator.src_abonent as operatorLogin,
    initiator.src_id as phoneNumber,
    initiator.dst_id as receiverPhoneNumber,
    initiator.created as incomingTime,
    initiator.connected as connectionTime,
    initiator.ended as disconnectionTime,
    null as waitTime,
    redirection.dst_abonent as redirectionLogin,
    redirection.dst_id as redirectionNumber,
    speak_time.speakTime as speakTime,
    null as ivrMessageTime,
    null as queueTime,
    intervaltosec( initiator.ended - initiator.created ) as operatorTime,
    intervaltosec( redirection.ended - redirection.connected ) as redirectTime,
    0 as isInDirection,
    case
        when redirection.dst_id is null then 3
        else 4
    end as finalStage
from
calls_case_uuid case_uuid
inner join call_legs initiator on
    (
        initiator.incoming = '1' and
        initiator.session_id = case_uuid.session_id and
        initiator.rowid =
        (
            select
                min(rowid)
            from
                call_legs
            where incoming = '1' and session_id = case_uuid.session_id
        )
    )
left join
    call_legs redirection on
    (
        redirection.intrusion = '0' and
        redirection.session_id = initiator.session_id and
        To_Number(redirection.leg_id) > To_Number(initiator.leg_id) and
        redirection.connected is not null
    )
inner join sessions_for_update calls on ( case_uuid.session_id = calls.session_id )
left join sessions_speak_time_temp speak_time on  ( speak_time.session_id = case_uuid.session_id )
where (
        redirection.connected is null or
        redirection.rowid =
        (
            select
                min( rowid )
            from
                call_legs
            where
                intrusion = '0' and
                session_id = redirection.session_id and
                connected >= initiator.connected and
                leg_id != initiator.leg_id
        )
      )
/

