create function
wfm_states(start_time timestamp, stop_time timestamp) return wfm_states_tp_tab
pipelined
is
line wfm_states_tp := wfm_states_tp(null, null, null, null);   
begin
   for i in 
       (
          with handlings as
            (select
                session_id
              , handling_from
              , handling_till
              , employee_login
              , employee_uuid
             from table(wfm_handlings(start_time, stop_time, NUMTODSINTERVAL(0, 'second')))
            )
          
          , states as 
            (select
                entered
              , leaved
              , status
              , login
             from status_changes
             where
                entered >= start_time
                and entered < stop_time
                and status in ('away', 'dnd', 'accident', 'standoff')
            )
          
          , states_intersect as 
            (select
                states.entered as rawdate
              , states.leaved as leaved
              , handlings.handling_from
              , handlings.handling_till
              , states.login
              , states.status
              , coalesce(handlings.handling_till, states.entered) as  real_entered
             from states
                 left join handlings 
                           on (handlings.employee_login = states.login
                           and handlings.handling_from < states.entered
                           and handlings.handling_till > states.entered)
            )
          
          , aggregated as 
            (select
                mv_employee.uuid as oper_id
              , states_intersect.real_entered as time_from
              , states_intersect.leaved as time_to
              , states_intersect.status as state
             from states_intersect
                  left join mv_employee                 
                            on mv_employee.login = states_intersect.login
             union all
             select
                handlings.employee_uuid as oper_id
              , handlings.handling_from as time_from
              , handlings.handling_till as time_to
              , 'handling' as state
             from handlings
            )
          
          , aggregated_typecast as 
            (select
                aggregated.oper_id
              , aggregated.time_from
              , aggregated.time_to
              , aggregated.state
             from aggregated
             order by       
                time_from
              , oper_id
            )
          
          select *
          from aggregated_typecast       
       )
       loop
           line := wfm_states_tp(i.oper_id, i.time_from, i.time_to, i.state);
           pipe row(line);       
       end loop;
   return;
end;
/

