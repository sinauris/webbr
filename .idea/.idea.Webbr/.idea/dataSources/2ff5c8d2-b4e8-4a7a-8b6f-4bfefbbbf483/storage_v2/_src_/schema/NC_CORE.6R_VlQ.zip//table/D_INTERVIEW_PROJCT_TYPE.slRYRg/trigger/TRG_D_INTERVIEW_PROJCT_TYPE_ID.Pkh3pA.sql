create trigger TRG_D_INTERVIEW_PROJCT_TYPE_ID
    before insert
    on D_INTERVIEW_PROJCT_TYPE
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_PROJECT_TYPE" IS NULL THEN
                                 SELECT SEQ_D_INTERVIEW_PROJCT_TYPE_ID.NEXTVAL INTO :NEW."ID_PROJECT_TYPE" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

