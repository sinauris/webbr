create PACKAGE BODY PKG_API AS
--------------------------------------------------------------------------------
------------------------------ФУНКЦИИ ДЛЯ ФИЛЬТРОВ------------------------------
--------------------------------------------------------------------------------
  --Получение списка зарегистрированных площадок
  FUNCTION GET_LOCATION_LIST(I_INCLUDE_ALL CHAR DEFAULT 'Y') RETURN PT_LOCATION_LIST PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_LOCATION_LIST
    IS
    WITH SQ_PRE_DATA AS
      (
        SELECT
          'L:' AS FLAG,
          MCI."UUID"  AS "AREAUUID",
          MCF."UUID"  AS "PARENT_UUID",
          MCI."TITLE" AS "AREANAME"
        FROM NAUCRM62.MV_CATALOG_ITEM MCI
        JOIN NAUCRM62.MV_CATALOG_FOLDER MCF ON MCF."UUID"=MCI.FOLDERUUID
        UNION
        SELECT 'C:' AS FLAG, UUID, CASE WHEN PARENTUUID != CATALOGUUID THEN PARENTUUID END AS PARENTUUID, TITLE
        FROM NAUCRM62.MV_CATALOG_FOLDER
        WHERE CATALOGCODE = 'Areas'
        UNION
        SELECT 'A:', NULL, NULL, 'Все Call-центры/площадки'
        FROM DUAL
        WHERE NVL(UPPER(I_INCLUDE_ALL),'Y') = 'Y'
      )
    SELECT
      CASE
        WHEN FLAG  NOT IN ('A:', 'C:') THEN PRIOR FLAG||PRIOR AREANAME||','
      END||FLAG||AREANAME AS LOCATION_ID,
      REPLACE(LPAD(AREANAME,LENGTH(AREANAME)+(LEVEL-1)*3,'*'),'*','&nbsp;') AS NAME
    FROM SQ_PRE_DATA
    START WITH PARENT_UUID IS NULL
    CONNECT BY PRIOR AREAUUID = PARENT_UUID
    ORDER SIBLINGS BY FLAG, AREANAME;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END GET_LOCATION_LIST;

  --Получение списка логинов
  FUNCTION GET_EMPLOYEES_LOGINS(I_JSON VARCHAR2) RETURN PT_EMPLOYEES_LOGINS PIPELINED
  IS
    V_PARAMS T_PARAMS := T_PARAMS();
    V_PROJECTS VARCHAR2(2000 CHAR) DEFAULT NULL;
    V_LOCATION VARCHAR2(2000 CHAR) DEFAULT NULL;
    V_PLATFORMS T_LIST_INTEGER := T_LIST_INTEGER();
    V_LOGINS T_LIST_VARCHAR := T_LIST_VARCHAR();
    V_DATE_START TIMESTAMP;
    V_DATE_END TIMESTAMP;
    V_ROLETYPE T_LIST_VARCHAR := T_LIST_VARCHAR();

    CURSOR GET_DATA RETURN PTR_EMPLOYEES_LOGINS
    IS
    WITH SQ_LOGINS AS
      (
        SELECT /*+ MATERIALIZE*/
          SUBSTR(COLUMN_VALUE, 1, DECODE(INSTR(COLUMN_VALUE,':'), 0, LENGTH(COLUMN_VALUE), INSTR(COLUMN_VALUE,':')-1)) AS LOGIN,
          PKG_STRINGS.FNC_TONUMBER(SUBSTR(COLUMN_VALUE, INSTR(COLUMN_VALUE, ':')+1)) AS PLATFORM_ID
        FROM TABLE(V_LOGINS)
      ),
      SQ_PROJECTS AS
      (--Список проектов по которым надо отфильтровать логины
        SELECT /*+ MATERIALIZE*/ PROJECT_ID, PLATFORM_ID
        FROM TABLE(PKG_API.GET_PROJECTS_IDS(V_PROJECTS))
        WHERE V_PROJECTS IS NOT NULL
      ),
      SQ_LOACTION_PRP AS
      (--Площадка по которой надо отфильтровать логины
        SELECT
          SUBSTR(COLUMN_VALUE,1,1) AS PARAM, SUBSTR(COLUMN_VALUE,3) AS VAL
        FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(UPPER(V_LOCATION)))
        WHERE V_LOCATION IS NOT NULL
      ),
      SQ_LOCATION AS
      (
        SELECT CALL_CENTRE_NAME, LOCATION_NAME
        FROM SQ_LOACTION_PRP
        PIVOT(MAX(VAL) FOR PARAM IN ('C' AS CALL_CENTRE_NAME, 'L' AS LOCATION_NAME))
      ),
      SQ_PRP_EMPL AS
      (
        SELECT VWE.LOGIN, VWE.SURNAME, VWE.NAME, VWE.PATRONYMIC,
          VWE.LOCATION_NAME, VWE.CALL_CENTRE_NAME, VWE.FID_PLATFORM,
          FRPE.ACTIVE_FROM, FRPE.ACTIVE_TILL
        FROM VW_EMPLOYEES VWE
        LEFT JOIN VW_REL_PROJECTS_EMPLOYEES FRPE ON VWE.LOGIN=FRPE.LOGIN AND VWE.FID_PLATFORM=FRPE.FID_PLATFORM
          AND FRPE.ACTIVE_FROM <= V_DATE_END AND FRPE.ACTIVE_TILL > V_DATE_START
        WHERE EXISTS(
                      SELECT 1
                      FROM SQ_LOCATION FSQL
                      WHERE NVL(UPPER(VWE.CALL_CENTRE_NAME), '*') = COALESCE(FSQL.CALL_CENTRE_NAME, UPPER(VWE.CALL_CENTRE_NAME), '*')
                        AND NVL(UPPER(VWE.LOCATION_NAME), '*') = COALESCE(FSQL.LOCATION_NAME, UPPER(VWE.LOCATION_NAME), '*')
                    )
          AND EXISTS(
                      SELECT 1
                      FROM TABLE(V_PLATFORMS) FP
                      WHERE FP.COLUMN_VALUE = VWE.FID_PLATFORM
                      UNION ALL
                      SELECT 1
                      FROM DUAL
                      WHERE V_PLATFORMS IS NULL
                    )
          AND EXISTS(
                      SELECT 1
                      FROM SQ_LOGINS FL
                      WHERE FL.LOGIN = VWE.LOGIN
                        AND COALESCE(FL.PLATFORM_ID, VWE.FID_PLATFORM, -1) = NVL(VWE.FID_PLATFORM, -1)
                      UNION ALL
                      SELECT 1
                      FROM DUAL
                      WHERE V_LOGINS IS NULL
                    )
          AND EXISTS(
                      SELECT 1
                      FROM TABLE(V_ROLETYPE) FRT
                      WHERE FRT.COLUMN_VALUE = LOWER(FRPE.ROLETYPE)
                      UNION ALL
                      SELECT 1
                      FROM DUAL
                      WHERE V_ROLETYPE IS NULL
                    )
          AND EXISTS(
                      SELECT 1
                      FROM SQ_PROJECTS FP
                      WHERE FRPE.PROJECT_ID = FP.PROJECT_ID
                        AND COALESCE(FRPE.FID_PLATFORM, FP.PLATFORM_ID, -1) = NVL(FP.PLATFORM_ID, -1)
                      UNION ALL
                      SELECT 1
                      FROM DUAL
                      WHERE V_PROJECTS IS NULL)
      )
    SELECT DISTINCT LOGIN, SURNAME, NAME, PATRONYMIC, CALL_CENTRE_NAME, LOCATION_NAME, FID_PLATFORM
    FROM SQ_PRP_EMPL EMPL;

  BEGIN
    IF SUBSTR(I_JSON, 1, 1) = '{'
      AND SUBSTR(I_JSON, -1) = '}' THEN
      V_PARAMS := PKG_STRINGS.FNC_JSON(I_JSON);

      SELECT VP."VALUE" INTO V_PROJECTS
      FROM TABLE(V_PARAMS) VP
      WHERE VP."KEY" = 'projects'
        AND ROWNUM=1;

      SELECT PKG_STRINGS.FNC_TONUMBER(PT.COLUMN_VALUE)
        BULK COLLECT INTO V_PLATFORMS
      FROM TABLE(V_PARAMS) VP,
        TABLE(PKG_STRINGS.FNC_STRTOTBL(REGEXP_REPLACE(VP."VALUE",'^\[|\]$',''))) PT
      WHERE VP."KEY" = 'platforms'
        AND PKG_STRINGS.FNC_TONUMBER(PT.COLUMN_VALUE) IS NOT NULL;

      SELECT TRIM('"' FROM PT.COLUMN_VALUE)
        BULK COLLECT INTO V_LOGINS
      FROM TABLE(V_PARAMS) VP,
        TABLE(PKG_STRINGS.FNC_STRTOTBL(REGEXP_REPLACE(VP."VALUE",'^\[|\]$',''))) PT
      WHERE VP."KEY" = 'logins'
        AND PT.COLUMN_VALUE IS NOT NULL;

      SELECT LOWER(TRIM('"' FROM PT.COLUMN_VALUE))
        BULK COLLECT INTO V_ROLETYPE
      FROM TABLE(V_PARAMS) VP,
        TABLE(PKG_STRINGS.FNC_STRTOTBL(REGEXP_REPLACE(VP."VALUE",'^\[|\]$',''))) PT
      WHERE VP."KEY" = 'roletype'
        AND TRIM('"' FROM PT.COLUMN_VALUE) IS NOT NULL;

      SELECT REGEXP_REPLACE(VP."VALUE",'"','') INTO V_LOCATION
      FROM TABLE(V_PARAMS) VP
      WHERE VP."KEY" = 'location'
        AND ROWNUM=1;

      SELECT CAST(REGEXP_REPLACE(VP."VALUE",'"','') AS TIMESTAMP) INTO V_DATE_START
      FROM TABLE(V_PARAMS) VP
      WHERE VP."KEY" = 'date_start'
        AND ROWNUM=1;

      SELECT CAST(REGEXP_REPLACE(VP."VALUE",'"','') AS TIMESTAMP) INTO V_DATE_END
      FROM TABLE(V_PARAMS) VP
      WHERE VP."KEY" = 'date_end'
        AND ROWNUM=1;


    ELSE
      V_LOGINS := T_LIST_VARCHAR();
      SELECT COLUMN_VALUE BULK COLLECT INTO V_LOGINS
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_JSON))
      WHERE COLUMN_VALUE IS NOT NULL;
    END IF;
    IF V_PLATFORMS.COUNT = 0 THEN V_PLATFORMS := NULL; END IF;
    IF V_LOGINS.COUNT = 0 THEN V_LOGINS := NULL; END IF;
    IF V_ROLETYPE.COUNT = 0 THEN V_ROLETYPE := NULL; END IF;

    IF V_DATE_START IS NULL THEN
      V_DATE_START := CAST(ADD_MONTHS(SYSDATE, -6) AS TIMESTAMP);
    END IF;

    IF V_DATE_END IS NULL THEN
      V_DATE_END := CAST(SYSDATE+1 AS TIMESTAMP);
    END IF;

    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END GET_EMPLOYEES_LOGINS;

  --Получение списка зарегистрированных операторов (новое)
  FUNCTION GET_EMPLOYEES_LIST(I_INCLUDE_ALL CHAR DEFAULT 'Y',
                              I_VIEW_LOGIN CHAR DEFAULT 'Y',
                              I_DATE_START TIMESTAMP DEFAULT NULL, --Дата начала отбора
                              I_DATE_END TIMESTAMP DEFAULT NULL, --Дата окончания отбора
                              I_PROJECT VARCHAR2 DEFAULT NULL, --Список проектов
                              I_LOCATION VARCHAR2 DEFAULT NULL, --Call-центр/площадка
                              I_ROLETYPE VARCHAR2 DEFAULT 'operator', --Список ролей сотрудников
                              I_PLATFORM VARCHAR2 DEFAULT NULL, --Список платформ
                              I_NEW_STYLE CHAR DEFAULT 'N')
    RETURN PT_EMPLOYEES_LIST PIPELINED
  AS
    V_DATE_FORMAT VARCHAR2(200 CHAR) DEFAULT NULL;
    V_ROLETYPE VARCHAR2(2000 CHAR) DEFAULT NULL;
    V_FILTER VARCHAR2(2000 CHAR) := '{"date_start": "_date_start", "date_end": "_date_end",'||
                                    ' "location": "_location", "logins": [], "platforms": [_platforms],'||
                                    ' "projects": _projects, "roletype": [_roletype]}';

    CURSOR GET_DATA RETURN PTR_EMPLOYEES_LIST
    IS
    WITH SQ_LOGINS AS
      (
        SELECT LOGIN||
          CASE
            WHEN UPPER(NVL(I_NEW_STYLE, 'N')) = 'Y'
            THEN ':'||TO_CHAR(FID_PLATFORM)
          END AS LOGIN,
          NVL(TRIM(TRIM(LAST_NAME)||' '||TRIM(FIRST_NAME)||' '||TRIM(MIDDLE_NAME)), '!Нет ФИО')||
            CASE
              WHEN UPPER(NVL(I_VIEW_LOGIN, 'Y')) = 'Y'
              THEN ' ('||LOGIN||')'
            END AS FIO
        FROM TABLE(GET_EMPLOYEES_LOGINS(V_FILTER)) PL
        WHERE UPPER(NVL(I_INCLUDE_ALL, 'Y')) != 'O'
        ORDER BY TRIM(TRIM(LAST_NAME)||' '||TRIM(FIRST_NAME)||' '||TRIM(MIDDLE_NAME))||
                      CASE
                        WHEN UPPER(NVL(I_VIEW_LOGIN, 'Y')) = 'Y'
                        THEN ' ('||LOGIN||')'
                      END
      )
    SELECT
      CASE
        WHEN UPPER(NVL(I_NEW_STYLE, 'N')) = 'Y'
        THEN V_FILTER
      END AS LOGIN,
      'Все сотрудники' AS FIO
    FROM DUAL
    WHERE UPPER(NVL(I_INCLUDE_ALL, 'Y')) IN ('Y', 'O')
    UNION ALL
    SELECT LOGIN, FIO
    FROM SQ_LOGINS;

  BEGIN
    SELECT NVL(SUBSTR(VALUE,1, INSTR(UPPER(VALUE),'X')-1), VALUE) INTO V_DATE_FORMAT
    FROM NLS_SESSION_PARAMETERS
    WHERE PARAMETER IN ('NLS_TIMESTAMP_FORMAT');
    V_FILTER := REPLACE(V_FILTER, '_date_start', TO_CHAR(I_DATE_START, V_DATE_FORMAT));
    V_FILTER := REPLACE(V_FILTER, '_date_end', TO_CHAR(I_DATE_END, V_DATE_FORMAT));
    V_FILTER := REPLACE(V_FILTER, '_location', I_LOCATION);
    V_FILTER := REPLACE(V_FILTER,'_platforms',REGEXP_REPLACE(I_PLATFORM,'"',''));
    IF SUBSTR(I_PROJECT, 1, 1) = '{'
      AND SUBSTR(I_PROJECT, -1) = '}' THEN
      V_FILTER := REPLACE(V_FILTER, '_projects', I_PROJECT);
    ELSE
      V_FILTER := REPLACE(V_FILTER, '_projects', '"'||I_PROJECT||'"');
    END IF;

    IF I_ROLETYPE IS NOT NULL THEN
      SELECT '"'||LISTAGG(TRIM(TRIM('"' FROM COLUMN_VALUE)),'","')WITHIN GROUP(ORDER BY COLUMN_VALUE)||'"'
        INTO V_ROLETYPE
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(LOWER(I_ROLETYPE)))
      GROUP BY 1;
    END IF;
    V_FILTER := REPLACE(V_FILTER, '_roletype', V_ROLETYPE);

    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;

  END GET_EMPLOYEES_LIST;

  --Получение списка проектов
  FUNCTION GET_PROJECTS_IDS(I_JSON VARCHAR2)
    RETURN PT_PROJECTS_IDS PIPELINED
  IS
    V_PARAMS T_PARAMS := T_PARAMS();
    V_PLATFORMS T_LIST_INTEGER := T_LIST_INTEGER();
    V_ID_ELEMENT T_LIST_VARCHAR := T_LIST_VARCHAR();
    V_DIRECTION T_LIST_VARCHAR := T_LIST_VARCHAR();
    V_ACTIVE INTEGER DEFAULT NULL;

    CURSOR GET_DATA RETURN PTR_PROJECTS_IDS
    IS
    WITH SQ_PROJECTS AS
      (
        SELECT /*+ MATERIALIZE*/
          SUBSTR(COLUMN_VALUE, 1, DECODE(INSTR(COLUMN_VALUE,':'), 0, LENGTH(COLUMN_VALUE), INSTR(COLUMN_VALUE,':')-1)) AS PROJECT_ID,
          SUBSTR(COLUMN_VALUE, INSTR(COLUMN_VALUE, ':')+1) AS PLATFORM_ID
        FROM TABLE(V_ID_ELEMENT)
      )
    SELECT ID_ELEMENT, CAPTION, FID_PLATFORM
    FROM MV_PROJECTS MVP
    WHERE MVP.IS_ACTIVE = DECODE(NVL(V_ACTIVE, -1), -1, MVP.IS_ACTIVE, V_ACTIVE)
      AND EXISTS(
                  SELECT 1
                  FROM TABLE(V_PLATFORMS) FPL
                  WHERE FPL.COLUMN_VALUE = MVP.FID_PLATFORM
                  UNION ALL
                  SELECT 1
                  FROM DUAL
                  WHERE V_PLATFORMS IS NULL
                )
      AND EXISTS(
                  SELECT 1
                  FROM SQ_PROJECTS FPPG
                  WHERE FPPG.PROJECT_ID IN (MVP.ID_ELEMENT, MVP.FID_GROUP)
                    AND COALESCE(PKG_STRINGS.FNC_TONUMBER(FPPG.PLATFORM_ID), MVP.FID_PLATFORM, -1) = NVL(MVP.FID_PLATFORM, -1)
                  UNION ALL
                  SELECT 1
                  FROM DUAL
                  WHERE V_ID_ELEMENT IS NULL
                )
      AND EXISTS(
                  SELECT 1
                  FROM TABLE(V_DIRECTION) FDIR
                  WHERE UPPER(FDIR.COLUMN_VALUE) = UPPER(MVP.DIRECTION)
                  UNION ALL
                  SELECT 1
                  FROM DUAL
                  WHERE V_DIRECTION IS NULL
                );

  BEGIN
    IF SUBSTR(I_JSON, 1, 1) = '{'
      AND SUBSTR(I_JSON, -1) = '}' THEN
      V_PARAMS := PKG_STRINGS.FNC_JSON(I_JSON);
      --Получаем признак активности из параметра
      SELECT PKG_STRINGS.FNC_TONUMBER(PT.COLUMN_VALUE)
        INTO V_ACTIVE
      FROM TABLE(V_PARAMS) VP,
        TABLE(PKG_STRINGS.FNC_STRTOTBL(REGEXP_REPLACE(VP."VALUE",'^\[|\]$',''))) PT
      WHERE VP."KEY" = 'active'
        AND PKG_STRINGS.FNC_TONUMBER(PT.COLUMN_VALUE) IS NOT NULL
        AND ROWNUM=1;
      --Получаем список платформ из параметра
      SELECT PKG_STRINGS.FNC_TONUMBER(PT.COLUMN_VALUE)
        BULK COLLECT INTO V_PLATFORMS
      FROM TABLE(V_PARAMS) VP,
        TABLE(PKG_STRINGS.FNC_STRTOTBL(REGEXP_REPLACE(VP."VALUE",'^\[|\]$',''))) PT
      WHERE VP."KEY" = 'platforms'
        AND PKG_STRINGS.FNC_TONUMBER(PT.COLUMN_VALUE) IS NOT NULL;
      --Получаем список проектов из параметра
      WITH SQ_FILTER AS
        (
          SELECT /*+ MATERIALIZE*/ TRIM('"' FROM PT.COLUMN_VALUE) as projects
          FROM TABLE(V_PARAMS) VP,
            TABLE(PKG_STRINGS.FNC_STRTOTBL(REGEXP_REPLACE(VP."VALUE",'^\[|\]$',''))) PT
          WHERE VP."KEY" = 'projects'
            AND PT.COLUMN_VALUE IS NOT NULL
        ),
        SQ_GROUPS_LIST_PRP AS
        (
          SELECT /*+ MATERIALIZE*/
            SYS_CONNECT_BY_PATH(ID_GROUP, ',')||',' AS PATHS
          FROM D_GROUPS DG
          START WITH DG.FID_GROUP IS NULL
          CONNECT BY PRIOR DG.ID_GROUP = DG.FID_GROUP
        ),
        SQ_GROUPS AS
        (
          SELECT RGP.FID_PROJECT AS PROJECT_ID
          FROM D_GROUPS DG
          JOIN REL_GROUP_PROJECTS RGP ON RGP.FID_GROUP = DG.ID_GROUP
          JOIN SQ_GROUPS_LIST_PRP SQGLP ON INSTR(SQGLP.PATHS, ','||TO_CHAR(DG.ID_GROUP)||',') > 0
                                        AND EXISTS(
                                                    SELECT 1
                                                    FROM SQ_FILTER SQP
                                                    WHERE INSTR(SQGLP.PATHS, ','||TO_CHAR(SQP.projects)||',') > 0
                                                  )
          UNION
          SELECT SQF.PROJECTS
          FROM SQ_FILTER SQF
          JOIN VW_PROJECTS VWP ON VWP.PROJECT_ID = SQF.PROJECTS
          UNION
          SELECT VWP.PROJECT_ID
          FROM VW_PROJECTS VWP
          WHERE NOT EXISTS(
                            SELECT 1
                            FROM REL_GROUP_PROJECTS RGP
                            WHERE RGP.FID_PROJECT = VWP.PROJECT_ID
                          )
            AND EXISTS(
                        SELECT 1
                        FROM SQ_FILTER
                        WHERE PROJECTS = '0'
                      )
        )
      SELECT PROJECT_ID
        BULK COLLECT INTO V_ID_ELEMENT
      FROM SQ_GROUPS;
      --Получаем список направлений из параметра
      SELECT TRIM('"' FROM PT.COLUMN_VALUE)
        BULK COLLECT INTO V_DIRECTION
      FROM TABLE(V_PARAMS) VP,
        TABLE(PKG_STRINGS.FNC_STRTOTBL(REGEXP_REPLACE(VP."VALUE",'^\[|\]$',''))) PT
      WHERE VP."KEY" = 'direction'
        AND PT.COLUMN_VALUE IS NOT NULL;
    ELSE--Получаем список значений параметра
      SELECT COLUMN_VALUE BULK COLLECT INTO V_ID_ELEMENT
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_JSON))
      WHERE COLUMN_VALUE IS NOT NULL;
    END IF;
    IF V_PLATFORMS.COUNT = 0 THEN V_PLATFORMS := NULL; END IF;
    IF V_DIRECTION.COUNT = 0 THEN V_DIRECTION := NULL; END IF;
    IF V_ID_ELEMENT.COUNT = 0 THEN V_ID_ELEMENT := NULL; END IF;

    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END GET_PROJECTS_IDS;

  FUNCTION GET_PROJECTS_LIST (I_INCLUDE_ALL CHAR,
                              I_DIRECTION VARCHAR2 DEFAULT NULL,
                              I_PLATFORM VARCHAR2 DEFAULT NULL,
                              I_ACTIVE NUMBER DEFAULT 1,
                              I_VIEW_GROUPS CHAR DEFAULT 'Y',
                              I_GROUP_PLATFORM CHAR DEFAULT 'N',
                              I_LIST_GROUPS VARCHAR2 DEFAULT NULL,
                              I_INDENT VARCHAR2 DEFAULT ' ',
                              I_INDENT_COUNT NUMBER DEFAULT 3,
                              I_VIEW_PLATFORM CHAR DEFAULT 'N',
                              I_NEW_STYLE CHAR DEFAULT 'N')
    RETURN PT_PROJECTS_LIST PIPELINED AS
    V_GROUP_PLATFORM CHAR := 'N';
    V_LIST_GROUPS VARCHAR2(1000 CHAR) DEFAULT NULL;
    V_DIRECTION VARCHAR2(150 CHAR) DEFAULT NULL;
    V_FILTER VARCHAR2(2000 CHAR);

    CURSOR GET_DATA RETURN PTR_PROJECTS_LIST
    IS
    WITH SQ_PROJECTS AS
      (
        SELECT /*+ MATERIALIZE*/
          LISTAGG(
          CASE
            WHEN UPPER(NVL(I_NEW_STYLE,'N')) = 'Y'
            THEN PL.PROJECT_ID||':'||PL.PLATFORM_ID
            ELSE PL.PROJECT_ID
          END,',')WITHIN GROUP(ORDER BY PL.PROJECT_ID) AS PROJECT_ID,
          CASE
            WHEN UPPER(NVL(I_NEW_STYLE,'N')) = 'Y'
              AND V_GROUP_PLATFORM = 'Y'
            THEN PL.PLATFORM_ID
            ELSE 0
          END AS PLATFORM_ID,
          PL.CAPTION||
          CASE
            WHEN UPPER(NVL(I_NEW_STYLE,'N')) != 'Y'
              AND V_GROUP_PLATFORM = 'Y'
            THEN '('||DM.CAPTION||')'
          END AS CAPTION, NVL(RGP.FID_GROUP, DECODE(UPPER(NVL(I_VIEW_GROUPS, 'Y')), 'Y', 0, NULL)) AS FID_GROUP
        FROM TABLE(PKG_API.GET_PROJECTS_IDS(
                                                  REPLACE(
                                                          REPLACE(V_FILTER,'_platforms',REGEXP_REPLACE(I_PLATFORM,'"','')),
                                                          '_projects', V_LIST_GROUPS)
                                                )
                  ) PL
        LEFT JOIN REL_GROUP_PROJECTS RGP ON RGP.FID_PROJECT=PL.PROJECT_ID
                                        AND UPPER(NVL(I_VIEW_GROUPS, 'Y')) = 'Y'
        LEFT JOIN D_MODULES DM ON DM.ID_MODULE = PL.PLATFORM_ID
        GROUP BY  CASE
                    WHEN UPPER(NVL(I_NEW_STYLE, 'N')) = 'Y'
                      AND V_GROUP_PLATFORM = 'Y'
                    THEN PL.PLATFORM_ID
                    ELSE 0
                  END,
                  PL.CAPTION||
                  CASE
                    WHEN UPPER(NVL(I_NEW_STYLE, 'N')) != 'Y'
                      AND V_GROUP_PLATFORM = 'Y'
                    THEN '('||DM.CAPTION||')'
                  END, NVL(RGP.FID_GROUP, DECODE(UPPER(NVL(I_VIEW_GROUPS, 'Y')), 'Y', 0, NULL))
      ),
      SQ_PRP_GROUP_ID AS
      (
        SELECT PROJECT_ID, FID_GROUP,
          (SUM(LENGTH(PROJECT_ID))OVER(PARTITION BY FID_GROUP)+
            COUNT(*)OVER(PARTITION BY FID_GROUP)) AS GRP_LENGTH
        FROM SQ_PROJECTS
        WHERE UPPER(NVL(I_NEW_STYLE,'N')) != 'Y'
      ),
      SQ_GROUP_ID AS
      (
        SELECT /*+ MATERIALIZE*/ TO_CHAR(FID_GROUP) AS FID_GROUP,
          LISTAGG(PROJECT_ID, ',') WITHIN GROUP (ORDER BY PROJECT_ID) AS ID_GROUP
        FROM SQ_PRP_GROUP_ID
        WHERE GRP_LENGTH < 2000
        GROUP BY FID_GROUP
      ),
      SQ_MODULES AS
      (
        SELECT /*+ MATERIALIZE*/TO_CHAR(ID_MODULE*-1) AS PROJECT_ID,
          CAPTION, NULL AS FID_GROUP, ID_MODULE AS PLATFORM_ID
        FROM D_MODULES DM
        WHERE EXISTS(
                      SELECT 1
                      FROM SQ_PROJECTS SQP
                      WHERE SQP.PLATFORM_ID = DM.ID_MODULE
                        AND UPPER(NVL(I_VIEW_GROUPS, 'Y')) = 'Y'
                        AND V_GROUP_PLATFORM = 'Y'
                        AND UPPER(NVL(I_NEW_STYLE, 'N')) = 'Y'
                    )
      ),
      SQ_GROUPS_LIST_PRP AS
      (
        SELECT /*+ MATERIALIZE*/ SQM.PLATFORM_ID,
          SYS_CONNECT_BY_PATH(ID_GROUP, ',')||',' AS PATHS
        FROM D_GROUPS DG
        LEFT JOIN SQ_MODULES SQM ON 1=1
        WHERE UPPER(NVL(I_VIEW_GROUPS, 'Y')) = 'Y'
        START WITH DG.FID_GROUP IS NULL
        CONNECT BY PRIOR DG.ID_GROUP = DG.FID_GROUP
      ),
      SQ_GROUPS AS
      (
        SELECT DISTINCT TO_CHAR(DG.ID_GROUP) AS PROJECT_ID, DG.CAPTION,
          NVL(DG.FID_GROUP, SQGLP.PLATFORM_ID*-1) AS FID_GROUP,
          SQGLP.PLATFORM_ID
        FROM D_GROUPS DG
        JOIN SQ_GROUPS_LIST_PRP SQGLP ON INSTR(SQGLP.PATHS, ','||TO_CHAR(DG.ID_GROUP)||',') > 0
                                      AND EXISTS(
                                                  SELECT 1
                                                  FROM SQ_PROJECTS SQP
                                                  WHERE INSTR(SQGLP.PATHS, ','||TO_CHAR(SQP.FID_GROUP)||',') > 0
                                                    AND SQP.PLATFORM_ID = NVL(SQGLP.PLATFORM_ID, SQP.PLATFORM_ID)
                                                )
      ),
      SQ_RESULT_LIST AS
      (
        SELECT PROJECT_ID, CAPTION, FID_GROUP, PLATFORM_ID, 1 as grp
        FROM SQ_MODULES
        UNION ALL
        SELECT PROJECT_ID, CAPTION, FID_GROUP, NVL(PLATFORM_ID, 0), 1
        FROM SQ_GROUPS
        UNION ALL
        SELECT PROJECT_ID, CAPTION, FID_GROUP, PLATFORM_ID, 0
        FROM SQ_PROJECTS
      ),
      SQ_RESULT AS
      (
        SELECT
          CASE
            WHEN UPPER(NVL(I_NEW_STYLE, 'N')) = 'Y'
              AND SQRL.GRP = 1
            THEN REPLACE(REPLACE(V_FILTER, '_platforms', PLATFORM_ID),
                        '_projects', CASE WHEN PKG_STRINGS.FNC_TONUMBER(PROJECT_ID) >= 0 THEN '"'||PROJECT_ID||'"' END)
            ELSE NVL(SQGID.ID_GROUP, DECODE(SQRL.GRP, 1, NULL, SQRL.PROJECT_ID))
          END PROJECT_ID,
          LPAD(I_INDENT, (LEVEL-1)*I_INDENT_COUNT*LENGTH(I_INDENT), I_INDENT)||SQRL.CAPTION AS TEXT,
          ROWNUM AS RN
        FROM SQ_RESULT_LIST SQRL
        LEFT JOIN SQ_GROUP_ID SQGID ON SQGID.FID_GROUP = SQRL.PROJECT_ID
                                    AND SQRL.GRP = 1
        START WITH SQRL.FID_GROUP IS NULL
        CONNECT BY PRIOR SQRL.PROJECT_ID = TO_CHAR(SQRL.FID_GROUP)
              AND PRIOR SQRL.PLATFORM_ID = SQRL.PLATFORM_ID
        ORDER SIBLINGS BY SQRL.PLATFORM_ID, SQRL.FID_GROUP NULLS FIRST,
          DECODE(SQRL.PROJECT_ID, '0', NULL, SQRL.CAPTION) NULLS LAST
      )
    SELECT
      CASE
        WHEN UPPER(NVL(I_NEW_STYLE, 'N')) = 'Y'
        THEN REPLACE(REPLACE(V_FILTER,'_platforms',REGEXP_REPLACE(I_PLATFORM,'"','')),
                    '_projects', V_LIST_GROUPS)
      END AS PROJECT_ID,
      'Все проекты' AS TEXT
    FROM DUAL
    WHERE UPPER(NVL(I_INCLUDE_ALL, 'Y')) = 'Y'
    UNION ALL
    SELECT PROJECT_ID, TEXT
    FROM SQ_RESULT;

  BEGIN
    --Привеодим старый и новый параметр к одному значению
    IF UPPER(NVL(I_GROUP_PLATFORM, 'N')) = 'Y'
      OR UPPER(NVL(I_VIEW_PLATFORM, 'N')) = 'Y' THEN
      V_GROUP_PLATFORM := 'Y';
    END IF;
    --Получаем список проектов/групп проектов из параметра
    IF I_LIST_GROUPS IS NOT NULL THEN
      SELECT '"'||LISTAGG(TRIM('"' FROM TRIM(COLUMN_VALUE)),'","')WITHIN GROUP(ORDER BY TRIM('"' FROM TRIM(COLUMN_VALUE)))||'"'
        INTO V_LIST_GROUPS
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_LIST_GROUPS))
      WHERE TRIM('"' FROM TRIM(COLUMN_VALUE)) IS NOT NULL;
    END IF;
    --Получаем список направлений из параметра
    IF I_DIRECTION IS NOT NULL THEN
      SELECT '"'||LISTAGG(TRIM('"' FROM COLUMN_VALUE),'","')WITHIN GROUP(ORDER BY TRIM('"' FROM COLUMN_VALUE))||'"'
        INTO V_DIRECTION
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_DIRECTION))
      WHERE TRIM('"' FROM COLUMN_VALUE) IS NOT NULL;
    END IF;
    --Формируем фильтр проектов
    V_FILTER := '{"active": '||TO_CHAR(I_ACTIVE)||', "platforms": [_platforms], '||
                '"projects": [_projects], "direction": ['||UPPER(V_DIRECTION)||']}';
    IF UPPER(NVL(I_NEW_STYLE, 'N')) = 'Y'
      AND V_GROUP_PLATFORM != 'Y' THEN
      V_FILTER := REPLACE(V_FILTER,'_platforms',REGEXP_REPLACE(I_PLATFORM,'"',''));
    END IF;

    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END GET_PROJECTS_LIST;

  --Получение списка зарегистрированных проектов
  FUNCTION GET_PROVIDERS_LIST (I_INCLUDE_ALL CHAR DEFAULT 'Y')
    RETURN PT_PROVIDERS_LIST PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_PROVIDERS_LIST
    IS
    SELECT ID_PROVIDER, NAME
    FROM D_PROVIDERS
    UNION ALL
    SELECT NULL, 'Все поставщики'
    FROM DUAL
    WHERE NVL(UPPER(I_INCLUDE_ALL),'Y') = 'Y'
    ORDER BY ID_PROVIDER NULLS FIRST;

  BEGIN
    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END GET_PROVIDERS_LIST;

  --Выборка статусов операторов
  FUNCTION GET_STATUSES(I_DATE_START TIMESTAMP, --Дата начала отбора
                        I_DATE_END TIMESTAMP, --Дата окончания отбора
                        I_PROJECT VARCHAR2 DEFAULT NULL, --Проект/группа проектов
                        I_GROUP_PROJECTS_LEVEL NUMBER DEFAULT 2, --Уровень группировки проектов
                        I_LOGIN VARCHAR2 DEFAULT NULL, --Логин оператора
                        I_LOCATION VARCHAR2 DEFAULT NULL, --Call-центр/площадка
                        I_GROUP_LOCATION NUMBER DEFAULT 2, --Группировка по Call-центру/площадке
                        I_STEP NUMBER DEFAULT 1, --Длина шага разделения по времени
                        I_STEP_TYPE VARCHAR2 DEFAULT 'DD', --Тип шаг разделения по времени
                        I_STATUSES VARCHAR2 DEFAULT NULL, --Статусы
                        I_PLATFORMS VARCHAR2 DEFAULT NULL, --Платформы
                        I_ROLETYPE VARCHAR2 DEFAULT NULL, --Роль сотрудника (оператор, супервайзер, ...)
                        I_COMPRESS CHAR DEFAULT 'Y') --Убирать offline занимающие целый диапазон
    RETURN PT_STATUS_CHANGES  PIPELINED AS

    V_LOGINS VARCHAR2(2000 CHAR) := I_LOGIN;
    V_STATUSES T_LIST_VARCHAR DEFAULT NULL;

    CURSOR GET_DATA RETURN PTR_STATUS_CHANGES
    IS
    WITH SQ_RANGES AS
      (
        SELECT /*+ MATERIALIZE*/ START_RANGE, STOP_RANGE, PKG_INTERVALS.FNC_INTERVALTOSEC(START_RANGE, STOP_RANGE) AS RANGE_LENGTH
        FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(I_DATE_START, I_DATE_END, NVL(I_STEP, 1), NVL(I_STEP_TYPE, 'DD')))
      ),
      SQ_PROJECTS AS
      (
        SELECT /*+ MATERIALIZE*/ PROJECT_ID, PLATFORM_ID
        FROM TABLE(GET_PROJECTS_IDS(I_PROJECT))
      ),
      SQ_LOGINS AS
      (
        SELECT /*+ MATERIALIZE*/ DISTINCT LOGIN, LAST_NAME, FIRST_NAME, MIDDLE_NAME,
          DECODE(NVL(I_GROUP_LOCATION, 2), 0, '{all}', CALL_CENTRE_NAME) AS CALL_CENTRE_NAME,
          DECODE(NVL(I_GROUP_LOCATION, 2), 2, LOCATION_NAME, '{all}') AS LOCATION_NAME, FID_PLATFORM
        FROM TABLE(GET_EMPLOYEES_LOGINS(V_LOGINS)) TL
      ),
      SQ_FILTER_STATUSES_PRP AS
      (
        SELECT ID_STATUS, SYS_CONNECT_BY_PATH(TRIM('|' FROM LOWER(NAME||'|'||REASON)),'\')||'\' AS PATHS
        FROM D_STATUSES
        START WITH FID_STATUS = 0 AND ID_STATUS > 0
        CONNECT BY PRIOR ID_STATUS = FID_STATUS
      ),
      SQ_FILTER_STATUSES AS
      (
        SELECT /*+ MATERIALIZE*/ID_STATUS
        FROM SQ_FILTER_STATUSES_PRP SQFSP
        WHERE EXISTS(
                      SELECT 1
                      FROM TABLE(V_STATUSES) FS
                      WHERE INSTR(SQFSP.PATHS, '\'||LOWER(FS.COLUMN_VALUE)||'\') > 0
                    )
      ),
      SQ_GET_PROJECT_RATES AS
      (
        SELECT DISTINCT
          DECODE(NVL(I_GROUP_PROJECTS_LEVEL, 2), 2, GREATEST(DLR.REPORT_DATE, VRPE.ACTIVE_FROM), DLR.REPORT_DATE) AS ACTIVE_FROM,
          DECODE(NVL(I_GROUP_PROJECTS_LEVEL, 2), 2, LEAST(DLR.REPORT_DATE+1, VRPE.ACTIVE_TILL), DLR.REPORT_DATE+1) AS ACTIVE_TILL,
          DECODE(NVL(I_GROUP_PROJECTS_LEVEL, 2), 0, '{all}', 1, NVL(TO_CHAR(RGP.FID_GROUP), '0'), DLR.FID_PROJECT) AS FID_PROJECT,
          DLR.LOGIN, DLR.FID_PLATFORM, AVG(DLR.RATE)OVER(PARTITION BY DLR.LOGIN, DLR.FID_PLATFORM, DLR.FID_PROJECT, DLR.REPORT_DATE) AS P_RATE,
          DLR.FID_PROJECT AS REAL_PROJECT
        FROM D_LOGIN_RATES DLR
        LEFT JOIN REL_GROUP_PROJECTS RGP ON RGP.FID_PROJECT = DLR.FID_PROJECT
                                        AND NVL(I_GROUP_PROJECTS_LEVEL, 2) = 1
        LEFT JOIN MV_REL_PRJ_EMP VRPE ON VRPE.LOGIN=DLR.LOGIN
                                            AND VRPE.FID_PLATFORM=DLR.FID_PLATFORM
                                            AND VRPE.PROJECT_ID=DLR.FID_PROJECT
                                            AND (DLR.REPORT_DATE BETWEEN VRPE.ACTIVE_FROM AND VRPE.ACTIVE_TILL
                                             OR DLR.REPORT_DATE = TRUNC(VRPE.ACTIVE_FROM))
        WHERE DLR.REPORT_DATE BETWEEN TRUNC(I_DATE_START) AND I_DATE_END - INTERVAL '1' SECOND
          AND ( EXISTS(
                      SELECT 1
                      FROM SQ_PROJECTS FSQP
                      WHERE FSQP.PROJECT_ID = DLR.FID_PROJECT
                        AND NVL(FSQP.PLATFORM_ID, DLR.FID_PLATFORM) = DLR.FID_PLATFORM
                    )
                OR I_PROJECT IS NULL
              )
          AND EXISTS(
                      SELECT 1
                      FROM SQ_LOGINS FSQL
                      WHERE DLR.LOGIN = FSQL.LOGIN
                        AND DLR.FID_PLATFORM = NVL(FSQL.FID_PLATFORM, DLR.FID_PLATFORM)
                    )
      ),
      SQ_PROJECT_RATES AS
      (
        SELECT /*+ MATERIALIZE*/
          ACTIVE_FROM, ACTIVE_TILL-INTERVAL '1' SECOND AS ACTIVE_TILL,
          FID_PROJECT, LOGIN, FID_PLATFORM, SUM(P_RATE) AS RATE
        FROM SQ_GET_PROJECT_RATES
        GROUP BY ACTIVE_FROM, ACTIVE_TILL, FID_PROJECT, LOGIN, FID_PLATFORM
      ),
      SQ_RESULT AS
      (
        SELECT GREATEST(VES.ENTERED, SQR.START_RANGE) AS ENTERED, VES.LOGIN,
          CASE
            WHEN VES.FID_PROJECT = 'project_not_determined'
            THEN SQPR.FID_PROJECT
            ELSE DECODE(NVL(I_GROUP_PROJECTS_LEVEL, 2), 0, '{all}', 1, NVL(TO_CHAR(RGP.FID_GROUP), '0'), VES.FID_PROJECT)
          END AS PROJECT_ID,
          SQLN.LAST_NAME, SQLN.FIRST_NAME, SQLN.MIDDLE_NAME, VES.FID_NAU_STATUS AS FID_STATUS,
          DS.NAME AS STATUS, VES.REASON, DS.CAPTION,
          CASE
            WHEN VES.FID_PROJECT = 'project_not_determined'
            THEN SQPR.RATE
            ELSE 1
          END AS PROJECT_RATE,
          PKG_INTERVALS.FNC_INTERVALTOSEC(GREATEST(VES.ENTERED, SQR.START_RANGE),
                                          LEAST(SQR.STOP_RANGE, CAST(VES.ENTERED+VES.DURATION/86400 AS TIMESTAMP))) AS DURATION,
          VES.DURATION as FULL_DURATION, VES.FID_PLATFORM, SQLN.CALL_CENTRE_NAME, SQLN.LOCATION_NAME, SQR.RANGE_LENGTH
        FROM VW_EMPLOYEES_STATUSES VES
        JOIN D_STATUSES DS ON DS.ID_STATUS = VES.FID_NAU_STATUS
        LEFT JOIN REL_GROUP_PROJECTS RGP ON RGP.FID_PROJECT = VES.FID_PROJECT
                                        AND NVL(I_GROUP_PROJECTS_LEVEL, 2) = 1
                                        and VES.FID_PROJECT != 'project_not_determined'
        LEFT JOIN SQ_RANGES SQR ON VES.ENTERED BETWEEN SQR.START_RANGE AND SQR.STOP_RANGE
                                OR SQR.START_RANGE BETWEEN VES.ENTERED AND CAST(VES.ENTERED+VES.DURATION/86400 AS TIMESTAMP)
        LEFT JOIN SQ_LOGINS SQLN ON VES.LOGIN = SQLN.LOGIN
                                AND VES.FID_PLATFORM = NVL(SQLN.FID_PLATFORM, VES.FID_PLATFORM)
        LEFT JOIN SQ_PROJECT_RATES SQPR ON VES.LOGIN=SQPR.LOGIN
                                        AND VES.FID_PLATFORM=SQPR.FID_PLATFORM
                                        AND VES.FID_PROJECT = 'project_not_determined'
                                        AND GREATEST(VES.ENTERED, SQR.START_RANGE) BETWEEN SQPR.ACTIVE_FROM AND SQPR.ACTIVE_TILL
        WHERE VES.ENTERED BETWEEN I_DATE_START-1 AND I_DATE_END
          AND CAST(VES.ENTERED+VES.DURATION/86400 AS TIMESTAMP) > I_DATE_START
          AND EXISTS(
                      SELECT 1
                      FROM SQ_LOGINS FSQL
                      WHERE VES.LOGIN = FSQL.LOGIN
                        AND VES.FID_PLATFORM = NVL(FSQL.FID_PLATFORM, VES.FID_PLATFORM)
                    )
              AND ( EXISTS(
                          SELECT 1
                          FROM SQ_PROJECTS FSQP
                          WHERE VES.FID_PROJECT = FSQP.PROJECT_ID
                            AND VES.FID_PLATFORM = NVL(FSQP.PLATFORM_ID, VES.FID_PLATFORM)
                          UNION ALL
                          SELECT 1
                          FROM DUAL
                          WHERE VES.FID_PROJECT = 'project_not_determined'
                            AND SQPR.LOGIN IS NOT NULL
                        )
                   OR I_PROJECT IS NULL
                   )
              AND EXISTS(
                          SELECT 1
                          FROM SQ_FILTER_STATUSES FS
                          WHERE FS.ID_STATUS = VES.FID_NAU_STATUS
                          UNION ALL
                          SELECT 1
                          FROM DUAL
                          WHERE V_STATUSES IS NULL
                        )
      )
    SELECT ENTERED, LOGIN, PROJECT_ID, FID_STATUS, STATUS, REASON, CAPTION as STATUS_CAPTION,
      PROJECT_RATE, DURATION, FULL_DURATION, FID_PLATFORM, CALL_CENTRE_NAME AS CC_CAPTION,
      LOCATION_NAME AS LOCATION_CAPTION, NULL AS FIRST_STATUS_ENTERED, NULL AS LAST_STATUS_ENDED
    FROM SQ_RESULT
    WHERE ENTERED IS NOT NULL
      AND CASE
            WHEN UPPER(NVL(I_COMPRESS, 'Y')) = 'Y'
              AND STATUS = 'offline'
            THEN DURATION
            ELSE 0
          END < RANGE_LENGTH;

  BEGIN
    IF NVL(I_GROUP_PROJECTS_LEVEL, 2) NOT BETWEEN 0 AND 2 THEN
      RAISE_APPLICATION_ERROR(-20000, 'I_GROUP_PROJECTS_LEVEL может иметь значение от 0 до 2.');
    END IF;
    IF NVL(I_GROUP_LOCATION, 2) NOT BETWEEN 0 AND 2 THEN
      RAISE_APPLICATION_ERROR(-20001, 'I_GROUP_PROJECTS_LEVEL может иметь значение от 0 до 2.');
    END IF;

    IF I_STATUSES IS NOT NULL THEN
      V_STATUSES := T_LIST_VARCHAR();
      SELECT COLUMN_VALUE BULK COLLECT INTO V_STATUSES
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_STATUSES));
    END IF;

    IF V_LOGINS IS NULL THEN
      SELECT LOGIN INTO V_LOGINS
      FROM TABLE(PKG_API.GET_EMPLOYEES_LIST('O', 'N', I_DATE_START, I_DATE_END,
                                            I_PROJECT, I_LOCATION, I_ROLETYPE,
                                            I_PLATFORMS, I_NEW_STYLE=>'Y'));
    END IF;

    IF SUBSTR(I_PROJECT, 1, 1) = '{' AND SUBSTR(I_PROJECT, -1) = '}' THEN
      V_LOGINS := REPLACE(V_LOGINS, '"projects": ""', '"projects": '||I_PROJECT);
    ELSE
      V_LOGINS := REPLACE(V_LOGINS, '"projects": ""', '"projects": "'||I_PROJECT||'"');
    END IF;

    FOR R IN GET_DATA LOOP
      PIPE ROW(R);
    END LOOP;
  END GET_STATUSES;

  --Выборка списка сессий
  FUNCTION GET_CALL_SESSIONS (I_DATE_START TIMESTAMP, --Дата начала отбора
                              I_DATE_END TIMESTAMP, --Дата окончания отбора
                              I_PROJECTS T_LIST_VARCHAR DEFAULT NULL,
                              I_DIRECTION T_LIST_VARCHAR DEFAULT NULL,
                              I_PLATFORM T_LIST_INTEGER DEFAULT NULL,
                              I_ABONENT T_LIST_VARCHAR DEFAULT NULL,
                              I_SELECT_ABONENTS NUMBER DEFAULT 1)
    RETURN PT_CALL_SESSIONS PIPELINED
  IS

    CURSOR GET_DATA RETURN CALL_SESSIONS%ROWTYPE
    IS
    WITH SQ_SESSIONS AS
      (
        SELECT *
        FROM CALL_SESSIONS CS
        WHERE CS.CREATED BETWEEN I_DATE_START AND I_DATE_END
          AND (
                CS.DIRECTION IN (
                                  SELECT COLUMN_VALUE
                                  FROM TABLE(I_DIRECTION)
                                )
                OR I_DIRECTION IS NULL
              )
          AND (
                CS.FID_PLATFORM IN(
                                    SELECT COLUMN_VALUE
                                    FROM TABLE(I_PLATFORM)
                                  )
                OR I_PLATFORM IS NULL
              )
      )
    SELECT *
    FROM SQ_SESSIONS SQS
    WHERE NVL(I_PROJECTS, I_ABONENT) IS NULL
      OR EXISTS (
                  SELECT 1
                  FROM CALLS_INFO CI
                  WHERE SQS.FID_PLATFORM=CI.FID_PLATFORM
                    AND SQS.SESSION_ID=CI.SESSION_ID
                    AND EXISTS(
                                SELECT 1
                                FROM DUAL
                                WHERE I_PROJECTS IS NULL
                                UNION ALL
                                SELECT 1
                                FROM TABLE(I_PROJECTS)FP
                                WHERE FP.COLUMN_VALUE=CI.FID_PROJECT
                              )
                    AND EXISTS(
                                SELECT 1
                                FROM DUAL
                                WHERE I_ABONENT IS NULL
                                UNION ALL
                                SELECT 1
                                FROM TABLE(I_ABONENT)FP
                                WHERE NVL(I_SELECT_ABONENTS, 1) = 1
                                  AND (
                                        CI.CALLER LIKE FP.COLUMN_VALUE
                                        OR  CI.CALLED LIKE FP.COLUMN_VALUE
                                      )
                                UNION ALL
                                SELECT 1
                                FROM TABLE(I_ABONENT)FP
                                WHERE NVL(I_SELECT_ABONENTS, 1) = 0
                                  AND (
                                        CI.CALLER NOT LIKE FP.COLUMN_VALUE
                                        OR  CI.CALLED NOT LIKE FP.COLUMN_VALUE
                                      )
                              )
                );

  BEGIN --GET_CALL_SESSIONS
    FOR I IN GET_DATA LOOP
      PIPE ROW(I);
    END LOOP;
  END GET_CALL_SESSIONS;
  --Переопределенный метод получения списка ЗФ
  FUNCTION GET_CALL_SESSIONS (I_DATE_START TIMESTAMP, --Дата начала отбора
                              I_DATE_END TIMESTAMP, --Дата окончания отбора
                              I_PROJECTS VARCHAR2 DEFAULT NULL,
                              I_DIRECTION VARCHAR2 DEFAULT NULL,
                              I_PLATFORM VARCHAR2 DEFAULT NULL,
                              I_ABONENT VARCHAR2 DEFAULT NULL,
                              I_SELECT_ABONENTS NUMBER DEFAULT 1)
    RETURN PT_CALL_SESSIONS PIPELINED
  IS
    V_PROJECT T_LIST_VARCHAR DEFAULT NULL;
    V_DIRECTION T_LIST_VARCHAR DEFAULT NULL;
    V_PLATFORM T_LIST_INTEGER DEFAULT NULL;
    V_ABONENT T_LIST_VARCHAR DEFAULT NULL;
  BEGIN --GET_CALL_SESSIONS
    IF I_PROJECTS IS NOT NULL THEN
      V_PROJECT := T_LIST_VARCHAR();
      SELECT PROJECT_ID BULK COLLECT INTO V_PROJECT
      FROM TABLE(GET_PROJECTS_IDS(I_PROJECTS));
    END IF;

    IF I_DIRECTION IS NOT NULL THEN
      V_DIRECTION := T_LIST_VARCHAR();
      SELECT TRIM(COLUMN_VALUE) BULK COLLECT INTO V_DIRECTION
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_DIRECTION));
    END IF;

    IF I_PLATFORM IS NOT NULL THEN
      V_PLATFORM := T_LIST_INTEGER();
      SELECT PKG_STRINGS.FNC_TONUMBER(TRIM(COLUMN_VALUE)) BULK COLLECT INTO V_PLATFORM
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_PLATFORM))
      WHERE PKG_STRINGS.FNC_TONUMBER(TRIM(COLUMN_VALUE)) IS NOT NULL;
    END IF;

    IF I_ABONENT IS NOT NULL THEN
      V_ABONENT := T_LIST_VARCHAR();
      SELECT TRIM(COLUMN_VALUE) BULK COLLECT INTO V_ABONENT
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_ABONENT));
    END IF;

    FOR I IN(
              SELECT *
              FROM TABLE(GET_CALL_SESSIONS(I_DATE_START, I_DATE_END, V_PROJECT, V_DIRECTION, V_PLATFORM, V_ABONENT, I_SELECT_ABONENTS))
            ) LOOP
      PIPE ROW(I);
    END LOOP;
  END GET_CALL_SESSIONS;

  --Выборка списка соединений в сессиях
  FUNCTION GET_CALL_LINKS(I_DATE_START TIMESTAMP, --Дата начала отбора
                          I_DATE_END TIMESTAMP, --Дата окончания отбора
                          I_PROJECTS T_LIST_VARCHAR DEFAULT NULL,
                          I_DIRECTION T_LIST_VARCHAR DEFAULT NULL,
                          I_PLATFORM T_LIST_INTEGER DEFAULT NULL,
                          I_ABONENT T_LIST_VARCHAR DEFAULT NULL,
                          I_SELECT_ABONENTS NUMBER DEFAULT 1,
                          I_QUALITY_CONTROL NUMBER DEFAULT NULL) -- =2 - дополнительно подавляет записи с прослушкой
    RETURN PT_CALL_LINKS PIPELINED
  IS
    CURSOR GET_DATA RETURN PTR_CALL_LINKS
    IS
    SELECT CS.SESSION_ID, CS.FID_PLATFORM, CS.CREATED, CS.ENDED, CS.DIRECTION,
      CI.FID_PROVIDER, DP.NAME AS PROVIDER_CAPTION, CI.FID_AREA, DR.AREA_CAPTION,
      CS.EXIT_CODE, CS.EXIT_CODE_DISCRIPTION, CS.IS_WORK_TIME, CI.LINK_ID,
      CI.FID_PROJECT, CI.FINAL_STAGE, CI.ABONENT, CI.CALLER, CI.CALLED,
      CI.IVR_NUMBER, CI.IVR_CREATED, CI.IVR_CONNECTED, CI.IVR_ENDED, CI.ENQUEUED_TIME,
      CI.UNBLOCKED_TIME, CI.DEQUEUED_TIME, CI.OPERATOR, CI.OPERATOR_CREATED,
      CI.OPERATOR_CONNECTED, CI.OPERATOR_ENDED, CI.OPERATOR_HOLD, CI.OPERATOR_WRAPUP,
      CI.SPEAK_SEGMENTS, CI.IS_QUALITY_CONTROL, CI.BRAKE_CALL, CI.COST
    FROM TABLE(GET_CALL_SESSIONS(I_DATE_START, I_DATE_END, I_PROJECTS, I_DIRECTION, I_PLATFORM, I_ABONENT, I_SELECT_ABONENTS)) CS
    JOIN CALLS_INFO CI ON COALESCE(CI.OPERATOR_CREATED, CI.IVR_CREATED, I_DATE_START) BETWEEN I_DATE_START AND I_DATE_END+INTERVAL '1' HOUR
                            AND CS.SESSION_ID=CI.SESSION_ID
                            AND CS.FID_PLATFORM=CI.FID_PLATFORM
                            AND CI.IS_QUALITY_CONTROL=NVL(MOD(I_QUALITY_CONTROL,2),CI.IS_QUALITY_CONTROL)
                            AND INSTR(CI.FINAL_STAGE, 'intrusion') = DECODE(I_QUALITY_CONTROL, 2, 0, INSTR(CI.FINAL_STAGE, 'intrusion'))
                            AND INSTR(CI.CALLED, 'intrusion') = DECODE(I_QUALITY_CONTROL, 2, 0, INSTR(CI.CALLED, 'intrusion'))
                            AND EXISTS(
                                        SELECT /*+ INDEX(CI IDX_CI_FID_PROJECT)*/1
                                        FROM TABLE(I_PROJECTS)
                                        WHERE I_PROJECTS IS NOT NULL
                                          AND CI.FID_PROJECT=COLUMN_VALUE
                                        UNION ALL
                                        SELECT 1
                                        FROM DUAL
                                        WHERE I_PROJECTS IS NULL
                                      )
                            AND EXISTS(
                                        SELECT 1
                                        FROM TABLE(I_ABONENT)
                                        WHERE I_ABONENT IS NOT NULL AND
                                          (
                                            NVL(I_SELECT_ABONENTS, 1) = 1
                                            AND (
                                                  CI.ABONENT LIKE COLUMN_VALUE
                                                  OR CI.OPERATOR LIKE COLUMN_VALUE
                                                )
                                          )OR
                                          (
                                            NVL(I_SELECT_ABONENTS, 1) != 1
                                            AND CI.ABONENT NOT LIKE COLUMN_VALUE
                                            AND CI.OPERATOR NOT LIKE COLUMN_VALUE
                                          )
                                        UNION ALL
                                        SELECT 1
                                        FROM DUAL
                                        WHERE I_ABONENT IS NULL
                                      )
    LEFT JOIN D_PROVIDERS DP ON DP.ID_PROVIDER = CI.FID_PROVIDER
    LEFT JOIN D_RATES DR ON DR.ID_RATE = CI.FID_AREA;

  BEGIN --GET_CALL_LINKS
    FOR I IN GET_DATA LOOP
      PIPE ROW(I);
    END LOOP;
  END GET_CALL_LINKS;

  --Выборка списка соединений в сессиях
  FUNCTION GET_CALL_LINKS(I_DATE_START TIMESTAMP, --Дата начала отбора
                          I_DATE_END TIMESTAMP, --Дата окончания отбора
                          I_PROJECTS VARCHAR2 DEFAULT NULL,
                          I_DIRECTION VARCHAR2 DEFAULT NULL,
                          I_PLATFORM VARCHAR2 DEFAULT NULL,
                          I_ABONENT VARCHAR2 DEFAULT NULL,
                          I_SELECT_ABONENTS NUMBER DEFAULT 1,
                          I_QUALITY_CONTROL NUMBER DEFAULT NULL)
    RETURN PT_CALL_LINKS PIPELINED
  IS

    V_PROJECT T_LIST_VARCHAR DEFAULT NULL;
    V_DIRECTION T_LIST_VARCHAR DEFAULT NULL;
    V_PLATFORM T_LIST_INTEGER DEFAULT NULL;
    V_ABONENT T_LIST_VARCHAR DEFAULT NULL;
  BEGIN --GET_CALL_LINKS
    IF I_PROJECTS IS NOT NULL THEN
      V_PROJECT := T_LIST_VARCHAR();
      SELECT PROJECT_ID BULK COLLECT INTO V_PROJECT
      FROM TABLE(GET_PROJECTS_IDS(I_PROJECTS));
    END IF;

    IF I_DIRECTION IS NOT NULL THEN
      V_DIRECTION := T_LIST_VARCHAR();
      SELECT TRIM(COLUMN_VALUE) BULK COLLECT INTO V_DIRECTION
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_DIRECTION));
    END IF;

    IF I_PLATFORM IS NOT NULL THEN
      V_PLATFORM := T_LIST_INTEGER();
      SELECT PKG_STRINGS.FNC_TONUMBER(TRIM(COLUMN_VALUE)) BULK COLLECT INTO V_PLATFORM
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_PLATFORM))
      WHERE PKG_STRINGS.FNC_TONUMBER(TRIM(COLUMN_VALUE)) IS NOT NULL;
    END IF;

    IF I_ABONENT IS NOT NULL THEN
      V_ABONENT := T_LIST_VARCHAR();
      SELECT TRIM(COLUMN_VALUE) BULK COLLECT INTO V_ABONENT
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_ABONENT));
    END IF;

    FOR I IN(
              SELECT *
              FROM TABLE(GET_CALL_LINKS(I_DATE_START, I_DATE_END, V_PROJECT, V_DIRECTION, V_PLATFORM, V_ABONENT, I_SELECT_ABONENTS, I_QUALITY_CONTROL))
            ) LOOP
      PIPE ROW(I);
    END LOOP;
  END GET_CALL_LINKS;

END PKG_API;
/

