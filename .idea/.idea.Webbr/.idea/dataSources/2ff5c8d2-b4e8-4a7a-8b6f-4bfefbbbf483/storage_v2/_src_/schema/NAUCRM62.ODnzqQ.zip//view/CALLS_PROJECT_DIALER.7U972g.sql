create view CALLS_PROJECT_DIALER as
SELECT
    v.session_id AS sessionid,
    v.case_uuid AS parentuid,
    CASE
        WHEN oper.connected IS NULL
        THEN NULL
        ELSE oper.dst_abonent
    END AS operatorlogin,
    initiator.src_id AS phonenumber,
    initiator.dst_id AS receiverphonenumber,
    initiator.created AS incomingtime,
    oper.connected AS connectiontime,
    oper.ended AS disconnectiontime,
    intervaltosec(NVL(oper.connected, initiator.ended) - oper.created) AS waittime,
    CASE
        WHEN oper.connected IS NULL
        THEN oper.dst_abonent
        ELSE redirection.dst_abonent
    END AS redirectionlogin,
    CASE
        WHEN oper.connected IS NULL
        THEN oper.dst_id
        ELSE redirection.dst_id
    END AS redirectionnumber,
    speak_time.speaktime AS speaktime,
    0 AS ivrmessagetime,
    0 AS queuetime,
    CASE
        WHEN oper.connected IS NULL
        THEN NULL
        ELSE intervaltosec(oper.ended - oper.connected)
    END AS operatortime,
    CASE
        WHEN oper.connected IS NULL
        THEN intervaltosec(oper.ended - oper.created)
        ELSE intervaltosec(redirection.ended - redirection.connected)
    END AS redirecttime,
    1 AS isindirection,
    CASE
        WHEN oper.connected IS NULL
        THEN 4
        WHEN (oper.connected IS NOT NULL
        AND redirection.connected IS NULL)
        THEN 3
        ELSE 4
    END AS finalstage
FROM
    (
        SELECT
            cp.session_id AS session_id,
            param_value AS case_uuid,
            changed
        FROM
            call_params cp
            INNER JOIN sessions_for_update calls ON (cp.session_id = calls.session_id)
        WHERE
            cp.param_name = 'npcp-dialer-client-ext-id' AND
            cp.session_id NOT IN (
                SELECT
                    session_id
                FROM
                    call_params temp
                WHERE
                    temp.session_id = cp.session_id AND
                    param_name = 'ProjectId'
            )
    ) v
    INNER JOIN call_legs initiator ON (
        v.session_id = initiator.session_id AND
        initiator.connected IS NOT NULL AND
        initiator.incoming = '1' AND
        (
            initiator.src_abonent_type = 'IVR' OR
            initiator.src_abonent IS NULL
        )
    )
    LEFT JOIN sessions_speak_time_temp speak_time ON (speak_time.session_id = v.session_id)
    INNER JOIN call_legs oper ON (
        v.session_id = oper.session_id AND
        oper.dst_abonent_type = 'SP'
    )
    LEFT JOIN call_legs redirection ON (
        redirection.intrusion = '0' AND
        redirection.session_id = oper.session_id AND
        redirection.incoming = '0' AND
        redirection.connected > oper.connected AND
        redirection.ended > oper.ended AND
        redirection.connected IS NOT NULL
    )
/

