create view VW_CUR_STATUSES as
SELECT NCS.ENTERED, NCS.LOGIN, NCS.REASON, NCS.STATUS, 2 AS FID_PLATFORM
FROM NAUCRM62.CUR_STATUSES NCS
/

comment on table VW_CUR_STATUSES is 'Представление по текущим статусам сотрудников'
/

