create type           SYS_PLSQL_1808349_9_1 as table of VARCHAR2(4000 BYTE);
/

