create trigger TRG_EMPLOYEES_ID
    before insert
    on EMPLOYEES
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_EMPLOYEE" IS NULL THEN
                                 SELECT SEQ_EMPLOYEES_ID.NEXTVAL INTO :NEW."ID_EMPLOYEE" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

