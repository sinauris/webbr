create type           SYS_PLSQL_1808372_1453_1 as table of "NC_CORE"."SYS_PLSQL_1808372_1438_1";
/

