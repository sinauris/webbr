create type           SYS_PLSQL_1808372_1718_1 as table of "NC_CORE"."SYS_PLSQL_1808372_1484_1";
/

