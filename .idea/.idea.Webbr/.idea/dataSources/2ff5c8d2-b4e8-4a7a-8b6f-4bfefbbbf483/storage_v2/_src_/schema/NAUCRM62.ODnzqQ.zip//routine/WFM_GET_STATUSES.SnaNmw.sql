create FUNCTION WFM_get_STATUSES (strt in timestamp, fnsh in timestamp)
RETURN wfm_type_status_table
AS
ahtt wfm_type_status_table;
today timestamp;
BEGIN
today:=to_timestamp(to_char(current_date));
if fnsh - INTERVAL '24' HOUR <= strt
then
if fnsh<=today
then
SELECT wfm_type_status
        (
                aa.oper_login
            ,   aa.time_from
            ,   aa.state
            ,   aa.substate
        )
BULK COLLECT INTO ahtt
FROM
(select * from wfm_statuses_table where time_from between strt and fnsh) aa;
return ahtt;

else
SELECT wfm_type_status
        (
                aa.oper_login
            ,   aa.time_from
            ,   aa.state
            ,   aa.substate
        )
BULK COLLECT INTO ahtt
FROM
(select * from table (wfm_statuses(strt,fnsh))) aa;
return ahtt;
end if;
else 
if fnsh<=today
then
SELECT wfm_type_status
        (
                aa.oper_login
            ,   aa.time_from
            ,   aa.state
            ,   aa.substate
        )
BULK COLLECT INTO ahtt
FROM
(select * from wfm_statuses_table where time_from between strt and fnsh) aa;
return ahtt;
else
SELECT wfm_type_status
        (
                aa.oper_login
            ,   aa.time_from
            ,   aa.state
            ,   aa.substate
        )
BULK COLLECT INTO ahtt
FROM
( select * from wfm_statuses_table where time_from between strt and today
union all
select * from table (wfm_statuses(today, fnsh))) aa;
return ahtt;
end if;
END if;
end;
/

