create view VW_GL_CALL_INFO as
Select
    t_call.sessionid,
    NULL as uuid,
    NULL as creationdate,
    NULL as parentuuid,
    NULL as wrapuptime,
    NULL as redirectcontacttitle,
    NULL as redirectcontactuuid,
    NULL as operatortitle,
    NULL as operatoruuid,
    NULL as relationtypetitle,
    NULL as relationtypeuuid,
    NULL as transfertitle,
    NULL as formuuid,
    t_call.parentuid,
    t_call.phonenumber,
    t_call.receiverphonenumber,
    t_call.incomingtime,
    t_call.connectiontime,
    t_call.disconnectiontime,
    t_call.waittime,
    t_call.redirectionlogin,
    t_call.redirectionnumber,
    t_call.speaktime,
    t_call.ivrmessagetime,
    t_call.queuetime,
    t_call.operatortime,
    t_call.redirecttime,
    t_call.isindirection,
    t_call.finalstage as nfinalstage,
    finalstage_alias(t_call.finalstage) as finalstage,
    t_call.operatorlogin
From
    Calls t_call
/

