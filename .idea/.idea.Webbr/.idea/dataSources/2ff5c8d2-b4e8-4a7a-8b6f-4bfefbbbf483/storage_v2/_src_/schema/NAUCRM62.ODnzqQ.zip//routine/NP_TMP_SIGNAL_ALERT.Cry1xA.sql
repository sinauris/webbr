create PROCEDURE NP_TMP_SIGNAL_ALERT AS
BEGIN
    DBMS_ALERT.SIGNAL('np_tmp_trigger_alert', '');
END;

/

