create procedure update_call_info AS
Begin
  dbms_output.put_line('update table sessions_speak_time_temp');
  update_sessions_speak_time();

  dbms_output.put_line('insert into tbl_gl_call_info');
  Insert Into tbl_gl_call_info
  Select
    src.sessionid,
    src.uuid,
    src.creationdate,
    src.parentid,
    src.redirectcontacttitle,
    src.redirectcontactuuid,
    src.employeetitle,
    src.employeeuuid,
    src.relationtypetitle,
    src.relationtypeuuid,
    src.parentuid,
    src.phonenumber,
    src.receiverphonenumber,
    src.incomingtime,
    src.connectiontime,
    src.disconnectiontime,
    src.waittime,
    src.redirectionlogin,
    src.redirectionnumber,
    src.speaktime,
    src.ivrmessagetime,
    src.queuetime,
    src.operatortime,
    src.redirecttime,
    src.isindirection,
    src.nfinalstage,
    src.finalstage,
    src.operatorlogin,
    src.transfertitle,
    src.formuuid,
    src.wrapuptime
  From
    sessions_for_update tmp inner join
    vw_gl_call_info src on src.sessionid = tmp.session_id
  Where
    src.incomingtime >= (select min(sub.created) from sessions_for_update sub) ;

  dbms_output.put_line('delete all from sessions_for_update');
  Delete From sessions_for_update;

  dbms_output.put_line('complete');

End;
/

