create view CALLS_PROJECT_ABONENTS_ALL as
Select
    sessions.session_id as session_id,
    project_id.project_id as project_id,
        project_id.changed as project_id_changed,
    abonents.dst_abonent as abonent,
    abonents.dst_id as id,
    abonents.created as created,
    abonents.connected as connected,
    abonents.ended as ended,
    abonents.leg_id as leg_id
From
    sessions_for_update sessions inner join
    calls_project_id_last project_id on
    (
        sessions.session_id = project_id.session_id
    ) left join
    call_legs abonents on
    (
        project_id.session_id = abonents.session_id and
        abonents.dst_abonent_type != 'SS' and
        abonents.dst_abonent_type != 'IVR' and
        abonents.created >= project_id.changed and
        abonents.connected is not null and
        abonents.intrusion = '0'
    )
/

