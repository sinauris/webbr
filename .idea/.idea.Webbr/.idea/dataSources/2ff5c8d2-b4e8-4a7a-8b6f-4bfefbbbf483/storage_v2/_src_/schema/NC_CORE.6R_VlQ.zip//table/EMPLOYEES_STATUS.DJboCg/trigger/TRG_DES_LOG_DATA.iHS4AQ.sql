create trigger TRG_DES_LOG_DATA
    instead of insert or update or delete
    on EMPLOYEES_STATUS
    for each row
    COMPOUND TRIGGER

  V_INT PLS_INTEGER := 0;

  AFTER EACH ROW IS
  BEGIN
    V_INT := V_INT+1;
  END AFTER EACH ROW;

  AFTER STATEMENT IS
    V_ACTION VARCHAR2(6);
    V_DISC CLOB;
  BEGIN
    V_DISC := '<VAL>';
    IF INSERTING THEN
      V_ACTION := 'INSERT';
      V_DISC := V_DISC||'Добавлен';
    ELSIF UPDATING THEN
      V_ACTION := 'UPDATE';
      V_DISC := V_DISC||'Обновлен';
    ELSE
      V_ACTION := 'DELETE';
      V_DISC := V_DISC||'Удален';
    END IF;

    IF TO_NUMBER(SUBSTR(TO_CHAR(V_INT), -1)) = 1 THEN
      V_DISC := V_DISC||'а '||TO_CHAR(V_INT)||' запись.</VAL>';
    ELSIF TO_NUMBER(SUBSTR(TO_CHAR(V_INT), -1)) < 5 THEN
      V_DISC := V_DISC||'о '||TO_CHAR(V_INT)||' записи.</VAL>';
    ELSE
      V_DISC := V_DISC||'о '||TO_CHAR(V_INT)||' записей.</VAL>';
    END IF;

    INSERT INTO LOG_ACTIONS(TABLE_NAME, ACT_USER, OPERATION, DISCRIPTION, "RESULT")
    VALUES ('EMPLOYEES_STATUS', USER, V_ACTION, XMLTYPE.CREATEXML(V_DISC), 'OK');

  END AFTER STATEMENT;

END;
/

