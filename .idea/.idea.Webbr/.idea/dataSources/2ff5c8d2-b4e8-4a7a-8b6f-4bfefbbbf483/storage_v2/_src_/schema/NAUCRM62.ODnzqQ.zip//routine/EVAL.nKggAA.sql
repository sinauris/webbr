create function eval(expr varchar2) return varchar2 as res varchar2(4000); begin    execute immediate 'begin :result := ' || expr || '; end;' using out res;    return res; end;
/

