create trigger TRG_EMPLOYEES_WORK_HISTORY_ID
    before insert
    on EMPLOYEES_WORK_HISTORY
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_WORK_HISTORY" IS NULL THEN
                                 SELECT SEQ_EMPLOYEES_WORK_HISTORY_ID.NEXTVAL INTO :NEW."ID_WORK_HISTORY" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

