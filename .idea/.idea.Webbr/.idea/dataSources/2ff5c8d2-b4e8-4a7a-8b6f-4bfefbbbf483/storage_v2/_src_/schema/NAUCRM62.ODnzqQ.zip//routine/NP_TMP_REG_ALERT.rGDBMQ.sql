create PROCEDURE NP_TMP_REG_ALERT AS
BEGIN
    DBMS_ALERT.REGISTER('np_tmp_trigger_alert');
END;

/

