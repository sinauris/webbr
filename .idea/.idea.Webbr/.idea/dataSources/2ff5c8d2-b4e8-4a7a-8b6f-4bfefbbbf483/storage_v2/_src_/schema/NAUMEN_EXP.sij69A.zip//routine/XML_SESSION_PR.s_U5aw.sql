create Function XML_SESSION_PR(PR In VarChar2, DH In TimeStamp, DE In TimeStamp) Return SESSION_NDD_T As
N           Number;
xNDD     SESSION_NDD;
xNDD_T SESSION_NDD_T := SESSION_NDD_T();
Begin
If (Add_Months(DH, 12) < DE) Or (DH > DE) Then
   Return xNDD_T;
   End If;

N := -1;

For SESSION_ID_T In (
With
P1 As (Select SRC_ID, DST_ID, SESSION_ID From NAUCRM.CALL_LEGS Where CREATED Between DH And DE),
P2 As (Select SRC_ID AB, SESSION_ID From P1 Union All Select DST_ID AB, SESSION_ID From P1),
P3 As (Select Distinct AB, SESSION_ID From P2)

Select Distinct a.SESSION_ID From P3 a, NAUCRM.ABONENTS b, NAUCRM.PROJECT_AGENTS c Where a.AB = b.LOGIN And b.ID = c.ABONENT_ID And c.PROJECT_ID = PR
) loop

N := N + 1;

xNDD := SESSION_NDD(N, SESSION_ID_T.SESSION_ID);
xNDD_T.Extend(1);
xNDD_T(xNDD_T.Last) := xNDD;
end loop;

Return xNDD_T;

End XML_SESSION_PR;
/

