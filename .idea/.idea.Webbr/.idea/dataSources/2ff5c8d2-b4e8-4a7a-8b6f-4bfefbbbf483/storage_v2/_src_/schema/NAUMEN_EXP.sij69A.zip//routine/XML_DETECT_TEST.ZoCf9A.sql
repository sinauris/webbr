create Function XML_DETECT_TEST(P_SESSION_ID In VarChar2) Return VarChar2 As L_RETURN VARCHAR2(32767);
Begin
With
P1 As (Select P_SESSION_ID SESSION_ID From DUAL),
P2_62 As (Select Distinct SRC_ID AB From NAUCRM62_TEST.CALL_LEGS@ORADEV_N62_T a, P1 b Where a.SESSION_ID = b.SESSION_ID Union Select Distinct DST_ID AB From NAUCRM62_TEST.CALL_LEGS@ORADEV_N62_T a, P1 b Where a.SESSION_ID = b.SESSION_ID),
P3_ID As (Select 'project340' ID_PROJ From DUAL Union All Select 'project257' ID_PROJ From DUAL),
P3_NUM_62 As (Select Distinct b.TEL From P3_ID a, NAUMEN_EXP.PROJ_NUMBER b Where a.ID_PROJ = b.PROJECT_ID),
P3_62 As (Select a.AB, c.SESSION_ID From P2_62 a, P3_NUM_62 b, P1 c Where a.AB = b.TEL),
P4 As (Select a.SESSION_ID, Decode(c.AB, Null, 0, 1) NUMS From P1 a, P3_62 c Where a.SESSION_ID = c.SESSION_ID (+)),
P5 As (Select Sum(NUMS) NUMS From P4)
Select To_Char(Sign(NUMS)) NUMS  Into L_RETURN From P5;
RETURN L_RETURN;
End XML_DETECT_TEST;
/

