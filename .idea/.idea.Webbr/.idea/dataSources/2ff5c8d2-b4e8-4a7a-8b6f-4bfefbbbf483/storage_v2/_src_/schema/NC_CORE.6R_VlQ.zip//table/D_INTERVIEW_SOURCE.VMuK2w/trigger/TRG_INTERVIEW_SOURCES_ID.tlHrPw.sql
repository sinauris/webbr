create trigger TRG_INTERVIEW_SOURCES_ID
    before insert
    on D_INTERVIEW_SOURCE
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_SOURCE" IS NULL THEN
                                 SELECT SEQ_INTERVIEW_SOURCES_ID.NEXTVAL INTO :NEW."ID_SOURCE" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

