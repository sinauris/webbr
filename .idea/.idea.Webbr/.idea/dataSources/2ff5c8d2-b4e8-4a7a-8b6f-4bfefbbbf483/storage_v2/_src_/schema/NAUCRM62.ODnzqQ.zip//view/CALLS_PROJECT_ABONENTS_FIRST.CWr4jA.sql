create view CALLS_PROJECT_ABONENTS_FIRST as
Select
    session_id,
    project_id,
    project_id_changed,
    abonent,
    created,
    connected,
    ended,
    leg_id,
    id
From
    calls_project_abonents_all abonets_all
Where
    connected is null or
    connected =
    (
        Select
            Min( connected )
        From
            calls_project_abonents_all
        Where
            abonets_all.session_id = session_id and abonets_all.project_id = project_id
    )
/

