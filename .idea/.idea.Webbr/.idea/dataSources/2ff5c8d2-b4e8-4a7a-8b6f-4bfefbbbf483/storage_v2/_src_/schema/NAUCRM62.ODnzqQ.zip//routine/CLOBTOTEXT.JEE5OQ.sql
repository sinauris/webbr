create FUNCTION ClobToText(text IN CLOB) RETURN VARCHAR2 IS
BEGIN
  RETURN to_char(text);
END;
/

