create type           SYS_PLSQL_1808343_178_1 as table of "NC_CORE"."SYS_PLSQL_1808343_154_1";
/

