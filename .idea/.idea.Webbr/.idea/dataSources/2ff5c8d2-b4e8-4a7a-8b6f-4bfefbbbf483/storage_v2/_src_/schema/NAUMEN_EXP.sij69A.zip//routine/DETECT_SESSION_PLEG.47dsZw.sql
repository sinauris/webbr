create Function DETECT_SESSION_PLEG(P_SESSION_ID In VarChar2, P_LEG_ID In NUMBER) Return VarChar2 As L_RETURN VARCHAR2(32767);
Begin
With
SS  As (Select P_SESSION_ID SESSION_ID, P_LEG_ID LEG_ID From DUAL),
SS1 As (
Select
Case
When a.SRC_ABONENT_TYPE =    'SS'    And a.DST_ABONENT_TYPE Like '%IVR%' Then 'True'
When a.SRC_ABONENT_TYPE Like '%IVR%' And a.DST_ABONENT_TYPE =    'SS'    Then 'True'
Else 'False'
End LEG_REZ,
a.SESSION_ID
From NAUCRM.CALL_LEGS a, SS b Where a.SESSION_ID = b.SESSION_ID And a.LEG_ID = b.LEG_ID
)

Select Decode(b.LEG_REZ, Null, 'False', b.LEG_REZ) LEG_REZ Into L_RETURN From SS a, SS1 b Where a.SESSION_ID = b.SESSION_ID (+);
RETURN L_RETURN;
End DETECT_SESSION_PLEG;
/

