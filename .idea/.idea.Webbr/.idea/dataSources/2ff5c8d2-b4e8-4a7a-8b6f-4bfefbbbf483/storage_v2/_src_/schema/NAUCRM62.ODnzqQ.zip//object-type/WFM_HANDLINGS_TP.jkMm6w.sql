create type wfm_handlings_tp
AS OBJECT 
(
    session_id varchar2(64), 
    project_uuid varchar2(32),
    project_title varchar2(512),
    project_type varchar2(16),
    employee_uuid varchar2(32), 
    employee_title varchar2(512), 
    employee_login varchar2(128),  
    handling_from timestamp,
    handling_till timestamp,
    handling_duration interval day to second,
    ringing_from timestamp,
    ringing_till timestamp,
    ringing_duration interval day to second,
    speaking_from timestamp,
    speaking_till timestamp,
    speaking_duration interval day to second,
    wrapup_from timestamp,
    wrapup_till timestamp,
    wrapup_duration interval day to second
);
/

