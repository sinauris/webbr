create FUNCTION FNC_REPORT_TIMESHEET
(
  I_DATE_START TIMESTAMP,
  I_DATE_END TIMESTAMP,
  I_PROJECT VARCHAR2 DEFAULT NULL,
  I_PROJECT_GROUP NUMBER DEFAULT 2,
  I_LOCATION VARCHAR2 DEFAULT NULL,
  I_LOGIN VARCHAR2 DEFAULT NULL,
  I_ROLETYPE VARCHAR2 DEFAULT 'operator',
  I_PLATFORMS VARCHAR2 DEFAULT NULL
) RETURN T_REPORT_TIMESHEET PIPELINED AS

  BEGIN
  FOR GET_DATA IN
  (
    WITH
      SQ_PROJECT_FILTER AS
      (
        SELECT /*+ MATERIALIZE*/ PROJECT_ID, CAPTION, PLATFORM_ID
        FROM table(PKG_API.GET_PROJECTS_IDS(I_PROJECT))
        UNION
        SELECT CASE WHEN I_PROJECT IS NULL OR I_PROJECT = '{"active": 1, "platforms": [], "projects": [], "direction": []}' THEN '{no_projects}' END PROJECT_ID,
               CASE WHEN I_PROJECT IS NULL OR I_PROJECT = '{"active": 1, "platforms": [], "projects": [], "direction": []}' THEN 'Без проекта' END CAPTION,
               CASE WHEN I_PROJECT IS NULL OR I_PROJECT = '{"active": 1, "platforms": [], "projects": [], "direction": []}' THEN 2 END PLATFORM_ID
        FROM DUAL
        UNION
        SELECT CASE WHEN I_PROJECT IS NULL OR I_PROJECT = '{"active": 1, "platforms": [], "projects": [], "direction": []}' THEN '{no_projects}' END PROJECT_ID,
               CASE WHEN I_PROJECT IS NULL OR I_PROJECT = '{"active": 1, "platforms": [], "projects": [], "direction": []}' THEN 'Без проекта' END CAPTION,
               CASE WHEN I_PROJECT IS NULL OR I_PROJECT = '{"active": 1, "platforms": [], "projects": [], "direction": []}' THEN 1 END PLATFORM_ID
        FROM DUAL
        UNION
        SELECT CASE WHEN I_PROJECT IS NULL OR I_PROJECT = '{"active": 1, "platforms": [], "projects": [], "direction": []}' THEN '{no_projects}' END PROJECT_ID,
               CASE WHEN I_PROJECT IS NULL OR I_PROJECT = '{"active": 1, "platforms": [], "projects": [], "direction": []}' THEN 'Без проекта' END CAPTION,
               CASE WHEN I_PROJECT IS NULL OR I_PROJECT = '{"active": 1, "platforms": [], "projects": [], "direction": []}' THEN 6 END PLATFORM_ID
        FROM DUAL
      ),
      SQ_LOGINS AS
      (
        SELECT LOGIN
        FROM TABLE(PKG_API.GET_EMPLOYEES_LIST('N', 'N',I_PROJECT=>I_PROJECT, I_ROLETYPE=>I_ROLETYPE, I_NEW_STYLE=>'N'))
        WHERE I_LOGIN IS NULL
        UNION
        SELECT COLUMN_VALUE LOGIN
        FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_LOGIN))
        WHERE I_LOGIN IS NOT NULL
      ),
      SQ_PROJECTS_PRP AS
      (
        SELECT /*+ MATERIALIZE*/ DISTINCT TRUNC(DLR.REPORT_DATE) REPORT_DATE,
          DLR.LOGIN, DLR.FID_PROJECT, DLR.FID_PLATFORM, SQP.CAPTION, DLR.RATE
        FROM D_LOGIN_RATES DLR
        LEFT JOIN SQ_PROJECT_FILTER SQP ON SQP.PROJECT_ID = DLR.FID_PROJECT
                                  AND SQP.PLATFORM_ID = DLR.FID_PLATFORM
        WHERE DLR.REPORT_DATE BETWEEN I_DATE_START AND I_DATE_END - INTERVAL '1' SECOND
          AND EXISTS (SELECT 1 FROM SQ_LOGINS LG WHERE LG.LOGIN = DLR.LOGIN)
          AND DLR.RATE > 0
      ),
      SQ_STATUSESS AS
      (
        SELECT /*+ MATERIALIZE*/
               TRUNC(ST.ENTERED) AS DAY_NUM, ST.LOGIN, ST.PROJECT_ID, ST.FID_PLATFORM, NVL(ST.LOCATION_CAPTION, 'Без Площадки') LOCATION_CAPTION,
               ST.ENTERED, CAST(ST.ENTERED+ST.DURATION/86400 AS TIMESTAMP) AS ENDED, ST.DURATION, ST.PROJECT_RATE, STATUS, FULL_DURATION
        FROM TABLE(PKG_API.GET_STATUSES(I_DATE_START, I_DATE_END, null, 0,
                            NVL(I_LOGIN,(SELECT LOGIN FROM TABLE(PKG_API.GET_EMPLOYEES_LIST(I_PROJECT=>I_PROJECT, I_LOCATION=>I_LOCATION, I_NEW_STYLE=>'Y'))WHERE rownum = 1)),
                            I_ROLETYPE=>I_ROLETYPE)) ST
        WHERE EXISTS (SELECT 1 FROM SQ_PROJECTS_PRP PRP WHERE PRP.LOGIN = ST.LOGIN)
      ),
      SQ_WORK_TIME AS
      (
        SELECT /*+ MATERIALIZE*/
               st.DAY_NUM, st.LOGIN, ST.FID_PLATFORM, ST.LOCATION_CAPTION,
               min(st.ENTERED) START_DAY,
               max(st.ENDED) STOP_DAY
        FROM SQ_STATUSESS st
        WHERE st.STATUS != 'offline'
          AND ST.FULL_DURATION <= 43200
        GROUP BY st.DAY_NUM, st.LOGIN, ST.FID_PLATFORM, ST.LOCATION_CAPTION
      ),
      SQ_AWAY_TIME AS
      (
        SELECT /*+ MATERIALIZE*/
               DAY_NUM, LOGIN, FID_PLATFORM, LOCATION_CAPTION,
               NVL(SUM(INT_BETW), 0) OFFLINE_DURATION
        FROM(
              SELECT st.DAY_NUM, st.LOGIN, st.FID_PLATFORM, ST.LOCATION_CAPTION,
                     st.ENTERED, st.ENDED,
                     st.DURATION INT_BETW,
                     st.STATUS
              FROM SQ_STATUSESS st
              WHERE (st.STATUS = 'offline' AND ST.FULL_DURATION > 300
                    OR st.STATUS NOT IN ('offline','available','notavailable') AND st.DURATION > 43200)
                AND EXISTS (SELECT 1
                            FROM SQ_WORK_TIME WT
                            WHERE WT.DAY_NUM = ST.DAY_NUM
                            AND WT.LOGIN = ST.LOGIN
                            AND WT.FID_PLATFORM = ST.FID_PLATFORM
                            AND WT.LOCATION_CAPTION = ST.LOCATION_CAPTION
                            AND ST.ENTERED BETWEEN WT.START_DAY AND WT.STOP_DAY
                            AND ST.ENDED BETWEEN WT.START_DAY AND WT.STOP_DAY)
            )
        GROUP BY DAY_NUM, LOGIN, FID_PLATFORM, LOCATION_CAPTION
      ),
      SQ_STATUSES AS
      (
        SELECT DISTINCT WT.DAY_NUM, WT.LOGIN, WT.LOCATION_CAPTION, WT.FID_PLATFORM, PRP.CAPTION,
          DECODE(I_PROJECT_GROUP, 0, 'Все проекты', 1, DG.CAPTION, 2, PRP.CAPTION, PRP.FID_PROJECT) PROJECT_ID,
          TRIM(VWE.SURNAME||' '||VWE.NAME||' '||VWE.PATRONYMIC) AS FIO,
          WT.START_DAY, WT.STOP_DAY, AW.OFFLINE_DURATION, PRP.FID_PROJECT, PRP.RATE,
          (PKG_INTERVALS.FNC_INTERVALTOSEC(WT.START_DAY, WT.STOP_DAY)-NVL(AW.OFFLINE_DURATION,0))*PRP.RATE/3600 DAY_TIME
        FROM SQ_WORK_TIME WT
        LEFT JOIN SQ_AWAY_TIME AW ON AW.DAY_NUM = WT.DAY_NUM
                                  AND AW.LOGIN = WT.LOGIN
                                  AND AW.FID_PLATFORM = WT.FID_PLATFORM
                                  AND AW.LOCATION_CAPTION = WT.LOCATION_CAPTION
        LEFT JOIN SQ_PROJECTS_PRP PRP ON PRP.LOGIN = WT.LOGIN
                                      AND PRP.FID_PLATFORM = WT.FID_PLATFORM
                                      AND PRP.REPORT_DATE = WT.DAY_NUM
        LEFT JOIN REL_GROUP_PROJECTS GP ON GP.FID_PROJECT = PRP.FID_PROJECT
                                                AND PRP.REPORT_DATE BETWEEN GP.CREATED AND GP.BLOCKED
        LEFT JOIN D_GROUPS DG ON DG.ID_GROUP = GP.FID_GROUP
        LEFT JOIN VW_EMPLOYEES VWE ON VWE.LOGIN = WT.LOGIN
                                           AND VWE.FID_PLATFORM = WT.FID_PLATFORM
        LEFT JOIN NC_CORE.VW_REL_PROJECTS_EMPLOYEES PE ON PE.LOGIN = WT.LOGIN
                                                      AND PE.FID_PLATFORM = WT.FID_PLATFORM
                                                      AND PE.PROJECT_ID = PRP.FID_PROJECT
                                                      AND PE.ACTIVE_FROM < WT.DAY_NUM + 1 - 1/86400 AND PE.ACTIVE_TILL > WT.DAY_NUM
        WHERE NVL(PE.ROLETYPE, I_ROLETYPE) = I_ROLETYPE
        AND PRP.CAPTION IS NOT NULL
      ),
       SQ_PROJECTS AS
      (
        SELECT /*+ MATERIALIZE*/ REPORT_DATE, LOGIN, FID_PLATFORM,
          LISTAGG(CAPTION, ', ') WITHIN GROUP (ORDER BY CAPTION) AS PROJECTS
        FROM (SELECT DISTINCT TO_CHAR(DAY_NUM,'MM/YYYY') REPORT_DATE, LOGIN, FID_PLATFORM, CAPTION
              FROM SQ_STATUSES PRP
              WHERE NVL(I_PROJECT_GROUP, 2) = 0)
        GROUP BY REPORT_DATE, LOGIN, FID_PLATFORM
      ),
      SQ_DATA AS
      (
        SELECT EXTRACT(DAY FROM SQS.DAY_NUM) AS DAY_NUM, TO_CHAR(SQS.DAY_NUM, 'MM/YYYY') AS WORK_MONTH, SQS.LOCATION_CAPTION,
          DECODE(NVL(I_PROJECT_GROUP, 2), 0, SQS.FIO, 'Все сотрудники') AS FIO,
          DECODE(NVL(I_PROJECT_GROUP, 2), 0, SQS.LOGIN, 'Все логины') AS LOGIN,
          NVL(SUBSTR(SQP.PROJECTS,1,400), SQS.PROJECT_ID) AS PROJECT_NAME,
          ROUND(SUM(SQS.DAY_TIME), 2) DAY_TIME
        FROM SQ_STATUSES SQS
        LEFT JOIN SQ_PROJECTS SQP ON SQP.REPORT_DATE=TO_CHAR(SQS.DAY_NUM, 'MM/YYYY')
                                  AND SQS.LOGIN=SQP.LOGIN
                                  AND SQS.FID_PLATFORM=SQP.FID_PLATFORM
        GROUP BY EXTRACT(DAY FROM SQS.DAY_NUM), TO_CHAR(SQS.DAY_NUM, 'MM/YYYY'), SQS.LOCATION_CAPTION,
          DECODE(NVL(I_PROJECT_GROUP, 2), 0, SQS.FIO, 'Все сотрудники'),
          DECODE(NVL(I_PROJECT_GROUP, 2), 0, SQS.LOGIN, 'Все логины'),
          NVL(SUBSTR(SQP.PROJECTS,1,400), SQS.PROJECT_ID)
      )
    SELECT LOGIN, FIO, LOCATION_CAPTION, WORK_MONTH, PROJECT_NAME, DAY_1, DAY_2, DAY_3,
      DAY_4, DAY_5, DAY_6, DAY_7, DAY_8, DAY_9, DAY_10, DAY_11, DAY_12, DAY_13, DAY_14,
      DAY_15, DAY_16, DAY_17, DAY_18, DAY_19, DAY_20, DAY_21, DAY_22, DAY_23, DAY_24,
      DAY_25, DAY_26, DAY_27, DAY_28, DAY_29, DAY_30, DAY_31, DAY_SUM
    FROM (
          SELECT DAY_NUM, WORK_MONTH, LOGIN, FIO, PROJECT_NAME, DAY_TIME, LOCATION_CAPTION
          FROM SQ_DATA
          WHERE DAY_TIME > 0
          UNION ALL
          (
            SELECT 32, WORK_MONTH, LOGIN, FIO, PROJECT_NAME, SUM(DAY_TIME), LOCATION_CAPTION
            FROM SQ_DATA
            WHERE DAY_TIME > 0
            GROUP BY WORK_MONTH, LOGIN, FIO, PROJECT_NAME, LOCATION_CAPTION
          )
         )
    PIVOT
      (
        MAX(DAY_TIME) FOR DAY_NUM IN (1 AS DAY_1, 2 AS DAY_2, 3 AS DAY_3, 4 AS DAY_4,
                          5 AS DAY_5, 6 AS DAY_6, 7 AS DAY_7, 8 AS DAY_8, 9 AS DAY_9,
                          10 AS DAY_10, 11 AS DAY_11, 12 AS DAY_12, 13 AS DAY_13,
                          14 AS DAY_14, 15 AS DAY_15, 16 AS DAY_16, 17 AS DAY_17,
                          18 AS DAY_18, 19 AS DAY_19, 20 AS DAY_20, 21 AS DAY_21,
                          22 AS DAY_22, 23 AS DAY_23, 24 AS DAY_24, 25 AS DAY_25,
                          26 AS DAY_26, 27 AS DAY_27, 28 AS DAY_28, 29 AS DAY_29,
                          30 AS DAY_30, 31 AS DAY_31, 32 AS DAY_SUM)
      )
    ORDER BY WORK_MONTH, LOCATION_CAPTION, LOGIN, PROJECT_NAME
  )
  LOOP
    PIPE ROW(TR_REPORT_TIMESHEET(
              GET_DATA.LOGIN,
              GET_DATA.FIO,
              GET_DATA.LOCATION_CAPTION,
              GET_DATA.WORK_MONTH,
              GET_DATA.PROJECT_NAME,
              GET_DATA.DAY_1,
              GET_DATA.DAY_2,
              GET_DATA.DAY_3,
              GET_DATA.DAY_4,
              GET_DATA.DAY_5,
              GET_DATA.DAY_6,
              GET_DATA.DAY_7,
              GET_DATA.DAY_8,
              GET_DATA.DAY_9,
              GET_DATA.DAY_10,
              GET_DATA.DAY_11,
              GET_DATA.DAY_12,
              GET_DATA.DAY_13,
              GET_DATA.DAY_14,
              GET_DATA.DAY_15,
              GET_DATA.DAY_16,
              GET_DATA.DAY_17,
              GET_DATA.DAY_18,
              GET_DATA.DAY_19,
              GET_DATA.DAY_20,
              GET_DATA.DAY_21,
              GET_DATA.DAY_22,
              GET_DATA.DAY_23,
              GET_DATA.DAY_24,
              GET_DATA.DAY_25,
              GET_DATA.DAY_26,
              GET_DATA.DAY_27,
              GET_DATA.DAY_28,
              GET_DATA.DAY_29,
              GET_DATA.DAY_30,
              GET_DATA.DAY_31,
              GET_DATA.DAY_SUM)
            );
  END LOOP;

END FNC_REPORT_TIMESHEET;
/

