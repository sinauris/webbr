create type           SYS_PLSQL_1808364_136_1 as table of "NC_CORE"."SYS_PLSQL_1808364_89_1";
/

