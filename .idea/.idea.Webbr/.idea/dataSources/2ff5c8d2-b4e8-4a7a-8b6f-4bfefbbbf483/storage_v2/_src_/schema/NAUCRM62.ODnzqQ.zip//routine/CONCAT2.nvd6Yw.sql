create FUNCTION CONCAT2(sep IN varchar2, p1 IN number, p2 IN varchar2) RETURN VARCHAR2 IS
BEGIN
    RETURN to_char(p1) || sep || p2;
END;
/

