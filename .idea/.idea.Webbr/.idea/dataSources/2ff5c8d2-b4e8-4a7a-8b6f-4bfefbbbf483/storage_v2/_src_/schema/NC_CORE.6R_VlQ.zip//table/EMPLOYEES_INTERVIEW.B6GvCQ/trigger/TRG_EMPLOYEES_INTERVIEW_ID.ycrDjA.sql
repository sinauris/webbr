create trigger TRG_EMPLOYEES_INTERVIEW_ID
    before insert
    on EMPLOYEES_INTERVIEW
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_INTERVIEW" IS NULL THEN
                                 SELECT SEQ_EMPLOYEES_INTERVIEW_ID.NEXTVAL INTO :NEW."ID_INTERVIEW" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

