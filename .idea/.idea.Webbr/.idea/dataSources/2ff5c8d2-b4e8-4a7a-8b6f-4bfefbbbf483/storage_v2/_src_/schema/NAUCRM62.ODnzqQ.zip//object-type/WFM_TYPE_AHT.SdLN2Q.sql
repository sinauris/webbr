create TYPE wfm_type_AHT FORCE AS OBJECT
  ( 
  ZN_TM                   timestamp,   
  project_id              char(32),
  value                   NUMBER(6), 
  AHT                     number(8)
  );
/

