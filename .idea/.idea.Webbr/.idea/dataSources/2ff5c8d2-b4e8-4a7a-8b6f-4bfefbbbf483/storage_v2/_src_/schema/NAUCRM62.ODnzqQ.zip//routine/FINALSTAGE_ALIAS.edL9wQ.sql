create FUNCTION finalstage_alias (fs IN NUMBER) RETURN VARCHAR2 AS
BEGIN

    Return
        Case
            When fs = 1 then 'ivr'
            When fs = 2 then 'queue'
            When fs = 3 then 'operator'
            When fs = 4 then 'redirect'
            When fs = 5 then 'ivrredirect'
            Else 'unknown'
        End;

END;
/

