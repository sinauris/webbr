create type           SYS_PLSQL_1808343_DUMMY_1 as table of number;
/

