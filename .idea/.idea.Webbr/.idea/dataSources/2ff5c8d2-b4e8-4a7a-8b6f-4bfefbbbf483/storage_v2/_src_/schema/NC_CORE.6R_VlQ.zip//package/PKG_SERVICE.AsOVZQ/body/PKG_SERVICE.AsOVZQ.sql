create PACKAGE BODY PKG_SERVICE AS
  --Тип для формирования отчета в XML
  TYPE LT_RESULT IS RECORD(
                            WORK_START TIMESTAMP,
                            WORK_LOG CLOB,
                            RESULT_NUM NUMBER,
                            RESULT_TXT VARCHAR2(1500),
                            IS_ERROR NUMBER(1)
                          );

  --Выборка логинов, работающих на проектах
  FUNCTION FNC_GET_LOGINS(
      I_DATE_START     TIMESTAMP, --Дата начала отбора
      I_DATE_END       TIMESTAMP, --Дата окончания отбора
      I_PROJECT        VARCHAR2 DEFAULT NULL, --Проект/группа проектов
      I_LOCATION       VARCHAR2 DEFAULT NULL, --Call-центр/площадка
      I_GROUP_LOCATION NUMBER DEFAULT 2, --Группировка по Call-центру/площадке
      I_PLATFORMS      VARCHAR2 DEFAULT NULL, --Платформы
      I_LOGIN          VARCHAR2 DEFAULT NULL, --Логин оператора
      I_ROLETYPE       VARCHAR2 DEFAULT NULL) --Роль сотрудника (оператор, супервайзер, ...)
    RETURN PT_LOGINS PIPELINED
  AS

    V_CALL_CENTER VARCHAR2(100) ;
    V_LOCATION    VARCHAR2(100) ;

    CURSOR GET_DATA
      RETURN PTR_LOGINS
    IS
    WITH SQ_FILTER_PROJECTS AS
      (--Выборка необходимых проектов
        SELECT
          /*+ MATERIALIZE*/
          DISTINCT ST.COLUMN_VALUE AS PROJECT_ID
        FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_PROJECT)) ST
        WHERE ST.COLUMN_VALUE IS NOT NULL
      )
    SELECT DISTINCT VWRPE.LOGIN,
      DECODE(I_GROUP_LOCATION, 0, '{all}', MVE.CALL_CENTRE_NAME) AS CALL_CENTRE_NAME,
      DECODE(I_GROUP_LOCATION, 2, MVE.LOCATION_NAME, '{all}')    AS LOCATION_NAME,
      MVE.FID_PLATFORM
    FROM VW_REL_PROJECTS_EMPLOYEES VWRPE
    JOIN MV_PROJECTS MVP       ON MVP.ID_ELEMENT=VWRPE.PROJECT_ID
    LEFT JOIN MV_EMPLOYEES MVE ON MVE.LOGIN=VWRPE.LOGIN AND MVE.FID_PLATFORM=VWRPE.FID_PLATFORM
    WHERE DECODE(LOWER(I_ROLETYPE), '*', '*', LOWER(VWRPE.ROLETYPE))=NVL(LOWER(I_ROLETYPE), 'operator')
      AND EXISTS
                (
                  SELECT 1
                  FROM SQ_FILTER_PROJECTS SQFP
                  WHERE SQFP.PROJECT_ID=VWRPE.PROJECT_ID
                    AND( VWRPE.ACTIVE_FROM BETWEEN I_DATE_START AND I_DATE_END
                    OR VWRPE.ACTIVE_TILL BETWEEN I_DATE_START AND I_DATE_END
                    OR I_DATE_START BETWEEN VWRPE.ACTIVE_FROM AND VWRPE.ACTIVE_TILL
                    OR I_DATE_END BETWEEN VWRPE.ACTIVE_FROM AND VWRPE.ACTIVE_TILL)
                  UNION ALL
                  SELECT 1 FROM DUAL WHERE I_PROJECT IS NULL
                )
      AND NVL2(I_LOGIN, VWRPE.LOGIN, '*')=NVL(I_LOGIN, '*')
      AND NVL2(V_LOCATION, MVE.LOCATION_NAME, '*')=NVL(V_LOCATION, '*')
      AND NVL2(V_CALL_CENTER, MVE.CALL_CENTRE_NAME, '*')=NVL(V_CALL_CENTER, '*')
      AND EXISTS
                (
                  SELECT 1
                  FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_PLATFORMS)) PL
                  WHERE PL.COLUMN_VALUE=TO_CHAR(MVE.FID_PLATFORM)
                  UNION ALL
                  SELECT 1 FROM DUAL WHERE I_PLATFORMS IS NULL
                ) ;

  BEGIN

    SELECT "CALL_CENTER",
      "LOCATION"
    INTO V_CALL_CENTER,
      V_LOCATION
    FROM
      (
        SELECT SUBSTR(COLUMN_VALUE, 1, 1) AS FLAG,
          SUBSTR(COLUMN_VALUE, 3)         AS FLAG_VALUE
        FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_LOCATION))
      )
      PIVOT(MIN(FLAG_VALUE) FOR FLAG IN('C' AS "CALL_CENTER", 'L' AS "LOCATION")) ;

    FOR R IN GET_DATA
    LOOP
      PIPE ROW(R) ;
    END LOOP;
  END FNC_GET_LOGINS;

  --Получение пропорций работы операторов на проектах
  FUNCTION FNC_GET_LOGIN_RATIO(
      I_DATE_START           TIMESTAMP, --Дата начала отбора
      I_DATE_END             TIMESTAMP, --Дата окончания отбора
      I_PROJECT              VARCHAR2 DEFAULT NULL, --Проект/группа проектов
      I_GROUP_PROJECTS_LEVEL NUMBER DEFAULT 2, --Уровень группировки проектов
      I_LOGIN                VARCHAR2 DEFAULT NULL, --Логин оператора
      I_LOCATION             VARCHAR2 DEFAULT NULL, --Call-центр/площадка
      I_PLATFORMS            VARCHAR2 DEFAULT NULL, --Платформы
      I_ROLETYPE             VARCHAR2 DEFAULT NULL) --Роль сотрудника (оператор, супервайзер, ...)
    RETURN PT_LOGIN_RATIO PIPELINED
  AS

    CURSOR GET_DATA
      RETURN PTR_LOGIN_RATIO
    IS
    WITH SQ_RANGES AS
      (--Разбиение интервала на подинтервалы
        SELECT
          /*+ MATERIALIZE*/
          START_RANGE,
          STOP_RANGE-INTERVAL '1' SECOND AS STOP_RANGE
        FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(CAST(TRUNC(I_DATE_START) AS TIMESTAMP), CAST(TRUNC(I_DATE_END)+1 AS TIMESTAMP)))
        WHERE START_RANGE<I_DATE_END
      ),
      SQ_FILTER_PROJECTS AS
      (--Выборка необходимых проектов
        SELECT
          /*+ MATERIALIZE*/
          DISTINCT ST.COLUMN_VALUE                                                           AS PROJECT_ID,
          NVL(DECODE(I_GROUP_PROJECTS_LEVEL, 0, '{all}', 1, MVP.FID_GROUP), ST.COLUMN_VALUE) AS FID_PROJECT
        FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_PROJECT)) ST
        JOIN MV_PROJECTS MVP ON MVP.ID_ELEMENT=ST.COLUMN_VALUE
        WHERE ST.COLUMN_VALUE IS NOT NULL
      ),
      SQ_STATUSES AS
      (
        SELECT VES.ENTERED,
          VES.LOGIN,
          VES.DURATION,
          VES.FID_PLATFORM,
          NVL(
          CASE
            WHEN DS.NAME='offline'
              AND VES.DURATION<300
            THEN NVL(LAG(VES.FID_PROJECT) OVER(PARTITION BY VES.LOGIN ORDER BY VES.ENTERED, DS.NAME), LEAD(
              CASE
                WHEN DS.NAME!='offline'
                THEN VES.FID_PROJECT
              END IGNORE NULLS) OVER(PARTITION BY VES.LOGIN ORDER BY VES.ENTERED, DS.NAME))
          END, VES.FID_PROJECT) AS FID_PROJECT,
          VES.FID_PROJECT       AS REAL_FID_PROJECT,
          CASE
            WHEN DS.NAME='offline'
              AND DURATION<300
            THEN LAG(DS.NAME) OVER(PARTITION BY VES.LOGIN ORDER BY ENTERED, DS.NAME)
            ELSE DS.NAME
          END     AS STATUS,
          DS.NAME AS REAL_STATUS
        FROM VW_EMPLOYEES_STATUSES VES
        JOIN D_STATUSES DS ON DS.ID_STATUS=VES.FID_NAU_STATUS AND DS.NAME NOT IN('available', 'notavailable')
        WHERE VES.ENTERED BETWEEN CAST(TRUNC(I_DATE_START)-1 AS TIMESTAMP) AND I_DATE_END
          AND EXISTS
          (
            SELECT 1
            FROM TABLE(PKG_SERVICE.FNC_GET_LOGINS(I_DATE_START, I_DATE_END, I_PROJECT, I_LOCATION, 0, I_PLATFORMS, I_LOGIN, I_ROLETYPE)) SQFL
            WHERE VES.LOGIN=SQFL.LOGIN
          )
      ),
      SQ_LOGIN_STATUSES AS
      (
        SELECT SQR.START_RANGE,
          SQR.STOP_RANGE,
          SQS.LOGIN,
          SQS.FID_PLATFORM,
          NVL2(I_PROJECT, NVL(SQFP.FID_PROJECT, '{others}'), NVL(DECODE(I_GROUP_PROJECTS_LEVEL, 0, '{all}', 1, MVP.FID_GROUP), SQS.FID_PROJECT))               AS FID_PROJECT,
          SUM( PKG_INTERVALS.FNC_INTERVALTOSEC( GREATEST(SQS.ENTERED, SQR.START_RANGE), LEAST(CAST(SQS.ENTERED+DURATION/86400 AS TIMESTAMP), SQR.STOP_RANGE))) AS PROJECT_TIME
        FROM SQ_STATUSES SQS
        JOIN SQ_RANGES SQR                ON(SQS.ENTERED BETWEEN SQR.START_RANGE AND SQR.STOP_RANGE OR SQR.START_RANGE BETWEEN SQS.ENTERED AND CAST(SQS.ENTERED+DURATION/86400 AS TIMESTAMP))
        LEFT JOIN MV_PROJECTS MVP         ON MVP.ID_ELEMENT=SQS.FID_PROJECT
        LEFT JOIN SQ_FILTER_PROJECTS SQFP ON SQFP.PROJECT_ID=SQS.FID_PROJECT
        WHERE SQS.STATUS!='offline'
          AND SQS.FID_PROJECT!='project_not_determined'
        GROUP BY SQR.START_RANGE,
          SQR.STOP_RANGE,
          SQS.LOGIN,
          SQS.FID_PLATFORM,
          NVL2(I_PROJECT, NVL(SQFP.FID_PROJECT, '{others}'), NVL(DECODE(I_GROUP_PROJECTS_LEVEL, 0, '{all}', 1, MVP.FID_GROUP), SQS.FID_PROJECT))
      )
    SELECT *
    FROM
      (
        SELECT START_RANGE,
          STOP_RANGE,
          LOGIN,
          FID_PROJECT,
          FID_PLATFORM,
          ROUND(PROJECT_TIME/DECODE(SUM(PROJECT_TIME) OVER(PARTITION BY START_RANGE, LOGIN), 0, 1, SUM(PROJECT_TIME) OVER(PARTITION BY START_RANGE, LOGIN)), 5) AS PROJECT_RATE
        FROM SQ_LOGIN_STATUSES
      )
    WHERE FID_PROJECT!='{others}'
    ORDER BY LOGIN,
      START_RANGE;

  BEGIN
    FOR R IN GET_DATA
    LOOP
      PIPE ROW(R) ;
    END LOOP;
  END FNC_GET_LOGIN_RATIO;

  --Выборка статусов операторов
  FUNCTION FNC_GET_STATUSES(
      I_DATE_START           TIMESTAMP, --Дата начала отбора
      I_DATE_END             TIMESTAMP, --Дата окончания отбора
      I_PROJECT              VARCHAR2 DEFAULT NULL, --Проект/группа проектов
      I_GROUP_PROJECTS_LEVEL NUMBER DEFAULT 2, --Уровень группировки проектов
      I_LOGIN                VARCHAR2 DEFAULT NULL, --Логин оператора
      I_LOCATION             VARCHAR2 DEFAULT NULL, --Call-центр/площадка
      I_GROUP_LOCATION       NUMBER DEFAULT 2, --Группировка по Call-центру/площадке
      I_STEP                 NUMBER DEFAULT 1, --Длина шага разделения по времени
      I_STEP_TYPE            VARCHAR2 DEFAULT 'DD', --Тип шаг разделения по времени
      I_STATUSES             VARCHAR2 DEFAULT NULL, --Статусы
      I_PLATFORMS            VARCHAR2 DEFAULT NULL, --Платформы
      I_ROLETYPE             VARCHAR2 DEFAULT NULL, --Роль сотрудника (оператор, супервайзер, ...)
      I_COMPRESS             CHAR DEFAULT 'Y') --Убирать offline занимающие целый диапазон
    RETURN PT_STATUS_CHANGES PIPELINED
  AS

    V_CALL_CENTER VARCHAR2(100) ;
    V_LOCATION    VARCHAR2(100) ;

    CURSOR GET_DATA
      RETURN PTR_STATUS_CHANGES
    IS
    WITH SQ_RANGES AS
      (--Разбиение интервала на подинтервалы
        SELECT
          /*+ MATERIALIZE*/
          START_RANGE,
          STOP_RANGE,
          FULL_RANGE
        FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(I_DATE_START, I_DATE_END, NVL(I_STEP, 1), NVL(I_STEP_TYPE, 'DD')))
      ),
      SQ_FILTER_STATUSES AS
      (--Выборка необходимых статусов
        SELECT
          /*+ MATERIALIZE*/
          DISTINCT DSS.ID_STATUS,
          DSS.NAME,
          DSS.REASON
        FROM D_STATUSES DSF
        LEFT JOIN D_STATUSES DSS ON DSF.ID_STATUS IN(DSS.FID_STATUS, DSS.ID_STATUS)
        WHERE EXISTS
          (
            SELECT 1
            FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_STATUSES)) FST
            WHERE DSF.NAME
              ||'|'
              ||DSF.REASON LIKE FST.COLUMN_VALUE
              ||'%'
            UNION
            SELECT 1 FROM DUAL WHERE I_STATUSES IS NULL
          )
          AND EXISTS
          (
            SELECT 1
            FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_PLATFORMS)) ST
            WHERE ST.COLUMN_VALUE=TO_CHAR(DSS.FID_PLATFORM)
              AND DSS.FID_PLATFORM>0
            UNION ALL
            SELECT 1
            FROM D_MODULES DPF
            WHERE I_PLATFORMS IS NULL
              AND DPF.ID_MODULE=DSS.FID_PLATFORM
              AND DSS.FID_PLATFORM>0
          )
      ),
      SQ_FILTER_PROJECTS AS
      (--Выборка необходимых проектов
        SELECT
          /*+ MATERIALIZE*/
          DISTINCT ST.COLUMN_VALUE AS PROJECT_ID
        FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_PROJECT)) ST
        WHERE ST.COLUMN_VALUE IS NOT NULL
      ),
      SQ_FILTER_LOGINS AS
      (--Выборка логинов на выбранных проектах
        SELECT
          /*+ MATERIALIZE*/
          LOGIN,
          CC_CAPTION,
          LOCATION_CAPTION,
          FID_PLATFORM
        FROM TABLE(PKG_SERVICE.FNC_GET_LOGINS(I_DATE_START, I_DATE_END, I_PROJECT, I_LOCATION, I_GROUP_LOCATION, I_PLATFORMS, I_LOGIN, I_ROLETYPE))
      ),
      SQ_LOGIN_RATIO AS
      (--Выборка логинов на выбранных проектах
        SELECT
          /*+ MATERIALIZE*/
          START_RANGE,
          STOP_RANGE,
          LOGIN,
          FID_PROJECT,
          FID_PLATFORM,
          PROJECT_RATE
        FROM TABLE(PKG_SERVICE.FNC_GET_LOGIN_RATIO(I_DATE_START, I_DATE_END, I_PROJECT, I_GROUP_PROJECTS_LEVEL, I_LOGIN, I_LOCATION, I_PLATFORMS, I_ROLETYPE))
      )
    SELECT DISTINCT GREATEST(VES.ENTERED, SQR.START_RANGE) AS ENTERED,
      VES.LOGIN,
      DECODE(I_GROUP_PROJECTS_LEVEL, 0, '{all}', 1, COALESCE(MVP.FID_GROUP, MVP.ID_ELEMENT, VES.FID_PROJECT), 2, NVL(VWRPE.PROJECT_ID, VES.FID_PROJECT)) AS FID_PROJECT,
      VES.FID_NAU_STATUS                                                                                                                                 AS FID_STATUS,
      VES.REASON,
      NVL(SQLR.PROJECT_RATE, DECODE(VES.FID_PROJECT, 'project_not_determined', 0, 1))                                                                AS PROJECT_RATE,
      PKG_INTERVALS.FNC_INTERVALTOSEC( GREATEST(VES.ENTERED, SQR.START_RANGE), LEAST(SQR.STOP_RANGE, CAST(VES.ENTERED+DURATION/86400 AS TIMESTAMP))) AS DURATION,
      VES.DURATION                                                                                                                                   AS FULL_DURATION,
      VES.FID_PLATFORM,
      SQFL.CC_CAPTION,
      SQFL.LOCATION_CAPTION
    FROM VW_EMPLOYEES_STATUSES VES
    JOIN SQ_FILTER_LOGINS SQFL                ON SQFL.LOGIN=VES.LOGIN AND SQFL.FID_PLATFORM=VES.FID_PLATFORM
    JOIN SQ_RANGES SQR                        ON VES.ENTERED BETWEEN SQR.START_RANGE AND SQR.STOP_RANGE OR SQR.START_RANGE BETWEEN VES.ENTERED AND CAST(VES.ENTERED+DURATION/86400 AS TIMESTAMP)
    JOIN SQ_FILTER_STATUSES SQFS              ON SQFS.ID_STATUS=VES.FID_NAU_STATUS
    LEFT JOIN VW_REL_PROJECTS_EMPLOYEES VWRPE ON VWRPE.LOGIN=VES.LOGIN AND VWRPE.FID_PLATFORM=VES.FID_PLATFORM AND VES.ENTERED BETWEEN VWRPE.ACTIVE_FROM AND VWRPE.ACTIVE_TILL AND VES.FID_PROJECT='project_not_determined' AND I_GROUP_PROJECTS_LEVEL>0 AND DECODE(LOWER(I_ROLETYPE), '*', '*', LOWER(VWRPE.ROLETYPE))=NVL(LOWER(I_ROLETYPE), 'operator')
    LEFT JOIN MV_PROJECTS MVP                 ON MVP.ID_ELEMENT=NVL(VWRPE.PROJECT_ID, VES.FID_PROJECT)
    LEFT JOIN SQ_LOGIN_RATIO SQLR             ON SQLR.LOGIN=VES.LOGIN AND VES.ENTERED BETWEEN SQLR.START_RANGE AND SQLR.STOP_RANGE AND SQLR.FID_PLATFORM=VES.FID_PLATFORM AND VES.FID_PROJECT='project_not_determined' AND SQLR.FID_PROJECT=DECODE(I_GROUP_PROJECTS_LEVEL, 0, '{all}', 1, NVL(MVP.FID_GROUP, MVP.ID_ELEMENT), 2, NVL(VWRPE.PROJECT_ID, VES.FID_PROJECT))
    WHERE VES.ENTERED BETWEEN I_DATE_START-1 AND I_DATE_END
      AND VES.DURATION>0
      AND NVL(SQLR.PROJECT_RATE, DECODE(VES.FID_PROJECT, 'project_not_determined', 0, 1))>0
      AND NOT( GREATEST(VES.ENTERED, SQR.START_RANGE)=SQR.START_RANGE
      AND GREATEST(SQR.START_RANGE, VES.ENTERED)=SQR.START_RANGE
      AND LEAST(SQR.STOP_RANGE, CAST(VES.ENTERED+DURATION/86400 AS TIMESTAMP))=SQR.STOP_RANGE
      AND SQFS.NAME='offline'
      AND UPPER(I_COMPRESS)!='N')
      AND EXISTS
      (
        SELECT 1 FROM SQ_FILTER_PROJECTS SQFP WHERE SQFP.PROJECT_ID=VES.FID_PROJECT
        UNION ALL
        SELECT 1
        FROM DUAL
        WHERE I_PROJECT IS NULL
          OR VES.FID_PROJECT='project_not_determined'
          OR SQFS.NAME='offline'
      ) ;

  BEGIN
    IF NVL(I_GROUP_PROJECTS_LEVEL, 2) NOT BETWEEN 0 AND 2 THEN
      RAISE_APPLICATION_ERROR(-20000, 'I_GROUP_PROJECTS_LEVEL может иметь значение от 0 до 2.') ;
    END IF;
    IF NVL(I_GROUP_LOCATION, 2) NOT BETWEEN 0 AND 2 THEN
      RAISE_APPLICATION_ERROR(-20001, 'I_GROUP_PROJECTS_LEVEL может иметь значение от 0 до 2.') ;
    END IF;

    SELECT "CALL_CENTER",
      "LOCATION"
    INTO V_CALL_CENTER,
      V_LOCATION
    FROM
      (
        SELECT SUBSTR(COLUMN_VALUE, 1, 1) AS FLAG,
          SUBSTR(COLUMN_VALUE, 3)         AS FLAG_VALUE
        FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_LOCATION))
      )
      PIVOT(MIN(FLAG_VALUE) FOR FLAG IN('C' AS "CALL_CENTER", 'L' AS "LOCATION")) ;

    FOR R IN GET_DATA
    LOOP
      PIPE ROW(R) ;
    END LOOP;
  END FNC_GET_STATUSES;

  --Обновление дополнительнх данных
  FUNCTION FNC_UPDATE_EXT_DATA(
      I_DATE_START TIMESTAMP,
      I_DATE_END   TIMESTAMP,
      I_FORCE      CHAR)
    RETURN LT_RESULT
  IS
    V_RESULT LT_RESULT;
    V_WORK LT_RESULT;
    V_CALLS NUMBER;

    FUNCTION STEP_UPDATE_CALLS(
        I_STEP NUMBER)
      RETURN LT_RESULT
    IS
      V_RESULT LT_RESULT;
    BEGIN
      V_RESULT.WORK_START:=SYSTIMESTAMP;
      V_RESULT.WORK_LOG:='<action id="'||TO_CHAR(I_STEP) ||'" time="{time}" {cnt}="{val}">{text}</action>';
      V_RESULT.IS_ERROR:=0;
      BEGIN
        IF I_STEP=1 THEN
          V_RESULT.RESULT_TXT:='Получаем информацию по ЗФ операторов';
          V_RESULT.RESULT_NUM:=SQL%ROWCOUNT;
        ELSIF I_STEP=2 THEN
          V_RESULT.RESULT_TXT:='Обновляем информацию по поствызывной обработке';
          MERGE INTO CALLS_INFO CI USING
          (
            WITH SQ_CALLS_INFO AS
              (
                SELECT
                  /*+ MATERIALIZE*/
                  CI.ROWID AS SYS_RID,
                  CI.FID_PLATFORM,
                  CI.SESSION_ID,
                  CI.OPERATOR,
                  CI.OPERATOR_WRAPUP,
                  CI.OPERATOR_ENDED,
                  CS.ENDED,
                  LEAD(CI.OPERATOR_CREATED) OVER(PARTITION BY CS.FID_PLATFORM, CS.SESSION_ID, CI.OPERATOR ORDER BY CI.LINK_ID) AS NEXT_OPERATOR_CREATED
                FROM CALL_SESSIONS CS
                JOIN CALLS_INFO CI ON CS.FID_PLATFORM=CI.FID_PLATFORM AND CS.SESSION_ID=CI.SESSION_ID
                WHERE CS.CREATED BETWEEN I_DATE_START AND I_DATE_END
                  AND CI.OPERATOR NOT IN('{no_operator}', '{ext_operator}')
              ),
              SQ_CALL_STATUSES AS
              (
                SELECT
                  /*+ MATERIALIZE*/
                  SQCI.SYS_RID,
                  SQCI.SESSION_ID,
                  HES.DURATION AS DURATION,
                  SQCI.OPERATOR_WRAPUP
                FROM H_EMPLOYEES_STATUS HES
                JOIN MV_STATUSES MVS         ON MVS.ID_NAU_STATUS=HES.FID_NAU_STATUS AND MVS.NAU_STATUS='wrapup'
                LEFT JOIN SQ_CALLS_INFO SQCI ON HES.LOGIN=SQCI.OPERATOR
                                            AND HES.FID_PLATFORM=SQCI.FID_PLATFORM
                                            AND HES.REASON=SQCI.SESSION_ID
                                            AND HES.ENTERED BETWEEN SQCI.OPERATOR_ENDED-INTERVAL '2' SECOND AND NVL(SQCI.NEXT_OPERATOR_CREATED, SQCI.ENDED+INTERVAL '1' HOUR)
                WHERE HES.ENTERED BETWEEN I_DATE_START AND I_DATE_END
              )
            SELECT SYS_RID,
              SESSION_ID,
              SUM(DURATION) AS DURATION
            FROM SQ_CALL_STATUSES
            WHERE SYS_RID IS NOT NULL
            GROUP BY SYS_RID,
              SESSION_ID
            HAVING SUM(DURATION)!=MAX(OPERATOR_WRAPUP)
          )
          TMP ON(CI.ROWID=TMP.SYS_RID)
        WHEN MATCHED THEN
          UPDATE SET CI.OPERATOR_WRAPUP=TMP.DURATION;
          V_RESULT.RESULT_NUM:=SQL%ROWCOUNT;
        ELSIF I_STEP=3 THEN
          V_RESULT.RESULT_TXT:='Обновляем информацию по проектам у статусов';
          INSERT INTO TMP_PROJ_INFO
            WITH SQ_SESSIONS AS
              (
                SELECT /*+ MATERIALIZE*/CS.SESSION_ID, CS.FID_PLATFORM, CS.ENDED, CI.FID_PROJECT,
                  CI.CALLED, CI.OPERATOR, CI.OPERATOR_CREATED,
                  CI.OPERATOR_CONNECTED, CI.OPERATOR_ENDED,
                  CASE
                    WHEN CS.DIRECTION = 'OUT'
                    THEN LEAD(CI.OPERATOR_CREATED)OVER(PARTITION BY CS.SESSION_ID, CS.FID_PLATFORM, CI.CALLER ORDER BY CI.LINK_ID)
                    ELSE LEAD(CI.OPERATOR_CREATED)OVER(PARTITION BY CS.SESSION_ID, CS.FID_PLATFORM, CI.CALLED ORDER BY CI.LINK_ID)
                  END AS OPERATOR_NEXT_CREATED
                FROM CALL_SESSIONS CS
                JOIN CALLS_INFO CI ON CS.FID_PLATFORM=CI.FID_PLATFORM
                                  AND CS.SESSION_ID=CI.SESSION_ID
                                  AND CI.OPERATOR_CREATED IS NOT NULL
                WHERE CS.CREATED BETWEEN I_DATE_START - 1/24 AND I_DATE_END + 1/24
              )
                SELECT /*+ MATERIALIZE*/ DISTINCT HES.ROWID AS SYS_RID, HES.ENTERED, HES.LOGIN,
                  FIRST_VALUE(COALESCE(SQSR.FID_PROJECT, SQSS.FID_PROJECT, SQSW.FID_PROJECT, SQSA.FID_PROJECT))OVER
                    (PARTITION BY HES.ROWID ORDER BY ABS(PKG_INTERVALS.FNC_INTERVALTOSEC(HES.ENTERED,
                                                          COALESCE(SQSR.OPERATOR_CREATED, SQSS.OPERATOR_CONNECTED, SQSW.OPERATOR_ENDED, SQSA.OPERATOR_ENDED))),
                                                    COALESCE(SQSR.OPERATOR_CREATED, SQSS.OPERATOR_CONNECTED, SQSW.OPERATOR_ENDED, SQSA.OPERATOR_ENDED) NULLS LAST) AS FID_PROJECT,
                  HES.FID_NAU_STATUS, HES.FID_NC_STATUS, HES.REASON, HES.DURATION, MVS.NAU_STATUS,
                  HES.FID_PLATFORM
                FROM H_EMPLOYEES_STATUS HES
                JOIN MV_STATUSES MVS ON MVS.ID_NAU_STATUS=HES.FID_NAU_STATUS
                                    AND MVS.NAU_STATUS IN ('ringing','speaking','wrapup','accident')
                LEFT JOIN SQ_SESSIONS SQSR ON HES.FID_PLATFORM=SQSR.FID_PLATFORM
                                          AND HES.LOGIN = SQSR.OPERATOR
                                          AND MVS.NAU_STATUS = 'ringing'
                                          AND HES.ENTERED BETWEEN SQSR.OPERATOR_CREATED - 2/86400 AND NVL(SQSR.OPERATOR_CONNECTED, SQSR.OPERATOR_ENDED) + 2/86400
                LEFT JOIN SQ_SESSIONS SQSS ON HES.FID_PLATFORM=SQSS.FID_PLATFORM
                                          AND HES.LOGIN = SQSS.OPERATOR
                                          AND MVS.NAU_STATUS = 'speaking'
                                          AND HES.ENTERED BETWEEN NVL(SQSS.OPERATOR_CONNECTED, SQSS.OPERATOR_CREATED) - 2/86400 AND SQSS.OPERATOR_ENDED + 2/86400
                LEFT JOIN SQ_SESSIONS SQSW ON HES.FID_PLATFORM=SQSW.FID_PLATFORM
                                          AND HES.LOGIN = SQSW.OPERATOR
                                          AND MVS.NAU_STATUS = 'wrapup'
                                          AND HES.ENTERED BETWEEN NVL(SQSW.OPERATOR_CONNECTED, SQSW.OPERATOR_ENDED) - 2/86400 AND NVL(SQSW.OPERATOR_NEXT_CREATED + 2/86400, SQSW.ENDED + 15/1440)
                                          AND HES.REASON = SQSW.SESSION_ID
                LEFT JOIN SQ_SESSIONS SQSA ON HES.FID_PLATFORM=SQSA.FID_PLATFORM
                                          AND HES.LOGIN = SQSA.OPERATOR
                                          AND MVS.NAU_STATUS = 'accident'
                                          AND HES.ENTERED BETWEEN SQSA.OPERATOR_CREATED - 2/86400 AND SQSA.OPERATOR_ENDED + 2/86400
                                          AND (INSTR(HES.REASON, SQSA.SESSION_ID) != 0
                                                OR HES.FID_PLATFORM = 1) -- В 4 Наумене нет привязки сессии
                WHERE HES.ENTERED BETWEEN I_DATE_START AND I_DATE_END+INTERVAL '1' HOUR
                  AND DECODE(I_FORCE, 'Y', 'pnd', HES.FID_PROJECT) = 'pnd';
          MERGE INTO H_EMPLOYEES_STATUS HES USING
          (
            SELECT SYS_RID, FID_PROJECT
            FROM TMP_PROJ_INFO
            WHERE FID_PROJECT IS NOT NULL
          )TMP
          ON(HES.ROWID=TMP.SYS_RID)
          WHEN MATCHED THEN
            UPDATE SET HES.FID_PROJECT = TMP.FID_PROJECT;
          V_RESULT.RESULT_NUM:=SQL%ROWCOUNT;
          DELETE FROM TMP_PROJ_INFO;
        ELSIF I_STEP=4 THEN
          V_RESULT.RESULT_TXT:='Обновляем информацию по удержанию вызовов';
          MERGE INTO CALLS_INFO CI USING
          (
            WITH SQ_CALL_STATUS AS
              (
                SELECT /*+ ORDERED*/ VWCS.ENTERED, VWCS.ENDED, VWCS.SESSION_ID,
                  VWCS.FID_PLATFORM, VWCS.INITIATOR_ID, VWCS.DESTINATION_ID
                FROM VW_CALL_STATUS VWCS
                WHERE VWCS.ENTERED BETWEEN I_DATE_START AND I_DATE_END+INTERVAL '1' HOUR
                      AND EXISTS
                      (
                          SELECT /*+ INDEX (TCSF IDX_TCS_SID_FP)*/1
                          FROM TMP_CALL_SESSIONS TCSF
                          WHERE TCSF.SESSION_ID = VWCS.SESSION_ID
                                AND TCSF.FID_PLATFORM = VWCS.FID_PLATFORM
                                AND VWCS.ENTERED BETWEEN TCSF.CREATED AND VWCS.ENTERED
                      )
              ),
                SQ_CALLS_HOLD AS
              (
                SELECT
                  /*+ MATERIALIZE*/
                  CI.ROWID                                                  AS SYS_RID,
                  PKG_INTERVALS.FNC_INTERVALTOSEC(VWCS.ENTERED, VWCS.ENDED) AS HOLD_DURATION
                FROM CALL_SESSIONS CS
                JOIN CALLS_INFO CI ON CS.SESSION_ID=CI.SESSION_ID AND CS.FID_PLATFORM=CI.FID_PLATFORM
                JOIN SQ_CALL_STATUS VWCS ON VWCS.FID_PLATFORM=CS.FID_PLATFORM AND VWCS.SESSION_ID=CS.SESSION_ID
                                        AND VWCS.INITIATOR_ID=CI.OPERATOR
                                        AND CASE
                                            WHEN REGEXP_LIKE(VWCS.DESTINATION_ID, '^([0-9]{0,3})8([0-9]{10})$') THEN SUBSTR(VWCS.DESTINATION_ID, -11)
                                            WHEN REGEXP_LIKE(VWCS.DESTINATION_ID, '^([0-9]{0,3})7([0-9]{10})$') THEN '8' || SUBSTR(VWCS.DESTINATION_ID, -10)
                                            WHEN REGEXP_LIKE(VWCS.DESTINATION_ID, '^([0-9]{0,3})810([0-9]{8,})$') THEN REGEXP_SUBSTR(VWCS.DESTINATION_ID, '810([0-9]{1,})$')
                                            ELSE VWCS.DESTINATION_ID
                                            END = CI.ABONENT
                                        AND VWCS.ENTERED BETWEEN CI.OPERATOR_CONNECTED AND CI.OPERATOR_ENDED
                WHERE CS.CREATED BETWEEN I_DATE_START AND I_DATE_END
                UNION ALL
                SELECT
                  /*+ MATERIALIZE*/
                  CI.ROWID                                                  AS SYS_RID,
                  PKG_INTERVALS.FNC_INTERVALTOSEC(VWCS.ENTERED, VWCS.ENDED) AS HOLD_DURATION
                FROM CALL_SESSIONS CS
                JOIN CALLS_INFO CI ON CS.SESSION_ID=CI.SESSION_ID AND CS.FID_PLATFORM=CI.FID_PLATFORM
                JOIN SQ_CALL_STATUS VWCS ON VWCS.FID_PLATFORM=CS.FID_PLATFORM AND VWCS.SESSION_ID=CS.SESSION_ID
                                        AND VWCS.INITIATOR_ID=CI.OPERATOR AND VWCS.DESTINATION_ID=SUBSTR(CI.ABONENT, 2)
                                        AND VWCS.ENTERED BETWEEN CI.OPERATOR_CONNECTED AND CI.OPERATOR_ENDED
                WHERE CS.CREATED BETWEEN I_DATE_START AND I_DATE_END
              )
            SELECT SYS_RID,
              SUM(HOLD_DURATION) AS HOLD_DURATION
            FROM SQ_CALLS_HOLD
            GROUP BY SYS_RID
          )
          TMP ON(CI.ROWID=TMP.SYS_RID)
        WHEN MATCHED THEN
          UPDATE SET CI.OPERATOR_HOLD=TMP.HOLD_DURATION;
          V_RESULT.RESULT_NUM:=SQL%ROWCOUNT;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          V_RESULT.RESULT_NUM:=SQLCODE;
          V_RESULT.RESULT_TXT:=V_RESULT.RESULT_TXT||': '||SQLERRM;
          V_RESULT.IS_ERROR:=1;
      END;
      --Результируем время выполнения шага
      V_RESULT.WORK_LOG:=REPLACE(V_RESULT.WORK_LOG, '{time}', PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START, SYSTIMESTAMP)) ;
      --Плучаем цифровой результат
      IF V_RESULT.IS_ERROR=1 THEN
        V_RESULT.WORK_LOG:=REPLACE(V_RESULT.WORK_LOG, '{cnt}', 'error') ;
      ELSE
        V_RESULT.WORK_LOG:=REPLACE(V_RESULT.WORK_LOG, '{cnt}', 'cnt') ;
      END IF;
      V_RESULT.WORK_LOG:=REPLACE(V_RESULT.WORK_LOG, '{val}', TO_CHAR(V_RESULT.RESULT_NUM)) ;
      --Выводим текст шага
      V_RESULT.WORK_LOG:=REPLACE(V_RESULT.WORK_LOG, '{text}', V_RESULT.RESULT_TXT) ;
      RETURN V_RESULT;
    END; --STEP_UPDATE

  BEGIN --FNC_UPDATE_EXT_DATA
    V_RESULT.WORK_START:=SYSTIMESTAMP;
    V_RESULT.WORK_LOG:='';
    V_RESULT.IS_ERROR:=0;
    SELECT DECODE(COUNT(*), 0, 3, 4) INTO V_CALLS FROM TMP_CALL_SESSIONS;
    --Пытаемся обновить информацию для звуков
    FOR I IN 1..V_CALLS
    LOOP
      V_WORK:=STEP_UPDATE_CALLS(I) ;
      V_RESULT.WORK_LOG:=V_RESULT.WORK_LOG || V_WORK.WORK_LOG;
      V_RESULT.IS_ERROR:=GREATEST(V_RESULT.IS_ERROR, V_WORK.IS_ERROR) ;
    END LOOP;
    RETURN V_RESULT;
  END; --FNC_UPDATE_EXT_DATA

  --Получение id проектов из группы
  FUNCTION FNC_PROJECTS_IDS(I_PROJECTS_GROUP T_LIST_VARCHAR,
                            I_SEARCH_SUBGROUP CHAR DEFAULT 'Y',
                            I_PLATFORMS T_LIST_INTEGER DEFAULT NULL,
                            I_ACTIVE NUMBER DEFAULT NULL)
    RETURN PT_PROJECTS_IDS PIPELINED IS

    V_PROJECTS_GROUP VARCHAR2(1000) := NULL;

    CURSOR GET_DATA RETURN PTR_PROJECTS_IDS
    IS
    WITH SQ_GROUP_LIST AS
      (
        SELECT /*+ MATERIALIZE*/ ID_GROUP
        FROM D_GROUPS
        WHERE NVL2(V_PROJECTS_GROUP, ID_GROUP, 1) = NVL(PKG_STRINGS.FNC_TONUMBER(V_PROJECTS_GROUP), NVL2(V_PROJECTS_GROUP, 0, 1))
        UNION ALL
        SELECT ID_GROUP
        FROM D_GROUPS
        WHERE NVL(UPPER(I_SEARCH_SUBGROUP), 'Y') = 'Y'
        START WITH FID_GROUP = PKG_STRINGS.FNC_TONUMBER(V_PROJECTS_GROUP)
        CONNECT BY FID_GROUP = PRIOR ID_GROUP
      )
    SELECT RGP.FID_PROJECT, DG.ID_GROUP, DG.FID_GROUP, VWP.FID_PLATFORM
    FROM REL_GROUP_PROJECTS RGP
    JOIN VW_PROJECTS VWP ON VWP.PROJECT_ID = RGP.FID_PROJECT
                        AND NVL2(I_ACTIVE, VWP.IS_ACTIVE, 1) = NVL(I_ACTIVE, 1)
                        AND EXISTS(
                                    SELECT 1
                                    FROM TABLE(I_PLATFORMS) PLF
                                    WHERE PLF.COLUMN_VALUE = VWP.FID_PLATFORM
                                    UNION ALL
                                    SELECT 1
                                    FROM DUAL
                                    WHERE I_PLATFORMS IS NULL
                                  )
    LEFT JOIN D_GROUPS DG ON DG.ID_GROUP = RGP.FID_GROUP
    WHERE EXISTS(
                  SELECT 1
                  FROM SQ_GROUP_LIST SQGL
                  WHERE RGP.FID_GROUP=SQGL.ID_GROUP
                )
    UNION ALL
    SELECT RGP.FID_PROJECT, DG.ID_GROUP, DG.FID_GROUP, VWP.FID_PLATFORM
    FROM REL_GROUP_PROJECTS RGP
    JOIN VW_PROJECTS VWP ON VWP.PROJECT_ID = RGP.FID_PROJECT
                        AND NVL2(I_ACTIVE, VWP.IS_ACTIVE, 1) = NVL(I_ACTIVE, 1)
                        AND EXISTS(
                                    SELECT 1
                                    FROM TABLE(I_PLATFORMS) PLF
                                    WHERE PLF.COLUMN_VALUE = VWP.FID_PLATFORM
                                    UNION ALL
                                    SELECT 1
                                    FROM DUAL
                                    WHERE I_PLATFORMS IS NULL
                                  )
    LEFT JOIN D_GROUPS DG ON DG.ID_GROUP = RGP.FID_GROUP
    WHERE RGP.FID_PROJECT = V_PROJECTS_GROUP;

  BEGIN --FNC_PROJECTS_IDS
    IF I_PROJECTS_GROUP IS NULL THEN
      FOR R IN GET_DATA LOOP
        PIPE ROW(R);
      END LOOP;
    ELSE
      FOR PG IN (
                  SELECT COLUMN_VALUE AS PROJECT_ID
                  FROM TABLE(I_PROJECTS_GROUP)
                ) LOOP
        V_PROJECTS_GROUP := PG.PROJECT_ID;
        FOR R IN GET_DATA LOOP
          PIPE ROW(R);
        END LOOP;
      END LOOP;
    END IF;
  END; --FNC_PROJECTS_IDS

  FUNCTION FNC_PROJECTS_IDS(I_PROJECTS_GROUP VARCHAR2,
                            I_SEARCH_SUBGROUP CHAR DEFAULT 'Y',
                            I_PLATFORMS VARCHAR2 DEFAULT NULL,
                            I_ACTIVE NUMBER DEFAULT NULL)
    RETURN PT_PROJECTS_IDS PIPELINED IS

    V_PROJECTS_GROUP T_LIST_VARCHAR := NULL;
    V_PLATFORMS T_LIST_INTEGER := NULL;
  BEGIN --FNC_PROJECTS_IDS

    IF I_PROJECTS_GROUP IS NOT NULL THEN
      V_PROJECTS_GROUP := T_LIST_VARCHAR();
      SELECT COLUMN_VALUE BULK COLLECT INTO V_PROJECTS_GROUP
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_PROJECTS_GROUP));
    END IF;

    IF I_PLATFORMS IS NOT NULL THEN
      V_PLATFORMS := T_LIST_INTEGER();
      SELECT PKG_STRINGS.FNC_TONUMBER(COLUMN_VALUE) BULK COLLECT INTO V_PLATFORMS
      FROM TABLE(PKG_STRINGS.FNC_STRTOTBL(I_PLATFORMS))
      WHERE PKG_STRINGS.FNC_TONUMBER(COLUMN_VALUE) IS NOT NULL;
    END IF;

    FOR R IN(
              SELECT *
              FROM TABLE(FNC_PROJECTS_IDS(V_PROJECTS_GROUP, I_SEARCH_SUBGROUP, V_PLATFORMS, I_ACTIVE))
            ) LOOP
        PIPE ROW(R);
    END LOOP;
  END; --FNC_PROJECTS_IDS

  --Получение списка проектов по выбранному в фильтре параметру
  FUNCTION FNC_FILTERED_PROJECTS_IDS(I_PARAM VARCHAR2)
    RETURN PT_PROJECTS_IDS PIPELINED IS

    V_PROJECTS_GROUP VARCHAR2(2000 CHAR);
    V_SEARCH_SUBGROUP CHAR := NULL;
    V_PLATFORMS VARCHAR2(2000 CHAR) := NULL;
    V_ACTIVE NUMBER := NULL;
  BEGIN --FNC_FILTERED_PROJECTS_IDS
    begin
      SELECT
        EXTRACTVALUE(XMLTYPE(I_PARAM),'/group') AS PROJECTS_GROUP,
        EXTRACTVALUE(XMLTYPE(I_PARAM),'/group/@fid_platform') AS FID_PLATFORM,
        EXTRACTVALUE(XMLTYPE(I_PARAM), '/group/@subgroup') AS SUBGROUP,
        EXTRACTVALUE(XMLTYPE(I_PARAM), '/group/@active') AS ACTIVE
        INTO V_PROJECTS_GROUP, V_PLATFORMS, V_SEARCH_SUBGROUP, V_ACTIVE
      FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        V_PROJECTS_GROUP := I_PARAM;
    END;

    FOR R IN(
              SELECT *
              FROM TABLE(FNC_PROJECTS_IDS(V_PROJECTS_GROUP, V_SEARCH_SUBGROUP, V_PLATFORMS, V_ACTIVE))
            ) LOOP
        PIPE ROW(R);
    END LOOP;
  END; --FNC_FILTERED_PROJECTS_IDS

  --Процедура обновления инфорамции по ЗФ
  PROCEDURE SP_UPDATE_CALLS(I_DATE_START TIMESTAMP, I_DATE_END TIMESTAMP,
                            I_FORCE CHAR, I_PLATFORMS T_LIST_INTEGER DEFAULT NULL) IS

    V_RESULT LT_RESULT;
    V_WORK LT_RESULT;
    V_DATE_START TIMESTAMP := I_DATE_START;
    V_DATE_END TIMESTAMP := I_DATE_END;
    V_PLATFORMS T_LIST_INTEGER := I_PLATFORMS;

    --Заливка данных
    FUNCTION LOAD_NAU RETURN LT_RESULT IS
      V_RESULT LT_RESULT;
      V_WORK LT_RESULT;
      V_SUBSTEP_START TIMESTAMP;
      VV_DATE_START TIMESTAMP;

      --Шаги по заливке
      FUNCTION STEP_LOAD(I_STEP NUMBER) RETURN LT_RESULT IS
        V_RESULT LT_RESULT;
        V_WORK LT_RESULT;
        BEGIN
          V_RESULT.WORK_START := SYSTIMESTAMP;
          V_RESULT.WORK_LOG := '<action id="'||TO_CHAR(I_STEP)||'" time="{time}" {cnt}="{val}">{text}</action>';
          V_RESULT.IS_ERROR := 0;
          BEGIN
            IF I_STEP = 1 THEN
              V_RESULT.RESULT_TXT := 'Получаем плечи по звуковым сессиям';
              INSERT INTO TMP_CALL_SESSIONS (SESSION_ID, CREATED, ENDED, FID_PLATFORM, FID_PROVIDER, FID_DIRECTION,
                                             LEG_TYPE, REAL_LEG_ID, IP_ADDRESS, PORT, LEG_CREATED,  LEG_CONNECTED,
                                             LEG_ENDED, LEG_ABONENT, LEG_INTRUSION, LEG_INCOMING, IVR_LEG_ID,
                                             REDIRECTED_LEG_ID, LAST_LEG, INIC_LEG_ID, ABONENT_LEG_ID, BRAKE_CALL,
                                             ENQUEUED_TIME, UNBLOCKED_TIME, DEQUEUED_TIME, BASEID, VOIP_REASON)
              WITH SQ_CALLS AS
                (
                  SELECT /*+ MATERIALIZE*/ *
                  FROM VW_CALL_SESSIONS VWCS
                  WHERE VWCS.ENDED BETWEEN V_DATE_START AND V_DATE_END
                    AND EXISTS(
                                SELECT 1
                                FROM TABLE(V_PLATFORMS) P
                                WHERE VWCS.FID_PLATFORM = TO_NUMBER(P.COLUMN_VALUE)
                              )
                    AND NOT EXISTS(
                                    SELECT /*+ INDEX_JOIN(CS PK_CS_SESSION_ID IDX_CS_FID_PLATFORM)*/ 1
                                    FROM CALL_SESSIONS CS
                                    WHERE VWCS.SESSION_ID = CS.SESSION_ID
                                      AND VWCS.FID_PLATFORM = CS.FID_PLATFORM
                                      AND NVL(UPPER(I_FORCE),'N') = 'N'
                                  )
                ),
                SQ_QUEUED_CALLS AS
                (
                  SELECT /*+ MATERIALIZE*/ *
                  FROM VW_QUEUED_CALLS VWQCI
                  WHERE VWQCI.ENQUEUED_TIME BETWEEN V_DATE_START-1 AND V_DATE_END+1
                    AND EXISTS(
                                SELECT 1
                                FROM TABLE(V_PLATFORMS) P
                                WHERE VWQCI.FID_PLATFORM = TO_NUMBER(P.COLUMN_VALUE)
                              )
                    AND EXISTS(
                                SELECT 1
                                FROM SQ_CALLS SQCF
                                WHERE SQCF.SESSION_ID = VWQCI.SESSION_ID
                                  AND SQCF.FID_PLATFORM = VWQCI.FID_PLATFORM
                              )
                ),
                SQ_ASTERISK AS
                (
                  SELECT DISTINCT CALL_ID,
                    FIRST_VALUE(START_TIME)OVER(PARTITION BY CALL_ID ORDER BY START_TIME DESC) START_TIME,
                    FIRST_VALUE(END_TIME)OVER(PARTITION BY CALL_ID ORDER BY START_TIME DESC) END_TIME,
                    FIRST_VALUE(IP)OVER(PARTITION BY CALL_ID ORDER BY START_TIME DESC) IP,
                    FIRST_VALUE(PORT)OVER(PARTITION BY CALL_ID ORDER BY START_TIME DESC) PORT
                  FROM ASTERISK.CDR
                  WHERE START_TIME BETWEEN CAST(V_DATE_START - 6/24 AS TIMESTAMP) AND V_DATE_END
                    AND FLAG = 1
                ),
                SQ_CALL_LEGS AS
                (
                  SELECT DISTINCT SQC.SESSION_ID, SQC.CREATED, SQC.ENDED, VWCL.FID_PLATFORM,
                    CASE
                      WHEN 'SP' IN (VWCL.SRC_ABONENT_TYPE, VWCL.DST_ABONENT_TYPE) THEN 'operator'
                      WHEN 'IVR' IN (VWCL.SRC_ABONENT_TYPE, VWCL.DST_ABONENT_TYPE) THEN 'ivr'
                      WHEN 'UNKNOWN' IN (VWCL.SRC_ABONENT_TYPE, VWCL.DST_ABONENT_TYPE) THEN '{ext_abonent}'
                    END AS LEG_TYPE,
                    VWCL.LEG_ID AS REAL_LEG,
                    CASE
                      WHEN 'UNKNOWN' = VWCL.DST_ABONENT_TYPE THEN NVL(ACDR.IP, DECODE(VWCL.DST_IP, 'rupost-buddy-main.newcontact.su', '37.221.186.105', VWCL.DST_IP))
                    END AS IP_ADDRESS,
                    CASE
                      WHEN 'UNKNOWN' = VWCL.DST_ABONENT_TYPE THEN NVL(ACDR.PORT, VWCL.DST_PORT)
                    END AS PORT,
                    CASE
                      WHEN 'UNKNOWN' = VWCL.DST_ABONENT_TYPE THEN VWCL.BASE_ID
                    END AS BASEID,
                    VWCL.CREATED AS LEG_CREATED, VWCL.CONNECTED AS LEG_CONNECTED, VWCL.ENDED AS LEG_ENDED,
                    VWCL.INTRUSION AS LEG_INTRUSION,
                    CASE
                      WHEN VWCL.SRC_ABONENT_TYPE = 'IVR' AND VWCL.INCOMING = 1
                      THEN 'DIALER'
                      WHEN VWCL.SRC_ABONENT_TYPE IN ('SP', 'IVR', 'UNKNOWN')
                      THEN NVL( CASE
                                  WHEN INSTR('ivr', VWCL.SRC_ABONENT) = 0 AND INSTR('nauss', VWCL.SRC_ABONENT) = 0
                                  THEN VWCL.SRC_ABONENT
                                END, VWCL.SRC_ID)
                      WHEN VWCL.DST_ABONENT_TYPE IN ('SP', 'IVR', 'UNKNOWN')
                      THEN NVL( CASE
                                  WHEN INSTR(VWCL.DST_ABONENT, 'ivr') = 0 AND INSTR(VWCL.DST_ABONENT, 'nauss') = 0
                                  THEN VWCL.DST_ABONENT
                                END, VWCL.DST_ID)
                    END AS LEG_ABONENT, VWCL.INCOMING AS LEG_INCOMING,
                    VWQCA.IVR_LEG_ID AS IVR_LEG_ID, VWQCI.NEXT_LEG_ID AS REDIRECTED_LEG_ID,
                    CASE
                      WHEN VWCL.INCOMING = 1
                      THEN ROW_NUMBER()OVER(PARTITION BY VWCL.SESSION_ID, VWCL.FID_PLATFORM ORDER BY VWCL.LEG_ID)
                      ELSE VWCL.LEG_ID
                    END AS INC_ROW, TO_CHAR(VWCL.VOIP_REASON) AS VOIP_REASON,
                    VWQCI.ENQUEUED_TIME, VWQCI.UNBLOCKED_TIME, VWQCI.DEQUEUED_TIME
                  FROM VW_CALL_LEGS VWCL
                  LEFT JOIN SQ_CALLS SQC ON SQC.SESSION_ID=VWCL.SESSION_ID
                                        AND SQC.FID_PLATFORM = VWCL.FID_PLATFORM
                  LEFT JOIN SQ_QUEUED_CALLS VWQCI ON VWQCI.SESSION_ID=VWCL.SESSION_ID
                                                  AND VWQCI.FID_PLATFORM=VWCL.FID_PLATFORM
                                                  AND VWQCI.IVR_LEG_ID = VWCL.LEG_ID
                  LEFT JOIN SQ_QUEUED_CALLS VWQCA ON VWQCA.SESSION_ID=VWCL.SESSION_ID
                                                  AND VWQCA.FID_PLATFORM=VWCL.FID_PLATFORM
                                                  AND VWQCA.NEXT_LEG_ID = VWCL.LEG_ID
                  LEFT JOIN SQ_ASTERISK ACDR ON ACDR.CALL_ID = VWCL.BASE_ID
                                            AND VWCL.ENDED BETWEEN ACDR.START_TIME-INTERVAL '10' SECOND  AND ACDR.END_TIME+INTERVAL '10' SECOND
                  WHERE VWCL.CREATED BETWEEN V_DATE_START-1 AND V_DATE_END+1
                    AND EXISTS(
                                SELECT 1
                                FROM TABLE(V_PLATFORMS) P
                                WHERE VWCL.FID_PLATFORM = TO_NUMBER(P.COLUMN_VALUE)
                              )
                    AND EXISTS(
                                SELECT 1
                                FROM SQ_CALLS SQCF
                                WHERE SQCF.SESSION_ID = VWCL.SESSION_ID
                                  AND SQCF.FID_PLATFORM = VWCL.FID_PLATFORM
                              )
                )
              SELECT DISTINCT SQCL.SESSION_ID, SQCL.CREATED, SQCL.ENDED, SQCL.FID_PLATFORM,
                NVL(DPA.FID_PROVIDER, 0), 0, SQCL.LEG_TYPE, SQCL.REAL_LEG, SQCL.IP_ADDRESS,
                SQCL.PORT, SQCL.LEG_CREATED, SQCL.LEG_CONNECTED, SQCL.LEG_ENDED, SQCL.LEG_ABONENT,
                SQCL.LEG_INTRUSION, SQCL.LEG_INCOMING, SQCL.IVR_LEG_ID, SQCL.REDIRECTED_LEG_ID,
                MAX(SQCL.REAL_LEG)OVER(PARTITION BY SQCL.FID_PLATFORM, SQCL.SESSION_ID),
                DECODE(COUNT(SQCL.REAL_LEG)OVER(PARTITION BY SQCL.FID_PLATFORM, SQCL.SESSION_ID), 1, SQCL.REAL_LEG),
                DECODE(COUNT(SQCL.REAL_LEG)OVER(PARTITION BY SQCL.FID_PLATFORM, SQCL.SESSION_ID), 1, SQCL.REAL_LEG),
                SQCL.VOIP_REASON||REPLACE('[abonent,caller,called,ivr,operator]',SQCL.LEG_TYPE, SQCL.VOIP_REASON),
                SQCL.ENQUEUED_TIME, SQCL.UNBLOCKED_TIME, SQCL.DEQUEUED_TIME, SQCL.BASEID, SQCL.VOIP_REASON
              FROM SQ_CALL_LEGS SQCL
              LEFT JOIN D_PROVIDER_ADDRESSES DPA ON DPA.IP_ADDRESS=SQCL.IP_ADDRESS
                                                AND DPA.PORT=SQCL.PORT
                                                AND SQCL.CREATED BETWEEN DPA.CREATED AND DPA.BLOCKED
              WHERE SQCL.INC_ROW IN (SQCL.REAL_LEG, SQCL.LEG_INCOMING);

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;

              SELECT NVL(MIN(CREATED), I_DATE_START) INTO V_DATE_START
              FROM TMP_CALL_SESSIONS;

              UPDATE TMP_CALL_SESSIONS TCS SET
                IVR_NUMBER = DECODE(TCS.LEG_TYPE, 'ivr', nvl(LEG_ABONENT,'DIALER')),
                IVR_CREATED = DECODE(TCS.LEG_TYPE, 'ivr', LEG_CREATED),
                IVR_CONNECTED = DECODE(TCS.LEG_TYPE, 'ivr', LEG_CONNECTED),
                IVR_ENDED = DECODE(TCS.LEG_TYPE, 'ivr', LEG_ENDED),
                OPERATOR = DECODE(TCS.LEG_TYPE, 'operator', LEG_ABONENT, '{ext_abonent}', '{ext_abonent}'),
                OPERATOR_CREATED = CASE WHEN TCS.LEG_TYPE IN ('operator', '{ext_abonent}') THEN LEG_CREATED END,
                OPERATOR_CONNECTED = CASE WHEN TCS.LEG_TYPE IN ('operator', '{ext_abonent}') THEN LEG_CONNECTED END,
                OPERATOR_ENDED = CASE WHEN TCS.LEG_TYPE IN ('operator', '{ext_abonent}') THEN LEG_ENDED END;
            ELSIF I_STEP = 2 THEN
              V_RESULT.RESULT_TXT := 'Проставляем IVR, абонентов, инициаторов';
              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                WITH SQ_LINKS_PRP AS
                  (
                    SELECT /*+ MATERIALIZE*/
                      TCS.ROWID AS SYS_ROWID, TCS.SESSION_ID, TCS.CREATED, TCS.ENDED, TCS.FID_PLATFORM,
                      TCS.FID_PROVIDER, TCS.FID_DIRECTION, TCS.DIRECTION, TCS.LEG_TYPE, TCS.REAL_LEG_ID, TCS.LEG_CREATED,
                      TCS.LEG_CONNECTED, TCS.LEG_ENDED, TCS.LEG_ABONENT, TCS.LEG_INCOMING, TCS.LEG_INTRUSION, TCS.LAST_LEG,
                      NVL(
                          LAG(CASE
                                WHEN TCS.LEG_CONNECTED IS NOT NULL
                                THEN DECODE(TCS.LEG_TYPE, 'ivr', TCS.REAL_LEG_ID, 0)
                              END IGNORE NULLS)OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM ORDER BY TCS.REAL_LEG_ID),
                          FIRST_VALUE(CASE
                                        WHEN TCS.LEG_TYPE='ivr'
                                        THEN TCS.REAL_LEG_ID
                                        ELSE 0
                                      END IGNORE NULLS)OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM ORDER BY TCS.REAL_LEG_ID)
                        )AS IVR_LEG_ID,
                      TCS.INIC_LEG_ID,
                      COALESCE(
                                FIRST_VALUE(CASE WHEN TCS.LEG_TYPE='{ext_abonent}' THEN TCS.REAL_LEG_ID END IGNORE NULLS)
                                  OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM ORDER BY TCS.REAL_LEG_ID),
                                FIRST_VALUE(CASE WHEN TCS.LEG_TYPE='operator' and TCS.LEG_INCOMING = 0 THEN TCS.REAL_LEG_ID END IGNORE NULLS)
                                  OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM ORDER BY TCS.REAL_LEG_ID),
                                TCS.ABONENT_LEG_ID
                              )AS ABONENT_LEG_ID,
                      TCS.REDIRECTED_LEG_ID, TCS.IP_ADDRESS, TCS.PORT,
                      ROW_NUMBER()OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM ORDER BY TCS.REAL_LEG_ID) AS LEG_NUM,
                      CASE
                        WHEN COUNT(TCS.REAL_LEG_ID)OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM) = 1
                          AND TCS.LEG_TYPE='{ext_abonent}' THEN 1
                      END AS CLR_OPR
                    FROM TMP_CALL_SESSIONS TCS
                  ),
                  SQ_LINKS AS
                  (
                    SELECT SQLK.SYS_ROWID, SQLK.SESSION_ID, SQLK.CREATED, SQLK.ENDED, SQLK.FID_PLATFORM,
                      SQLK.FID_PROVIDER, SQLK.FID_DIRECTION, SQLK.DIRECTION, SQLK.LEG_TYPE, SQLK.REAL_LEG_ID,
                      SQLK.LEG_CREATED, SQLK.LEG_CONNECTED, SQLK.LEG_ENDED, SQLK.LEG_ABONENT, SQLK.LEG_INCOMING,
                      SQLK.LEG_INTRUSION, SQLK.LAST_LEG, NVL2(SQLKC.SESSION_ID, 0, SQLK.IVR_LEG_ID) AS IVR_LEG_ID,
                      SQLK.INIC_LEG_ID, SQLK.ABONENT_LEG_ID, SQLK.REDIRECTED_LEG_ID, SQLK.IP_ADDRESS, SQLK.PORT,
                      SQLK.LEG_NUM, SQLK.CLR_OPR
                    FROM SQ_LINKS_PRP SQLK
                    LEFT JOIN SQ_LINKS_PRP SQLKC ON SQLKC.SESSION_ID = SQLK.SESSION_ID
                                                AND SQLKC.FID_PLATFORM = SQLK.FID_PLATFORM
                                                AND SQLKC.REAL_LEG_ID = SQLK.IVR_LEG_ID
                                                AND SQLKC.LEG_ABONENT = SQLK.LEG_ABONENT
                  )
                SELECT DISTINCT SQLN.SYS_ROWID,
                  CASE
                    WHEN SQLN.LEG_TYPE != 'ivr'
                    THEN DECODE(SQLN.IVR_LEG_ID, 0, NULL, SQLN.IVR_LEG_ID)
                  END AS IVR_LEG_ID,
                  COALESCE( CASE
                              WHEN SQLN.LEG_TYPE = 'ivr'
                              THEN DECODE(SQLN.IVR_LEG_ID, 0, TO_NUMBER(NULL), SQLN.IVR_LEG_ID)
                            END, MAX(TCSI.REAL_LEG_ID)OVER(PARTITION BY SQLN.SYS_ROWID), SQLN.INIC_LEG_ID) AS INIC_LEG_ID,
                  SQLN.ABONENT_LEG_ID, SQLN.CLR_OPR
                FROM SQ_LINKS SQLN
                LEFT JOIN TMP_CALL_SESSIONS TCSI ON TCSI.SESSION_ID=SQLN.SESSION_ID
                                                AND TCSI.FID_PLATFORM=SQLN.FID_PLATFORM
                                                AND TCSI.REAL_LEG_ID < SQLN.REAL_LEG_ID
                                                AND SQLN.LEG_CREATED BETWEEN DECODE(TCSI.LEG_INCOMING, 1, TCSI.LEG_CREATED, TCSI.LEG_CONNECTED) AND TCSI.LEG_ENDED
                                                AND TCSI.LEG_INTRUSION = 0
                                                AND CASE
                                                      WHEN TCSI.LEG_INCOMING = 1
                                                        OR TCSI.LEG_TYPE = 'operator'
                                                      THEN '*'
                                                      ELSE TCSI.LEG_TYPE
                                                    END NOT IN ('ivr', SQLN.LEG_TYPE)
                WHERE CASE WHEN SQLN.LEG_NUM > 2 THEN TCSI.LEG_ABONENT ELSE '*' END != 'DIALER'
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.IVR_LEG_ID=TMP.IVR_LEG_ID,
                  TCS.INIC_LEG_ID=TMP.INIC_LEG_ID,
                  TCS.ABONENT_LEG_ID=TMP.ABONENT_LEG_ID,
                  TCS.CALLED = NVL2(TMP.CLR_OPR, '*', TCS.CALLED),
                  TCS.OPERATOR_CREATED = NVL2(TMP.CLR_OPR, NULL, TCS.OPERATOR_CREATED),
                  TCS.OPERATOR_ENDED = NVL2(TMP.CLR_OPR, NULL, TCS.OPERATOR_ENDED);

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 3 THEN
              V_RESULT.RESULT_TXT := 'Определяем IVR оценки качества';
              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                WITH SQ_PARAMS AS
                  (
                    SELECT /*+ MATERIALIZE*/*
                    FROM VW_CALL_PARAMS VCP
                    WHERE VCP.CHANGED BETWEEN V_DATE_START AND V_DATE_END+1
                      AND EXISTS(
                                  SELECT 1
                                  FROM TMP_CALL_SESSIONS TCS
                                  WHERE VCP.SESSION_ID=TCS.SESSION_ID
                                    AND VCP.FID_PLATFORM=TCS.FID_PLATFORM
                                    AND UPPER(VCP.PARAM_NAME)='QUALITY_CONTROL'
                                    AND VCP.PARAM_VALUE not in ('0', '-1')
                                )
                  ),
                  SQ_DATA AS
                  (
                    SELECT /*+ MATERIALIZE*/
                      DISTINCT TCS.ROWID AS SYS_ROWID,
                      NVL2(SQP.SESSION_ID, 1, 0) AS IS_QUALITY_CONTROL
                    FROM TMP_CALL_SESSIONS TCS
                    LEFT JOIN SQ_PARAMS SQP ON SQP.SESSION_ID=TCS.SESSION_ID
                                            AND SQP.FID_PLATFORM=TCS.FID_PLATFORM
                                            AND SQP.CHANGED BETWEEN TCS.LEG_CREATED AND TCS.LEG_ENDED
                                            AND TCS.LEG_TYPE='ivr'
                  )
                SELECT *
                FROM SQ_DATA
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.IS_QUALITY_CONTROL = TMP.IS_QUALITY_CONTROL;

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;

              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                WITH SQ_PARAMS AS
                  (
                    SELECT /*+ MATERIALIZE*/*
                    FROM VW_CALL_PARAMS VCP
                    WHERE VCP.CHANGED BETWEEN V_DATE_START AND V_DATE_END+1
                      AND EXISTS(
                                  SELECT 1
                                  FROM TMP_CALL_SESSIONS TCS
                                  WHERE VCP.SESSION_ID=TCS.SESSION_ID
                                    AND VCP.FID_PLATFORM=TCS.FID_PLATFORM
                                    AND UPPER(VCP.PARAM_NAME)='QUALITY_CONTROL_NUMBER'
                                    AND TRIM(VCP.PARAM_VALUE) = TRIM(TCS.LEG_ABONENT)
                                )
                  ),
                  SQ_DATA AS
                  (
                    SELECT /*+ MATERIALIZE*/
                      DISTINCT TCS.ROWID AS SYS_RID, 1 AS IS_QUALITY_CONTROL
                    FROM TMP_CALL_SESSIONS TCS
                    JOIN SQ_PARAMS VWCP ON VWCP.SESSION_ID=TCS.SESSION_ID
                                            AND VWCP.FID_PLATFORM=TCS.FID_PLATFORM
                                            AND TRIM(VWCP.PARAM_VALUE) = TRIM(TCS.LEG_ABONENT)
                    WHERE TCS.LEG_TYPE = 'ivr'
                      AND NVL(TCS.IS_QUALITY_CONTROL, 0) = 0
                  )
                SELECT *
                FROM SQ_DATA
              )TMP
              ON (TCS.ROWID = TMP.SYS_RID)
              WHEN MATCHED THEN
                UPDATE SET TCS.IS_QUALITY_CONTROL = TMP.IS_QUALITY_CONTROL;

              V_RESULT.RESULT_NUM := V_RESULT.RESULT_NUM+SQL%ROWCOUNT;
            ELSIF I_STEP = 4 THEN
              V_RESULT.RESULT_TXT := 'Проставляем плечи перенаправления';
              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                WITH SQ_DATA AS
                  (
                    SELECT /*+ MATERIALIZE*/ DISTINCT TCS.ROWID AS SYS_ROWID,
                      MAX(TCSR.REAL_LEG_ID)OVER(PARTITION BY TCS.ROWID) AS REDIRECTED_LEG_ID
                    FROM TMP_CALL_SESSIONS TCS
                    JOIN TMP_CALL_SESSIONS TCSR ON TCSR.SESSION_ID=TCS.SESSION_ID
                                                AND TCSR.FID_PLATFORM=TCS.FID_PLATFORM
                                                AND TCS.REAL_LEG_ID IN (TCSR.IVR_LEG_ID, TCSR.INIC_LEG_ID)
                                                AND TCSR.IS_QUALITY_CONTROL = 0
                                                AND TCS.REDIRECTED_LEG_ID IS NULL
                                                AND (
                                                      TCSR.LEG_INTRUSION = 0
                                                      OR TCSR.OPERATOR_ENDED > TCS.OPERATOR_ENDED+INTERVAL '2' SECOND
                                                    )
                  )
                SELECT * FROM SQ_DATA
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.REDIRECTED_LEG_ID = DECODE(TCS.REAL_LEG_ID, TMP.REDIRECTED_LEG_ID, NULL, TMP.REDIRECTED_LEG_ID);

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;

              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                WITH SQ_DATA AS
                  (
                    SELECT /*+ MATERIALIZE*/ DISTINCT TCS.ROWID AS SYS_ROWID,
                      GREATEST(TCS.REDIRECTED_LEG_ID, NVL(TCSR.REDIRECTED_LEG_ID, -1)) AS REDIRECTED_LEG_ID
                    FROM TMP_CALL_SESSIONS TCS
                    JOIN TMP_CALL_SESSIONS TCSR ON TCSR.SESSION_ID=TCS.SESSION_ID
                                                AND TCSR.FID_PLATFORM=TCS.FID_PLATFORM
                                                AND TCSR.REAL_LEG_ID=TCS.REDIRECTED_LEG_ID
                                                AND TCSR.LEG_INCOMING=1
                  )
                SELECT * FROM SQ_DATA
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.REDIRECTED_LEG_ID = TMP.REDIRECTED_LEG_ID;

              V_RESULT.RESULT_NUM := V_RESULT.RESULT_NUM+SQL%ROWCOUNT;

              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                WITH SQ_DATA AS
                  (
                    SELECT /*+ MATERIALIZE*/ DISTINCT TCS.ROWID AS SYS_ROWID,
                      GREATEST(TCS.REDIRECTED_LEG_ID, NVL(TCSR.REDIRECTED_LEG_ID, -1)) AS REDIRECTED_LEG_ID
                    FROM TMP_CALL_SESSIONS TCS
                    JOIN TMP_CALL_SESSIONS TCSR ON TCSR.SESSION_ID=TCS.SESSION_ID
                                                AND TCSR.FID_PLATFORM=TCS.FID_PLATFORM
                                                AND TCSR.REAL_LEG_ID=TCS.REDIRECTED_LEG_ID
                                                and TCS.LEG_TYPE!='ivr'
                                                AND TCSR.LEG_TYPE='ivr'
                  )
                SELECT * FROM SQ_DATA
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.REDIRECTED_LEG_ID = TMP.REDIRECTED_LEG_ID;

              V_RESULT.RESULT_NUM := V_RESULT.RESULT_NUM+SQL%ROWCOUNT;
            ELSIF I_STEP = 5 THEN
              V_RESULT.RESULT_TXT := 'Проставляем направления';
              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                SELECT DISTINCT TCS.SESSION_ID, TCS.FID_PLATFORM,
                  CASE
                    WHEN FIRST_VALUE(TCS.LEG_TYPE)OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM ORDER BY TCS.REAL_LEG_ID)='{ext_abonent}'
                    THEN 'IN'
                    WHEN FIRST_VALUE(TCS.LEG_TYPE)OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM ORDER BY TCS.REAL_LEG_ID)='operator'
                      AND FIRST_VALUE(TCSR.LEG_TYPE)OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM ORDER BY TCS.REAL_LEG_ID)='{ext_abonent}'
                    THEN 'OUT'
                    WHEN FIRST_VALUE(TCS.LEG_TYPE)OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM ORDER BY TCS.REAL_LEG_ID)='operator'
                    THEN 'INTERNAL'
                    WHEN FIRST_VALUE(TCS.LEG_TYPE)OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM ORDER BY TCS.REAL_LEG_ID)='ivr'
                    THEN 'DIALER'
                  END AS DIRECTION
                FROM TMP_CALL_SESSIONS TCS
                LEFT JOIN TMP_CALL_SESSIONS TCSR ON TCSR.SESSION_ID=TCS.SESSION_ID
                                                AND TCSR.FID_PLATFORM=TCS.FID_PLATFORM
                                                AND TCSR.REAL_LEG_ID=TCS.REDIRECTED_LEG_ID
              )TMP
              ON(TMP.SESSION_ID=TCS.SESSION_ID AND TMP.FID_PLATFORM=TCS.FID_PLATFORM)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.DIRECTION = TMP.DIRECTION;

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 6 THEN
              V_RESULT.RESULT_TXT := 'Проставляем IVR';
              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                WITH SQ_QUEUED_CALLS AS
                (
                  SELECT /*+ MATERIALIZE*/
                    VQC.SESSION_ID, VQC.FID_PLATFORM, VQC.IVR_LEG_ID, VQC.FINAL_STAGE,
                    VQC.ENQUEUED_TIME, VQC.UNBLOCKED_TIME, VQC.DEQUEUED_TIME, VQC.PROJECT_ID
                  FROM VW_QUEUED_CALLS VQC
                  WHERE VQC.ENQUEUED_TIME BETWEEN V_DATE_START-1 AND V_DATE_END+1
                    AND EXISTS(
                                SELECT 1 FROM TMP_CALL_SESSIONS TCS
                                WHERE TCS.SESSION_ID = VQC.SESSION_ID
                                AND TCS.FID_PLATFORM = VQC.FID_PLATFORM
                                AND TCS.IVR_LEG_ID = VQC.IVR_LEG_ID
                               )
                )
                SELECT
                  DISTINCT TCS.ROWID AS SYS_ROWID, TCSI.IVR_NUMBER, TCSI.IVR_CREATED, TCSI.IVR_CONNECTED, TCSI.IVR_ENDED,
                  FIRST_VALUE(VQC.ENQUEUED_TIME IGNORE NULLS)OVER(PARTITION BY TCS.ROWID ORDER BY NVL(VQC.UNBLOCKED_TIME, VQC.DEQUEUED_TIME)) AS ENQUEUED_TIME,
                  FIRST_VALUE(VQC.UNBLOCKED_TIME IGNORE NULLS)OVER(PARTITION BY TCS.ROWID ORDER BY NVL(VQC.UNBLOCKED_TIME, VQC.DEQUEUED_TIME)) AS UNBLOCKED_TIME,
                  FIRST_VALUE(VQC.DEQUEUED_TIME IGNORE NULLS)OVER(PARTITION BY TCS.ROWID ORDER BY NVL(VQC.UNBLOCKED_TIME, VQC.DEQUEUED_TIME) DESC) AS DEQUEUED_TIME,
                  REPLACE(TCS.BRAKE_CALL, 'ivr', SUBSTR(TCSI.BRAKE_CALL, 1, INSTR(TCSI.BRAKE_CALL, '[')-1)) AS BRAKE_CALL,
                  FIRST_VALUE(VQC.PROJECT_ID IGNORE NULLS)OVER(PARTITION BY TCS.ROWID ORDER BY NVL(VQC.UNBLOCKED_TIME, VQC.DEQUEUED_TIME) DESC) AS FID_PROJECT,
                  CASE
                    WHEN TCSI.IVR_ENDED = TCS.OPERATOR_ENDED
                      OR TCS.OPERATOR_CONNECTED IS NOT NULL
                    THEN 'operator'
                    ELSE FIRST_VALUE(VQC.FINAL_STAGE IGNORE NULLS)OVER(PARTITION BY TCS.ROWID ORDER BY NVL(VQC.UNBLOCKED_TIME, VQC.DEQUEUED_TIME) DESC)
                  END AS FINAL_STAGE
                FROM TMP_CALL_SESSIONS TCS
                JOIN TMP_CALL_SESSIONS TCSI ON TCSI.SESSION_ID=TCS.SESSION_ID
                                            AND TCSI.FID_PLATFORM=TCS.FID_PLATFORM
                                            AND TCSI.REAL_LEG_ID=TCS.IVR_LEG_ID
                LEFT JOIN SQ_QUEUED_CALLS VQC ON VQC.SESSION_ID=TCS.SESSION_ID
                                              AND VQC.FID_PLATFORM=TCS.FID_PLATFORM
                                              AND VQC.IVR_LEG_ID=TCS.IVR_LEG_ID
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.IVR_NUMBER = TMP.IVR_NUMBER,
                  TCS.IVR_CREATED = TMP.IVR_CREATED,
                  TCS.IVR_CONNECTED = TMP.IVR_CONNECTED,
                  TCS.IVR_ENDED = TMP.IVR_ENDED,
                  TCS.ENQUEUED_TIME = TMP.ENQUEUED_TIME,
                  TCS.UNBLOCKED_TIME = TMP.UNBLOCKED_TIME,
                  TCS.DEQUEUED_TIME = TMP.DEQUEUED_TIME,
                  TCS.FID_PROJECT = TMP.FID_PROJECT,
                  TCS.FINAL_STAGE = NVL(TMP.FINAL_STAGE, DECODE(TCS.LEG_TYPE, 'ivr', 'ivr')),
                  TCS.BRAKE_CALL = TMP.BRAKE_CALL;

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 7 THEN
              V_RESULT.RESULT_TXT := 'Проставляем абонента';
              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                WITH SQ_CALL_LEGS AS
                  (
                    SELECT /*+ MATERIALIZE*/ *
                    FROM VW_CALL_LEGS VCL
                    WHERE VCL.CREATED BETWEEN V_DATE_START AND V_DATE_END+1
                      AND EXISTS(
                                  SELECT 1
                                  FROM TMP_CALL_SESSIONS FTCS
                                  WHERE FTCS.SESSION_ID = VCL.SESSION_ID
                                    AND FTCS.FID_PLATFORM = VCL.FID_PLATFORM
                                    AND VCL.LEG_ID = FTCS.ABONENT_LEG_ID
                                )
                  ),
                  SQ_DATA AS
                  (
                    SELECT /*+ MATERIALIZE*/ DISTINCT TCS.ROWID AS SYS_ROWID,
                      REPLACE(TCS.BRAKE_CALL, 'abonent', SUBSTR(TCSA.BRAKE_CALL, 1, INSTR(TCSA.BRAKE_CALL, '[')-1)) AS BRAKE_CALL,
                      NVL(CASE
                            WHEN TCS.DIRECTION = 'IN' THEN VCL.SRC_ID
                            WHEN INSTR(VCL.DST_ABONENT, 'ivr') = 0 AND INSTR(VCL.DST_ABONENT, 'nauss') = 0
                            THEN NVL(VCL.DST_ABONENT, VCL.DST_ID)
                            ELSE VCL.DST_ID
                          END, TCSA.LEG_ABONENT) AS ABONENT,
                      DECODE(TCS.DIRECTION, 'DIALER', TCSA.IP_ADDRESS, TCS.IP_ADDRESS) AS IP_ADDRESS,
                      DECODE(TCS.DIRECTION, 'DIALER', TCSA.PORT, TCS.PORT) AS PORT,
                      DECODE(TCS.DIRECTION, 'DIALER', TCSA.FID_PROVIDER, TCS.FID_PROVIDER) AS FID_PROVIDER,
                      DECODE(TCS.DIRECTION, 'DIALER', TCSA.BASEID, TCS.BASEID) AS BASEID
                    FROM TMP_CALL_SESSIONS TCS
                    JOIN TMP_CALL_SESSIONS TCSA ON TCSA.SESSION_ID=TCS.SESSION_ID
                                                AND TCSA.FID_PLATFORM=TCS.FID_PLATFORM
                                                AND TCSA.REAL_LEG_ID=TCS.ABONENT_LEG_ID
                    LEFT JOIN SQ_CALL_LEGS VCL ON TCS.REAL_LEG_ID=TCS.ABONENT_LEG_ID
                                              AND TCS.REAL_LEG_ID=TCS.INIC_LEG_ID
                                              AND VCL.SESSION_ID=TCS.SESSION_ID
                                              AND VCL.FID_PLATFORM=TCS.FID_PLATFORM
                                              AND VCL.LEG_ID=TCS.ABONENT_LEG_ID
                  )
                SELECT SYS_ROWID, BRAKE_CALL,
                  CASE
                    WHEN REPLACE(ABONENT, '+', '810') LIKE '810%'
                      OR REGEXP_REPLACE(REPLACE(ABONENT, '+', '810'),'[^[[:digit:]]]*') IS NULL
                      OR LENGTH(REPLACE(ABONENT, '+', '810')) < 10
                    THEN REPLACE(ABONENT, '+', '810')
                    ELSE '8'||SUBSTR(REPLACE(ABONENT, '+', '810'),-10)
                  END AS ABONENT,
                  IP_ADDRESS, PORT, FID_PROVIDER, BASEID
                FROM SQ_DATA
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.ABONENT = TMP.ABONENT,
                  TCS.IP_ADDRESS = TMP.IP_ADDRESS,
                  TCS.PORT = TMP.PORT,
                  TCS.FID_PROVIDER = TMP.FID_PROVIDER,
                  TCS.BASEID = TMP.BASEID,
                  TCS.BRAKE_CALL = TMP.BRAKE_CALL;

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 8 THEN
              V_RESULT.RESULT_TXT := 'Корректируем операторов';
              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                SELECT DISTINCT TCS.ROWID AS SYS_ROWID,
                  CASE
                    WHEN TCS.IVR_NUMBER='DIALER' THEN NULL
                    WHEN TCS.OPERATOR='{ext_operator}' OR TCS.DIRECTION IN ('OUT', 'INTERNAL')
                    THEN FIRST_VALUE(TCS.OPERATOR)OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM
                                                        ORDER BY TCS.REAL_LEG_ID)
                    ELSE TCS.OPERATOR
                  END AS OPERATOR,
                  NVL (
                        DECODE(IVR_NUMBER, 'DIALER', NULL, TCS.OPERATOR_CREATED),
                        CASE WHEN TCS.DIRECTION IN ('OUT', 'INTERNAL') THEN NVL(TCS.OPERATOR_CREATED, TCS.IVR_CREATED) END
                      )AS OPERATOR_CREATED,
                  NVL (
                        DECODE(IVR_NUMBER, 'DIALER', NULL, TCS.OPERATOR_CONNECTED),
                        CASE WHEN TCS.DIRECTION IN ('OUT', 'INTERNAL') THEN NVL(TCS.OPERATOR_CONNECTED, TCS.IVR_CONNECTED) END
                      )AS OPERATOR_CONNECTED,
                  NVL (
                        DECODE(IVR_NUMBER, 'DIALER', NULL, TCS.OPERATOR_ENDED),
                        CASE WHEN TCS.DIRECTION IN ('OUT', 'INTERNAL') THEN NVL(TCS.OPERATOR_ENDED, TCS.IVR_ENDED) END
                      )AS OPERATOR_ENDED,
                  DECODE(IVR_NUMBER, 'DIALER', 'dialer', TCS.FINAL_STAGE) AS FINAL_STAGE
                FROM TMP_CALL_SESSIONS TCS
                WHERE TCS.DIRECTION IN ('OUT', 'INTERNAL', 'DIALER')
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.OPERATOR = TMP.OPERATOR,
                  TCS.OPERATOR_CREATED = TMP.OPERATOR_CREATED,
                  TCS.OPERATOR_CONNECTED = TMP.OPERATOR_CONNECTED,
                  TCS.OPERATOR_ENDED = TMP.OPERATOR_ENDED,
                  TCS.FINAL_STAGE = TMP.FINAL_STAGE;

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 9 THEN
              V_RESULT.RESULT_TXT := 'Проставляем звонящего и куда звонит';
              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                SELECT DISTINCT TCS.ROWID AS SYS_ROWID, TCS.SESSION_ID,
                  NVL(DECODE(TCSI.LEG_TYPE, 'operator', TCSI.OPERATOR, TCSI.LEG_ABONENT), TCSI.IVR_NUMBER) AS CALLER,
                  REPLACE (
                            REPLACE(TCS.BRAKE_CALL, 'caller', SUBSTR(TCSI.BRAKE_CALL, 1, INSTR(TCSI.BRAKE_CALL, '[')-1)),
                            DECODE(TCS.DIRECTION, 'OUT', 'operator', 'INTERNAL', 'operator'),
                            SUBSTR(TCSI.BRAKE_CALL, 1, INSTR(TCSI.BRAKE_CALL, '[')-1)
                          ) AS BRAKE_CALL,
                  CASE
                    WHEN TCS.REAL_LEG_ID=TCS.ABONENT_LEG_ID
                      AND TCS.REAL_LEG_ID=TCS.INIC_LEG_ID
                      AND TCS.DIRECTION != 'IN'
                    THEN TCS.ABONENT
                    ELSE TCS.LEG_ABONENT
                  END AS CALLED
                FROM TMP_CALL_SESSIONS TCS
                LEFT JOIN TMP_CALL_SESSIONS TCSI ON TCSI.SESSION_ID=TCS.SESSION_ID
                                                AND TCSI.FID_PLATFORM=TCS.FID_PLATFORM
                                                AND TCSI.REAL_LEG_ID=TCS.INIC_LEG_ID
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.CALLER = TMP.CALLER,
                  TCS.CALLED = DECODE(TCS.CALLED, '*', NULL, TMP.CALLED),
                  TCS.BRAKE_CALL = TMP.BRAKE_CALL;

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 10 THEN
              V_RESULT.RESULT_TXT := 'Удаляем звонящих';
              UPDATE TMP_CALL_SESSIONS SET REDIRECTED_LEG_ID = -1
              WHERE REDIRECTED_LEG_ID IS NULL;
              DELETE FROM TMP_CALL_SESSIONS
              WHERE REDIRECTED_LEG_ID > -1
                AND (
                      LEG_INCOMING = 1
                      OR CALLER='DIALER'
                    );

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 11 THEN
              V_RESULT.RESULT_TXT := 'Удаляем лишние IVR';
              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                SELECT DISTINCT TCS.ROWID AS SYS_ROWID, NVL(TCSI.REAL_LEG_ID, -1) AS IVR_LEG_ID,
                  NVL(TCS.FINAL_STAGE, DECODE(TCS.LEG_TYPE, 'ivr', 'ivr'))||
                    NVL2(TCSI.REAL_LEG_ID, '\redirect',NULL) AS FINAL_STAGE
                FROM TMP_CALL_SESSIONS TCS
                LEFT JOIN TMP_CALL_SESSIONS TCSI ON TCSI.SESSION_ID=TCS.SESSION_ID
                                                AND TCSI.FID_PLATFORM=TCS.FID_PLATFORM
                                                AND TCSI.REAL_LEG_ID=TCS.REDIRECTED_LEG_ID
                                                AND TCSI.LEG_TYPE=TCS.LEG_TYPE
                                                AND TCS.LEG_TYPE='ivr'
                WHERE TCS.IVR_LEG_ID IS NULL
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.IVR_LEG_ID = TMP.IVR_LEG_ID,
                  TCS.FINAL_STAGE = TMP.FINAL_STAGE;

              DELETE FROM TMP_CALL_SESSIONS
              WHERE IVR_LEG_ID = -1
                AND REDIRECTED_LEG_ID > -1
                AND LEG_TYPE='ivr';

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 12 THEN
              V_RESULT.RESULT_TXT := 'Проставляем проекты по параметрам звонка';
              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                WITH SQ_QUE_CALLS AS
                  (
                    SELECT /*+ MATERIALIZE*/
                      SESSION_ID, IVR_LEG_ID, PROJECT_ID, FID_PLATFORM, ENQUEUED_TIME
                    FROM VW_QUEUED_CALLS VQC
                    WHERE ENQUEUED_TIME BETWEEN V_DATE_START AND V_DATE_END+1
                      AND EXISTS(
                                  SELECT 1
                                  FROM TMP_CALL_SESSIONS TCS
                                  WHERE VQC.SESSION_ID=TCS.SESSION_ID
                                    AND VQC.FID_PLATFORM=TCS.FID_PLATFORM
                                    AND TCS.FID_PROJECT IS NULL
                                )
                  ),
                  SQ_DATA AS
                  (
                    SELECT /*+ MATERIALIZE*/DISTINCT TCS.ROWID AS SYS_ROWID,
                      FIRST_VALUE(VQC.PROJECT_ID)OVER(PARTITION BY TCS.ROWID ORDER BY vqc.ENQUEUED_TIME DESC) AS FID_PROJECT
                    FROM TMP_CALL_SESSIONS TCS
                    JOIN SQ_QUE_CALLS VQC ON VQC.SESSION_ID=TCS.SESSION_ID
                                          AND VQC.FID_PLATFORM=TCS.FID_PLATFORM
                                          AND VQC.IVR_LEG_ID=TCS.REAL_LEG_ID
                    WHERE TCS.FID_PROJECT IS NULL
                  )
                SELECT *
                FROM SQ_DATA
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.FID_PROJECT = TMP.FID_PROJECT;

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;

              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                WITH SQ_DATA AS
                  (
                    SELECT /*+ MATERIALIZE*/ TCS.ROWID AS SYS_ROWID, TCSI.FID_PROJECT
                    FROM TMP_CALL_SESSIONS TCS
                    JOIN TMP_CALL_SESSIONS TCSI ON TCSI.SESSION_ID=TCS.SESSION_ID
                                                AND TCSI.FID_PLATFORM=TCS.FID_PLATFORM
                                                AND TCSI.REAL_LEG_ID=TCS.INIC_LEG_ID
                                                AND TCSI.FID_PROJECT IS NOT NULL
                                                AND TCS.FID_PROJECT IS NULL
                                                AND TCS.LEG_TYPE = '{ext_abonent}'
                  )
                SELECT *
                FROM SQ_DATA
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.FID_PROJECT = TMP.FID_PROJECT;

              V_RESULT.RESULT_NUM := V_RESULT.RESULT_NUM+SQL%ROWCOUNT;

              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                WITH SQ_PARAMS AS
                  (
                    SELECT CP.SESSION_ID, CP.FID_PLATFORM, CP.CHANGED, CP.PARAM_VALUE
                    FROM NC_CORE.VW_CALL_PARAMS CP
                    WHERE CP.CHANGED BETWEEN V_DATE_START AND V_DATE_END+1
                      AND UPPER(CP.PARAM_NAME) = 'PROJECTID'
                  ),
                  SQ_DATA AS
                  (
                    SELECT DISTINCT TCS.ROWID AS SYS_ROWID,
                      FIRST_VALUE(VCP.PARAM_VALUE)OVER(PARTITION BY TCS.ROWID ORDER BY VCP.CHANGED DESC) AS FID_PROJECT
                    FROM TMP_CALL_SESSIONS TCS
                      LEFT JOIN SQ_PARAMS VCP ON VCP.SESSION_ID=TCS.SESSION_ID
                                                AND VCP.FID_PLATFORM=TCS.FID_PLATFORM
                                                AND VCP.CHANGED<CASE
                                                                  WHEN TCS.CREATED+INTERVAL '2' SECOND > TCS.ENDED
                                                                  THEN TCS.LEG_ENDED+INTERVAL '1' SECOND
                                                                  ELSE TCS.LEG_ENDED
                                                                END
                    WHERE TCS.FID_PROJECT IS NULL
                  )
                SELECT *
                FROM SQ_DATA
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.FID_PROJECT = TMP.FID_PROJECT;

              V_RESULT.RESULT_NUM := V_RESULT.RESULT_NUM+SQL%ROWCOUNT;
            ELSIF I_STEP = 13 THEN
              V_RESULT.RESULT_TXT := 'Корректируем финальный статус';
              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                SELECT DISTINCT TCS.ROWID AS SYS_ROWID,
                  DECODE(TCS.OPERATOR, '{ext_abonent}', CASE
                                                          WHEN TCS.LAST_LEG = TCS.INIC_LEG_ID
                                                            AND TCS.ABONENT_LEG_ID = TCS.LAST_LEG
                                                          THEN 'error'
                                                          ELSE 'redirected'
                                                        END,
                    CASE
                      WHEN TCS.LEG_INTRUSION = 1 THEN 'intrusion'
                      WHEN TCS.FINAL_STAGE='redirect' and TCS.LEG_TYPE != 'ivr' THEN TCS.LEG_TYPE
                      WHEN TCS.FINAL_STAGE='redirect' THEN TCS.LEG_TYPE||'\'||TCS.FINAL_STAGE
                      WHEN TCS.DIRECTION IN ('IN', 'DIALER')
                        AND TCS.FINAL_STAGE='queue'
                        AND COUNT(TCS.REAL_LEG_ID)OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM, TCS.IVR_NUMBER) > 1
                      THEN 'operator'
                      WHEN TCS.DIRECTION IN ('IN', 'DIALER')
                      THEN NVL(TCS.FINAL_STAGE, DECODE(TCS.LEG_TYPE, 'ext_abonent', '{ext_operator}', TCS.LEG_TYPE))
                      ELSE 'operator'
                    END)||
                    CASE
                      WHEN TCS.OPERATOR_CREATED IS NOT NULL
                        AND TCS.OPERATOR_CONNECTED IS NOT NULL
                        AND TCSR.SESSION_ID IS NOT NULL
                      THEN '\redirect'||DECODE(GREATEST(TCS.LEG_ENDED, TCSR.LEG_ENDED),
                            TCS.LEG_ENDED, NVL2(TCSR.LEG_CONNECTED, '(cancel)', '(break)'))
                      WHEN TCS.OPERATOR_CREATED IS NOT NULL
                        AND TCS.OPERATOR_CONNECTED IS NULL
                        AND NVL(TCS.FINAL_STAGE, '*')!='queue' THEN '(break)'
                    END AS FINAL_STAGE
                FROM TMP_CALL_SESSIONS TCS
                LEFT JOIN TMP_CALL_SESSIONS TCSR ON TCSR.SESSION_ID=TCS.SESSION_ID
                                                AND TCSR.FID_PLATFORM=TCS.FID_PLATFORM
                                                AND TCSR.REAL_LEG_ID=TCS.REDIRECTED_LEG_ID
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.FINAL_STAGE = CASE
                                      WHEN TMP.FINAL_STAGE = 'ivr'
                                        AND TCS.UNBLOCKED_TIME IS NOT NULL
                                        AND OPERATOR_CREATED IS NULL
                                      THEN 'queue'
                                      ELSE TMP.FINAL_STAGE
                                    END,
                  TCS.CALLED = DECODE(TMP.FINAL_STAGE, 'error', NULL, TCS.CALLED);

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;

              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                WITH SQ_DATA AS
                  (
                    SELECT /*+ MATERIALIZE*/ DISTINCT TCS.ROWID AS SYS_ROWID,
                      TCS.FINAL_STAGE||'\operator' AS FINAL_STAGE
                    FROM TMP_CALL_SESSIONS TCS
                    JOIN TMP_CALL_SESSIONS TCSR ON TCSR.SESSION_ID=TCS.SESSION_ID
                                                AND TCSR.FID_PLATFORM=TCS.FID_PLATFORM
                                                AND TCSR.REDIRECTED_LEG_ID=TCS.REAL_LEG_ID
                                                AND TCS.LEG_INTRUSION=1
                  )
                SELECT *
                FROM SQ_DATA
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.FINAL_STAGE = TMP.FINAL_STAGE;

              V_RESULT.RESULT_NUM := V_RESULT.RESULT_NUM+SQL%ROWCOUNT;
            ELSIF I_STEP = 14 THEN
              V_RESULT.RESULT_TXT := 'Проставляем завершение звонка';
              MERGE INTO TMP_CALL_SESSIONS TCS USING
              (
                WITH SQ_BRAKE_CALL AS
                  (
                    SELECT DISTINCT TCS.ROWID AS SYS_ROWID, TCS.SESSION_ID, TCS.FID_PLATFORM, TCS.REAL_LEG_ID,
                      TCS.FINAL_STAGE, TCS.BRAKE_CALL, TCS.LEG_ABONENT, TCS.CALLER, TCS.CALLED,
                      TRIM('|' FROM
                            CASE
                              WHEN SUBSTR(TCS.BRAKE_CALL, 1, INSTR(TCS.BRAKE_CALL, '[')-1) NOT IN ('201', '200') THEN 'tech_problem'
                              WHEN (INSTR(TCS.FINAL_STAGE, '\redirect')>0
                                AND INSTR(TCS.FINAL_STAGE, '(cancel)')+INSTR(TCS.FINAL_STAGE, '(break)')=0)
                              THEN 'redirected'
                              WHEN PKG_STRINGS.FNC_ELEMENT(TRIM(']' FROM SUBSTR(TCS.BRAKE_CALL, INSTR(TCS.BRAKE_CALL,'[')+1)),4) = '201'
                              THEN DECODE(TCS.LEG_TYPE, 'ivr', 'system', 'system(operator)')
                              WHEN TCS.DIRECTION = 'DIALER'
                                  AND PKG_STRINGS.FNC_ELEMENT(TRIM(']' FROM SUBSTR(TCS.BRAKE_CALL, INSTR(TCS.BRAKE_CALL,'[')+1)),1) = '200'
                                THEN 'caller'
                              WHEN TCS.DIRECTION = 'DIALER'
                                  AND PKG_STRINGS.FNC_ELEMENT(TRIM(']' FROM SUBSTR(TCS.BRAKE_CALL, INSTR(TCS.BRAKE_CALL,'[')+1)),1) = '201'
                                THEN 'called'
                              WHEN(
                                    TCS.LEG_ABONENT=TCS.CALLER AND SUBSTR(TCS.BRAKE_CALL, 1, INSTR(TCS.BRAKE_CALL, '[')-1)='201'
                                  )OR
                                  (
                                    PKG_STRINGS.FNC_ELEMENT(TRIM(']' FROM SUBSTR(TCS.BRAKE_CALL, INSTR(TCS.BRAKE_CALL,'[')+1)),2) = '201'
                                    AND SUBSTR(TCS.BRAKE_CALL, 1, INSTR(TCS.BRAKE_CALL, '[')-1)!='201'
                                  )
                              THEN DECODE(TCS.LEG_INTRUSION, 1, 'called', 'caller')
                              WHEN TCS.LEG_ABONENT=TCS.CALLED AND SUBSTR(TCS.BRAKE_CALL, 1, INSTR(TCS.BRAKE_CALL, '[')-1)='201'
                              THEN DECODE(TCS.LEG_INTRUSION, 1, 'caller', 'called')
                              WHEN NVL(PKG_STRINGS.FNC_TONUMBER(
                                        PKG_STRINGS.FNC_ELEMENT(TRIM(']' FROM SUBSTR(TCS.BRAKE_CALL, INSTR(TCS.BRAKE_CALL,'[')+1)),2)),
                                        200) NOT IN (200, 201)
                              THEN 'tech_problem'
                              WHEN PKG_STRINGS.FNC_ELEMENT(TRIM(']' FROM SUBSTR(TCS.BRAKE_CALL, INSTR(TCS.BRAKE_CALL,'[')+1)),1) = '201'
                              THEN DECODE(TCS.DIRECTION,'IN','caller','called')
                              WHEN TCS.REDIRECTED_LEG_ID = -1
                                AND LEAD(TCS.IS_QUALITY_CONTROL)OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM ORDER BY TCS.REAL_LEG_ID) = 1
                              THEN DECODE(TCS.LEG_ABONENT, TCS.CALLED, 'called', 'caller')
                              WHEN TCS.REDIRECTED_LEG_ID = -1 THEN 'not_determined'
                            END||'|'||DECODE(TCS.FINAL_STAGE, 'intrusion', NULL,
                            CASE
                              WHEN PKG_STRINGS.FNC_ELEMENT(TRIM(']' FROM SUBSTR(TCS.BRAKE_CALL, INSTR(TCS.BRAKE_CALL,'[')+1)),1) = '201'
                              THEN 'abonent201'
                              WHEN PKG_STRINGS.FNC_ELEMENT(TRIM(']' FROM SUBSTR(TCS.BRAKE_CALL, INSTR(TCS.BRAKE_CALL,'[')+1)),5) = '201'
                              THEN 'operator201'
                              WHEN PKG_STRINGS.FNC_ELEMENT(TRIM(']' FROM SUBSTR(TCS.BRAKE_CALL, INSTR(TCS.BRAKE_CALL,'[')+1)),4) = '201'
                              THEN 'system201'
                              WHEN NVL(PKG_STRINGS.FNC_TONUMBER(
                                        PKG_STRINGS.FNC_ELEMENT(TRIM(']' FROM SUBSTR(TCS.BRAKE_CALL, INSTR(TCS.BRAKE_CALL,'[')+1)),1)),
                                        200) NOT IN (200, 201)
                              THEN 'tech_problem'||TO_CHAR(PKG_STRINGS.FNC_TONUMBER(
                                        PKG_STRINGS.FNC_ELEMENT(TRIM(']' FROM SUBSTR(TCS.BRAKE_CALL, INSTR(TCS.BRAKE_CALL,'[')+1)),1)))
                              WHEN PKG_STRINGS.FNC_ELEMENT(TRIM(']' FROM SUBSTR(TCS.BRAKE_CALL, INSTR(TCS.BRAKE_CALL,'[')+1)),2) = '201'
                              THEN
                                CASE
                                  WHEN TCS.LEG_ABONENT=TCS.CALLED AND TCS.OPERATOR='{ext_abonent}'
                                    AND SUBSTR(TCS.BRAKE_CALL, 1, INSTR(TCS.BRAKE_CALL, '[')-1)='201'
                                  THEN 'ext_operator201'
                                  ELSE DECODE(TCS.DIRECTION,'OUT','operator','INTERNAL','operator','abonent')||'201'
                                END
                              WHEN TCS.LEG_ABONENT=TCS.CALLED AND SUBSTR(TCS.BRAKE_CALL, 1, INSTR(TCS.BRAKE_CALL, '[')-1)='201'
                              THEN DECODE(TCS.LEG_TYPE,'ivr', 'system', 'operator', 'operator', 'ext_abonent')||'201'
                              WHEN SUBSTR(TCS.BRAKE_CALL, 1, INSTR(TCS.BRAKE_CALL, '[')-1) NOT IN ('201', '200')
                              THEN 'tech_problem'||SUBSTR(TCS.BRAKE_CALL, 1, INSTR(TCS.BRAKE_CALL, '[')-1)
                            END)) AS BC
                    FROM TMP_CALL_SESSIONS TCS
                  ),
                  SQ_RESULT AS
                  (
                    SELECT SYS_ROWID, SESSION_ID, FID_PLATFORM, REAL_LEG_ID, FINAL_STAGE,
                      NVL(REPLACE(BC,'system(operator)','system'),
                          REPLACE(LAG(BC IGNORE NULLS)
                                    OVER(PARTITION BY SESSION_ID, FID_PLATFORM
                                          ORDER BY REAL_LEG_ID),'system(operator)',
                                  CASE
                                    WHEN SUBSTR(BRAKE_CALL, 1, INSTR(BRAKE_CALL, '[')-1) NOT IN ('201', '200') THEN 'tech_problem'
                                    WHEN SUBSTR(BRAKE_CALL, 1, INSTR(BRAKE_CALL, '[')-1) = '201'
                                    THEN DECODE(LEG_ABONENT, CALLER, 'caller', 'called')
                                    ELSE DECODE(LEG_ABONENT, CALLER, 'called', 'caller')
                                  END)) AS BC
                    FROM SQ_BRAKE_CALL
                  )
                SELECT SYS_ROWID,
                  SUBSTR(BC, 1,
                          NVL(
                              DECODE(FINAL_STAGE,'intrusion', DECODE(INSTR(BC, '|'), 0, NULL, INSTR(BC, '|')-1)),
                              LENGTH(BC)
                            )
                        ) AS BRAKE_CALL
                FROM SQ_RESULT
              )TMP
              ON(TMP.SYS_ROWID=TCS.ROWID)
              WHEN MATCHED THEN
                UPDATE SET
                  TCS.BRAKE_CALL = TMP.BRAKE_CALL;

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 15 THEN
              V_RESULT.RESULT_TXT := 'Очистка данных';
              DELETE FROM CALLS_INFO CI
              WHERE COALESCE(CI.OPERATOR_CREATED, CI.IVR_CREATED, V_DATE_START) BETWEEN V_DATE_START AND V_DATE_END+1
                 AND EXISTS(
                             SELECT 1
                             FROM TMP_CALL_SESSIONS TCS
                             WHERE CI.FID_PLATFORM = TCS.FID_PLATFORM
                               AND CI.SESSION_ID = TCS.SESSION_ID
                          );

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 16 THEN
              V_RESULT.RESULT_TXT := 'Загрузка списка сессий';
              MERGE INTO CALL_SESSIONS CS USING
              (
                WITH SQ_CALLS AS
                  (
                    SELECT DISTINCT TCS.SESSION_ID, TCS.FID_PLATFORM, TCS.CREATED, TCS.ENDED, TCS.DIRECTION, TCS.ABONENT,
                      TO_NUMBER(REGEXP_REPLACE(SUBSTR(TCS.BRAKE_CALL,INSTR(TCS.BRAKE_CALL, '|')+1),'[^[[:digit:]]]*','')) AS EXIT_CODE,
                      REGEXP_REPLACE(SUBSTR(TCS.BRAKE_CALL,INSTR(TCS.BRAKE_CALL, '|')+1),'[^[[:alpha:]|[:punct:]]]*','') AS EXIT_CODE_DISCRIPTION,
                      ROW_NUMBER()OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM ORDER BY TCS.LEG_INTRUSION, TCS.LEG_ENDED DESC, TCS.IP_ADDRESS NULLS LAST) AS RID
                    FROM TMP_CALL_SESSIONS TCS
                    WHERE INSTR(BRAKE_CALL, '|') > 0
                  ),
                  SQ_RESULT AS
                  (
                    SELECT SESSION_ID, FID_PLATFORM, CREATED, ENDED, DIRECTION,
                      ABONENT, EXIT_CODE, EXIT_CODE_DISCRIPTION, RID
                    FROM SQ_CALLS
                    UNION
                    SELECT DISTINCT TCS.SESSION_ID, TCS.FID_PLATFORM, TCS.CREATED, TCS.ENDED, TCS.DIRECTION,
                      TCS.ABONENT, 0 AS EXIT_CODE, 'not_determined' AS EXIT_CODE_DISCRIPTION,
                      ROW_NUMBER()OVER(PARTITION BY TCS.SESSION_ID, TCS.FID_PLATFORM ORDER BY TCS.LEG_INTRUSION, TCS.LEG_ENDED DESC, TCS.IP_ADDRESS NULLS LAST) AS RID
                    FROM TMP_CALL_SESSIONS TCS
                    WHERE INSTR(NVL(BRAKE_CALL, 'not_determined'), '|') = 0
                      AND NOT EXISTS(
                                      SELECT 1
                                      FROM SQ_CALLS FSQS
                                      WHERE TCS.SESSION_ID=FSQS.SESSION_ID
                                        AND TCS.FID_PLATFORM=FSQS.FID_PLATFORM
                                    )
                  )
                SELECT /*+ INDEX(VCP IDX_CALL_PARAMS_CHANGED)*/ SQR.SESSION_ID, SQR.FID_PLATFORM, SQR.CREATED,
                  SQR.ENDED, SQR.DIRECTION, SQR.EXIT_CODE, SQR.EXIT_CODE_DISCRIPTION, NVL2(VCP.SESSION_ID, 0, 1) AS IS_WORK_TIME
                FROM SQ_RESULT SQR
                LEFT JOIN VW_CALL_PARAMS VCP ON VCP.CHANGED BETWEEN V_DATE_START AND V_DATE_END+1
                                            AND VCP.SESSION_ID=SQR.SESSION_ID
                                            AND VCP.FID_PLATFORM=SQR.FID_PLATFORM
                                            AND VCP.CHANGED BETWEEN SQR.CREATED AND SQR.ENDED
                                            AND UPPER(VCP.PARAM_NAME) = 'INCORRECT_CALL_TIME'
                                            AND VCP.PARAM_VALUE = '1'
                WHERE RID = 1
              )TMP
              ON(CS.SESSION_ID = TMP.SESSION_ID AND CS.FID_PLATFORM = TMP.FID_PLATFORM)
              WHEN MATCHED THEN
                UPDATE SET CS.CREATED = TMP.CREATED, CS.ENDED = TMP.ENDED,
                            CS.DIRECTION = NVL(TMP.DIRECTION,'{error}'),
                            CS.EXIT_CODE = TMP.EXIT_CODE,
                            CS.EXIT_CODE_DISCRIPTION = TMP.EXIT_CODE_DISCRIPTION,
                            CS.IS_WORK_TIME = TMP.IS_WORK_TIME
              WHEN NOT MATCHED THEN
                INSERT(CS.SESSION_ID, CS.CREATED, CS.ENDED, CS.DIRECTION, CS.FID_PLATFORM,
                        CS.EXIT_CODE, CS.EXIT_CODE_DISCRIPTION, CS.IS_WORK_TIME)
                VALUES(TMP.SESSION_ID, TMP.CREATED, TMP.ENDED, NVL(TMP.DIRECTION,'{error}'), TMP.FID_PLATFORM,
                        TMP.EXIT_CODE, TMP.EXIT_CODE_DISCRIPTION, TMP.IS_WORK_TIME);

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 17 THEN
              V_RESULT.RESULT_TXT := 'Загрузка информации по соединениям';
              INSERT INTO CALLS_INFO(SESSION_ID, FID_PLATFORM, LINK_ID, FID_PROJECT, FINAL_STAGE, ABONENT, CALLER, CALLED,
                                     IVR_NUMBER, IVR_CREATED, IVR_CONNECTED, IVR_ENDED, ENQUEUED_TIME, UNBLOCKED_TIME,
                                     DEQUEUED_TIME, OPERATOR, OPERATOR_CREATED, OPERATOR_CONNECTED, OPERATOR_ENDED,
                                     OPERATOR_HOLD, OPERATOR_WRAPUP, SPEAK_SEGMENTS, IS_QUALITY_CONTROL, BASEID,
                                     INCORRECT_CALL_TIME, BRAKE_CALL, FID_PROVIDER, IP_ADDRESS, PORT, FID_AREA, VOIP_REASON)
              WITH SQ_CALL_LEGS AS
                (
                  SELECT /*+ MATERIALIZE*/ *
                  FROM VW_CALL_LEGS VCL
                  WHERE VCL.CREATED BETWEEN V_DATE_START AND V_DATE_END+1
                    AND EXISTS(
                                SELECT 1
                                FROM TMP_CALL_SESSIONS FTCS
                                WHERE FTCS.SESSION_ID = VCL.SESSION_ID
                                  AND FTCS.FID_PLATFORM = VCL.FID_PLATFORM
                                  AND VCL.LEG_ID = FTCS.REAL_LEG_ID
                              )
                ),
                SQ_RESULT AS
                (
                  SELECT /*+ INDEX(MVEPC IDX_MVEPCNT_LOGIN_TIME)*/ DISTINCT
                    TCS.SESSION_ID, TCS.FID_PLATFORM, TCS.REAL_LEG_ID, TCS.DIRECTION, TCS.LEG_TYPE,
                    COALESCE(TCS.FID_PROJECT, MVEPC.FID_PROJECT, DPP.FID_PROJECT, 'project_not_determined')AS FID_PROJECT,
                    TCS.FINAL_STAGE, NVL(TCS.ABONENT,'{no_abonent}') AS ABONENT, NVL(TCS.CALLER,'{no_caller}') AS CALLER,
                    COALESCE(TCS.CALLED, VWCL.DST_ID, '{no_called}') AS CALLED, TCS.IVR_NUMBER, TCS.IVR_CREATED, TCS.IVR_CONNECTED,
                    TCS.IVR_ENDED, TCS.ENQUEUED_TIME, TCS.UNBLOCKED_TIME, TCS.DEQUEUED_TIME,
                    NVL(DECODE(TCS.FINAL_STAGE, 'error', NULL, TCS.OPERATOR),'{no_operator}') AS OPERATOR,
                    DECODE(TCS.FINAL_STAGE, 'error', NULL, TCS.OPERATOR_CREATED) AS OPERATOR_CREATED,
                    DECODE(TCS.FINAL_STAGE, 'error', NULL, TCS.OPERATOR_CONNECTED) AS OPERATOR_CONNECTED,
                    DECODE(TCS.FINAL_STAGE, 'error', NULL, TCS.OPERATOR_ENDED) AS OPERATOR_ENDED,
                    CASE
                      WHEN NVL(TCS.OPERATOR,'{no_operator}') NOT IN ('{no_operator}','{ext_operator}')
                      THEN 0
                    END AS OPERATOR_HOLD,
                    CASE
                      WHEN NVL(TCS.OPERATOR,'{no_operator}') NOT IN ('{no_operator}','{ext_operator}')
                      THEN 0
                    END AS OPERATOR_WRAPUP,
                    CASE
                      WHEN NVL(TCS.OPERATOR,'{no_operator}') NOT IN ('{no_operator}','{ext_operator}')
                      THEN '0'
                    END AS SPEAK_SEGMENTS,
                    NVL(TCS.IS_QUALITY_CONTROL, 0) AS IS_QUALITY_CONTROL,
                    (CS.IS_WORK_TIME*-1)+1 AS INCORRECT_CALL_TIME,
                    NVL(SUBSTR(TCS.BRAKE_CALL, 1, DECODE(INSTR(TCS.BRAKE_CALL, '|'), 0, LENGTH(TCS.BRAKE_CALL), INSTR(TCS.BRAKE_CALL, '|')-1)),'not_determined') AS BRAKE_CALL,
                    TCS.FID_PROVIDER, TCS.IP_ADDRESS, TCS.PORT, TCS.BASEID, TCS.VOIP_REASON
                  FROM TMP_CALL_SESSIONS TCS
                  LEFT JOIN CALL_SESSIONS CS ON CS.CREATED BETWEEN V_DATE_START AND V_DATE_END
                                            AND CS.SESSION_ID = TCS.SESSION_ID
                                            AND CS.FID_PLATFORM = TCS.FID_PLATFORM
                  LEFT JOIN MV_EMPLOYEES_PROJECTS_CNT MVEPC ON MVEPC.LOGIN = TCS.OPERATOR
                                                            AND MVEPC.FID_PLATFORM = TCS.FID_PLATFORM
                                                            AND MVEPC.PROJECT_CNT = 1
                                                            AND TCS.CREATED BETWEEN MVEPC.ACTIVE_FROM AND MVEPC.ACTIVE_TILL
                  LEFT JOIN SQ_CALL_LEGS VWCL ON VWCL.SESSION_ID = TCS.SESSION_ID
                                              AND VWCL.FID_PLATFORM = TCS.FID_PLATFORM
                                              AND VWCL.LEG_ID = TCS.REAL_LEG_ID
                  LEFT JOIN D_PROJECT_PHONES DPP ON COALESCE(TCS.FID_PROJECT, MVEPC.FID_PROJECT) IS NULL
                                                AND DPP.FID_PLATFORM=TCS.FID_PLATFORM
                                                AND CS.CREATED BETWEEN DPP.CREATED AND DPP.BLOCKED
                                                AND COALESCE(TCS.CALLED, VWCL.DST_ID, '{no_called}') LIKE DPP.PHONE
                )
              SELECT SESSION_ID, FID_PLATFORM,
                ROW_NUMBER()OVER(PARTITION BY SESSION_ID, FID_PLATFORM ORDER BY REAL_LEG_ID) AS LINK_ID,
                FID_PROJECT, NVL(FINAL_STAGE, DECODE(LEG_TYPE, '{ext_abonent}', 'redirected', LEG_TYPE)),
                ABONENT, CALLER, CALLED, IVR_NUMBER, IVR_CREATED, IVR_CONNECTED, IVR_ENDED, ENQUEUED_TIME,
                UNBLOCKED_TIME, DEQUEUED_TIME, decode(OPERATOR, '{ext_abonent}', '{ext_operator}', OPERATOR),
                OPERATOR_CREATED, OPERATOR_CONNECTED, OPERATOR_ENDED, OPERATOR_HOLD, OPERATOR_WRAPUP,
                SPEAK_SEGMENTS, IS_QUALITY_CONTROL, BASEID, INCORRECT_CALL_TIME, BRAKE_CALL,
                NVL(FID_PROVIDER, 0), NVL(IP_ADDRESS, '0'), NVL(PORT, 0), 0, VOIP_REASON
              FROM SQ_RESULT
              ORDER BY FID_PLATFORM, SESSION_ID;

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 18 THEN
              V_WORK := FNC_UPDATE_EXT_DATA(V_DATE_START-1, V_DATE_END, I_FORCE);
              V_RESULT.RESULT_TXT := 'Обновление дополнительной информации'||V_WORK.WORK_LOG;
              V_RESULT.RESULT_NUM := V_WORK.RESULT_NUM;
              V_RESULT.IS_ERROR := V_WORK.IS_ERROR;
              V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}="{val}"','');
              COMMIT;
            ELSIF I_STEP = 19 THEN
              V_RESULT.RESULT_TXT := 'Обновление стоимости соединений';
              PKG_BILLING.SP_UPDATE_COSTS(V_DATE_START, V_DATE_END, I_FORCE);
              V_RESULT.RESULT_NUM := 0;
              COMMIT;
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              V_RESULT.RESULT_NUM := SQLCODE;
              V_RESULT.RESULT_TXT := V_RESULT.RESULT_TXT||': '||SQLERRM;
              V_RESULT.IS_ERROR := 1;
          END;
          --Результируем время выполнения шага
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
          --Плучаем цифровой результат
          IF V_RESULT.IS_ERROR = 1 THEN
            V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','error');
          ELSE
            V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','cnt');
          END IF;
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{val}',TO_CHAR(V_RESULT.RESULT_NUM));
          --Выводим текст шага
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{text}',V_RESULT.RESULT_TXT);
          RETURN V_RESULT;
        END;--Шаги по заливке

      BEGIN
        V_RESULT.WORK_START := SYSTIMESTAMP;
        V_RESULT.WORK_LOG := '<prepare time="{time}">';
        V_SUBSTEP_START := SYSTIMESTAMP;
        VV_DATE_START := V_DATE_START;
        V_WORK.IS_ERROR := 0;
        FOR I IN 1..14 LOOP
          EXIT WHEN V_WORK.IS_ERROR = 1;
          V_WORK := STEP_LOAD(I);
          V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
        END LOOP;
        --Результируем время выполнения шага
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_SUBSTEP_START,SYSTIMESTAMP));
        V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||'</prepare>';
        IF V_WORK.IS_ERROR = 0 THEN
          V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||'<load time="{time}">';
          V_SUBSTEP_START := SYSTIMESTAMP;
          <<LOAD_DATA>>
          FOR I IN 15..19 LOOP
            V_WORK := STEP_LOAD(I);
            V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
            IF V_WORK.IS_ERROR = 1 AND I < 18 THEN
              ROLLBACK;
              EXIT LOAD_DATA;
            END IF;
          END LOOP;
          --Результируем время выполнения шага
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_SUBSTEP_START,SYSTIMESTAMP));
          V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||'</load>';
        ELSE
          ROLLBACK;
        END IF;
        V_DATE_START := VV_DATE_START;
        V_RESULT.IS_ERROR := V_WORK.IS_ERROR;
        V_RESULT.WORK_LOG := '<NAUMEN time="{time}">'||V_RESULT.WORK_LOG||'</NAUMEN>';
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
        RETURN V_RESULT;
      END;--Заливка данных

    BEGIN --SP_UPDATE_CALLS
      IF V_PLATFORMS IS NULL THEN
        V_PLATFORMS := T_LIST_INTEGER();
        SELECT ID_MODULE BULK COLLECT INTO V_PLATFORMS
        FROM D_MODULES
        WHERE ID_MODULE IN (2,6);
      END IF;
      --Смещаем начальную дату отбора для поиска потерянных сессий
      IF NVL(UPPER(I_FORCE),'N') = 'N' THEN
        IF TO_CHAR(V_DATE_END,'HH24:MI') = '00:00' THEN
          V_DATE_START := CAST(TRUNC(V_DATE_START)-2 AS TIMESTAMP);
        ELSIF TO_CHAR(V_DATE_END,'HH24:MI') = '12:00' THEN
          V_DATE_START := CAST(TRUNC(V_DATE_START)-1 AS TIMESTAMP);
        ELSIF EXTRACT(MINUTE FROM V_DATE_END) = 0 THEN
          V_DATE_START := CAST(TRUNC(V_DATE_START,'HH') AS TIMESTAMP);
        END IF;
      END IF;

      V_RESULT.WORK_START := SYSTIMESTAMP; --Начинаем работу по заливке
      V_RESULT.IS_ERROR := 0;

      V_WORK := LOAD_NAU;
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
      V_RESULT.IS_ERROR := GREATEST(V_RESULT.IS_ERROR, V_WORK.IS_ERROR);
      --Формируем лог событий
      V_RESULT.WORK_LOG := '<UPDATE_CALLS time="{time}" filter_date_start="{date_start}" filter_date_stop="{date_stop}" force="{force}">'||V_RESULT.WORK_LOG||'</UPDATE_CALLS>';
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_start}',to_char(V_DATE_START,'DD.MM.YYYY HH24:MI:SS'));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_stop}',to_char(V_DATE_END,'DD.MM.YYYY HH24:MI:SS'));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{force}',I_FORCE);

      INSERT INTO LOG_ACTIONS (LOG_TIME, ACT_USER, OPERATION, DISCRIPTION, "RESULT")
        SELECT V_RESULT.WORK_START, USER, 'UPDATE_CALLS', XMLTYPE(V_RESULT.WORK_LOG), DECODE(V_RESULT.IS_ERROR, 0, 'OK', 'Error')
        FROM DUAL;

      COMMIT;

      SYS.DBMS_OUTPUT.PUT_LINE(V_RESULT.WORK_LOG);
      DBMS_STATS.DELETE_TABLE_STATS('NC_CORE', 'TMP_CALL_SESSIONS');
      DBMS_STATS.DELETE_TABLE_STATS('NC_CORE', 'TMP_OPERATORS_CALLS');

    END SP_UPDATE_CALLS; --SP_UPDATE_CALLS

  --Процедура обновления инфорамции по переключениям статусов
  PROCEDURE SP_UPDATE_STATUSES(I_DATE_START TIMESTAMP, I_DATE_END TIMESTAMP,
                               I_FORCE CHAR, I_PLATFORMS T_LIST_INTEGER DEFAULT NULL) IS

    TYPE LTR_DATES IS RECORD(START_RANGE TIMESTAMP, STOP_RANGE TIMESTAMP, CNT NUMBER);
    TYPE LT_DATES IS TABLE OF LTR_DATES;

    V_RESULT LT_RESULT;
    V_WORK LT_RESULT;
    V_PLATFORMS T_LIST_INTEGER := I_PLATFORMS;
    V_DATES LT_DATES;

    --Шаги по заливке
    FUNCTION STEP_LOAD(I_STEP NUMBER) RETURN LT_RESULT IS
      V_RESULT LT_RESULT;
      V_WORK LT_RESULT;
      V_LOG CLOB := NULL;
      BEGIN
        V_RESULT.WORK_START := SYSTIMESTAMP;
        V_RESULT.WORK_LOG := '<action id="'||TO_CHAR(I_STEP)||'" time="{time}" {cnt}="{val}">{text}</action>';
        V_RESULT.IS_ERROR := 0;
        BEGIN
          IF I_STEP = 1 THEN
            V_RESULT.RESULT_TXT := 'Получаем текущие статусы';
            V_LOG := V_LOG||'<act time="{time}">Обновляем MV</act>';
            --DBMS_SNAPSHOT.REFRESH('MV_EMPLOYEES_SCHEDULE', 'C') ;
            DBMS_SNAPSHOT.REFRESH('MV_EMPLOYEES_PROJECTS_CNT', 'C') ;
            V_LOG := REPLACE(V_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
            INSERT INTO TMP_EMPLOYEES_STATUSES (STEP, ENTERED, LOGIN,
                                                STATUS, FID_NAU_STATUS, FID_NC_STATUS, REASON, FID_PLATFORM)
              SELECT DISTINCT 1, VWCS.ENTERED, VWCS.LOGIN, VWCS.STATUS, MVS.ID_NAU_STATUS,
                MVS.ID_NC_STATUS, NVL(VWCS.REASON,'*'), MVS.ID_PLATFORM
              FROM VW_CUR_STATUSES VWCS
                JOIN MV_STATUSES MVS ON VWCS.FID_PLATFORM=MVS.ID_PLATFORM
                                        AND VWCS.STATUS=MVS.NAU_STATUS
                                        AND NVL(VWCS.REASON,'*') LIKE MVS.NAU_STATUS_REASON
                                        AND VWCS.ENTERED BETWEEN MVS.ACTIVE_FROM AND MVS.ACTIVE_TILL
              WHERE EXISTS(
                        SELECT 1
                        FROM TABLE(V_PLATFORMS) P
                        WHERE VWCS.FID_PLATFORM = TO_NUMBER(P.COLUMN_VALUE)
                    )
                    AND EXISTS(
                        SELECT 1
                        FROM MV_EMPLOYEES MVE
                        WHERE VWCS.LOGIN=MVE.LOGIN
                              AND VWCS.FID_PLATFORM=MVE.FID_PLATFORM
                    )
                    AND I_DATE_END > TRUNC(CAST(SYSDATE AS TIMESTAMP));
            V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
          ELSIF I_STEP = 2 THEN
            V_RESULT.RESULT_TXT := 'Очищаем список статусов';
            DELETE FROM H_EMPLOYEES_STATUS HES
            WHERE ENTERED BETWEEN I_DATE_START AND I_DATE_END
                  AND EXISTS(
                      SELECT 1
                      FROM TABLE(V_PLATFORMS) P
                      WHERE HES.FID_PLATFORM = TO_NUMBER(P.COLUMN_VALUE)
                  )
                  AND UPPER(I_FORCE) = 'Y';
            V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
          ELSIF I_STEP = 3 THEN
            V_RESULT.RESULT_TXT := 'Формируем список дат для заливки статусов';
            WITH SQ_CHANGED_STATUSES AS
            (
              SELECT LOGIN, ENTERED, FID_NAU_STATUS,
                FID_NC_STATUS, REASON, FID_PLATFORM
              FROM EMPLOYEES_STATUS
              WHERE CAST(TRUNC(I_DATE_END) AS TIMESTAMP) >= CAST(TRUNC(SYSDATE) AS TIMESTAMP)
                    AND CAST(TRUNC(ENTERED) AS TIMESTAMP) < CAST(TRUNC(SYSDATE)AS TIMESTAMP)
                    AND  UPPER(I_FORCE) != 'Y'
              MINUS
              SELECT LOGIN, ENTERED, FID_NAU_STATUS,
                FID_NC_STATUS, REASON, FID_PLATFORM
              FROM TMP_EMPLOYEES_STATUSES
            ),
                SQ_FIX_DATES AS
              (
                  SELECT /*+ MATERIALIZE*/ START_RANGE, STOP_RANGE
                  FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(I_DATE_START,
                  LEAST(CAST(TRUNC(I_DATE_END) AS TIMESTAMP),
                        CAST(TRUNC(SYSDATE) AS TIMESTAMP))))
              ),
                SQ_DATES AS
              (
                SELECT CAST(START_RANGE AS TIMESTAMP) AS START_RANGE,
                       CAST(STOP_RANGE AS TIMESTAMP) AS STOP_RANGE
                FROM SQ_FIX_DATES
                UNION
                SELECT CAST(TRUNC(ENTERED) AS TIMESTAMP), CAST(TRUNC(ENTERED)+1 AS TIMESTAMP)
                FROM SQ_CHANGED_STATUSES SQCS
                WHERE NOT EXISTS(
                    SELECT 1
                    FROM SQ_FIX_DATES SQFD
                    WHERE CAST(TRUNC(SQCS.ENTERED) AS TIMESTAMP) = SQFD.START_RANGE
                )
                GROUP BY TRUNC(ENTERED)
                UNION
                SELECT CAST(TRUNC(SYSDATE) AS TIMESTAMP), CAST(TRUNC(SYSDATE+1) AS TIMESTAMP)
                FROM DUAL
                WHERE I_DATE_END > CAST(TRUNC(SYSDATE) AS TIMESTAMP)
              )
            SELECT DISTINCT START_RANGE, STOP_RANGE, 0
            BULK COLLECT INTO V_DATES
            FROM SQ_DATES;

            V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
          ELSIF I_STEP = 4 THEN
            V_RESULT.RESULT_TXT := 'Загружаем новые статусы';
            V_RESULT.RESULT_NUM := 0;
            FOR I IN V_DATES.FIRST..V_DATES.LAST LOOP
              INSERT INTO H_EMPLOYEES_STATUS(ENTERED, LOGIN, FID_PROJECT,
                                             FID_NAU_STATUS, FID_NC_STATUS, REASON, DURATION, FID_PLATFORM, LEAVED)
                WITH SQ_SELECTED_DATA AS
                (
                  SELECT /*+ MATERIALIZE*/VWSC.ENTERED, VWSC.LOGIN, MVS.ID_NAU_STATUS AS FID_NAU_STATUS,
                                                                    MVS.ID_NC_STATUS AS FID_NC_STATUS, NVL(VWSC.REASON, '*') AS REASON,
                    VWSC.DURATION, VWSC.FID_PLATFORM, VWSC.LEAVED
                  FROM VW_STATUS_CHANGES VWSC
                    JOIN MV_STATUSES MVS ON VWSC.FID_PLATFORM=MVS.ID_PLATFORM
                                            AND VWSC.STATUS=MVS.NAU_STATUS
                                            AND NVL(VWSC.REASON, '*') LIKE MVS.NAU_STATUS_REASON
                                            AND VWSC.ENTERED BETWEEN MVS.ACTIVE_FROM AND MVS.ACTIVE_TILL
                  WHERE VWSC.ENTERED BETWEEN V_DATES(I).START_RANGE AND V_DATES(I).STOP_RANGE
                        AND EXISTS(
                            SELECT 1
                            FROM MV_EMPLOYEES MVE
                            WHERE VWSC.FID_PLATFORM=MVE.FID_PLATFORM
                                  AND VWSC.LOGIN=MVE.LOGIN
                        )
                  MINUS
                  SELECT ENTERED, LOGIN, FID_NAU_STATUS, FID_NC_STATUS, REASON, DURATION, FID_PLATFORM, LEAVED
                  FROM H_EMPLOYEES_STATUS FHES
                  WHERE FHES.ENTERED BETWEEN V_DATES(I).START_RANGE AND V_DATES(I).STOP_RANGE
                )
                SELECT SQSD.ENTERED, SQSD.LOGIN,
                  CASE
                    WHEN MVS.NAU_STATUS IN ('ringing','speaking','wrapup','accident')
                      THEN 'pnd'
                    WHEN MVS.NAU_STATUS = 'offline'
                      THEN '{no_projects}'
                    ELSE NVL(MVEPC.FID_PROJECT,'{no_projects}')
                  END AS FID_PROJECT, SQSD.FID_NAU_STATUS, SQSD.FID_NC_STATUS, SQSD.REASON, SQSD.DURATION, SQSD.FID_PLATFORM, SQSD.LEAVED
                FROM SQ_SELECTED_DATA SQSD
                  JOIN MV_STATUSES MVS ON SQSD.FID_NAU_STATUS=MVS.ID_NAU_STATUS
                  LEFT JOIN MV_EMPLOYEES_PROJECTS_CNT MVEPC ON SQSD.FID_PLATFORM=MVEPC.FID_PLATFORM
                                                               AND SQSD.LOGIN=MVEPC.LOGIN
                                                               AND SQSD.ENTERED BETWEEN MVEPC.ACTIVE_FROM AND MVEPC.ACTIVE_TILL
                ORDER BY ENTERED;
              V_RESULT.RESULT_NUM := V_RESULT.RESULT_NUM+SQL%ROWCOUNT;
              V_DATES(I).CNT := SQL%ROWCOUNT;
              V_LOG := V_LOG||'<dates date_start="{date_start}" date_stop="{date_stop}">Загружено статусов: {cnt}.</dates>';
              V_LOG := REPLACE(V_LOG,'{date_start}',TO_CHAR(V_DATES(I).START_RANGE,'DD.MM.YYYY HH24:MI:SS'));
              V_LOG := REPLACE(V_LOG,'{date_stop}',TO_CHAR(V_DATES(I).STOP_RANGE,'DD.MM.YYYY HH24:MI:SS'));
              V_LOG := REPLACE(V_LOG,'{cnt}',TO_CHAR(SQL%ROWCOUNT));
            END LOOP;
          ELSIF I_STEP = 5 THEN
            V_RESULT.RESULT_TXT := 'Формируем текущие статусы';
            V_RESULT.RESULT_NUM := 0;
            DELETE FROM EMPLOYEES_STATUS ES
            WHERE EXISTS(
                          WITH SQ_DROP AS
                            (
                              SELECT LOGIN, ENTERED, FID_NAU_STATUS,
                                FID_NC_STATUS, REASON, FID_PLATFORM
                              FROM EMPLOYEES_STATUS
                              WHERE I_DATE_END > TRUNC(CAST(SYSDATE AS TIMESTAMP))
                              MINUS
                              SELECT LOGIN, ENTERED, FID_NAU_STATUS,
                                FID_NC_STATUS, REASON, FID_PLATFORM
                              FROM TMP_EMPLOYEES_STATUSES
                            )
                          SELECT 1
                          FROM SQ_DROP SQD
                          WHERE ES.ENTERED=SQD.ENTERED
                            AND ES.LOGIN=SQD.LOGIN
                            AND ES.FID_NAU_STATUS=SQD.FID_NAU_STATUS
                            AND ES.FID_NC_STATUS=SQD.FID_NC_STATUS
                            AND ES.FID_PLATFORM=SQD.FID_PLATFORM
                            AND ES.REASON=SQD.REASON
                        );

                INSERT INTO EMPLOYEES_STATUS ES (LOGIN, ENTERED, FID_NAU_STATUS,
                                FID_NC_STATUS, REASON, FID_PLATFORM, FID_PROJECT)
                SELECT TES.LOGIN, TES.ENTERED, TES.FID_NAU_STATUS,
                  TES.FID_NC_STATUS, TES.REASON, TES.FID_PLATFORM,
                  CASE
                    WHEN TES.STATUS IN ('ringing','speaking','wrapup','accident')
                      THEN 'pnd'
                    WHEN TES.STATUS = 'offline'
                      THEN '{no_projects}'
                    ELSE NVL(MVEPC.FID_PROJECT,'{no_projects}')
                  END AS FID_PROJECT
                FROM TMP_EMPLOYEES_STATUSES TES
                LEFT JOIN MV_EMPLOYEES_PROJECTS_CNT MVEPC ON TES.FID_PLATFORM=MVEPC.FID_PLATFORM
                                                          AND TES.LOGIN=MVEPC.LOGIN
                                                          AND TES.ENTERED BETWEEN MVEPC.ACTIVE_FROM AND MVEPC.ACTIVE_TILL
                WHERE NOT EXISTS(
                                  SELECT 1
                                  FROM EMPLOYEES_STATUS FES
                                  WHERE FES.ENTERED=TES.ENTERED
                                    AND FES.LOGIN=TES.LOGIN
                                    AND FES.FID_NAU_STATUS=TES.FID_NAU_STATUS
                                    AND FES.FID_NC_STATUS=TES.FID_NC_STATUS
                                    AND FES.FID_PLATFORM=TES.FID_PLATFORM
                                    AND FES.REASON=TES.REASON
                                );
            V_RESULT.RESULT_NUM := V_RESULT.RESULT_NUM+SQL%ROWCOUNT;
          ELSIF I_STEP = 7 THEN
            V_RESULT.RESULT_TXT := 'Обновляем загруженность сотрудника на проекте';
            V_RESULT.RESULT_NUM := 0;

            UPDATE D_LOGIN_RATES LR SET LR.RATE = 0
            WHERE LR.RATE != 0
              AND LR.REPORT_DATE BETWEEN CAST(TRUNC(I_DATE_START) AS TIMESTAMP)
                                     AND CAST(TRUNC(I_DATE_END+1-1/86400) AS TIMESTAMP);

            MERGE INTO D_LOGIN_RATES DLR USING
            (
              WITH SQ_RANGES AS
                (
                  SELECT /*+ MATERIALIZE*/ START_RANGE, STOP_RANGE
                  FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(CAST(TRUNC(I_DATE_START) AS TIMESTAMP), CAST(TRUNC(I_DATE_END+1-1/86400) AS TIMESTAMP)))
                ),
                SQ_STATUSES AS
                (
                  SELECT /*+ MATERIALIZE*/ CAST(TRUNC(GREATEST(SQR.START_RANGE, HES.ENTERED)) AS TIMESTAMP) AS ENTERED,
                    HES.LOGIN, HES.FID_PROJECT,
                    PKG_INTERVALS.FNC_INTERVALTOSEC(GREATEST(SQR.START_RANGE, HES.ENTERED),
                                                    LEAST(SQR.STOP_RANGE, CAST(HES.ENTERED+HES.DURATION/86400 AS TIMESTAMP))) AS DURATION,
                    HES.FID_PLATFORM
                  FROM SQ_RANGES SQR
                    JOIN H_EMPLOYEES_STATUS HES ON HES.ENTERED BETWEEN CAST(TRUNC(I_DATE_START)-1 AS TIMESTAMP)
                                                                   AND CAST(TRUNC(I_DATE_END)+1 AS TIMESTAMP)
                                               AND HES.ENTERED < SQR.STOP_RANGE
                                               AND SQR.START_RANGE <= CAST(HES.ENTERED+HES.DURATION/86400 AS TIMESTAMP)
                    JOIN D_STATUSES DS ON DS.ID_STATUS = HES.FID_NAU_STATUS
                  WHERE DS.NAME NOT IN ('offline','available','notavailable', 'accident', 'redirect')
                ),
                SQ_RATES_LIST_ALL AS
                ( -- рейтинг по статусам в выборке c {no_projects}
                  SELECT /*+ MATERIALIZE*/ DISTINCT ENTERED, LOGIN,
                    DECODE(FID_PROJECT, 'pnd', 'project_not_determined', FID_PROJECT) FID_PROJECT, FID_PLATFORM,
                    SUM(DURATION)OVER(PARTITION BY ENTERED,LOGIN, FID_PLATFORM, DECODE(FID_PROJECT, 'pnd', 'project_not_determined', FID_PROJECT))/
                    GREATEST(SUM(DURATION)OVER(PARTITION BY ENTERED, LOGIN, FID_PLATFORM), 1) AS RATE
                  FROM SQ_STATUSES
                ),
                SQ_RATES_LIST AS
                (
                  SELECT /*+ MATERIALIZE*/ DISTINCT ENTERED, LOGIN, FID_PROJECT, FID_PLATFORM,
                    SUM(DURATION)OVER(PARTITION BY ENTERED,LOGIN, FID_PLATFORM, FID_PROJECT)/
                          GREATEST(SUM(DURATION)OVER(PARTITION BY ENTERED, LOGIN, FID_PLATFORM), 1) AS RATE
                  FROM SQ_STATUSES
                  WHERE FID_PROJECT NOT IN ('project_not_determined', 'pnd', '{no_projects}')
                ),
                SQ_RATES_LIST_OF AS
                ( -- рейтинг записей по непривязанным проектам
                  SELECT  /*+ MATERIALIZE*/ ENTERED, LOGIN, FID_PROJECT, FID_PLATFORM, RATE
                  FROM SQ_RATES_LIST_ALL
                  WHERE (ENTERED, LOGIN, FID_PROJECT, FID_PLATFORM) NOT IN
                        (
                          SELECT ENTERED, LOGIN, FID_PROJECT, FID_PLATFORM FROM SQ_RATES_LIST
                        )
                ),
                SQ_RATES_CALC AS
                (
                  SELECT /*+ MATERIALIZE*/ ENTERED, LOGIN, FID_PLATFORM,
                    COUNT(DISTINCT FID_PROJECT) AS PRJ, SUM(RATE) AS RATES
                  FROM SQ_RATES_LIST
                  GROUP BY ENTERED, LOGIN, FID_PLATFORM
                ),
                SQ_RATES_CALC_OF AS
                ( -- суммарный рейтинг и количество с непривязанными проектами с рейтингами за день
                  SELECT /*+ MATERIALIZE*/ ENTERED, LOGIN, FID_PLATFORM,
                    COUNT(DISTINCT FID_PROJECT) AS PRJ, SUM(RATE) AS RATES
                  FROM SQ_RATES_LIST_OF
                  GROUP BY ENTERED, LOGIN, FID_PLATFORM
                ),
                SQ_LOGIN_PROJECTS AS
                (
                  SELECT DISTINCT
                    GREATEST(SQR.START_RANGE, CAST(TRUNC(VRPE.ACTIVE_FROM) AS TIMESTAMP)) AS ENTERED, VRPE.LOGIN, VRPE.PROJECT_ID, VRPE.FID_PLATFORM,
                    GREATEST(COUNT(DISTINCT VRPE.PROJECT_ID)OVER(PARTITION BY GREATEST(SQR.START_RANGE, CAST(TRUNC(VRPE.ACTIVE_FROM) AS TIMESTAMP)),
                    VRPE.LOGIN, VRPE.FID_PLATFORM), 1) AS PROJECT_CNT
                  FROM SQ_RANGES SQR
                    JOIN VW_REL_PROJECTS_EMPLOYEES VRPE ON VRPE.ACTIVE_FROM BETWEEN SQR.START_RANGE AND SQR.STOP_RANGE
                                                        OR SQR.START_RANGE BETWEEN VRPE.ACTIVE_FROM AND VRPE.ACTIVE_TILL
                  WHERE EXISTS
                    (
                      SELECT 1
                      FROM SQ_RATES_CALC_OF SQRL
                      WHERE SQRL.ENTERED = GREATEST(SQR.START_RANGE, CAST(TRUNC(VRPE.ACTIVE_FROM) AS TIMESTAMP))
                        AND SQRL.LOGIN = VRPE.LOGIN
                        AND SQRL.FID_PLATFORM = VRPE.FID_PLATFORM
                    )
                ),
                SQ_RESULT AS
                (
                  SELECT DISTINCT SQRC.ENTERED, SQRC.LOGIN,
                    NVL(SQLP.PROJECT_ID, SQRL.FID_PROJECT) PROJECT_ID, SQRC.FID_PLATFORM,
                    NVL2(SQLP.PROJECT_CNT, 1, SQRL.RATE)/GREATEST(NVL(SQLP.PROJECT_CNT, 0), 1) AS RATE
                  FROM SQ_RATES_CALC_OF SQRC
                    JOIN SQ_RATES_LIST_OF SQRL ON SQRL.ENTERED = SQRC.ENTERED
                                              AND SQRL.LOGIN = SQRC.LOGIN
                                              AND SQRL.FID_PLATFORM = SQRC.FID_PLATFORM
                                              AND SQRL.FID_PROJECT IN ('project_not_determined', '{no_projects}')
                    LEFT JOIN SQ_LOGIN_PROJECTS SQLP ON SQRC.ENTERED = SQLP.ENTERED
                                                    AND SQRC.LOGIN = SQLP.LOGIN
                                                    AND SQRC.FID_PLATFORM = SQLP.FID_PLATFORM
                  WHERE NOT EXISTS
                    (
                      SELECT 1 FROM SQ_RATES_LIST SQC
                      WHERE SQC.ENTERED = SQRL.ENTERED
                        AND SQC.LOGIN = SQRL.LOGIN
                        AND SQC.FID_PLATFORM = SQRL.FID_PLATFORM
                    )
                  UNION ALL
                  SELECT ENTERED, LOGIN, FID_PROJECT PROJECT_ID, FID_PLATFORM, RATE
                  FROM SQ_RATES_LIST
                )
              SELECT ENTERED, LOGIN, PROJECT_ID, FID_PLATFORM, RATE
              FROM SQ_RESULT SQRL
            )TMP
            ON(DLR.REPORT_DATE = TMP.ENTERED AND DLR.LOGIN = TMP.LOGIN AND DLR.FID_PROJECT = TMP.PROJECT_ID AND DLR.FID_PLATFORM = TMP.FID_PLATFORM)
            WHEN MATCHED THEN
              UPDATE SET DLR.RATE = TMP.RATE
            WHEN NOT MATCHED THEN
              INSERT(DLR.REPORT_DATE, DLR.LOGIN, DLR.FID_PROJECT, DLR.FID_PLATFORM, DLR.RATE)
              VALUES(TMP.ENTERED, TMP.LOGIN, TMP.PROJECT_ID, TMP.FID_PLATFORM, TMP.RATE);

            V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            COMMIT;
          ELSIF I_STEP = 6 THEN
            V_RESULT.RESULT_TXT := 'Обновляем дополнительную информацию';
            V_RESULT.RESULT_NUM := 0;
            FOR I IN V_DATES.FIRST..V_DATES.LAST LOOP
              IF V_DATES(I).CNT > 0 THEN
                V_WORK := FNC_UPDATE_EXT_DATA(V_DATES(I).START_RANGE, V_DATES(I).STOP_RANGE, I_FORCE);
                COMMIT;
                V_RESULT.RESULT_NUM := V_RESULT.RESULT_NUM+V_WORK.RESULT_NUM;
                V_LOG := V_LOG||'<dates date_start="{date_start}" date_stop="{date_stop}">'||V_WORK.WORK_LOG||'</dates>';
                V_LOG := REPLACE(V_LOG,'{date_start}',TO_CHAR(V_DATES(I).START_RANGE,'DD.MM.YYYY HH24:MI:SS'));--,'DD.M.YYYY HH24:MI:SS'
                V_LOG := REPLACE(V_LOG,'{date_stop}',TO_CHAR(V_DATES(I).STOP_RANGE,'DD.MM.YYYY HH24:MI:SS'));
              END IF;
            END LOOP;
          END IF;
          EXCEPTION
          WHEN OTHERS THEN
          V_RESULT.RESULT_NUM := SQLCODE;
          V_RESULT.RESULT_TXT := V_RESULT.RESULT_TXT||': '||SQLERRM;
          V_RESULT.IS_ERROR := 1;
        END;
        --Результируем время выполнения шага
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
        --Плучаем цифровой результат
        IF V_RESULT.IS_ERROR = 1 THEN
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','error');
        ELSE
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','cnt');
        END IF;
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{val}',TO_CHAR(V_RESULT.RESULT_NUM));
        --Выводим текст шага
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{text}',V_RESULT.RESULT_TXT||V_LOG);
        RETURN V_RESULT;
      END;--Шаги по заливке

    BEGIN --SP_UPDATE_STATUSES
      IF V_PLATFORMS IS NULL THEN
        V_PLATFORMS := T_LIST_INTEGER();
        SELECT ID_MODULE BULK COLLECT INTO V_PLATFORMS
        FROM D_MODULES
        WHERE ID_MODULE IN (2,6);
      END IF;

      V_RESULT.WORK_START := SYSTIMESTAMP; --Начинаем работу по заливке
      FOR I IN 1..7 LOOP
        EXIT WHEN V_WORK.IS_ERROR = 1;
        V_WORK := STEP_LOAD(I);
        V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
      END LOOP;
      V_RESULT.IS_ERROR := V_WORK.IS_ERROR;
      IF V_WORK.IS_ERROR = 1 THEN ROLLBACK; END IF;
      --Формируем лог событий
      V_RESULT.WORK_LOG := '<UPDATE_STATUSES time="{time}" filter_date_start="{date_start}" filter_date_stop="{date_stop}" force="{force}">'||V_RESULT.WORK_LOG||'</UPDATE_STATUSES>';
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_start}',to_char(I_DATE_START,'DD.MM.YYYY HH24:MI:SS'));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_stop}',to_char(I_DATE_END,'DD.MM.YYYY HH24:MI:SS'));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{force}',I_FORCE);

      INSERT INTO LOG_ACTIONS (LOG_TIME, ACT_USER, OPERATION, DISCRIPTION, "RESULT")
        SELECT V_RESULT.WORK_START, USER, 'UPDATE_STATUSES', XMLTYPE(V_RESULT.WORK_LOG), DECODE(V_RESULT.IS_ERROR, 0, 'OK', 'Error')
        FROM DUAL;

      COMMIT;

      DBMS_STATS.DELETE_TABLE_STATS('NC_CORE', 'TMP_CALL_SESSIONS');
      DBMS_STATS.DELETE_TABLE_STATS('NC_CORE', 'TMP_OPERATORS_CALLS');

    END SP_UPDATE_STATUSES; --SP_UPDATE_STATUSES

  --Процедура синхронизации групп с PMS
  PROCEDURE SP_SYNCHRONIZATION_GROUPS IS
    V_RESULT LT_RESULT;
    V_WORK LT_RESULT;

    --Шаги по заливке
    FUNCTION STEP_LOAD(I_STEP NUMBER) RETURN LT_RESULT IS
      V_RESULT LT_RESULT;
      V_WORK LT_RESULT;
    BEGIN
      V_RESULT.WORK_START := SYSTIMESTAMP;
      V_RESULT.WORK_LOG := '<action id="'||TO_CHAR(I_STEP)||'" time="{time}" {cnt}="{val}">{text}</action>';
      V_RESULT.IS_ERROR := 0;
      BEGIN
        IF I_STEP = 1 THEN
          V_RESULT.RESULT_TXT := 'Удаляем группы удаленные из PMS';
          DELETE FROM D_GROUPS
          WHERE IMPORT_GROUP_ID IS NOT NULL
            AND NOT EXISTS
            (
              SELECT 1
              FROM VW_PARTNERS62 VWP
              WHERE D_GROUPS.IMPORT_GROUP_ID=VWP.PARTNERUUID
            ) ;

          V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
        ELSIF I_STEP = 2 THEN
          V_RESULT.RESULT_TXT := 'Синхронизируем группы с PMS';
          MERGE INTO D_GROUPS DG USING
          (
            SELECT DISTINCT PARTNERUUID, PARTNERNAME
            FROM VW_PARTNERS62 VWP
            WHERE NOT EXISTS
              (
                SELECT 1
                FROM D_GROUPS
                WHERE D_GROUPS.IMPORT_GROUP_ID=VWP.PARTNERUUID
                  AND D_GROUPS.CAPTION=VWP.PARTNERNAME
              )
          )
          TMP ON(DG.IMPORT_GROUP_ID=TMP.PARTNERUUID)
          WHEN MATCHED THEN
            UPDATE SET DG.CAPTION=TMP.PARTNERNAME
          WHEN NOT MATCHED THEN
            INSERT (CAPTION, IMPORT_GROUP_ID)
            VALUES (TMP.PARTNERNAME, TMP.PARTNERUUID);

          V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
        ELSIF I_STEP = 3 THEN
          V_RESULT.RESULT_TXT := 'Удаляем из связей проекты удаленные из системы';
          DELETE FROM REL_GROUP_PROJECTS RGP
          WHERE NOT EXISTS
            (
              SELECT 1
              FROM VW_PROJECTS VWP
              WHERE RGP.FID_PROJECT=VWP.PROJECT_ID
            );

          V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
        ELSIF I_STEP = 4 THEN
          V_RESULT.RESULT_TXT := 'Добавляем в связи проекты связанные с группами в PMS если проекты не имеют группы';
          INSERT INTO REL_GROUP_PROJECTS(FID_GROUP, FID_PROJECT)
          SELECT DG.ID_GROUP, VWP.UUID
          FROM VW_PARTNERS62 VWP
          JOIN D_GROUPS DG ON DG.IMPORT_GROUP_ID=VWP.PARTNERUUID
          WHERE NOT EXISTS
            (
              SELECT 1
              FROM REL_GROUP_PROJECTS RGP
              WHERE VWP.UUID=RGP.FID_PROJECT
            );

          V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          V_RESULT.RESULT_NUM := SQLCODE;
          V_RESULT.RESULT_TXT := V_RESULT.RESULT_TXT||': '||SQLERRM;
          V_RESULT.IS_ERROR := 1;
      END;
      --Результируем время выполнения шага
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
      --Плучаем цифровой результат
      IF V_RESULT.IS_ERROR = 1 THEN
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','error');
      ELSE
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','cnt');
      END IF;
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{val}',TO_CHAR(V_RESULT.RESULT_NUM));
      --Выводим текст шага
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{text}',V_RESULT.RESULT_TXT);
      RETURN V_RESULT;
    END;--Шаги по заливке

  BEGIN --SP_UPDATE_STATUSES
    V_RESULT.WORK_START := SYSTIMESTAMP; --Начинаем работу по заливке
    FOR I IN 1..4 LOOP
      EXIT WHEN V_WORK.IS_ERROR = 1;
      V_WORK := STEP_LOAD(I);
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
    END LOOP;
    V_RESULT.IS_ERROR := V_WORK.IS_ERROR;
    IF V_WORK.IS_ERROR = 1 THEN ROLLBACK; END IF;
    --Формируем лог событий
    V_RESULT.WORK_LOG := '<UPDATE_GROUPS time="{time}">'||V_RESULT.WORK_LOG||'</UPDATE_GROUPS>';
    V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));

    INSERT INTO LOG_ACTIONS (LOG_TIME, ACT_USER, OPERATION, DISCRIPTION, "RESULT")
    SELECT V_RESULT.WORK_START, USER, 'UPDATE_GROUPS', XMLTYPE(V_RESULT.WORK_LOG), DECODE(V_RESULT.IS_ERROR, 0, 'OK', 'Error')
    FROM DUAL;

    COMMIT;
  END SP_SYNCHRONIZATION_GROUPS;

  --Процедура изменения структуры групп
  PROCEDURE SP_CHANGE_GROUPS(
                              IO_ACTION IN OUT VARCHAR2,
                              IO_GROUP_ID IN OUT NUMBER,
                              I_GROUP_NAME IN VARCHAR2,
                              I_PARENT_GROUP_ID NUMBER,
                              I_PROJECT_ID VARCHAR2) IS

    V_GROUP_ID NUMBER;
  BEGIN
    IF UPPER(IO_ACTION) IN ('ADD', 'EDIT') AND I_PROJECT_ID IS NULL THEN --Добавление/изменение группы
      IF I_GROUP_NAME IS NULL THEN
        RAISE_APPLICATION_ERROR(-20000, 'I_GROUP_NAME не может быть пустым.') ;
      END IF;

      IF UPPER(IO_ACTION) = 'ADD' THEN
        IO_GROUP_ID := NULL;
        INSERT INTO D_GROUPS (CAPTION, FID_GROUP)
        VALUES(I_GROUP_NAME, I_PARENT_GROUP_ID)
        RETURN ID_GROUP INTO IO_GROUP_ID;
      ELSE
        IF IO_GROUP_ID IS NULL THEN
          RAISE_APPLICATION_ERROR(-20001, 'IO_GROUP_ID не может быть пустым.') ;
        END IF;

        UPDATE D_GROUPS SET CAPTION=I_GROUP_NAME, FID_GROUP=I_PARENT_GROUP_ID
        WHERE ID_GROUP = IO_GROUP_ID;
        IO_GROUP_ID := 1;
      END IF;
    ELSIF UPPER(IO_ACTION) = 'DELETE' AND I_PROJECT_ID IS NULL THEN --Удаление группы
      IF IO_GROUP_ID IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'IO_GROUP_ID не может быть пустым.') ;
      END IF;

      DELETE FROM D_GROUPS WHERE ID_GROUP = IO_GROUP_ID;
      IO_GROUP_ID := 1;
    ELSIF UPPER(IO_ACTION) IN ('ADD', 'EDIT') THEN --Добавление/изменение привязки проектов к группам
      IF IO_GROUP_ID IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'IO_GROUP_ID не может быть пустым.') ;
      END IF;

      IF UPPER(IO_ACTION) = 'ADD' THEN
        INSERT INTO REL_GROUP_PROJECTS (FID_GROUP, FID_PROJECT)
        VALUES(IO_GROUP_ID, I_PROJECT_ID);
        IO_GROUP_ID := 1;
      ELSE
        IF I_PARENT_GROUP_ID IS NULL THEN
          RAISE_APPLICATION_ERROR(-20001, 'I_PARENT_GROUP_ID не может быть пустым.') ;
        END IF;

        UPDATE REL_GROUP_PROJECTS SET FID_GROUP=IO_GROUP_ID
        WHERE FID_PROJECT = I_PROJECT_ID
          AND FID_GROUP = I_PARENT_GROUP_ID;
        IO_GROUP_ID := 1;
      END IF;
    ELSIF UPPER(IO_ACTION) = 'DELETE' THEN --Удаление привязки проектов к группам
      IF IO_GROUP_ID IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'IO_GROUP_ID не может быть пустым.') ;
      END IF;

      DELETE FROM D_GROUPS WHERE ID_GROUP = IO_GROUP_ID;
      IO_GROUP_ID := 1;
    END IF;
    IO_ACTION := 'RESULT';
  END SP_CHANGE_GROUPS;

  --Включение и отключение JOBов в схеме
  PROCEDURE SP_CHANGE_JOB_STATE(I_ENABLED CHAR DEFAULT 'Y')
  IS
    V_ACTIVE_JOB NUMBER;
    V_START_WAIT TIMESTAMP;
  BEGIN
    IF NVL(UPPER(I_ENABLED),'Y') = 'Y' THEN
      DBMS_SCHEDULER.enable(name=>'J_FILL_CALLS');
      DBMS_SCHEDULER.enable(name=>'J_LOAD_CHATS');
      DBMS_SCHEDULER.enable(name=>'J_LOAD_STATUSES');
      DBMS_SCHEDULER.enable(name=>'J_LOAD_WORK_INTERVALS');
    ELSE
      DBMS_SCHEDULER.disable(name=>'J_FILL_CALLS', force => TRUE);
      DBMS_SCHEDULER.disable(name=>'J_LOAD_CHATS', force => TRUE);
      DBMS_SCHEDULER.disable(name=>'J_LOAD_STATUSES', force => TRUE);
      DBMS_SCHEDULER.disable(name=>'J_LOAD_WORK_INTERVALS', force => TRUE);
      V_START_WAIT := CAST(SYSTIMESTAMP AS TIMESTAMP);
      LOOP
        SELECT COUNT(DISTINCT DECODE(STATE, 'RUNNING', STATE))
          INTO V_ACTIVE_JOB
        FROM USER_SCHEDULER_JOBS
        WHERE JOB_NAME='J_LOAD_STATUSES'
          OR JOB_NAME='J_FILL_CALLS'
          OR JOB_NAME = 'J_LOAD_WORK_INTERVALS';

        EXIT WHEN V_ACTIVE_JOB = 0 OR PKG_INTERVALS.FNC_INTERVALTOMIN(V_START_WAIT, CAST(SYSTIMESTAMP AS TIMESTAMP), 0, 'D') > 15;
        DBMS_LOCK.SLEEP(30);
      END LOOP;
    END IF;
  END; --SP_CHANGE_JOB_STATE

  --Процедура обновления кодов операторов связи
  PROCEDURE SP_UPDATE_PROVIDERS(I_DATE_START TIMESTAMP,
                                I_DATE_END TIMESTAMP,
                                I_FORCE CHAR DEFAULT 'N')
  IS
    V_RESULT LT_RESULT;
    V_WORK LT_RESULT;

    --Шаги по заливке
    FUNCTION STEP_LOAD(I_STEP NUMBER) RETURN LT_RESULT IS
      V_RESULT LT_RESULT;
    BEGIN
      V_RESULT.WORK_START := SYSTIMESTAMP;
      V_RESULT.WORK_LOG := '<action id="'||TO_CHAR(I_STEP)||'" time="{time}" {cnt}="{val}">{text}</action>';
      V_RESULT.IS_ERROR := 0;
      BEGIN
        IF I_STEP = 1 THEN
          V_RESULT.RESULT_TXT := 'Обновление IP-адресов операторов связи';
          MERGE INTO CALLS_INFO CI USING
          (
            SELECT CI.ROWID AS SYS_ROWID, ACDR.IP, ACDR.PORT
            FROM CALLS_INFO CI
            JOIN ASTERISK.CDR ACDR ON ACDR.START_TIME BETWEEN I_DATE_START-INTERVAL '10' MINUTE AND I_DATE_END+INTERVAL '10' MINUTE
                                  AND NVL(CI.IVR_CREATED, CI.OPERATOR_CREATED) BETWEEN ACDR.START_TIME-INTERVAL '10' MINUTE AND ACDR.END_TIME+INTERVAL '10' MINUTE
                                  AND CI.BASEID = ACDR.CALL_ID
                                  AND ACDR.FLAG = 1
                                  AND (ACDR.IP != CI.IP_ADDRESS
                                        OR ACDR.PORT != CI.PORT)
            WHERE CI.FID_PROVIDER = DECODE(UPPER(NVL(I_FORCE, 'N')), 'Y', CI.FID_PROVIDER, 0)
              AND NVL(CI.OPERATOR_CREATED, CI.IVR_CREATED) BETWEEN I_DATE_START AND I_DATE_END
          )TMP
          ON(TMP.SYS_ROWID=CI.ROWID)
          WHEN MATCHED THEN
            UPDATE SET CI.IP_ADDRESS = TMP.IP,
                        CI.PORT = TMP.PORT;

          V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
        ELSIF I_STEP = 2 THEN
          V_RESULT.RESULT_TXT := 'Обновление ID операторов связи';
          MERGE INTO CALLS_INFO CI USING
          (
            SELECT CI.ROWID AS SYS_ROWID, NVL(DPA.FID_PROVIDER, 0) AS FID_PROVIDER
            FROM CALLS_INFO CI
            JOIN D_PROVIDER_ADDRESSES DPA ON DPA.IP_ADDRESS=CI.IP_ADDRESS
                                          AND DPA.PORT=CI.PORT
                                          AND NVL(CI.OPERATOR_CREATED, CI.IVR_CREATED) BETWEEN DPA.CREATED AND DPA.BLOCKED
            WHERE NVL(CI.OPERATOR_CREATED, CI.IVR_CREATED) BETWEEN I_DATE_START AND I_DATE_END
              AND (CI.FID_PROVIDER = DECODE(UPPER(NVL(I_FORCE, 'N')), 'Y', CI.FID_PROVIDER, 0)
                OR CI.FID_PROVIDER != DECODE(UPPER(NVL(I_FORCE, 'N')), 'N', DPA.FID_PROVIDER, CI.FID_PROVIDER))
          )TMP
          ON(TMP.SYS_ROWID=CI.ROWID)
          WHEN MATCHED THEN
            UPDATE SET
              CI.FID_PROVIDER = TMP.FID_PROVIDER;

          V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          V_RESULT.RESULT_NUM := SQLCODE;
          V_RESULT.RESULT_TXT := V_RESULT.RESULT_TXT||': '||SQLERRM;
          V_RESULT.IS_ERROR := 1;
      END;
      --Результируем время выполнения шага
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
      --Плучаем цифровой результат
      IF V_RESULT.IS_ERROR = 1 THEN
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','error');
      ELSE
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','cnt');
      END IF;
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{val}',TO_CHAR(V_RESULT.RESULT_NUM));
      --Выводим текст шага
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{text}',V_RESULT.RESULT_TXT);
      RETURN V_RESULT;
    END;--Шаги по заливке

  BEGIN
    V_RESULT.WORK_START := SYSTIMESTAMP; --Начинаем работу по заливке
    FOR I IN 1..2 LOOP
      V_WORK := STEP_LOAD(I);
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
      V_RESULT.IS_ERROR := GREATEST(NVL(V_RESULT.IS_ERROR, 0), V_WORK.IS_ERROR);
    END LOOP;

    --Формируем лог событий
    V_RESULT.WORK_LOG := '<UPDATE_PROVIDERS time="{time}" filter_date_start="{date_start}" filter_date_stop="{date_stop}" force="{force}">'||V_RESULT.WORK_LOG||'</UPDATE_PROVIDERS>';
    V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
    V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_start}',to_char(I_DATE_START,'DD.MM.YYYY HH24:MI:SS'));
    V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_stop}',to_char(I_DATE_END,'DD.MM.YYYY HH24:MI:SS'));
    V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{force}',I_FORCE);

    INSERT INTO LOG_ACTIONS (LOG_TIME, ACT_USER, OPERATION, DISCRIPTION, "RESULT")
    SELECT V_RESULT.WORK_START, USER, 'UPDATE_PROVIDERS', XMLTYPE(V_RESULT.WORK_LOG), DECODE(V_RESULT.IS_ERROR, 0, 'OK', 'Error')
    FROM DUAL;

    COMMIT;
  END SP_UPDATE_PROVIDERS;

  -- Процедура расчета рабочих интервалов
  PROCEDURE PRC_LOAD_WORK_INTERVALS
    (
      I_DATE_START IN TIMESTAMP DEFAULT NULL,
      I_DATE_END IN TIMESTAMP DEFAULT NULL,
      I_FORCE IN VARCHAR2 DEFAULT 'N'
    ) AS
    TYPE LOG_T_RESULT IS RECORD(
      WORK_START TIMESTAMP,
      WORK_LOG CLOB,
      RESULT_NUM NUMBER,
      RESULT_TXT VARCHAR2(1500),
      IS_ERROR NUMBER(1)
    );
    V_DATE_START TIMESTAMP;
    V_DATE_END TIMESTAMP;
    V_RESULT LOG_T_RESULT;
    V_SUBSTEP_START TIMESTAMP;


    BEGIN
      IF I_DATE_START IS NULL
        THEN IF TO_CHAR(SYSTIMESTAMP,'HH24') = '00' AND TO_CHAR(SYSTIMESTAMP,'MI') < '35'
               THEN V_DATE_START := CAST(SYSTIMESTAMP - 30 AS TIMESTAMP);
               ELSE V_DATE_START := CAST(SYSTIMESTAMP - 10 AS TIMESTAMP);
             END IF;
        ELSE V_DATE_START := I_DATE_START;
      END IF;
      IF I_DATE_END IS NULL
        THEN V_DATE_END := SYSTIMESTAMP;
        ELSE V_DATE_END := I_DATE_END;
      END IF;
      V_RESULT.WORK_START := SYSTIMESTAMP;

      BEGIN
        -- Добавим псевдо-статусы для новых сотрудников
        V_SUBSTEP_START := SYSTIMESTAMP;
        V_RESULT.IS_ERROR := 0;
        V_RESULT.RESULT_TXT := 'Добавление псевдо-статусов';

        INSERT INTO H_EMPLOYEES_STATUS
        SELECT CAST(ENTERED - 301/86400 AS TIMESTAMP) ENTERED, LOGIN,
               '{no_projects}' FID_PROJECT, FID_NAU_STATUS, FID_NC_STATUS,
               'Pseudo' REASON, 301 DURATION, FID_PLATFORM, ENTERED LIVED
        FROM
          (
            SELECT /*+ PUSH_PRED (SQS_N)*/ DISTINCT SQS_N.LOGIN, SQS_N.FID_PLATFORM,
              FIRST_VALUE(SQS_N.ENTERED)OVER(PARTITION BY SQS_N.LOGIN, SQS_N.FID_PLATFORM ORDER BY SQS_N.ENTERED) ENTERED,
              FIRST_VALUE(SQS_N.DURATION)OVER(PARTITION BY SQS_N.LOGIN, SQS_N.FID_PLATFORM ORDER BY SQS_N.ENTERED) DURATION,
              FIRST_VALUE(SQS_N.FID_NAU_STATUS)OVER(PARTITION BY SQS_N.LOGIN, SQS_N.FID_PLATFORM ORDER BY SQS_N.ENTERED) FID_NAU_STATUS,
              FIRST_VALUE(SQS_N.FID_NC_STATUS)OVER(PARTITION BY SQS_N.LOGIN, SQS_N.FID_PLATFORM ORDER BY SQS_N.ENTERED) FID_NC_STATUS
            FROM VW_EMPLOYEES_STATUSES SQS_N
            WHERE SQS_N.DURATION > 0
              AND
                (
                  SELECT MIN(VWE.CREATION_TIME)
                  FROM VW_EMPLOYEES VWE
                  WHERE VWE.REMOVED = 0 AND VWE.LOGIN = SQS_N.LOGIN
                ) >= V_DATE_START
          )
        WHERE DURATION <= 300;

        V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
        EXCEPTION
        WHEN OTHERS THEN
        V_RESULT.RESULT_NUM := SQLCODE;
        V_RESULT.RESULT_TXT := V_RESULT.RESULT_TXT||': '||SQLERRM;
        V_RESULT.IS_ERROR := 1;
      END;

      IF V_RESULT.IS_ERROR = 1 THEN ROLLBACK; END IF;
      -- Формируем лог
      V_RESULT.WORK_LOG := '<WORK_INTERVALS time="{time_all}" date_start="{date_start}" date_stop="{date_stop}" force="{force}" >';
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_start}',TO_CHAR(V_DATE_START,'DD.MM.YYYY HH24:MI:SS'));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_stop}',TO_CHAR(V_DATE_END,'DD.MM.YYYY HH24:MI:SS'));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{force}',I_FORCE);

      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG || '<Pseudo time="{time}" val="{val}">{text}</Pseudo>';
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_SUBSTEP_START, SYSTIMESTAMP));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{val}',TO_CHAR(V_RESULT.RESULT_NUM));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{text}',TO_CHAR(V_RESULT.RESULT_TXT));

      COMMIT;

      BEGIN
        -- Добавляем или обновляем интервалы
        V_SUBSTEP_START := SYSTIMESTAMP;
        V_RESULT.RESULT_TXT := 'Добавление/обновление интервалов';
        MERGE INTO EMPLOYEES_WORK_INTERVAL EWI USING
          (
            WITH
                SQ_FIRST_WE AS
              ( -- Выборка самого старого рабочего интервала, попадающего на начало диапазона расчета
                  SELECT LOGIN, FID_PLATFORM, START_WORK_TIME, END_WORK_TIME, INTERVAL_NO
                  FROM
                    (
                      SELECT EWI.LOGIN, EWI.FID_PLATFORM, EWI.START_WORK_TIME, EWI.END_WORK_TIME,
                        RANK()OVER(PARTITION BY EWI.LOGIN, EWI.FID_PLATFORM ORDER BY EWI.END_WORK_TIME DESC) INTERVAL_NO
                      FROM EMPLOYEES_WORK_INTERVAL EWI
                      WHERE EWI.TIME_DELETED IS NULL
                    )
                  WHERE V_DATE_START BETWEEN START_WORK_TIME AND END_WORK_TIME
                        AND INTERVAL_NO > 1
              ),
                SQ_STATUSES AS
              ( -- Статусы для обработки
                  SELECT /*+ PUSH_PRED (VES)*/
                    VES.FID_NAU_STATUS, DS.NAME, DS.REASON,
                    VES.LOGIN, VES.FID_PLATFORM,
                    VES.ENTERED, VES.DURATION, CAST(VES.ENTERED + VES.DURATION/86400 AS TIMESTAMP) LEAVED
                  FROM VW_EMPLOYEES_STATUSES VES
                    JOIN D_STATUSES DS
                      ON DS.ID_STATUS = VES.FID_NAU_STATUS
                        AND DS.NAME NOT IN ('redirect','available','notavailable')
                  WHERE VES.ENTERED < V_DATE_END
                    AND CAST(VES.ENTERED + VES.DURATION/86400 AS TIMESTAMP) > V_DATE_START
                    AND VES.FID_PLATFORM != 1
                    AND NOT EXISTS
                      ( -- Не берем статусы, начинающиеся до конца самого старого рабочего интервала, попадающего на начало диапазона расчета
                        SELECT 1 FROM SQ_FIRST_WE FWE
                        WHERE FWE.LOGIN = VES.LOGIN
                          AND FWE.END_WORK_TIME > VES.ENTERED
                          AND DS.NAME != 'offline'
                          AND VES.DURATION <= 43200
                      )
              ),
                SQ_OFFLINE AS
              ( -- Оффлайны и слишком длинные статусы (СДС)
                  SELECT DISTINCT
                    SQS.NAME STATUS_NAME,
                    SQS.LOGIN, SQS.FID_PLATFORM,
                    SQS.ENTERED, SQS.DURATION, SQS.LEAVED
                  FROM SQ_STATUSES SQS
                  WHERE (SQS.NAME = 'offline' AND SQS.DURATION > 300
                         OR  SQS.NAME != 'offline' AND SQS.DURATION > 43200)
              ),
                SQ_OFFLINE_GOOD AS
              ( -- Оффлайны и СДС, не накрывающие рабочие статусы
                  SELECT SOF.STATUS_NAME, SOF.LOGIN, SOF.FID_PLATFORM, SOF.ENTERED, SOF.DURATION, SOF.LEAVED
                  FROM SQ_OFFLINE SOF
                    LEFT JOIN SQ_STATUSES SQSF ON SQSF.LOGIN = SOF.LOGIN AND SQSF.FID_PLATFORM = SOF.FID_PLATFORM
                                              AND SQSF.ENTERED > SOF.ENTERED AND SQSF.LEAVED < SOF.LEAVED
                                              AND SQSF.NAME != 'offline' AND SQSF.DURATION <= 43200
                  WHERE SQSF.FID_NAU_STATUS IS NULL
              ),
                SQ_OFFLINE_BAD AS
              ( -- Оффлайны, СДС и накрытые ими рабочие статусы
                  SELECT SOF.STATUS_NAME, SQSF.NAME S_NAME, SOF.LOGIN, SOF.FID_PLATFORM,
                    NVL(LAG(SQSF.LEAVED)OVER(PARTITION BY SOF.LOGIN, SOF.FID_PLATFORM, SOF.ENTERED ORDER BY SQSF.ENTERED, SQSF.LEAVED),SOF.ENTERED) INT_BEG1,
                    SQSF.ENTERED INT_END1,
                    SQSF.LEAVED INT_BEG2,
                    NVL(LEAD(SQSF.ENTERED)OVER(PARTITION BY SOF.LOGIN, SOF.FID_PLATFORM, SOF.ENTERED ORDER BY SQSF.ENTERED, SQSF.LEAVED),SOF.LEAVED) INT_END2,
                    SOF.ENTERED, SOF.LEAVED, SQSF.ENTERED E1, SQSF.LEAVED L1
                  FROM SQ_OFFLINE SOF
                    LEFT JOIN SQ_STATUSES SQSF ON SQSF.LOGIN = SOF.LOGIN AND SQSF.FID_PLATFORM = SOF.FID_PLATFORM
                                              AND SQSF.ENTERED > SOF.ENTERED AND SQSF.LEAVED < SOF.LEAVED
                                              AND SQSF.NAME != 'offline' AND SQSF.DURATION <= 43200
                  WHERE SQSF.FID_NAU_STATUS IS NOT NULL
              ),
                SQ_OFFLINE_FROM_BAD AS
              ( -- Нерабочие интервалы из Оффлайнов и СДС, накрывающих рабочие статусы
                SELECT STATUS_NAME, LOGIN, FID_PLATFORM, INT_BEG1 INT_BEG, INT_END1 INT_END,
                  PKG_INTERVALS.FNC_INTERVALTOSEC(INT_BEG1, INT_END1) DURATION
                FROM SQ_OFFLINE_BAD
                WHERE PKG_INTERVALS.FNC_INTERVALTOSEC(INT_BEG1, INT_END1) > DECODE(STATUS_NAME, 'offline', 300, 43200)
                UNION
                SELECT STATUS_NAME, LOGIN, FID_PLATFORM, INT_BEG2 INT_BEG, INT_END2 INT_END,
                  PKG_INTERVALS.FNC_INTERVALTOSEC(INT_BEG2, INT_END2) DURATION
                FROM SQ_OFFLINE_BAD
                WHERE PKG_INTERVALS.FNC_INTERVALTOSEC(INT_BEG2, INT_END2) > DECODE(STATUS_NAME, 'offline', 300, 43200)
              ),
                SQ_AWAY_INTERVALS AS
              ( -- Все нерабочие интервалы
                  SELECT STATUS_NAME, LOGIN, FID_PLATFORM, INT_BEG, INT_END, ROWNUM AS ROWNO
                  FROM
                    (
                      SELECT STATUS_NAME, LOGIN, FID_PLATFORM, ENTERED INT_BEG, LEAVED INT_END
                      FROM SQ_OFFLINE_GOOD
                      UNION
                      SELECT DISTINCT STATUS_NAME, LOGIN, FID_PLATFORM, INT_BEG, INT_END
                      FROM SQ_OFFLINE_FROM_BAD
                    )
              ),
                SQ_UNIQUE_AWAY_INTERVALS AS
              ( -- Не перекрывающиеся нерабочие интервалы
                SELECT STATUS_NAME, LOGIN, FID_PLATFORM, INT_BEG, INT_END
                FROM SQ_AWAY_INTERVALS AI
                WHERE NOT EXISTS
                  (
                    SELECT 1 FROM SQ_AWAY_INTERVALS AI1
                    WHERE AI1.LOGIN = AI.LOGIN
                      AND AI1.INT_BEG < AI.INT_END
                      AND AI1.INT_END > AI.INT_BEG
                      AND AI1.ROWNO != AI.ROWNO
                  )
                  AND NOT EXISTS
                  (
                    SELECT 1 FROM SQ_STATUSES SS
                    WHERE SS.LOGIN = AI.LOGIN
                      AND SS.ENTERED < AI.INT_END AND SS.LEAVED > AI.INT_BEG
                      AND SS.FID_PLATFORM != AI.FID_PLATFORM
                      AND SS.DURATION BETWEEN 1 AND 43200
                  )
                UNION ALL -- Свернутые перекрывающиеся нерабочие интервалы
                SELECT DISTINCT 'cal-offline' STATUS_NAME, AII.LOGIN, 0 FID_PLATFORM,
                  GREATEST(AII.INT_BEG, AII1.INT_BEG) INT_BEG,
                  LEAST(AII.INT_END, AII1.INT_END) INT_END
                FROM SQ_AWAY_INTERVALS AII
                  JOIN SQ_AWAY_INTERVALS AII1 ON AII1.LOGIN = AII.LOGIN
                                             AND AII1.INT_BEG < AII.INT_END
                                             AND AII1.INT_END > AII.INT_BEG
                                             AND AII1.ROWNO != AII.ROWNO
              ),
                SQ_PRE_WORK_INTERVALS AS
              ( -- Предварительно рабочие интервалы
                  SELECT SOF.LOGIN, SOF.FID_PLATFORM,
                    SOF.INT_END WR_BEGIN,
                    LEAD(SOF.INT_BEG)OVER(PARTITION BY SOF.LOGIN ORDER BY SOF.INT_BEG, SOF.INT_END) WR_END
                  FROM SQ_UNIQUE_AWAY_INTERVALS SOF
                  WHERE PKG_INTERVALS.FNC_INTERVALTOSEC(SOF.INT_BEG, SOF.INT_END) > 300
              )
            SELECT PWI.LOGIN, 0 FID_PLATFORM,
              MIN(GREATEST(PWI.WR_BEGIN,SQS.ENTERED)) WR_BEGIN,
              MAX(LEAST(PWI.WR_END, SQS.LEAVED)) WR_END,
              NULL TIME_DELETED
            FROM SQ_PRE_WORK_INTERVALS PWI
              JOIN SQ_STATUSES SQS ON SQS.LOGIN = PWI.LOGIN
                                  AND SQS.ENTERED >= PWI.WR_BEGIN AND SQS.LEAVED <= PWI.WR_END
                                  AND SQS.NAME != 'offline'  AND SQS.DURATION BETWEEN 1 AND 43200
            GROUP BY PWI.LOGIN, PWI.WR_BEGIN
            MINUS
            SELECT EWI.LOGIN, EWI.FID_PLATFORM, EWI.START_WORK_TIME WR_BEGIN, EWI.END_WORK_TIME WR_END, EWI.TIME_DELETED
            FROM EMPLOYEES_WORK_INTERVAL EWI
            WHERE EWI.END_WORK_TIME > V_DATE_START
          ) TMP
        ON (EWI.LOGIN = TMP.LOGIN AND EWI.START_WORK_TIME = TMP.WR_BEGIN)
        WHEN MATCHED THEN
        UPDATE SET EWI.END_WORK_TIME = TMP.WR_END, EWI.TIME_CREATED = SYSTIMESTAMP,
          EWI.TIME_DELETED = NULL, EWI.TIME_REVERTED = CASE WHEN EWI.TIME_DELETED IS NOT NULL THEN SYSTIMESTAMP END
        WHEN NOT MATCHED THEN
        INSERT(EWI.TIME_CREATED, EWI.LOGIN, EWI.FID_PLATFORM, EWI.START_WORK_TIME, EWI.END_WORK_TIME)
        VALUES(SYSTIMESTAMP, TMP.LOGIN, TMP.FID_PLATFORM, TMP.WR_BEGIN, TMP.WR_END);

        V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
        EXCEPTION
        WHEN OTHERS THEN
        V_RESULT.RESULT_NUM := SQLCODE;
        V_RESULT.RESULT_TXT := V_RESULT.RESULT_TXT||': '||SQLERRM;
        V_RESULT.IS_ERROR := 1;
      END;
      IF V_RESULT.IS_ERROR = 1 THEN ROLLBACK; END IF;
      -- Формируем лог
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG || '<Insert time="{time}" val="{val}">{text}</Insert>';
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_SUBSTEP_START, SYSTIMESTAMP));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{val}',TO_CHAR(V_RESULT.RESULT_NUM));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{text}',TO_CHAR(V_RESULT.RESULT_TXT));

      COMMIT;

      BEGIN
        -- Удаляем интервалы, перекрытые после загрузки пропущенных статусов
        V_SUBSTEP_START := SYSTIMESTAMP;
        V_RESULT.RESULT_TXT := 'Удаление неверных интервалов';
        UPDATE EMPLOYEES_WORK_INTERVAL EWI
        SET EWI.TIME_DELETED = SYSTIMESTAMP, EWI.TIME_REVERTED = NULL
        WHERE EXISTS
        (
            SELECT 1 FROM EMPLOYEES_WORK_INTERVAL EWIT
            WHERE EWIT.LOGIN = EWI.LOGIN
                  AND EWIT.START_WORK_TIME <= EWI.START_WORK_TIME AND EWIT.END_WORK_TIME >= EWI.END_WORK_TIME
                  AND (EWIT.START_WORK_TIME != EWI.START_WORK_TIME OR EWIT.END_WORK_TIME != EWI.END_WORK_TIME)
                  AND EWIT.TIME_DELETED IS NULL
        )
          AND EWI.TIME_DELETED IS NULL;

        V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
        EXCEPTION
        WHEN OTHERS THEN
        V_RESULT.RESULT_NUM := SQLCODE;
        V_RESULT.RESULT_TXT := V_RESULT.RESULT_TXT||': '||SQLERRM;
        V_RESULT.IS_ERROR := 1;
      END;
      IF V_RESULT.IS_ERROR = 1 THEN ROLLBACK; END IF;
      -- Формируем лог
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG || '<Delete time="{time}" val="{val}">{text}</Delete>';
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_SUBSTEP_START, SYSTIMESTAMP));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{val}',TO_CHAR(V_RESULT.RESULT_NUM));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{text}',TO_CHAR(V_RESULT.RESULT_TXT));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time_all}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START, SYSTIMESTAMP));
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG || '</WORK_INTERVALS>';

      INSERT INTO LOG_ACTIONS (LOG_TIME, ACT_USER, OPERATION, DISCRIPTION, "RESULT")
        SELECT V_RESULT.WORK_START, USER,'INSERT_WORK_INTERVALS', XMLTYPE(V_RESULT.WORK_LOG), DECODE(V_RESULT.IS_ERROR, 0, 'OK', 'Error')
        FROM DUAL;

      COMMIT;
    END PRC_LOAD_WORK_INTERVALS;

  -- Процедура расчета КРП
  PROCEDURE PRC_LOAD_LOGIN_RATES
    (
      I_DATE_START IN TIMESTAMP DEFAULT NULL,
      I_DATE_END IN TIMESTAMP DEFAULT NULL
    ) AS
    TYPE LOG_T_RESULT IS RECORD
    (
      WORK_START TIMESTAMP,
      WORK_LOG CLOB,
      RESULT_NUM NUMBER,
      RESULT_TXT VARCHAR2(1500),
      IS_ERROR NUMBER(1)
    );
    V_DATE_START TIMESTAMP;
    V_DATE_END TIMESTAMP;
    V_RESULT LOG_T_RESULT;
    V_SUBSTEP_START TIMESTAMP;

    BEGIN
      IF I_DATE_END IS NULL
      THEN V_DATE_END := SYSTIMESTAMP;
      ELSE V_DATE_END := I_DATE_END;
      END IF;
      IF I_DATE_START IS NULL
      THEN V_DATE_START := CAST(SYSTIMESTAMP - 1 AS TIMESTAMP);
      ELSE V_DATE_START := I_DATE_START;
      END IF;
      V_RESULT.WORK_START := SYSTIMESTAMP;
      V_RESULT.RESULT_TXT := 'Обновляем загруженность сотрудника на проекте';
      V_RESULT.RESULT_NUM := 0;

      BEGIN
        V_SUBSTEP_START := SYSTIMESTAMP;
        V_RESULT.IS_ERROR := 0;
        -- Обнулим до расчета
        UPDATE EMPLOYEES_LOGIN_RATES LR SET LR.RATE = 0
        WHERE LR.RATE != 0
              AND LR.REPORT_DATE BETWEEN CAST(TRUNC(V_DATE_START) AS TIMESTAMP)
              AND CAST(TRUNC(V_DATE_END+1-1/86400) AS TIMESTAMP);
        -- Рассчитаем загруженность
        MERGE INTO EMPLOYEES_LOGIN_RATES DLR USING
          (
            WITH
                SQ_RANGES AS
              ( -- получение интервалов для расчета
                  SELECT /*+ MATERIALIZE*/ START_RANGE, STOP_RANGE
                  FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(CAST(TRUNC(V_DATE_START) AS TIMESTAMP),
                                                                CAST(TRUNC(V_DATE_END+1-1/86400) AS TIMESTAMP)))
              ),
                SQ_STATUSES AS
              ( -- получение статусов
                  SELECT CAST(TRUNC(GREATEST(SQR.START_RANGE, HES.ENTERED)) AS TIMESTAMP) AS ENTERED,
                    DS.NAME, HES.LOGIN, HES.FID_PROJECT,
                    PKG_INTERVALS.FNC_INTERVALTOSEC(GREATEST(SQR.START_RANGE, HES.ENTERED),
                                                    LEAST(SQR.STOP_RANGE, CAST(HES.ENTERED+HES.DURATION/86400 AS TIMESTAMP))) AS DURATION,
                    HES.FID_PLATFORM
                  FROM SQ_RANGES SQR
                    JOIN H_EMPLOYEES_STATUS HES
                      ON HES.ENTERED < CAST(TRUNC(V_DATE_END+1-1/86400) AS TIMESTAMP)
                         AND CAST(HES.ENTERED+HES.DURATION/86400 AS TIMESTAMP) > CAST(TRUNC(V_DATE_START) AS TIMESTAMP)
                         AND HES.ENTERED < SQR.STOP_RANGE
                         AND CAST(HES.ENTERED+HES.DURATION/86400 AS TIMESTAMP) > SQR.START_RANGE
                         AND HES.FID_PLATFORM != 1
                    JOIN D_STATUSES DS ON DS.ID_STATUS = HES.FID_NAU_STATUS
                  WHERE DS.NAME NOT IN ('offline','available','notavailable', 'accident', 'redirect', 'dnd')
              ),
                SQ_RATES_LIST_ALL AS
              ( -- рейтинг по статусам в выборке c {no_projects}
                  SELECT /*+ MATERIALIZE*/ DISTINCT ENTERED, LOGIN,
                    DECODE(FID_PROJECT, 'pnd', 'project_not_determined', FID_PROJECT) FID_PROJECT, FID_PLATFORM,
                    SUM(DURATION)OVER(PARTITION BY ENTERED,LOGIN, DECODE(FID_PROJECT, 'pnd', 'project_not_determined', FID_PROJECT))/
                        GREATEST(SUM(DURATION)OVER(PARTITION BY ENTERED, LOGIN), 1) AS RATE
                  FROM SQ_STATUSES
              ),
                SQ_RATES_LIST AS
              ( -- рейтинг по статусам в выборке без {no_projects}
                  SELECT /*+ MATERIALIZE*/ DISTINCT ENTERED, LOGIN, FID_PROJECT, FID_PLATFORM,
                    SUM(DURATION)OVER(PARTITION BY ENTERED,LOGIN, FID_PROJECT)/
                        GREATEST(SUM(DURATION)OVER(PARTITION BY ENTERED, LOGIN), 1) AS RATE
                  FROM SQ_STATUSES
                  WHERE FID_PROJECT NOT IN ('project_not_determined', 'pnd', '{no_projects}')
              ),
                SQ_RATES_LIST_OF AS
              ( -- рейтинг записей по непривязанным проектам
                  SELECT /*+ MATERIALIZE*/ ENTERED, LOGIN, FID_PROJECT, FID_PLATFORM, RATE
                  FROM SQ_RATES_LIST_ALL
                  WHERE (ENTERED, LOGIN, FID_PROJECT, FID_PLATFORM) NOT IN
                    (
                      SELECT ENTERED, LOGIN, FID_PROJECT, FID_PLATFORM FROM SQ_RATES_LIST
                    )
              ),
                SQ_RATES_CALC AS
              ( -- суммарный рейтинг и количество проектов с рейтингами за день
                  SELECT /*+ MATERIALIZE*/ ENTERED, LOGIN, 0 FID_PLATFORM,
                    COUNT(DISTINCT FID_PROJECT) AS PRJ, SUM(RATE) AS RATES
                  FROM SQ_RATES_LIST
                  GROUP BY ENTERED, LOGIN
              ),
                SQ_RATES_CALC_OF AS
              ( -- суммарный рейтинг и количество с непривязанными проектами с рейтингами за день
                  SELECT /*+ MATERIALIZE*/ ENTERED, LOGIN, 0 FID_PLATFORM,
                    COUNT(DISTINCT FID_PROJECT) AS PRJ, SUM(RATE) AS RATES
                  FROM SQ_RATES_LIST_OF
                  GROUP BY ENTERED, LOGIN
              ),
                SQ_LOGIN_PROJECTS AS
              ( -- проекты, привязанные к сотрудникам, которые не попали в рейтинг(из-за непривязанных) за день и количество
                  SELECT DISTINCT
                    GREATEST(SQR.START_RANGE, CAST(TRUNC(VRPE.ACTIVE_FROM) AS TIMESTAMP)) AS ENTERED, VRPE.LOGIN, VRPE.PROJECT_ID, VRPE.FID_PLATFORM,
                    GREATEST(COUNT(DISTINCT VRPE.PROJECT_ID)OVER
                              (PARTITION BY GREATEST(SQR.START_RANGE, CAST(TRUNC(VRPE.ACTIVE_FROM) AS TIMESTAMP)), VRPE.LOGIN), 1) AS PROJECT_CNT
                  FROM SQ_RANGES SQR
                    JOIN VW_REL_PROJECTS_EMPLOYEES VRPE
                      ON VRPE.ACTIVE_FROM <= SQR.STOP_RANGE AND VRPE.ACTIVE_TILL >= SQR.START_RANGE
                         AND VRPE.FID_PLATFORM != 1
                  WHERE EXISTS
                    (
                      SELECT 1
                      FROM SQ_RATES_CALC_OF SQRL
                      WHERE SQRL.ENTERED = GREATEST(SQR.START_RANGE, CAST(TRUNC(VRPE.ACTIVE_FROM) AS TIMESTAMP))
                        AND SQRL.LOGIN = VRPE.LOGIN
                    )
              ),
                SQ_RESULT AS
              ( -- Добавляем к рейтингу нераспределенный в соответствии с привязанными проектами 
                SELECT DISTINCT SQRC.ENTERED, SQRC.LOGIN,
                  NVL(SQLP.PROJECT_ID, SQRL.FID_PROJECT) PROJECT_ID, NVL(SQLP.FID_PLATFORM, 0) FID_PLATFORM,
                  NVL2(SQLP.PROJECT_CNT, 1, SQRL.RATE)/GREATEST(NVL(SQLP.PROJECT_CNT, 0), 1) AS RATE
                FROM SQ_RATES_CALC_OF SQRC
                  JOIN SQ_RATES_LIST_OF SQRL ON SQRL.ENTERED = SQRC.ENTERED
                                                AND SQRL.LOGIN = SQRC.LOGIN
                                                AND SQRL.FID_PROJECT IN ('project_not_determined', '{no_projects}')
                  LEFT JOIN SQ_LOGIN_PROJECTS SQLP ON SQRC.ENTERED = SQLP.ENTERED
                                                      AND SQRC.LOGIN = SQLP.LOGIN
                WHERE NOT EXISTS
                  (
                    SELECT 1 FROM SQ_RATES_LIST SQC
                    WHERE SQC.ENTERED = SQRL.ENTERED
                          AND SQC.LOGIN = SQRL.LOGIN
                  )
                UNION ALL
                SELECT ENTERED, LOGIN, FID_PROJECT PROJECT_ID, FID_PLATFORM, RATE
                FROM SQ_RATES_LIST
              )
            SELECT ENTERED, LOGIN, PROJECT_ID, FID_PLATFORM, RATE
            FROM SQ_RESULT SQRL
          )TMP
        ON(DLR.REPORT_DATE = TMP.ENTERED AND DLR.LOGIN = TMP.LOGIN AND DLR.FID_PROJECT = TMP.PROJECT_ID AND DLR.FID_PLATFORM = TMP.FID_PLATFORM)
        WHEN MATCHED THEN
          UPDATE SET DLR.RATE = TMP.RATE
        WHEN NOT MATCHED THEN
          INSERT(DLR.REPORT_DATE, DLR.LOGIN, DLR.FID_PROJECT, DLR.FID_PLATFORM, DLR.RATE)
          VALUES(TMP.ENTERED, TMP.LOGIN, TMP.PROJECT_ID, TMP.FID_PLATFORM, TMP.RATE);

        V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
        EXCEPTION
        WHEN OTHERS THEN
        V_RESULT.RESULT_NUM := SQLCODE;
        V_RESULT.RESULT_TXT := V_RESULT.RESULT_TXT||': '||SQLERRM;
        V_RESULT.IS_ERROR := 1;
      END;
      IF V_RESULT.IS_ERROR = 1 THEN ROLLBACK; END IF;
      -- Формируем лог
      V_RESULT.WORK_LOG := '<LOGIN_RATES time="{time_all}" date_start="{date_start}" date_stop="{date_stop}" >';
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_start}',TO_CHAR(V_DATE_START,'DD.MM.YYYY HH24:MI:SS'));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_stop}',TO_CHAR(V_DATE_END,'DD.MM.YYYY HH24:MI:SS'));
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG || '<Rates_count time="{time}" val="{val}">{text}</Rates_count>';
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_SUBSTEP_START, SYSTIMESTAMP));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{val}',TO_CHAR(V_RESULT.RESULT_NUM));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{text}',TO_CHAR(V_RESULT.RESULT_TXT));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time_all}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START, SYSTIMESTAMP));
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG || '</LOGIN_RATES>';

      INSERT INTO LOG_ACTIONS (LOG_TIME, ACT_USER, OPERATION, DISCRIPTION, "RESULT")
        SELECT V_RESULT.WORK_START, USER,'INSERT_LOGIN_RATES', XMLTYPE(V_RESULT.WORK_LOG), DECODE(V_RESULT.IS_ERROR, 0, 'OK', 'Error')
        FROM DUAL;

      COMMIT;
    END PRC_LOAD_LOGIN_RATES;

  -- Процедура рассчета суммы длительностей статусов
  PROCEDURE PRC_LOAD_STATUSES_SUM
    (
      I_DATE_START IN TIMESTAMP DEFAULT NULL,
      I_DATE_END IN TIMESTAMP DEFAULT NULL
    ) AS
    TYPE LOG_T_RESULT IS RECORD
    (
      WORK_START TIMESTAMP,
      WORK_LOG CLOB,
      RESULT_NUM NUMBER,
      RESULT_TXT VARCHAR2(1500),
      IS_ERROR NUMBER(1)
    );
    V_DATE_START TIMESTAMP;
    V_DATE_END TIMESTAMP;
    V_RESULT LOG_T_RESULT;
    V_SUBSTEP_START TIMESTAMP;

    BEGIN
      IF I_DATE_END IS NULL
      THEN V_DATE_END := CAST(TRUNC(SYSTIMESTAMP + 1 - 1/86400) AS TIMESTAMP);
      ELSE V_DATE_END := I_DATE_END;
      END IF;
      IF I_DATE_START IS NULL
      THEN V_DATE_START := CAST(TRUNC(SYSTIMESTAMP - 1) AS TIMESTAMP);
      ELSE V_DATE_START := I_DATE_START;
      END IF;
      V_RESULT.WORK_START := SYSTIMESTAMP;
      V_RESULT.RESULT_TXT := 'Рассчитываем сумму длительностей статусов';
      V_RESULT.RESULT_NUM := 0;
      BEGIN
        V_SUBSTEP_START := SYSTIMESTAMP;
        V_RESULT.IS_ERROR := 0;

        -- Обнулим до расчета
        UPDATE EWI_SUM_STATUSES ESS SET ESS.SUM_DURATION = 0
        WHERE ESS.SUM_DURATION != 0
              AND ESS.REPORT_DATE = V_DATE_START
              AND EXISTS
              (
                  SELECT 1 FROM EMPLOYEES_WORK_INTERVAL EWI
                  WHERE EWI.ID_WORK_INTERVAL = ESS.FID_WORK_INTERVAL
                        AND EWI.END_WORK_TIME > V_DATE_START
              );
        -- Рассчитаем суммы статусов
        MERGE INTO EWI_SUM_STATUSES ESS USING
        (
          WITH
            SQ_RANGES AS
            ( -- получение интервалов для расчета
              SELECT /*+ MATERIALIZE*/ START_RANGE, STOP_RANGE
              FROM TABLE(PKG_INTERVALS.FNC_INTERVALTORANGES(V_DATE_START, V_DATE_END))
            ),
            SQ_INTERVALS AS
            ( -- получение рабочих интервалов
              SELECT /*+ MATERIALIZE*/
                EWI.ID_WORK_INTERVAL, EWI.LOGIN,
                EWI.START_WORK_TIME, EWI.END_WORK_TIME,
                GREATEST(EWI.START_WORK_TIME, RN.START_RANGE) START_RANGE,
                LEAST (EWI.END_WORK_TIME, RN.STOP_RANGE) STOP_RANGE
              FROM EMPLOYEES_WORK_INTERVAL EWI
                JOIN SQ_RANGES RN ON RN.STOP_RANGE > EWI.START_WORK_TIME
                                     AND RN.START_RANGE < EWI.END_WORK_TIME
              WHERE EWI.TIME_DELETED IS NULL
            ),
            SQ_LIMITS AS
            (
              SELECT /*+ MATERIALIZE*/ MIN(START_WORK_TIME) LOW_LIMIT, MAX(END_WORK_TIME) HIGH_LIMIT
              FROM SQ_INTERVALS
            ),
            SQ_STATUSES AS
            ( -- получение статусов
              SELECT /*+INDEX (HES IDX_HES_STATUS_TIME_LEAVED)*/
                SQR.ID_WORK_INTERVAL,
                GREATEST(SQR.START_RANGE, HES.ENTERED) ENTERED,
                PKG_INTERVALS.FNC_INTERVALTOSEC(GREATEST(SQR.START_RANGE, HES.ENTERED),
                                                LEAST(SQR.STOP_RANGE, HES.LEAVED)) DURATION,
                HES.FID_PROJECT,
                HES.FID_NAU_STATUS
              FROM H_EMPLOYEES_STATUS HES
                JOIN D_STATUSES DS ON DS.ID_STATUS = HES.FID_NAU_STATUS
                                  AND DS.NAME NOT IN ('offline','available','notavailable', 'accident', 'redirect', 'standoff')
                JOIN SQ_INTERVALS SQR ON SQR.LOGIN = HES.LOGIN
                                     AND SQR.STOP_RANGE > HES.ENTERED AND SQR.START_RANGE < HES.LEAVED
                CROSS JOIN SQ_LIMITS SL
              WHERE HES.ENTERED < SL.HIGH_LIMIT AND HES.LEAVED > SL.LOW_LIMIT
                    AND HES.DURATION <= 43200
            )
          SELECT SS.ID_WORK_INTERVAL, SS.FID_NAU_STATUS, TRUNC(SS.ENTERED) REPORT_DATE, SS.FID_PROJECT, SUM(SS.DURATION) DURATION
          FROM SQ_STATUSES SS
          GROUP BY SS.ID_WORK_INTERVAL, SS.FID_NAU_STATUS, TRUNC(SS.ENTERED), SS.FID_PROJECT
          HAVING SUM(SS.DURATION) > 0
          MINUS
          SELECT FID_WORK_INTERVAL, FID_STATUS, REPORT_DATE, FID_PROJECT, SUM_DURATION
          FROM EWI_SUM_STATUSES
        ) TMP
        ON
        (
          ESS.FID_WORK_INTERVAL = TMP.ID_WORK_INTERVAL
          AND ESS.FID_STATUS = TMP.FID_NAU_STATUS
          AND ESS.REPORT_DATE = TMP.REPORT_DATE
          AND ESS.FID_PROJECT = TMP.FID_PROJECT
        )
        WHEN MATCHED THEN
          UPDATE SET ESS.SUM_DURATION = TMP.DURATION
        WHEN NOT MATCHED THEN
          INSERT (ESS.FID_WORK_INTERVAL, ESS.FID_STATUS, ESS.SUM_DURATION, ESS.REPORT_DATE, ESS.FID_PROJECT)
          VALUES (TMP.ID_WORK_INTERVAL, TMP.FID_NAU_STATUS, TMP.DURATION, TMP.REPORT_DATE, TMP.FID_PROJECT);
        V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
        EXCEPTION
        WHEN OTHERS THEN
        V_RESULT.RESULT_NUM := SQLCODE;
        V_RESULT.RESULT_TXT := V_RESULT.RESULT_TXT||': '||SQLERRM;
        V_RESULT.IS_ERROR := 1;
      END;
      IF V_RESULT.IS_ERROR = 1 THEN ROLLBACK; END IF;
      -- Формируем лог
      V_RESULT.WORK_LOG := '<STATUSES_SUM time="{time_all}" date_start="{date_start}" date_stop="{date_stop}" >';
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_start}',TO_CHAR(V_DATE_START,'DD.MM.YYYY HH24:MI:SS'));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_stop}',TO_CHAR(V_DATE_END,'DD.MM.YYYY HH24:MI:SS'));
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG || '<Rows_count time="{time}" val="{val}">{text}</Rows_count>';
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_SUBSTEP_START, SYSTIMESTAMP));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{val}',TO_CHAR(V_RESULT.RESULT_NUM));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{text}',TO_CHAR(V_RESULT.RESULT_TXT));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time_all}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START, SYSTIMESTAMP));
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG || '</STATUSES_SUM>';

      INSERT INTO LOG_ACTIONS (LOG_TIME, ACT_USER, OPERATION, DISCRIPTION, "RESULT")
        SELECT V_RESULT.WORK_START, USER,'INSERT_STATUSES_SUM', XMLTYPE(V_RESULT.WORK_LOG), DECODE(V_RESULT.IS_ERROR, 0, 'OK', 'Error')
        FROM DUAL;

      COMMIT;

    END PRC_LOAD_STATUSES_SUM;

  -- Процедура обновления реестра Россвязи
  PROCEDURE PRC_UPDATE_ROSSVYAZ(I_CHANGE_DATE IN TIMESTAMP DEFAULT SYSTIMESTAMP)
    AS
    TYPE LOG_T_RESULT IS RECORD
    (
      WORK_START TIMESTAMP,
      WORK_LOG CLOB,
      RESULT_NUM NUMBER,
      RESULT_TXT VARCHAR2(1500),
      IS_ERROR NUMBER(1)
    );

    V_DATE_START TIMESTAMP;
    V_DATE_END TIMESTAMP;
    V_RESULT LOG_T_RESULT;
    V_WORK LT_RESULT;
    V_SUBSTEP_START TIMESTAMP;

    FUNCTION STEP_LOAD(I_STEP NUMBER) RETURN LT_RESULT IS
      V_RESULT_S LT_RESULT;
      BEGIN  -- STEP_LOAD
        V_RESULT_S.WORK_START := SYSTIMESTAMP;
        V_RESULT_S.WORK_LOG := '<action id="'||TO_CHAR(I_STEP)||'" time="{time}" {cnt}="{val}">{text}</action>';
        V_RESULT_S.IS_ERROR := 0;
        BEGIN
          IF I_STEP = 1 THEN
            V_RESULT_S.RESULT_TXT := 'Склейка кодов';
            UPDATE TMP_PHONECODES TP
            SET TP.FIRST_CODE = TO_NUMBER(TP.ABCDEF || TP.CODE_FROM), TP.LAST_CODE = TO_NUMBER(TP.ABCDEF || TP.CODE_TO);
            V_RESULT_S.RESULT_NUM := SQL%ROWCOUNT;

          ELSIF I_STEP = 2 THEN
            V_RESULT_S.RESULT_TXT := 'Существующие интервалы';
            UPDATE TMP_PHONECODES TP
              SET TP.ALREADY_EXISTS = 'Y'
            WHERE EXISTS
              (
                SELECT 1 FROM D_PHONECODES DP
                WHERE DP.FIRST_CODE = TP.FIRST_CODE AND DP.LAST_CODE = TP.LAST_CODE
                  --AND TP.OPERATOR = DP.OPERATOR AND TP.AREA = DP.AREA
                  AND DP.BLOCKED = TO_TIMESTAMP('01.01.2999', 'DD.MM.YYYY')
              );
            V_RESULT_S.RESULT_NUM := SQL%ROWCOUNT;

          ELSIF I_STEP = 3 THEN
            V_RESULT_S.RESULT_TXT := 'Блокировка интервалов';
            UPDATE D_PHONECODES DP
              SET DP.BLOCKED = I_CHANGE_DATE - INTERVAL '1' SECOND
            WHERE NOT EXISTS
              (
                SELECT 1 FROM TMP_PHONECODES TP
                WHERE DP.FIRST_CODE = TP.FIRST_CODE AND DP.LAST_CODE = TP.LAST_CODE
                      AND TP.ALREADY_EXISTS = 'Y'
              )
              AND DP.ID_PHONECODE != 0
              AND DP.BLOCKED = TO_TIMESTAMP('01.01.2999', 'DD.MM.YYYY');
            V_RESULT_S.RESULT_NUM := SQL%ROWCOUNT;

          ELSIF I_STEP = 4 THEN
            V_RESULT_S.RESULT_TXT := 'Добавление новых интервалов';
            INSERT INTO D_PHONECODES DP (FIRST_CODE, LAST_CODE, OPERATOR, AREA, CREATED)
              SELECT TP.FIRST_CODE, TP.LAST_CODE, TP.OPERATOR, TP.AREA, I_CHANGE_DATE CREATED
              FROM TMP_PHONECODES TP
              WHERE TP.ALREADY_EXISTS = 'N';
            V_RESULT_S.RESULT_NUM := SQL%ROWCOUNT;

          ELSIF I_STEP = 5 THEN
            V_RESULT_S.RESULT_TXT := 'Изменение оператора';
            MERGE INTO D_PHONECODES DPH
            USING
            (
              SELECT DP.FIRST_CODE, DP.LAST_CODE, DP.OPERATOR, DP.AREA,
                TP.OPERATOR OPERATOR_NEW, TP.AREA AREA_NEW
              FROM D_PHONECODES DP
                JOIN TMP_PHONECODES TP ON DP.FIRST_CODE = TP.FIRST_CODE
                                      AND DP.LAST_CODE = TP.LAST_CODE
                                      AND (TP.OPERATOR != DP.OPERATOR OR TP.AREA != DP.AREA)
                                      AND TP.ALREADY_EXISTS = 'Y'
              WHERE DP.BLOCKED = TO_TIMESTAMP('01.01.2999', 'DD.MM.YYYY')
            ) TMP
            ON
            (
              DPH.FIRST_CODE = TMP.FIRST_CODE AND DPH.LAST_CODE = TMP.LAST_CODE
            )
            WHEN MATCHED THEN
            UPDATE SET DPH.OPERATOR = TMP.OPERATOR_NEW, DPH.AREA = TMP.AREA_NEW;
            V_RESULT_S.RESULT_NUM := SQL%ROWCOUNT;
          END IF;
          EXCEPTION
          WHEN OTHERS THEN
          V_RESULT_S.RESULT_NUM := SQLCODE;
          V_RESULT_S.RESULT_TXT := V_RESULT_S.RESULT_TXT||': '||SQLERRM;
          V_RESULT_S.IS_ERROR := 1;
        END;
        --Результируем время выполнения шага
        V_RESULT_S.WORK_LOG := REPLACE(V_RESULT_S.WORK_LOG,'{time}',NC_CORE.PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT_S.WORK_START,SYSTIMESTAMP));
        IF V_RESULT_S.IS_ERROR = 1 THEN
          V_RESULT_S.WORK_LOG := REPLACE(V_RESULT_S.WORK_LOG,'{cnt}','error');
        ELSE
          V_RESULT_S.WORK_LOG := REPLACE(V_RESULT_S.WORK_LOG,'{cnt}','cnt');
        END IF;
        V_RESULT_S.WORK_LOG := REPLACE(V_RESULT_S.WORK_LOG,'{val}',TO_CHAR(V_RESULT_S.RESULT_NUM));
        V_RESULT_S.WORK_LOG := REPLACE(V_RESULT_S.WORK_LOG,'{text}',V_RESULT_S.RESULT_TXT);
        RETURN V_RESULT_S;
      END; -- STEP_LOAD

    BEGIN -- PRC_UPDATE_ROSSVYAZ
      V_DATE_START := SYSTIMESTAMP;
      V_RESULT.WORK_START := SYSTIMESTAMP;  --Начинаем работу по обновлению
      V_RESULT.IS_ERROR := 0;
      FOR I IN 1..5 LOOP
        EXIT WHEN V_WORK.IS_ERROR = 1;
        V_WORK := STEP_LOAD(I);
        V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
      END LOOP;
      IF V_WORK.IS_ERROR = 1 THEN
        ROLLBACK;
      ELSE
        COMMIT;
      END IF;
      -- Лог событий
      V_DATE_END := SYSTIMESTAMP;
      V_RESULT.WORK_LOG := '<UPDATE_ROSSVYAZ time="{time}" date_start="{date_start}" date_stop="{date_stop}">'||V_RESULT.WORK_LOG||'</UPDATE_ROSSVYAZ>';
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',NC_CORE.PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_start}',to_char(V_DATE_START,'DD.MM.YYYY HH24:MI:SS'));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_stop}',to_char(V_DATE_END,'DD.MM.YYYY HH24:MI:SS'));
      -- Пишем в таблицу логов
      INSERT INTO LOG_ACTIONS (LOG_TIME, ACT_USER, OPERATION, DISCRIPTION, "RESULT")
        SELECT V_DATE_START, USER, 'UPDATE_ROSSVYAZ', XMLTYPE(V_RESULT.WORK_LOG), DECODE(V_RESULT.IS_ERROR, 0, 'OK', 'Error')
        FROM DUAL;
      COMMIT;

    END PRC_UPDATE_ROSSVYAZ;

  ------------------------------------------------------
  --процедура загрузки чатов, почты в отчетную платформу
  ------------------------------------------------------
  PROCEDURE SP_UPDATE_CHATS(I_DATE_START TIMESTAMP, I_DATE_END TIMESTAMP,
                            I_FORCE CHAR DEFAULT 'N', I_PLATFORMS T_LIST_INTEGER DEFAULT NULL) IS

    V_RESULT LT_RESULT;
    V_WORK LT_RESULT;
    V_DATE_START TIMESTAMP := I_DATE_START;
    V_DATE_END TIMESTAMP := I_DATE_END;
    V_PLATFORMS T_LIST_INTEGER := I_PLATFORMS;

  --------------------------------------------
  --Заливка данных по чатам почты россии ИСО при занесении через редактор коммон админа
  --------------------------------------------
      FUNCTION LOAD_CHATS_ISO RETURN LT_RESULT IS
      V_RESULT LT_RESULT;
      V_WORK LT_RESULT;
      V_SUBSTEP_START TIMESTAMP;

      --Шаги по заливке
      FUNCTION STEP_LOAD(I_STEP NUMBER) RETURN LT_RESULT IS
        V_RESULT LT_RESULT;
        V_WORK LT_RESULT;
        BEGIN
          V_RESULT.WORK_START := SYSTIMESTAMP;
          V_RESULT.WORK_LOG := '<action id="'||TO_CHAR(I_STEP)||'" time="{time}" {cnt}="{val}">{text}</action>';
          V_RESULT.IS_ERROR := 0;
          BEGIN
            IF I_STEP = 1 THEN
              V_RESULT.RESULT_TXT := 'Загрузка списка сессий';
              MERGE INTO CALL_SESSIONS CS USING
              (
                SELECT  CHAT.SESSION_ID, CHAT.PLATFORM AS  FID_PLATFORM, CONNECTION_TIME,
                  FINISH_TIME, 'chat' AS DIRECTION, 200 AS EXIT_CODE,
                  'not_determined' AS EXIT_CODE_DISCRIPTION, 1 AS IS_WORK_TIME
                FROM TABLE(RP_CHAT_INTEGRATION.PKG_GET_CHATS_INFO.FNC_GET_CHATS_INFO_ISO(V_DATE_START, V_DATE_END)
                ) CHAT
                WHERE EXISTS(
                              SELECT 1
                              FROM TABLE(V_PLATFORMS) P
                              WHERE TO_NUMBER(P.COLUMN_VALUE) = CHAT.PLATFORM
                            )
                  AND NOT EXISTS(
                                  SELECT /*+ INDEX_JOIN(CS PK_CS_SESSION_ID IDX_CS_FID_PLATFORM)*/ 1
                                  FROM CALL_SESSIONS CS
                                  WHERE CHAT.SESSION_ID = CS.SESSION_ID
                                    AND CHAT.PLATFORM = CS.FID_PLATFORM
                                    AND NVL(UPPER(I_FORCE),'N') = 'N'
                                )
              )TMP
              ON(CS.SESSION_ID = TMP.SESSION_ID AND CS.FID_PLATFORM = TMP.FID_PLATFORM)
              WHEN MATCHED THEN
                UPDATE SET CS.CREATED = TMP.CONNECTION_TIME, CS.ENDED = TMP.FINISH_TIME,
                            CS.DIRECTION = NVL(TMP.DIRECTION,'{error}'),
                            CS.EXIT_CODE = TMP.EXIT_CODE, CS.EXIT_CODE_DISCRIPTION = TMP.EXIT_CODE_DISCRIPTION,
                            CS.IS_WORK_TIME = TMP.IS_WORK_TIME
              WHEN NOT MATCHED THEN
                INSERT(CS.SESSION_ID, CS.CREATED, CS.ENDED, CS.DIRECTION,
                        CS.FID_PLATFORM, CS.EXIT_CODE, CS.EXIT_CODE_DISCRIPTION, CS.IS_WORK_TIME)
                VALUES(TMP.SESSION_ID, TMP.CONNECTION_TIME, TMP.FINISH_TIME, NVL(TMP.DIRECTION,'{error}'),
                        TMP.FID_PLATFORM, TMP.EXIT_CODE, TMP.EXIT_CODE_DISCRIPTION, TMP.IS_WORK_TIME);

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 2 THEN
              V_RESULT.RESULT_TXT := 'Загрузка информации по соединениям';
              INSERT INTO CALLS_INFO(SESSION_ID, FID_PLATFORM, LINK_ID, FID_PROJECT, FINAL_STAGE, ABONENT,
                                     CALLER, CALLED, OPERATOR, OPERATOR_CREATED,  OPERATOR_CONNECTED,
                                     OPERATOR_ENDED, OPERATOR_HOLD, OPERATOR_WRAPUP, SPEAK_SEGMENTS,
                                     IS_QUALITY_CONTROL, INCORRECT_CALL_TIME, BRAKE_CALL, FID_PROVIDER,
                                     FID_AREA, "COST", IP_ADDRESS, PORT)
            SELECT /*+ MATERIALIZE*/
                  CHAT.SESSION_ID,
                  CHAT.PLATFORM AS FID_PLATFORM,
                  ROW_NUMBER()OVER(PARTITION BY CHAT.SESSION_ID ORDER BY CHAT.CONNECTION_TIME) AS LINK_ID,
                  CHAT.PROJECT_ID AS FID_PROJECT,
                  'operator' AS FINAL_STAGE,
                  'Посетитель' AS ABONENT,
                  CHAT.OPERATOR_LOGIN AS CALLER,
                  CHAT.OPERATOR_LOGIN AS CALLED,
                  CHAT.OPERATOR_LOGIN AS OPERATOR,
                  CHAT.CONNECTION_TIME AS OPERATOR_CREATED,
                  CHAT.CONNECTION_TIME AS OPERATOR_CONNECTED,
                  CHAT.FINISH_TIME AS OPERATOR_ENDED,
                  0 AS OPERATOR_HOLD, 0 AS OPERATOR_WRAPUP, '0' AS SPEAK_SEGMENTS,
                  0 AS IS_QUALITY_CONTROL,
                  0 AS INCORRECT_CALL_TIME,
                  '{not_determined}' AS BRAKE_CALL,
                  0,
                  0,
                  0,
                  '0',
                  0
                  FROM TABLE(RP_CHAT_INTEGRATION.PKG_GET_CHATS_INFO.FNC_GET_CHATS_INFO_ISO(V_DATE_START,V_DATE_END)) CHAT

                  WHERE EXISTS(
                                SELECT 1
                                FROM TABLE(V_PLATFORMS) P
                                WHERE TO_NUMBER(P.COLUMN_VALUE) = CHAT.PLATFORM
                              )
                    AND EXISTS(
                                SELECT 1
                                FROM CALL_SESSIONS CS
                                WHERE CHAT.SESSION_ID = CS.SESSION_ID
                                  AND CHAT.PLATFORM = CS.FID_PLATFORM
                              )
                    AND NOT EXISTS(
                                    SELECT /*+ INDEX_JOIN(CS PK_CS_SESSION_ID IDX_CS_FID_PLATFORM)*/ 1
                                    FROM CALLS_INFO CS
                                    WHERE CHAT.SESSION_ID = CS.SESSION_ID
                                      AND CHAT.PLATFORM = CS.FID_PLATFORM
                                      AND NVL(UPPER(I_FORCE),'N') = 'N'
                                  );
              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              V_RESULT.RESULT_NUM := SQLCODE;
              V_RESULT.RESULT_TXT := V_RESULT.RESULT_TXT||': '||SQLERRM;
              V_RESULT.IS_ERROR := 1;
          END;
          --Результируем время выполнения шага
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
          --Плучаем цифровой результат
          IF V_RESULT.IS_ERROR = 1 THEN
            V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','error');
          ELSE
            V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','cnt');
          END IF;
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{val}',TO_CHAR(V_RESULT.RESULT_NUM));
          --Выводим текст шага
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{text}',V_RESULT.RESULT_TXT);
          RETURN V_RESULT;
        END;--Шаги по заливке

      BEGIN
        V_RESULT.WORK_START := SYSTIMESTAMP;
        V_RESULT.WORK_LOG := '<load time="{time}">';
        V_SUBSTEP_START := SYSTIMESTAMP;
        V_WORK.IS_ERROR := 0;
        FOR I IN 1..2 LOOP
          EXIT WHEN V_WORK.IS_ERROR = 1;
          V_WORK := STEP_LOAD(I);
          V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
        END LOOP;
        IF V_WORK.IS_ERROR = 1 THEN
          ROLLBACK;
        ELSE
          COMMIT;
        END IF;
        --Результируем время выполнения шага
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_SUBSTEP_START,SYSTIMESTAMP));
        V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||'</load>';
        V_RESULT.IS_ERROR := V_WORK.IS_ERROR;
        V_RESULT.WORK_LOG := '<CHATS_ISO time="{time}">'||V_RESULT.WORK_LOG||'</CHATS_ISO>';
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
        RETURN V_RESULT;
      END;--Заливка данных по чатам почты России ИСО
      --------------------------------------------------
      --Заливка данных по чатам почты россии КРАФТТОЛК автоинтеграция
      --------------------------------------------------
      FUNCTION LOAD_CHATS_CRAFT_TALK RETURN LT_RESULT IS
      V_RESULT LT_RESULT;
      V_WORK LT_RESULT;
      V_SUBSTEP_START TIMESTAMP;

      --Шаги по заливке
      FUNCTION STEP_LOAD(I_STEP NUMBER) RETURN LT_RESULT IS
        V_RESULT LT_RESULT;
        V_WORK LT_RESULT;
        BEGIN
          V_RESULT.WORK_START := SYSTIMESTAMP;
          V_RESULT.WORK_LOG := '<action id="'||TO_CHAR(I_STEP)||'" time="{time}" {cnt}="{val}">{text}</action>';
          V_RESULT.IS_ERROR := 0;
          BEGIN
            IF I_STEP = 1 THEN
              V_RESULT.RESULT_TXT := 'Загрузка списка сессий';
              MERGE INTO CALL_SESSIONS CS USING
              (
                SELECT DISTINCT CHAT.SESSION_ID, CHAT.PLATFORM AS  FID_PLATFORM, CONNECTION_TIME,
                  FINISH_TIME, 'chat' AS DIRECTION, 200 AS EXIT_CODE,
                  'not_determined' AS EXIT_CODE_DISCRIPTION, 1 AS IS_WORK_TIME
                FROM TABLE(RP_CHAT_INTEGRATION.PKG_GET_CHATS_INFO.FNC_GET_CHATS_CRAFT_TALK(V_DATE_START, V_DATE_END)
                ) CHAT
                WHERE EXISTS(
                              SELECT 1
                              FROM TABLE(V_PLATFORMS) P
                              WHERE TO_NUMBER(P.COLUMN_VALUE) = CHAT.PLATFORM
                            )
                  AND NOT EXISTS(
                                  SELECT /*+ INDEX_JOIN(CS PK_CS_SESSION_ID IDX_CS_FID_PLATFORM)*/ 1
                                  FROM CALL_SESSIONS CS
                                  WHERE CHAT.SESSION_ID = CS.SESSION_ID
                                    AND CHAT.PLATFORM = CS.FID_PLATFORM
                                    AND NVL(UPPER(I_FORCE),'N') = 'N'
                                )
              )TMP
              ON(CS.SESSION_ID = TMP.SESSION_ID AND CS.FID_PLATFORM = TMP.FID_PLATFORM)
              WHEN MATCHED THEN
                UPDATE SET CS.CREATED = TMP.CONNECTION_TIME, CS.ENDED = TMP.FINISH_TIME,
                            CS.DIRECTION = NVL(TMP.DIRECTION,'{error}'),
                            CS.EXIT_CODE = TMP.EXIT_CODE, CS.EXIT_CODE_DISCRIPTION = TMP.EXIT_CODE_DISCRIPTION,
                            CS.IS_WORK_TIME = TMP.IS_WORK_TIME
              WHEN NOT MATCHED THEN
                INSERT(CS.SESSION_ID, CS.CREATED, CS.ENDED, CS.DIRECTION,
                        CS.FID_PLATFORM, CS.EXIT_CODE, CS.EXIT_CODE_DISCRIPTION, CS.IS_WORK_TIME)
                VALUES(TMP.SESSION_ID, TMP.CONNECTION_TIME, TMP.FINISH_TIME, NVL(TMP.DIRECTION,'{error}'),
                        TMP.FID_PLATFORM, TMP.EXIT_CODE, TMP.EXIT_CODE_DISCRIPTION, TMP.IS_WORK_TIME);

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 2 THEN
              V_RESULT.RESULT_TXT := 'Загрузка информации по соединениям';
              INSERT INTO CALLS_INFO(SESSION_ID, FID_PLATFORM, LINK_ID, FID_PROJECT, FINAL_STAGE, ABONENT,
                                     CALLER, CALLED, OPERATOR, OPERATOR_CREATED,  OPERATOR_CONNECTED,
                                     OPERATOR_ENDED, OPERATOR_HOLD, OPERATOR_WRAPUP, SPEAK_SEGMENTS,
                                     IS_QUALITY_CONTROL, INCORRECT_CALL_TIME, BRAKE_CALL, FID_PROVIDER,
                                     FID_AREA, "COST", IP_ADDRESS, PORT)
            SELECT /*+ MATERIALIZE*/
                  CHAT.SESSION_ID,
                  CHAT.PLATFORM AS FID_PLATFORM,
                  LINK_ID AS LINK_ID,
                  CHAT.PROJECT_ID AS FID_PROJECT,
                  'operator' AS FINAL_STAGE,
                  'Посетитель' AS ABONENT,
                  CHAT.OPERATOR_LOGIN AS CALLER,
                  CHAT.OPERATOR_LOGIN AS CALLED,
                  CHAT.OPERATOR_LOGIN AS OPERATOR,
                  CHAT.CONNECTION_TIME AS OPERATOR_CREATED,
                  CHAT.CONNECTION_TIME AS OPERATOR_CONNECTED,
                  CHAT.FINISH_TIME AS OPERATOR_ENDED,
                  0 AS OPERATOR_HOLD, 0 AS OPERATOR_WRAPUP, '0' AS SPEAK_SEGMENTS,
                  0 AS IS_QUALITY_CONTROL,
                  0 AS INCORRECT_CALL_TIME,
                  '{not_determined}' AS BRAKE_CALL,
                  0,
                  0,
                  0,
                  '0',
                  0
                  FROM TABLE(RP_CHAT_INTEGRATION.PKG_GET_CHATS_INFO.FNC_GET_CHATS_CRAFT_TALK(V_DATE_START,V_DATE_END)) CHAT

                  WHERE EXISTS(
                                SELECT 1
                                FROM TABLE(V_PLATFORMS) P
                                WHERE TO_NUMBER(P.COLUMN_VALUE) = CHAT.PLATFORM
                              )
                    AND EXISTS(
                                SELECT 1
                                FROM CALL_SESSIONS CS
                                WHERE CHAT.SESSION_ID = CS.SESSION_ID
                                  AND CHAT.PLATFORM = CS.FID_PLATFORM
                              )
                    AND NOT EXISTS(
                                    SELECT /*+ INDEX_JOIN(CS PK_CS_SESSION_ID IDX_CS_FID_PLATFORM)*/ 1
                                    FROM CALLS_INFO CS
                                    WHERE CHAT.SESSION_ID = CS.SESSION_ID
                                      AND CHAT.PLATFORM = CS.FID_PLATFORM
                                      AND NVL(UPPER(I_FORCE),'N') = 'N'
                                  );
              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              V_RESULT.RESULT_NUM := SQLCODE;
              V_RESULT.RESULT_TXT := V_RESULT.RESULT_TXT||': '||SQLERRM;
              V_RESULT.IS_ERROR := 1;
          END;
          --Результируем время выполнения шага
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
          --Плучаем цифровой результат
          IF V_RESULT.IS_ERROR = 1 THEN
            V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','error');
          ELSE
            V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','cnt');
          END IF;
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{val}',TO_CHAR(V_RESULT.RESULT_NUM));
          --Выводим текст шага
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{text}',V_RESULT.RESULT_TXT);
          RETURN V_RESULT;
        END;--Шаги по заливке

      BEGIN
        V_RESULT.WORK_START := SYSTIMESTAMP;
        V_RESULT.WORK_LOG := '<load time="{time}">';
        V_SUBSTEP_START := SYSTIMESTAMP;
        V_WORK.IS_ERROR := 0;
        FOR I IN 1..2 LOOP
          EXIT WHEN V_WORK.IS_ERROR = 1;
          V_WORK := STEP_LOAD(I);
          V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
        END LOOP;
        IF V_WORK.IS_ERROR = 1 THEN
          ROLLBACK;
        ELSE
          COMMIT;
        END IF;
        --Результируем время выполнения шага
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_SUBSTEP_START,SYSTIMESTAMP));
        V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||'</load>';
        V_RESULT.IS_ERROR := V_WORK.IS_ERROR;
        V_RESULT.WORK_LOG := '<CHATS_CRAFT_TALK time="{time}">'||V_RESULT.WORK_LOG||'</CHATS_CRAFT_TALK>';
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
        RETURN V_RESULT;
      END;--Заливка данных по чатам почты россии КРАФТ ТОЛК

    ------------------------
    --Заливка данных ГИС ЖКХ
    ------------------------
    FUNCTION LOAD_MAIL_ZHKH RETURN LT_RESULT IS
      V_RESULT LT_RESULT;
      V_WORK LT_RESULT;
      V_SUBSTEP_START TIMESTAMP;

      --Шаги по заливке
      FUNCTION STEP_LOAD(I_STEP NUMBER) RETURN LT_RESULT IS
        V_RESULT LT_RESULT;
        V_WORK LT_RESULT;
        BEGIN
          V_RESULT.WORK_START := SYSTIMESTAMP;
          V_RESULT.WORK_LOG := '<action id="'||TO_CHAR(I_STEP)||'" time="{time}" {cnt}="{val}">{text}</action>';
          V_RESULT.IS_ERROR := 0;
          BEGIN
            IF I_STEP = 1 THEN
              V_RESULT.RESULT_TXT := 'Загрузка списка сессий';
              MERGE INTO CALL_SESSIONS CS USING
                (
                  SELECT TO_CHAR(MLS.SESSION_ID) SESSION_ID, 2 FID_PLATFORM,
                         CAST(MLS.CONNECTION_TIME AS TIMESTAMP) CREATED,
                         CAST(MLS.FINISH_TIME AS TIMESTAMP) ENDED,
                         'mail' DIRECTION, 200 EXIT_CODE,
                         'not_determined' EXIT_CODE_DISCRIPTION, 1 IS_WORK_TIME
                  FROM TABLE(GIS_ZHKH.PKG_RATING_EMAIL.FNC_GET_RATING_EMAIL(V_DATE_START, V_DATE_END)) MLS
                  WHERE EXISTS(
                                SELECT 1
                                FROM TABLE(V_PLATFORMS) P
                                WHERE TO_NUMBER(P.COLUMN_VALUE) = 2
                              )
                    AND NOT EXISTS(
                                    SELECT /*+ INDEX(CS PK_CS_SID_PL)*/ 1
                                    FROM CALL_SESSIONS CS
                                    WHERE CS.SESSION_ID = TO_CHAR(MLS.SESSION_ID)
                                      AND CS.FID_PLATFORM = 2
                                      AND NVL(UPPER(I_FORCE),'N') = 'N'
                                  )
                )TMP
              ON(CS.SESSION_ID = TMP.SESSION_ID AND CS.FID_PLATFORM = TMP.FID_PLATFORM)
              WHEN MATCHED THEN
              UPDATE SET CS.CREATED = TMP.CREATED, CS.ENDED = TMP.ENDED,
                CS.DIRECTION = NVL(TMP.DIRECTION,'{error}'),
                CS.EXIT_CODE = TMP.EXIT_CODE, CS.EXIT_CODE_DISCRIPTION = TMP.EXIT_CODE_DISCRIPTION,
                CS.IS_WORK_TIME = TMP.IS_WORK_TIME
              WHEN NOT MATCHED THEN
              INSERT(CS.SESSION_ID, CS.CREATED, CS.ENDED, CS.DIRECTION,
                     CS.FID_PLATFORM, CS.EXIT_CODE, CS.EXIT_CODE_DISCRIPTION, CS.IS_WORK_TIME)
              VALUES(TMP.SESSION_ID, TMP.CREATED, TMP.ENDED, NVL(TMP.DIRECTION,'{error}'),
                TMP.FID_PLATFORM, TMP.EXIT_CODE, TMP.EXIT_CODE_DISCRIPTION, TMP.IS_WORK_TIME);

              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            ELSIF I_STEP = 2 THEN
              V_RESULT.RESULT_TXT := 'Загрузка информации по соединениям';
              INSERT INTO CALLS_INFO(SESSION_ID, FID_PLATFORM, LINK_ID, FID_PROJECT, FINAL_STAGE, ABONENT,
                                     CALLER, CALLED, OPERATOR, OPERATOR_CREATED,  OPERATOR_CONNECTED,
                                     OPERATOR_ENDED, OPERATOR_HOLD, OPERATOR_WRAPUP, SPEAK_SEGMENTS,
                                     IS_QUALITY_CONTROL, INCORRECT_CALL_TIME, BRAKE_CALL, FID_PROVIDER,
                                     FID_AREA, "COST", IP_ADDRESS, PORT)
                WITH
                    SQ_MAILS AS
                  (
                    SELECT MLS.SESSION_ID, 2 FID_PLATFORM, 1 LINK_ID,
                      MLS.PROJECT_ID FID_PROJECT, 'operator' FINAL_STAGE,
                      MLS.ABONENT, MLS.ABONENT CALLER, MLS.EMAIL CALLED,
                      MLS.OPERATOR_LOGIN OPERATOR,
                      CAST(MLS.CONNECTION_TIME AS TIMESTAMP) OPERATOR_CREATED,
                      CAST(MLS.CONNECTION_TIME AS TIMESTAMP) OPERATOR_CONNECTED,
                      CAST(MLS.FINISH_TIME AS TIMESTAMP) AS OPERATOR_ENDED,
                      0 OPERATOR_HOLD, 0 OPERATOR_WRAPUP, '0' SPEAK_SEGMENTS,
                      0 IS_QUALITY_CONTROL, '{not_determined}' BRAKE_CALL
                    FROM TABLE(GIS_ZHKH.PKG_RATING_EMAIL.FNC_GET_RATING_EMAIL(V_DATE_START, V_DATE_END)) MLS
                    WHERE EXISTS(
                                  SELECT 1
                                  FROM TABLE(V_PLATFORMS) P
                                  WHERE TO_NUMBER(P.COLUMN_VALUE) = 2
                                )
                      AND EXISTS(
                                  SELECT /*+ INDEX(CS PK_CS_SID_PL)*/ 1
                                  FROM CALL_SESSIONS CS
                                  WHERE CS.SESSION_ID = TO_CHAR(MLS.SESSION_ID)
                                    AND CS.FID_PLATFORM = 2
                                )
                      AND NOT EXISTS(
                                      SELECT /*+ INDEX(IDX_CI_SID_PL)*/ 1
                                      FROM CALLS_INFO CI
                                      WHERE CI.SESSION_ID = TO_CHAR(MLS.SESSION_ID)
                                        AND CI.FID_PLATFORM = 2
                                        AND NVL(UPPER(I_FORCE),'N') = 'N'
                                    )
                  )
                SELECT SESSION_ID, FID_PLATFORM, LINK_ID, FID_PROJECT, FINAL_STAGE, ABONENT,
                  CALLER, CALLED, OPERATOR, OPERATOR_CREATED, OPERATOR_CONNECTED, OPERATOR_ENDED,
                  OPERATOR_HOLD, OPERATOR_WRAPUP, SPEAK_SEGMENTS, IS_QUALITY_CONTROL,
                  0 AS INCORRECT_CALL_TIME, BRAKE_CALL, 0, 0, 0, '0', 0
                FROM SQ_MAILS;
              V_RESULT.RESULT_NUM := SQL%ROWCOUNT;
            END IF;
            EXCEPTION
            WHEN OTHERS THEN
            V_RESULT.RESULT_NUM := SQLCODE;
            V_RESULT.RESULT_TXT := V_RESULT.RESULT_TXT||': '||SQLERRM;
            V_RESULT.IS_ERROR := 1;
          END;
          --Результируем время выполнения шага
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
          --Плучаем цифровой результат
          IF V_RESULT.IS_ERROR = 1 THEN
            V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','error');
          ELSE
            V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{cnt}','cnt');
          END IF;
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{val}',TO_CHAR(V_RESULT.RESULT_NUM));
          --Выводим текст шага
          V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{text}',V_RESULT.RESULT_TXT);
          RETURN V_RESULT;
        END;--Шаги по заливке

      BEGIN
        V_RESULT.WORK_START := SYSTIMESTAMP;
        V_RESULT.WORK_LOG := '<load time="{time}">';
        V_SUBSTEP_START := SYSTIMESTAMP;
        V_WORK.IS_ERROR := 0;
        FOR I IN 1..2 LOOP
          EXIT WHEN V_WORK.IS_ERROR = 1;
          V_WORK := STEP_LOAD(I);
          V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
        END LOOP;
        IF V_WORK.IS_ERROR = 1 THEN
          ROLLBACK;
        ELSE
          COMMIT;
        END IF;
        --Результируем время выполнения шага
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_SUBSTEP_START,SYSTIMESTAMP));
        V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||'</load>';
        V_RESULT.IS_ERROR := V_WORK.IS_ERROR;
        V_RESULT.WORK_LOG := '<MailZHKH time="{time}">'||V_RESULT.WORK_LOG||'</MailZHKH>';
        V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
        RETURN V_RESULT;
      END;--Заливка данных ГИС ЖКХ

    BEGIN --SP_UPDATE_CHATS
      IF V_PLATFORMS IS NULL THEN
        V_PLATFORMS := T_LIST_INTEGER();
        SELECT ID_MODULE BULK COLLECT INTO V_PLATFORMS
        FROM D_MODULES
        WHERE ID_MODULE IN (2,6,7,8);
      END IF;
      --Смещаем начальную дату отбора для поиска потерянных сессий
      IF NVL(UPPER(I_FORCE),'N') = 'N' THEN
        IF TO_CHAR(V_DATE_END,'HH24:MI') = '00:00' THEN
          V_DATE_START := CAST(TRUNC(V_DATE_START)-2 AS TIMESTAMP);
        ELSIF TO_CHAR(V_DATE_END,'HH24:MI') = '12:00' THEN
          V_DATE_START := CAST(TRUNC(V_DATE_START)-1 AS TIMESTAMP);
        ELSIF EXTRACT(MINUTE FROM V_DATE_END) = 0 THEN
          V_DATE_START := CAST(TRUNC(V_DATE_START,'HH') AS TIMESTAMP);
        END IF;
      END IF;

      V_RESULT.WORK_START := SYSTIMESTAMP; --Начинаем работу по заливке
      V_RESULT.IS_ERROR := 0;


      V_WORK := LOAD_MAIL_ZHKH;
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
      V_RESULT.IS_ERROR := GREATEST(V_RESULT.IS_ERROR, V_WORK.IS_ERROR);
      V_WORK := LOAD_CHATS_ISO;
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
      V_RESULT.IS_ERROR := GREATEST(V_RESULT.IS_ERROR, V_WORK.IS_ERROR);
      V_WORK := LOAD_CHATS_CRAFT_TALK;
      V_RESULT.WORK_LOG := V_RESULT.WORK_LOG||V_WORK.WORK_LOG;
      V_RESULT.IS_ERROR := GREATEST(V_RESULT.IS_ERROR, V_WORK.IS_ERROR);
      --Формируем лог событий
      V_RESULT.WORK_LOG := '<UPDATE_CHATS time="{time}" filter_date_start="{date_start}" filter_date_stop="{date_stop}" force="{force}">'||V_RESULT.WORK_LOG||'</UPDATE_CHATS>';
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{time}',PKG_INTERVALS.FNC_INTERVALTOCHAR(V_RESULT.WORK_START,SYSTIMESTAMP));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_start}',to_char(V_DATE_START,'DD.MM.YYYY HH24:MI:SS'));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{date_stop}',to_char(V_DATE_END,'DD.MM.YYYY HH24:MI:SS'));
      V_RESULT.WORK_LOG := REPLACE(V_RESULT.WORK_LOG,'{force}',I_FORCE);

      INSERT INTO LOG_ACTIONS (LOG_TIME, ACT_USER, OPERATION, DISCRIPTION, "RESULT")
        SELECT V_RESULT.WORK_START, USER, 'UPDATE_CHATS', XMLTYPE(V_RESULT.WORK_LOG), DECODE(V_RESULT.IS_ERROR, 0, 'OK', 'Error')
        FROM DUAL;

      COMMIT;

      SYS.DBMS_OUTPUT.PUT_LINE(V_RESULT.WORK_LOG);

    END SP_UPDATE_CHATS; --SP_UPDATE_CHATS

END PKG_SERVICE;
/

