create type           SYS_PLSQL_1808372_1962_1 as table of "NC_CORE"."SYS_PLSQL_1808372_1940_1";
/

