create trigger TRG_D_PROJECT_PREFIX_ID
    before insert
    on D_PROJECT_PREFIX
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_PROJECT_PREFIX" IS NULL THEN
                                 SELECT SEQ_D_PROJECT_PREFIX_ID.NEXTVAL INTO :NEW."ID_PROJECT_PREFIX" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

