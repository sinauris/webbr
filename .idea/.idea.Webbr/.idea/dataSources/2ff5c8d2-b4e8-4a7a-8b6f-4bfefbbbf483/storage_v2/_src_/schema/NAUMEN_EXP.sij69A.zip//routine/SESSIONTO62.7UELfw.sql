create Function SessionTo62(P_SESSION_ID In VarChar2) Return VarChar2 As L_RETURN VarChar2(16);
Begin
With
T0 As (Select P_SESSION_ID SESSION_ID From DUAL),
T1 As (Select SESSION_ID, INSTR(SESSION_ID,'_',1,1) T1, INSTR(SESSION_ID,'_',1,2) T2, INSTR(SESSION_ID,'_',1,3) T3 From T0),
T2 As (Select SESSION_ID, SubStr(SESSION_ID,T1 - 2, 1) S0, SubStr(SESSION_ID,T1 - 1, 1) S1, SubStr(SESSION_ID,T1 + 1, T2 - T1 - 1) S2, SubStr(SESSION_ID,T2 + 1, T3 - T2 - 1) S3, SubStr(SESSION_ID, T3 + 1, Length(SESSION_ID) - T3) S4 From T1),
T3 As (Select SESSION_ID, Decode(S0,'s','0',S0)||Decode(S1,'s','0',S1)||S2||Decode(Length(S3),1,'00'||S3,2,'0'||S3,S3)||Decode(Length(S4),1,'000000'||S4,2,'00000'||S4,3,'0000'||S4,4,'000'||S4,5,'00'||S4,6,'0'||S4,S4) S0 From T2)
Select NumTo62(To_Number(S0)) Into L_RETURN From T3;
Return L_RETURN;
End SessionTo62;
/

