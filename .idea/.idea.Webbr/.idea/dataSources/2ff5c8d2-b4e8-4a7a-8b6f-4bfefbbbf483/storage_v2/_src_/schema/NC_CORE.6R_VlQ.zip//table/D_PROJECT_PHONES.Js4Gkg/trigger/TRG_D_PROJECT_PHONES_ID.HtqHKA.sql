create trigger TRG_D_PROJECT_PHONES_ID
    before insert
    on D_PROJECT_PHONES
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_PROJECT_PHONE" IS NULL THEN
                                 SELECT SEQ_D_PROJECT_PHONES_ID.NEXTVAL INTO :NEW."ID_PROJECT_PHONE" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

