create type           SYS_PLSQL_1808372_862_1 as table of "NC_CORE"."SYS_PLSQL_1808372_807_1";
/

