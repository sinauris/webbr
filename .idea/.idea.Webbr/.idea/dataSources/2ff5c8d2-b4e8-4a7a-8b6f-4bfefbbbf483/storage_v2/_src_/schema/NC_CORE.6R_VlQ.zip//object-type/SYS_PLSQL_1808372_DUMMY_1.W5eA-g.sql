create type           SYS_PLSQL_1808372_DUMMY_1 as table of number;
/

