create type           SYS_PLSQL_1808372_1208_1 as table of "NC_CORE"."SYS_PLSQL_1808372_1184_1";
/

