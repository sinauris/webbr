create type           SYS_PLSQL_2394302_144_1 as table of "NC_CORE"."SYS_PLSQL_2394302_127_1";
/

