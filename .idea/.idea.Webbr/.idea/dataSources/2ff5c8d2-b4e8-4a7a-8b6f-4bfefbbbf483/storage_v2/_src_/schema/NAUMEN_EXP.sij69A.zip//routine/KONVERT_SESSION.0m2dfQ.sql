create Function            KONVERT_SESSION(IP_SESSION In VarChar2, D_H In TimeStamp, D_E In TimeStamp) Return KONVERT_NDD_T As
xNDD      KONVERT_NDD;
xNDD_T  KONVERT_NDD_T := KONVERT_NDD_T();
Begin

for i in (
With

T0 As (
Select '37.221.186.20' IP From DUAL Union All
Select '37.221.186.118' IP From DUAL Union All
Select '37.221.186.119' IP From DUAL Union All
Select '37.221.186.120' IP From DUAL Union All
Select '37.221.186.121' IP From DUAL Union All
Select '127.0.0.1' IP From DUAL
),

T1 As (Select D_H D_HOME, D_E D_END From DUAL),
T2 As (Select IP_SESSION IP From DUAL),

T3 As (
Select a.SESSION_ID From NAUCRM62.CALL_LEGS a, T1 b, T2 c Where a.CREATED Between b.D_HOME And b.D_END And a.SRC_IP = c.IP
Union
Select a.SESSION_ID From NAUCRM62.CALL_LEGS a, T1 b, T2 c Where a.CREATED Between b.D_HOME And b.D_END And a.DST_IP = c.IP
),

T4 As (
Select a.SESSION_ID, a.LEG_ID, a.CREATED, a.CONNECTED, a.ENDED From NAUCRM62.CALL_LEGS a, T3 b Where a.SESSION_ID = b.SESSION_ID
Minus
Select a.SESSION_ID, a.LEG_ID, a.CREATED, a.CONNECTED, a.ENDED From NAUCRM62.CALL_LEGS a, T3 b, T0 c Where  a.SESSION_ID = b.SESSION_ID And a.DST_IP = c.IP
),

T5 As (Select SESSION_ID, Min(Nvl(CONNECTED,CREATED)) CONNECTED, Max(ENDED) ENDED From T4 Where CONNECTED Is Not Null Group By SESSION_ID)

Select b.FILENAME, To_Char(a.CONNECTED,'yyyy mm dd hh24 mi ss') CONNECTED, To_Char(a.ENDED,'yyyy mm dd hh24 mi ss') ENDED From T5 a, NAUCRM62.RECORDS40 b Where a.SESSION_ID = b.SESSION_ID

Order By CONNECTED
)

loop
xNDD := KONVERT_NDD(i.FILENAME, i.CONNECTED, i.ENDED);
xNDD_T.Extend(1);
xNDD_T(xNDD_T.Last) := xNDD;

end loop;

RETURN xNDD_T;
End KONVERT_SESSION;
/

