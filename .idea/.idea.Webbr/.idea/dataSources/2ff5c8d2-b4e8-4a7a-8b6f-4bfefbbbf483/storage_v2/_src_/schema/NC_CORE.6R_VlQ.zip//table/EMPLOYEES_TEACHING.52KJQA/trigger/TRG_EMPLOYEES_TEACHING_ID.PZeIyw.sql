create trigger TRG_EMPLOYEES_TEACHING_ID
    before insert
    on EMPLOYEES_TEACHING
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_TEACH" IS NULL THEN
                                 SELECT SEQ_EMPLOYEES_TEACHING_ID.NEXTVAL INTO :NEW."ID_TEACH" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

