create FUNCTION INTERVALIZE(fst DATE, snd DATE, per CHAR DEFAULT 'MI', percnt NUMBER DEFAULT 0, prec NUMBER DEFAULT 0, sf CHAR DEFAULT 'DD.MM.YYYY HH24:MI', df CHAR DEFAULT ' - ', ff CHAR DEFAULT 'DD.MM.YYYY HH24:MI')
RETURN INTERVAL_TAB
AS
V_INTERVALS INTERVAL_TAB;
BEGIN
SELECT INTERVAL_OBJ(TT.S, TT.F, TT.P)
BULK COLLECT INTO V_INTERVALS
FROM
(
SELECT
  (case when s < fst AND prec > 0 then fst else s end)
 s,
  (case when f > snd AND prec > 0 then snd else f end)
 f,
  to_char((case when s < fst AND prec > 0 then fst else s end) ,sf)
  ||df||
  to_char((case when f > snd AND prec > 0 then snd else f end), ff)
 p
FROM
(
SELECT
  add_months(
   trunc((fst), per)
   +(level-1)
    *(case when per IN ('SYYYY','YYYY','YEAR','SYEAR','YYY','YY','Y', 'Q', 'MONTH','MON','MM','RM') then 0 else (case when percnt = 0 then 1 else percnt end) end)
    *(case when per IN ('DAY','DY','D') then 7 else 1 end)
    /(case when per IN ('HH','HH12','HH24') then 24 else case when per = 'MI' then 1440 else 1 end end)
   ,(level-1)
    *(case when per IN ('SYYYY','YYYY','YEAR','SYEAR','YYY','YY','Y') then 12 else case when per = 'Q' then 3 else 1 end end)
    *(case when per IN ('SYYYY','YYYY','YEAR','SYEAR','YYY','YY','Y', 'Q', 'MONTH','MON','MM','RM') then (case when percnt = 0 then 1 else percnt end) else 0 end)
  )
 s,
  add_months(
   trunc((fst), per)
   +(level)
    *(case when per IN ('SYYYY','YYYY','YEAR','SYEAR','YYY','YY','Y', 'Q', 'MONTH','MON','MM','RM') then 0 else (case when percnt = 0 then 1 else percnt end) end)
    *(case when per IN ('DAY','DY','D') then 7 else 1 end)
    /(case when per IN ('HH','HH12','HH24') then 24 else case when per = 'MI' then 1440 else 1 end end)
   ,(level)
    *(case when per IN ('SYYYY','YYYY','YEAR','SYEAR','YYY','YY','Y') then 12 else case when per = 'Q' then 3 else 1 end end)
    *(case when per IN ('SYYYY','YYYY','YEAR','SYEAR','YYY','YY','Y', 'Q', 'MONTH','MON','MM','RM') then (case when percnt = 0 then 1 else percnt end) else 0 end)
  )
 f
FROM dual
connect BY level <= 1 + (
 case when per IN ('SYYYY','YYYY','YEAR','SYEAR','YYY','YY','Y', 'Q', 'MONTH','MON','MM','RM')
 then (
 trunc(
 months_between(
  trunc((snd)-1/86400, per)
  ,
  trunc((fst), per)
 )
 /(case when per IN ('SYYYY','YYYY','YEAR','SYEAR','YYY','YY','Y') then 12 else case when per = 'Q' then 3 else 1 end end)
 /(case when percnt = 0 then 1 else percnt end)
 )
 )
 else (
 trunc(
 (
  trunc((snd)-1/86400, per)
  -
  trunc((fst), per)
 )
 *(case when per IN ('HH','HH12','HH24') then 24 else case when per = 'MI' then 1440 else 1 end end)
 /(case when per IN ('DAY','DY','D') then 7 else 1 end)
 /(case when percnt = 0 then 1 else percnt end)
 )
 ) end
)
)
WHERE s IS NOT NULL AND f IS NOT NULL ORDER BY s) TT;
RETURN V_INTERVALS;
 
EXCEPTION
WHEN OTHERS THEN
V_INTERVALS.DELETE;
RETURN V_INTERVALS;
END;
/

