create trigger TRG_D_RATES_ID
    before insert
    on D_RATES
    for each row
BEGIN
                           IF INSERTING THEN
                              IF :NEW."ID_RATE" IS NULL THEN
                                 SELECT SEQ_D_RATES_ID.NEXTVAL INTO :NEW."ID_RATE" FROM DUAL;
                              END IF;
                           END IF;
                        END;

/

