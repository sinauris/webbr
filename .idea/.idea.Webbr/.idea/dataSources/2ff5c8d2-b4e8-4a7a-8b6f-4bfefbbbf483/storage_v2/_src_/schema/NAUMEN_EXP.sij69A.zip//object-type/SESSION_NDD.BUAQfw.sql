create Type SESSION_NDD As Object (
 ID Number,
 SESSION_ID VarChar2(50)
);
/

