create PACKAGE PKG_STRINGS AS
/*
----------------------------------------УТИЛИТЫ ДЛЯ РАБОТЫ СО СТРОКАМИ----------------------------------------

  FNC_STRTOTBL - преобразование строки разделенной разделителями в таблицу
  FNC_ELEMENT - получение элемента строки разделенной разделителями
  FNC_DISTINCT - удаление дублирующихся элементов строки разделенной разделителями
  FNC_TONUMBER - преобразование значения в число. Успешное преобразование выдает число, ошибка - пустое значение
*/

  /*Преобразование строки в таблицу по разделителю
  I_STRING - строка;
  I_DELIMITER - разделитель
  */ 
  TYPE PT_TBLROWS IS TABLE OF VARCHAR2(4000);
  FUNCTION FNC_STRTOTBL(I_STRING IN VARCHAR2, I_DELIMITER IN CHAR DEFAULT ',')
    RETURN PT_TBLROWS PIPELINED;
  FUNCTION FNC_STRTOTBL(I_STRING IN CLOB, I_DELIMITER IN CHAR DEFAULT ',')
    RETURN PT_TBLROWS PIPELINED;

  /*Получение элемента строки разделенной разделителем
  I_STRING - строка;
  I_OCCURENCE - вхождение;
  I_DELIMITER - разделитель
  */
  FUNCTION FNC_ELEMENT(I_STRING IN VARCHAR2, I_OCCURENCE IN NUMBER DEFAULT 1, I_DELIMITER IN CHAR DEFAULT ',')
    RETURN VARCHAR2;
  FUNCTION FNC_ELEMENT(I_STRING IN CLOB, I_OCCURENCE IN NUMBER DEFAULT 1, I_DELIMITER IN CHAR DEFAULT ',')
    RETURN VARCHAR2;

  /*Удаление дублей из строки
  I_STRING - строка;
  I_DELIMITER - разделитель
  */ 
  FUNCTION FNC_DISTINCT(I_STRING IN VARCHAR2, I_DELIMITER IN CHAR DEFAULT ',')
    RETURN VARCHAR2;    
  
  /*Преобразование в число
  I_STRING - строка
  */ 
  FUNCTION FNC_TONUMBER(I_STRING IN VARCHAR2)
    RETURN NUMBER;

  /*Получение из строки типа JSON таблицы формата ключ=значение*/
  FUNCTION FNC_JSON(I_JSON VARCHAR2) RETURN T_PARAMS;

END PKG_STRINGS;
/

