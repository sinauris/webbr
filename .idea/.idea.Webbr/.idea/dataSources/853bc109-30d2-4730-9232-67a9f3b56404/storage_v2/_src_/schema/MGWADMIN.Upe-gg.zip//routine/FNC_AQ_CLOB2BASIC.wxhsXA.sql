create FUNCTION                    fnc_AQ_CLOB2basic(AQCLOB IN MQ_ADAPTER.AQ_CLOB )
   RETURN sys.mgw_basic_msg_t 
   IS 
       v_CLOB  CLOB;
       v_basic  sys.mgw_basic_msg_t;
   BEGIN
       v_CLOB := AQCLOB.C_VALUE;
       V_BASIC :=  SYS.MGW_BASIC_MSG_T.CONSTRUCT;
       v_basic.text_body := sys.mgw_text_value_t(null, v_CLOB);
       v_basic.header := sys.mgw_name_value_array_t(sys.mgw_name_value_t.construct_integer('MGW_MQ_encoding', 273), sys.mgw_name_value_t.construct_integer('MGW_MQ_characterSet', 1208) );
       return v_basic;
   END FNC_AQ_CLOB2BASIC;
/

