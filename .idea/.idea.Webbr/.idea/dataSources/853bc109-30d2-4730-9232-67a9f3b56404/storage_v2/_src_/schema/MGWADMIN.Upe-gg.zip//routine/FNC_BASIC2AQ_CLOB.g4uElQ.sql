create FUNCTION                                     fnc_basic2AQ_CLOB(basic IN sys.mgw_basic_msg_t)
RETURN MQ_ADAPTER.AQ_CLOB 
IS 
  PRAGMA AUTONOMOUS_TRANSACTION; 
   v_CLOB  CLOB;
   v_AQ_CLOB  MQ_ADAPTER.AQ_CLOB;
BEGIN
  BEGIN
    NULL;
    -- INSERT INTO MGWADMIN.MSG_LOG(MSG_TIME, MSG)
    -- VALUES(SYSTIMESTAMP, BASIC);
    -- commit;
   EXCEPTION
     when others then null;
   end;
   v_CLOB := COALESCE(basic.text_body.large_value, basic.text_body.small_value);
   V_AQ_CLOB := MQ_ADAPTER.AQ_CLOB (V_CLOB);
 
   return v_AQ_CLOB;
END FNC_BASIC2AQ_CLOB;
/

